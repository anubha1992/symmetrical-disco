class Configuration
  attr_accessor :capybara_timeout, :app, :policy, :host_os, :git_branch, :headless,
                :raise_exception, :log_output, :log_level, :capybara, :browser, :test_env,
                :selenium_grid_url, :max_tries, :retry_sleep, :step_snapshot,
                :screenshot_path, :refresh_path, :min_retries, :session_vars, :error_to_report,
                :exception_whitelist, :validator_report, :store_to_mongo, :api_test_result, :test_result, :uw_rule_hard_issue_count

  def initialize
    @app                    = Object.const_get('PolicyCenter')
    @browser                = Rails.application.secrets.test_config[:browser].to_sym
    @test_env               = Rails.application.secrets.test_config[:environment].to_s
    @log_level              = Rails.application.secrets.test_config[:log_level].to_s
    @headless               = Rails.application.secrets.test_config[:headless].to_s
    @capybara_timeout       = 30
    @raise_exception        = true
    @max_tries              = 60
    @min_retries            = 10
    @retry_sleep            = 1
    @capybara               = nil
    @selenium_grid_url      = 'http://patchwork:4444/wd/hub'
    @refresh_path           = "#{Rails.root}/config/refresh.yml"
    @step_snapshot          = false
    @step_snapshot_path     = "#{Rails.root}/log/steps/#{Time.now.strftime('screenshot_%F_%H-%M-%S')}.png"
    @screenshot_path        = "#{Rails.root}/log/reports/#{Time.now.strftime('screenshot_%F_%H-%M-%S')}.png"
    @ws_template_path       = Rails.root.join('lib','templates')
    @ws_template_path_digital = Rails.root.join('lib','templates','digital')
    @ws_fixtures_path       = Rails.root.join('lib','prism','web_service','fixtures')
    @ws_template_path_ssc   = Rails.root.join('lib','templates','ssc')
    @session_vars           = {}
    @store_to_mongo         = {}
    @api_test_result        = {}
    @test_result            = {}
    @policy                 = nil
    @cuke_report_items      = []
    @validator_report       = []
    @exception_whitelist    = ['HTTP request failed: 500']
    $uw_rule_hard_issue_count = 0
    $regreporting_error_counter = 0
    $actual_value = " "
    $claimNumber = " "
  end

  def load_config
    Prism.logger.debug "Loading config..."
    @host_os  ||= find_host_os
    @settings = JSON.parse(YAML.ext_load_file("#{Rails.root.cleanpath}/config/settings/#{@test_env}.yml").to_json, object_class: OpenStruct)
  end

  def config_browser
    @capybara = init_capybara
    if browser == :ie && @host_os == :windows
      require 'win32/registry'
      disable_windows_authentication
      ie_protected_zones
    elsif browser == :ie && @host_os != :windows
      raise Error::WebDriverError, "Invalid operating system '#{@host_os}' to run Internet explorer"
    end
  end

  def find_host_os
    os_str = RbConfig::CONFIG['host_os']
    case os_str
      when /mswin|msys|mingw|cygwin|bccwin|wince|emc/
        :windows
      when /darwin|mac os/
        :macosx
      when /linux/
        :linux
      when /solaris|bsd/
        :unix
      else
        raise Error::WebDriverError, "unknown os: #{os_str.inspect}"
    end
  end

  def load_yaml_file(file_name)
    YAML.ext_load_file(File.open(file_name)).with_indifferent_access if File.exist?(file_name)
  end

  def init_capybara
    Watir.default_timeout = 90
    Capybara.register_driver browser do |app|
      client = Selenium::WebDriver::Remote::Http::Default.new
      client.open_timeout = 180 # Increase timeout instead of the default 60
      client.read_timeout = 180 # Increase timeout instead of the default 60

      if browser  == :chrome
        browser_options = ::Selenium::WebDriver::Chrome::Options.new.tap do |opts|
          opts.args << '--window-size=1920,1080'
          opts.args << '--force-device-scale-factor=0.95'
          if headless =~ /y/i
            opts.args << '--headless'
            opts.args << '--no-sandbox'
            opts.args << '--disable-gpu'
            opts.args << '--disable-site-isolation-trials'
          end
        end
        opts = {:browser => browser, :http_client => client, options: browser_options}
      elsif browser == :internet_explorer || browser == :ie
        opts.merge!(introduce_flakiness_by_ignoring_security_domains: true)
        opts.merge!(native_events: true)
      else
        opts = {:browser => browser, :http_client => client}
      end
      Capybara::Selenium::Driver.new(app, opts)
    end

    if browser == :chrome
      Prism.logger.info "Loading chromedriver..."
      driver_name = "chromedriver"
      driver_name = "chromedriver.exe" if @host_os == :windows
      Selenium::WebDriver::Chrome::Service.driver_path = File.join(Rails.root.to_path, 'lib', 'utils', driver_name)
    elsif browser == :firefox
        Prism.logger.info "Loading geckodriver..."
        driver_name = "geckodriver"
        driver_name = "geckodriver.exe" if @host_os == :windows
        Selenium::WebDriver::Firefox::Service.driver_path = File.join(Rails.root.to_path, 'lib', 'utils', driver_name)
    elsif browser == :internet_explorer || browser == :ie
      Prism.logger.info "Loading Internet Explorer..."
      driver_name = "IEDriverServer"
      driver_name = "IEDriverServer.exe" if @host_os == :windows
      Selenium::WebDriver::IE.driver_path = File.join(Rails.root.to_path, 'lib', 'utils', driver_name)
    end

    Capybara.javascript_driver = browser
    Capybara.default_driver = browser
    Capybara.current_driver = browser
    Capybara.default_max_wait_time = capybara_timeout
    Capybara.run_server = false
    Capybara
  end

  private

  def disable_windows_authentication
    Win32::Registry::HKEY_CURRENT_USER.open('Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\',
                                            Win32::Registry::KEY_WRITE) do |reg|
      reg.write('EnableNegotiate', Win32::Registry::REG_DWORD, 0)
    end
  end

  def ie_protected_zones
    (1..4).each do |zone|
      Win32::Registry::HKEY_CURRENT_USER.open("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\#{zone}\\",
                                              Win32::Registry::KEY_WRITE) do |reg|
        reg.write('2500', Win32::Registry::REG_DWORD, 0)
      end
    end
  end
end

