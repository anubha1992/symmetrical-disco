module Prism
  class UpdateQuoteMotor < Apigee

    attr_accessor :swagger, :swagger_public_id, :rest_response, :request_body_json, :ref_data, :rest_url, :token, :err_message, :payload, :request_body

    def initialize(ref_data)
      @request_body_json = Prism.session_vars[:request_body_json]
      @ref_data = ref_data
      @rest_url = Prism.settings.api_endpoints.digital.update_quote_motor.url
      @swagger = IO.read(Prism.ws_template_path_digital.join("create_update_quote_contract", "create_update_quote_contract_motor.json"))
      @swagger_public_id = IO.read(Prism.ws_template_path_digital.join("create_update_quote_contract", "create_update_quote_contract_motor_validate_public_id.json"))

    end

    def send_request
      begin
        @rest_url = Prism.settings.api_endpoints.digital.update_quote_motor.url
        quote_num=Prism.session_vars[:quote_number]
        @rest_url=@rest_url+quote_num.to_s
        @rest_response = RestClient::Request.execute(
            method: :put,
            url: @rest_url,
            headers: prepare_header_options,
            payload: @request_body_json,
            read_timeout: 120,
            open_timeout: 240,
            proxy: nil
        )
      rescue RestClient::ExceptionWithResponse => err
        if err.response["metadata"].present?
          Prism.session_vars[:response_422] = err.response
          Prism.logger.info "response 422: #{err.response}"
        #   if err.response["validation_messages"].present?
        #     err.response["validation_messages"].each_with_index do |msg, count|
        #       if msg["severity"] =~ /error/
        #         if !msg["description"] =~ /needs to be updated to an identified contact/
        #           err_count = err_count + 1
        #         end
        #       end
        #     end
        #   end
        else
          Prism.session_vars[:response_error] = err.response
          Prism.logger.info "Error: #{err.response}"
          if !@ref_data[:coverages_discounts].present?
            # if err_count > 0
            expect(err).to eq(200)
            # end
          end
        end
        # Prism.session_vars[:err_count] = err_count

      end
    end

    def send_request_vr
      begin
        @rest_url = Prism.settings.api_endpoints.digital.update_quote_motor.url
        quote_num=Prism.session_vars[:quote_number]
        @rest_url=@rest_url+quote_num.to_s
        @rest_response = RestClient::Request.execute(
            method: :put,
            url: @rest_url,
            headers: prepare_header_options,
            payload: @request_body_json,
            read_timeout: 120,
            open_timeout: 240,
            proxy: nil
        )
      rescue RestClient::ExceptionWithResponse => err
        if err.response["metadata"].present?
          Prism.session_vars[:response_422] = err.response
          Prism.logger.info "response 422: #{err.response}"
        end
        Prism.session_vars[:response_error] = err.response
        Prism.logger.info "Error : #{err.response}"
        # Prism.logger.info "Error Code: #{err.error_code}"
      end
    end


    def prepare_header_options
      header_options = {}
      header_options.merge!({"X-Iag-Auth-Consumer-System": send_token_request,
                             "X-Iag-Jurisdiction": "Iag_AU_ALL",
                             "X-Iag-Consumer-System": "test",
                             "X-Iag-Brand": "CGU",
                             "X-Iag-Channel": "digital",
                             "Authorization": "Basic c3U6Z3c=",
                             "Content-Type": "application/json",
                             "X-Iag-User-Profile": "test",
                             "X-Iag-User": "test",
                             "X-Iag-Session-Id": "test",
                             "X-Iag-Product": "Iag_PersonalMotor",
                             "X-Iag-Distributor": "test",
                             "X-Iag-Agent-Id": "test",
                             "X-Iag-Distribution-Channel": "test",
                             "X-Iag-Sales-Channel": "test",
                             "X-Iag-Auth-User": "test"
                            })
      header_options
    end

    ###This method is used to generate a token required as an header input for retrieving vehicle details using 'get' method
    def send_token_request
      @rest_response = RestClient::Request.execute(
          method: :post,
          url: Prism.settings.api_endpoints.token_generator.url,
          headers: {accept: :json, content_type: :json, authorization: "Basic R3VpZGV3aXJlX1BDOldnc0ZGd0dNZXo3RXA=", },
          payload: prepare_token_payload,
          read_timeout: 120,
          open_timeout: 240,
          proxy: nil
      )
      @token = @rest_response.body.split(':')[1].chop
      @token.tr('\"', '')
    end

    def prepare_token_payload
      if @ref_data[:token_payload].present?
        payload = JSON.parse(@ref_data[:token_payload])
      end
      payload.to_json
    end

    def is_response_valid
      ## Contract test and return array result
      ## If no error, return true or return array of validation errors
      validation_errors = JSON::Validator.fully_validate(swagger, rest_response, fragment: "#/definitions/QuoteResponse")
      validation_errors.any? ? validation_errors : true
    end

    def is_response_public_id_present
      ## Contract test and return array result
      ## If no error, return true or return array of validation errors
      validation_errors = JSON::Validator.fully_validate(swagger_public_id, rest_response, fragment: "#/definitions/QuoteResponse")
      validation_errors.any? ? validation_errors : true
    end

  end
end