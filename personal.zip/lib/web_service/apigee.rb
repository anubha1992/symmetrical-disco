require_relative 'rest_service'

module Prism
  class Apigee < RestService

    attr_accessor :base_config, :rest_response

    def initialize(args)
      prepare_config(args[:application])
    end

    private

    def get_auth_token
      response = RestClient::Request.execute(
        method: :post,
        url: base_config.auth_token.url,
        payload: {api_key: @base_config.auth_token.api_key, api_secret: @base_config.auth_token.api_secret, grant_type: @base_config.auth_token.grant_type},
        read_timeout: 120,
        open_timeout: 240,
        headers: {:accept => :json},
        proxy: "http://#{ENV['PROXY_USER']}:#{ENV['PROXY_PASS']}@proxy.auiag.corp:8080"
      )
      body = JSON.parse(response.body)
      body["access_token"]
    end

    def prepare_config(rest_application)
      @base_config = HashIt.new(Prism.settings.wsdl_endpoints.apigee.send(rest_application))
    end
  end
end