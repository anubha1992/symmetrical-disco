module Prism
  class AppLogin

    UsernamePassword = Struct.new(:username, :password)
    UsernamePasswordFields = Struct.new(:username_field, :password_field)

    def initialize(env)
      @env = env
    end

    def login(role, frame_id=nil)
      go_to_login_page
      user = Prism.settings.send(Prism.app.to_s.underscore).users.select{|user| user.role == role}
      user.first['username'] = ENV['TUSER_ID'] if ENV['TUSER_ID'].present?
      user.first['password'] = ENV['TUSER_PWD'] if ENV['TUSER_PWD'].present?
      unless role =~ /SSO/
        @page_populator = Prism.app::PagePopulator.new('Login', @ref_data)
        login_steps = {}
        login_steps[:username] = user.first['username']
        login_steps[:password] = user.first['password']
        login_steps[:login_button] = 'should_click'

        @page_populator.populate_page_with(login_steps)
      end
      wait_for_page_load
    end

    private

    def reset_browser_settings
      begin
        Prism.capybara.page.driver.reset!
      rescue Exception => e
        Prism.logger.info e.backtrace.join('')
      end
      handle_web_alert('dismiss')
    end

    def wait_for_page_load
      repeat_on_exception{page.evaluate_script('document.readyState') == 'complete' ? true: raise(RuntimeError, "document.readyState not 'complete'.")}
    end

    def go_to_login_page
      reset_browser_settings

      current_try = 0
      Prism.logger.info "Attempting to access url: #{Prism.capybara.app_host}"
      begin
        handle_web_alert{visit Prism.capybara.app_host}
        # Prism.logger.debug("Page Source :#{page.source}")
        # sometimes, only on Bamboo, it cant find the proxy server
        # hack to rescue this only if it happens on the login page for CC only
        if page.source.match /Unable to find the proxy server/
          Prism.logger.warn("Found the bad proxy text")
          fail "Bad proxy, retry"
        else
          #Prism.logger.debug("bad proxy text not found")
        end
      rescue => e
        if e.message.match /Bad proxy/
          page.reset_session!
          retry if (current_try+=1)<Prism.max_tries
        else
          Prism.logger.info("Didnt match the bad proxy in the exception catch - it was #{e.message} - rethrow")
          fail e
        end
      end

      wait_for_page_load
    end

    def fill_username_password(user, fields, frame_id=nil)
      if frame_id
        page.driver.within_frame(frame_id) do
          fill_in fields[:username_field], :with => user[:username]
          fill_in fields[:password_field], :with => user[:password]

          unless password_correct?(fields[:password_field], user[:password])
            fill_in fields[:password_field], :with => ""
            fill_in fields[:password_field], :with => user[:password]
          end
        end
      else
        fill_in fields[:username_field], :with => "#{user[:username]}\t"
        fill_in fields[:password_field], :with => "#{user[:password]}\t" if fields[:password_field].present?
        if fields[:password_field].present?
          unless password_correct?(fields[:password_field], user[:password])
            fill_in fields[:password_field], :with => ""
            fill_in fields[:password_field], :with => user[:password]
          end
        end
      end
    end

    def password_correct?(password_field, password)
      find(:xpath, "//input[@name='#{password_field}']").value == password
    end

    def not_logged_in?
      wait_for_page_load
      page.execute_script("return document.getElementsByName('username')").any?
    end

    def press_submit(login_button=nil, frame_id=nil)
      if frame_id
        page.driver.within_frame(frame_id) do
          login_button.present? ? find(login_button).click : page.execute_script('document.forms[0].submit()')
        end
      else
        login_button.present? ? find(login_button).click : page.execute_script('document.forms[0].submit()')
      end
      return true
    end

    def handle_web_alert(action='accept', &block)
      begin
        block.call if block
      rescue Selenium::WebDriver::Error::NoSuchAlertError => e
        Prism.logger.info 'No alert.'
        block.call if block
      rescue Selenium::WebDriver::Error::UnexpectedAlertOpenError => e
        Prism.logger.info 'An unhandled alert.'
        Prism.capybara.page.driver.browser.switch_to.alert.send(action)
        block.call if block
      end
    end

    def repeat_on_exception(timeout=20, sleep_time=1, raise_exception=Prism.raise_exception, &block)
      start_time = Time.now
      rval = nil
      begin
        rval = block.call
      rescue => e
        Prism.logger.info "repeat on:#{block.to_s}, current time: #{Time.now}"
        if Time.now > (start_time + timeout) && raise_exception
          raise_exception.present? ? abort(e.to_s) : abort(raise_exception)
        end
        sleep sleep_time
        retry
      end
      rval
    end

  end
end
