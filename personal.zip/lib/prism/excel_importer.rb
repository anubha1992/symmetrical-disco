module Prism
  class ExcelImporter
    attr_accessor :file_name, :model_name, :nested_columns, :excel_parser, :reference_column

    def initialize(*args)
      @file_name, @model_name, @nested_columns, @reference_column = args
      @reference_column = 'scenario_id' unless @reference_column.present?
      Prism.logger.info "Reading from: #{excel_path}, Reference column: #{@reference_column}"
      @excel_parser = SpreadsheetHelper::Parser.new(excel_path)
    end

    def import_scenarios
      hashes_from_sheet1 = excel_to_hash
      ## Excel sheet name should match the field name in the general sheet section
      @excel_parser.xls.sheets.delete('change_control')
      worksheets = @excel_parser.xls.sheets
      worksheets.drop(1).each do |nested_column|
        nested_hashes = excel_to_hash(nested_column)
        hashes_from_sheet1 = hashes_from_sheet1.inject([]) {|memo, obj| memo << build_nested_hash(nested_column, obj, nested_hashes)}
      end

      hashes_from_sheet1.each_with_index do |scenario_hash, index|
        Prism.logger.debug "Index: #{index}, #{scenario_hash['scenario_id']}"
        if scenario_hash['add_vehicles'].present? && scenario_hash['add_drivers'].present?
          Prism.logger.debug "Restructure scenario for vehicle-driver and store to DB"
          Prism.logger.debug "Vehicle info before re-structure -> #{scenario_hash['add_vehicles']}"
          create_or_replace(model_name, [build_vehicle_driver(scenario_hash)])
        else
          Prism.logger.debug "No vehicle-driver. Store to DB without restructure"
          create_or_replace(model_name, [scenario_hash])
        end

        if scenario_hash['add_properties'].present? && scenario_hash['add_properties_information'].present?
          Prism.logger.debug "Restructure scenario for property-property information and store to DB"
          Prism.logger.debug "Property info before re-structure -> #{scenario_hash['add_properties']}"
          create_or_replace(model_name, [build_property_to_property_information(scenario_hash)])
        else
          Prism.logger.debug "No property-property information. Store to DB without restructure"
          create_or_replace(model_name, [scenario_hash])
        end

        if scenario_hash['add_vehicles'].present? && scenario_hash['add_coverages'].present?
          Prism.logger.debug "Restructure scenario for vehicle-cover_type and store to DB"
          Prism.logger.debug "Vehicle info before re-structure -> #{scenario_hash['add_vehicles']}"
          create_or_replace(model_name, [build_vehicle_cover_type(scenario_hash)])
        else
          Prism.logger.debug "No vehicle-cover_type. Store to DB without restructure"
          create_or_replace(model_name, [scenario_hash])
        end

        if scenario_hash['add_properties'].present? && scenario_hash['add_coverages'].present?
          Prism.logger.debug "Restructure scenario for property-cover_type and store to DB"
          Prism.logger.debug "Property info before re-structure -> #{scenario_hash['add_properties']}"
          create_or_replace(model_name, [build_property_cover_type(scenario_hash)])
        else
          Prism.logger.debug "No property-cover_type. Store to DB without restructure"
          create_or_replace(model_name, [scenario_hash])
        end
      end
    end

    def excel_to_hash(sheet_identifier = 0)
      Prism.logger.debug "Excel to hash: Sheet #{sheet_identifier}"
      SpreadsheetHelper::Parser.new(excel_path, sheet_identifier).to_hash do |row|
        transform_row(row)
      end
    end

    def build_vehicle_driver(scenario)
      scenario['add_vehicles'] = [scenario['add_vehicles']].flatten
      scenario['add_drivers'] = [scenario['add_drivers']].flatten
      no_of_vehicles = scenario['add_vehicles'].count
      if scenario['add_vehicles'].count == 1
        ## only one vehicle
        Prism.logger.debug "only one vehicle.."
        scenario['add_vehicles'][0]['add_drivers'] = [scenario['add_drivers']].flatten
      elsif scenario['link_vehicle_driver'].present?
        ## Vehicle to driver mapping available
        Prism.logger.debug "Vehicle to driver mapping available.."
        scenario['link_vehicle_driver'].each do |vehicle_driver_info|
          Prism.logger.debug "Vehicle to driver mapping -> vehicle_driver_info"
          vehicle_number, driver_numbers = vehicle_driver_info.split("-")
          vehicle_index = vehicle_number.to_i-1
          scenario['add_vehicles'][vehicle_index]['add_drivers'] = []
          driver_numbers.split(",").each do |driver_number|
            if scenario['add_vehicles'][vehicle_index].present?
              scenario['add_vehicles'][vehicle_index]['add_drivers'] << scenario['add_drivers'][driver_number.to_i-1]
              Prism.logger.debug "Add driver '#{driver_number}' to vehicle '#{vehicle_index}'"
            else
              raise "Invalid vehicle index: #{vehicle_index} in link_vehicle_driver column (#{scenario['link_vehicle_driver']}) for scenario #{scenario['scenario_id']}"
            end
            Prism.logger.debug "Present vehicle status -> #{scenario['add_vehicles']}"
          end
        end
      else
        ## multiple vehicles
        Prism.logger.debug "Multiple vehicles -> But no driver mapping available.."
        scenario['add_drivers'].each_with_index do |driver, index|
          if scenario['add_vehicles'][index].present?
            scenario['add_vehicles'][index]['add_drivers'] = [driver].flatten
          else
            scenario['add_vehicles'][no_of_vehicles-1]['add_drivers'] << driver
          end
        end
      end
      Prism.logger.debug "#{scenario['scenario_id']} -> #{scenario['add_vehicles']}"
      scenario.delete('add_drivers') if scenario['add_drivers'].present?
      scenario
    end

    def build_property_to_property_information(scenario)
      scenario['add_properties'] = [scenario['add_properties']].flatten
      scenario['add_properties_information'] = [scenario['add_properties_information']].flatten
      no_of_properties = scenario['add_properties'].count
      if scenario['add_properties'].count == 1
        ## only one Property
        Prism.logger.debug "only one property.."
        scenario['add_properties'][0]['add_properties_information'] = [scenario['add_properties_information']].flatten
      elsif scenario['link_property_to_property_info'].present?
        ## Property to property info mapping available
        Prism.logger.debug "Property to property information mapping available.."
        scenario['link_property_to_property_info'].each do |property_info|
          Prism.logger.debug "Property to property information mapping -> property_info"
          property_number, property_info_numbers = property_info.split("-")
          property_index = property_number.to_i-1
          scenario['add_properties'][property_index]['add_properties_information'] = []
          property_info_numbers.split(",").each do |property_info_number|
            if scenario['add_properties'][property_index].present?
              scenario['add_properties'][property_index]['add_properties_information'] << scenario['add_properties_information'][property_info_number.to_i-1]
              Prism.logger.debug "Add property information '#{property_info_number}' to property '#{property_index}'"
            else
              raise "Invalid property index: #{property_index} in link_property_to_property_info column (#{scenario['link_property_to_property_info']}) for scenario #{scenario['scenario_id']}"
            end
            Prism.logger.debug "Present property status -> #{scenario['add_properties']}"
          end
        end
      else
        ## multiple properties
        Prism.logger.debug "Multiple properties -> But no property information mapping available.."
        scenario['add_properties_information'].each_with_index do |property_info, index|
          if scenario['add_properties'][index].present?
            scenario['add_properties'][index]['add_properties_information'] = [property_info].flatten
          else
            scenario['add_properties'][no_of_properties-1]['add_properties_information'] << property_info
          end
        end
      end
      Prism.logger.debug "#{scenario['scenario_id']} -> #{scenario['add_properties']}"
      scenario.delete('add_properties_information') if scenario['add_properties_information'].present?
      scenario
    end

    def build_vehicle_cover_type(scenario)
      scenario['add_vehicles'] = [scenario['add_vehicles']].flatten
      scenario['add_coverages'] = [scenario['add_coverages']].flatten
      no_of_vehicles = scenario['add_vehicles'].count
      if scenario['add_vehicles'].count == 1
        ## only one vehicle
        Prism.logger.debug "only one vehicle.."
        scenario['add_vehicles'][0]['add_coverages'] = [scenario['add_coverages']].flatten
      elsif scenario['link_vehicle_cover_type'].present?
        ## Vehicle to cover_type mapping available
        Prism.logger.debug "Vehicle to cover_type mapping available.."
        scenario['link_vehicle_cover_type'].each do |vehicle_covertype_info|
          Prism.logger.debug "Vehicle to cover type mapping -> vehicle_covertype_info"
          vehicle_number, cover_type_numbers = vehicle_covertype_info.split("-")
          vehicle_index = vehicle_number.to_i-1
          scenario['add_vehicles'][vehicle_index]['add_coverages'] = []
          if scenario['add_vehicles'][vehicle_index].present?
            scenario['add_vehicles'][vehicle_index]['add_coverages'] << scenario['add_coverages'][cover_type_numbers.to_i-1]
            Prism.logger.debug "Add cover type '#{cover_type_numbers}' to vehicle '#{vehicle_index}'"
          else
            raise "Invalid vehicle index: #{vehicle_index} in link_vehicle_cover_type column (#{scenario['link_vehicle_cover_type']}) for scenario #{scenario['scenario_id']}"
          end
          Prism.logger.debug "Present vehicle status -> #{scenario['add_vehicles']}"
        end
      else
        ## multiple vehicles
        Prism.logger.debug "Multiple vehicles -> But no cover_type mapping available.."
        scenario['add_coverages'].each_with_index do |coverage, index|
          if scenario['add_vehicles'][index].present?
            scenario['add_vehicles'][index]['add_coverages'] = [coverage].flatten
          else
            scenario['add_vehicles'][no_of_vehicles-1]['add_coverages'] << coverage
          end
        end
      end
      Prism.logger.debug "#{scenario['scenario_id']} -> #{scenario['add_vehicles']}"
      scenario.delete('add_coverages') if scenario['add_coverages'].present?
      scenario
    end

    def build_property_cover_type(scenario)
      scenario['add_properties'] = [scenario['add_properties']].flatten
      if scenario['valuable_contents'].present?
      scenario['add_coverages'] = contents_over_10k(scenario['add_coverages'],scenario,"valuable")
      end
      if scenario['portable_contents'].present?
        scenario['add_coverages'] = contents_over_10k(scenario['add_coverages'], scenario, "portable")
      end
      scenario['add_coverages'] = [scenario['add_coverages']].flatten
      no_of_properties = scenario['add_properties'].count
      if scenario['add_properties'].count == 1
        ## only one property
        Prism.logger.debug "only one property.."
        scenario['add_properties'][0]['add_coverages'] = [scenario['add_coverages']].flatten
      elsif scenario['link_property_cover_type'].present?
        ## Property to cover_type mapping available
        Prism.logger.debug "Property to cover_type mapping available.."
        scenario['link_property_cover_type'].each do |property_covertype_info|
          Prism.logger.debug "Property to cover type mapping -> property_covertype_info"
          property_number, cover_type_numbers = property_covertype_info.split("-")
          property_index = property_number.to_i-1
          scenario['add_properties'][property_index]['add_coverages'] = []
          cover_type_numbers.split(",").each do |cover_type_number|
            if scenario['add_properties'][property_index].present?
              scenario['add_properties'][property_index]['add_coverages'] << scenario['add_coverages'][cover_type_number.to_i-1]
              Prism.logger.debug "Add cover type '#{cover_type_number}' to property '#{property_index}'"
            else
              raise "Invalid property index: #{property_index} in link_property_cover_type column (#{scenario['link_property_cover_type']}) for scenario #{scenario['scenario_id']}"
            end
          end
          Prism.logger.debug "Present property status -> #{scenario['add_properties']}"
        end
      else
        ## multiple properties
        Prism.logger.debug "Multiple properties -> But no cover_type mapping available.."
        scenario['add_coverages'].each_with_index do |coverage, index|
          if scenario['add_properties'][index].present?
            scenario['add_properties'][index]['add_coverages'] = [property].flatten
          else
            scenario['add_properties'][no_of_properties-1]['add_coverages'] << coverage
          end
        end
      end
      Prism.logger.debug "#{scenario['scenario_id']} -> #{scenario['add_properties']}"
      scenario.delete('add_coverages') if scenario['add_coverages'].present?
      scenario
    end

    def contents_over_10k(coverage, scenario,type)
      Prism.logger.debug "#{scenario['scenario_id']} -> #{coverage}"
      if coverage[0]["#{type}_contents"]["individual_#{type}s_over_10k"] == "Yes" && scenario["#{type}_contents"].present?
        coverage[0]["#{type}_contents"]["#{type}s_over_10k"] = []
        coverage[0]["#{type}_contents"]["#{type}s_over_10k"] = scenario["#{type}_contents"]
        Prism.logger.debug "Present coverage status -> #{coverage}"
      end
      scenario.delete("#{type}_contents") if scenario["#{type}_contents"].present?
      coverage
    end

    def transform_row(row)
      row.compact
      row.inject({}) do |memo, element|
        if element.first.include?('.')
          split_keys = element.first.split('.')
          memo[split_keys.first] = {} unless memo[split_keys.first].present?
          memo[split_keys.first].merge!({split_keys.last => cc_formatter(element.last)})
        else
          memo[element.first] = cc_formatter(element.last)
        end
        memo
      end.to_h
    end

    def excel_to_json(sheet_identifier)
      merged_array = []
      SpreadsheetHelper::Parser.new(excel_path, sheet_identifier).each_row do |row|
        row.each do |incident|
          merged_array << JSON.load(incident)
        end
      end
      merged_array
    end

    def build_nested_hash(column_name, hash1, hashes2)
      Hash[hash1.map do |k, v|
        if k == column_name
          k = column_name, v = get_nested_hash(v, hashes2)
        else
          k = k, v
        end
      end]
    end

    def nested_hash_by_reference_column(ref_col, hashes2, claim_number)
      incidents = hashes2.find_all {|hashes_select| hashes_select[ref_col] == claim_number}
      if !incidents.blank?
        incidents.each do |each_incident|
          each_incident.except!(ref_col)
        end
        incidents #once the claim number column has been dropped from each incident within the array, return the array of incidents
      end
    end

    def excel_path
      "#{Rails.root}/lib/utils/excel_import/#{file_name}"
    end

    private

    def create_or_replace(model_name, hashes)
      if @run_type == 'rpa'
        model_klass = ClaimsAssistant.const_get((@model_name))
      else
        model_klass = Prism.const_get((@model_name))
      end
      ## Create or replace, don't update
      hashes.each do |item|
        if item['scenario_id'].present?
          criteria = {scenario_id: item['scenario_id']}
          item['git_branch'].present? ? criteria.merge!({git_branch: item['git_branch']}) : criteria.merge!({git_branch: {'$exists': false}})
          item['environment'].present? ? criteria.merge!({environment: item['environment']}) : criteria.merge!({environment: {'$exists': false}})
          existing_record = model_klass.where(criteria)

          if existing_record.exists?
            Prism.logger.info "Found existing record for scenario: #{item['scenario_id']}. Performing delete and re-load"
            existing_record.delete
            model_klass.create!(item)
          else
            Prism.logger.info "Importing new scenario: #{item['scenario_id']}"
            model_klass.create!(item)
          end
        else
          Prism.logger.info "Importing row: #{item}"
          model_klass.create!(item)
        end
      end
    end

    # Get nested hashes from the sheet based on the identifiers (name or index)
    def get_nested_hash(v, hashes2)
      v.split(',').inject([]) {|memo, index| memo << hashes2[index.to_i - 2]}
    end

    def cc_formatter(value)
      case value
        when Date
          value.to_time.strftime('%d/%m/%Y')
        when /\|/ # Convert to Array
          value.split('|').map(&:strip)
        when /=>/ # Convert to Hash
          [value.split('=>').map(&:strip)].to_h
        else
          value.to_s
      end
    end
  end
end
