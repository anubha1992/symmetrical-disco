module Prism
  class ValidateXml
    attr_accessor :document, :schema

    def initialize(document_or_path, schema_path)
      read_document(document_or_path)
      read_schema(schema_path)
    end

    def validate
      @schema.validate(@document)
    end

    def valid?
      @schema.valid?(@document)
    end

    private

    def read_schema(schema_path)
      @schema = Nokogiri::XML::Schema(File.read(schema_path))
    end

    private
    def read_document(document_or_path)
      if document_or_path.is_a?(Nokogiri::XML::Document)
        @document = document_or_path
      else
        @document = Nokogiri::XML(File.read(document_or_path))
      end
    end
  end
end
