module Prism
  class WebTable
    include Capybara::DSL

    attr_accessor :page_obj, :table, :table_element, :properties, :found_row

    def initialize(page_obj, identifier)
      @page_obj = page_obj
      identifier = identifier.parameterize.underscore
      @table = page_obj.public_send("#{identifier}_table")
      @table_element = page_obj.public_send("#{identifier}_table_element")
      @properties = page_obj.public_send("#{identifier}_properties")
    end

    def row_count
      table_element.count
    end

    def each_row
      (0..row_count-2).each do |index|
        yield(properties[index])
      end
    end

    def find_row_by_property_text(target_property_name, text)
      each_row do |indexed_property|
        if indexed_property.public_send(target_property_name.parameterize.underscore) == text
          @found_row = indexed_property
          break
        end
      end
      self
    end
  end
end
