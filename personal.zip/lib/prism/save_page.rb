module Prism
  class SavePage

    attr_reader :path

    def initialize(path="#{Rails.root}/log/reports/%s.html")
      @path = path
    end

    def save_page(page_path=Prism.save_page_path)
      save page_path
    end

    private

    def save(file_path=nil)
      page_path = file_path || path
      
      # check if screenshot_path has a %s escape in it - if so populate with timestamp
      if page_path.match(/%s/)
        page_path = sprintf(page_path, Time.now.strftime('saved_page_%F_%H-%M-%S'))
      end

      begin
        Prism.capybara.page.save_page page_path
      rescue Exception => e       
        Prism.logger.info "An error has occurred with saving page: #{e}"
      end
    end
  end
end
