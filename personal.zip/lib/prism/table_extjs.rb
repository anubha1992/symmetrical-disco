module Prism
  class TableExtjs

    attr_accessor :number_of_rows, :id, :element

    def wait_row_load(page_obj, element)
      wait_retry("Failed to find the row with page obj: #{page_obj}, element: #{element}", Prism.min_retries, @raise_exception) do
        id = get_element_id(page_obj, element)
        script = %|
          var comp = Ext.getCmp("#{id}");
          rows = comp.view.dataSource.data.items;
          return rows.length;
        |
        Prism.capybara.page.execute_script(script).to_i
      end
    end

    def initialize(page_obj, element, raise_exception=true)
      if page_obj.is_a?(String)
        @page_obj = get_page_obj(page_obj)
      else page_obj.is_a?(Object)
        @page_obj = page_obj
      end

      page_element_exist?(@page_obj, element, Prism.min_retries, raise_exception)
      @page          = Prism.capybara.page
      @id            = get_element_id(@page_obj, element)
      @raise_exception = raise_exception
      @number_of_rows = wait_row_load(@page_obj, element)
      @element       = element
      @html_entities = HTMLEntities.new
    end

    def get_titles(remove_nb_space=true)
      page_element_exist?(@page_obj, @element)
      # Remove non-breaking space: &#160; is the numeric reference for the entity reference &nbsp;
      if remove_nb_space
        columns(@id).delete_if { |item| item == "&#160;" }
      else
        columns(@id)
      end
    end

    def each_row_with_index
      return if number_of_rows == 0
      loop do
        current_row = 0
        page_element_exist?(@page_obj, @element)
        while current_row < row_length
          Prism.logger.debug("each_row_with_index(): current_row = #{current_row}")
          click_row(current_row)
          yield(row_data(current_row), current_row)
          current_row += 1
        end
        break unless next_page?
      end
    end

    def get_document_table_row_panel_values(table_fields, panel_fields)
      self.inject([]) do |array, row|
        t_fields = get_document_table_row_values(table_fields, row)
        p_fields = get_panel_values(panel_fields, @page_obj)
        row_panel_values = t_fields.merge(p_fields)
        Prism.logger.info "extract row panel values: #{row_panel_values}"
        array << row_panel_values
        array
      end
    end

    def get_document_table_row_values(table_fields, row)
      hash = {}
      get_titles(remove_nb_space=false).each_with_index do |t, i|
        # table_fields.each_with_index do |t, i|
        val = @html_entities.decode(row[i])
        value = is_number?(val) ? format_num(val) : val
        hash.store(to_symbol(t), value)
      end
      std_fields = table_fields.map{|f| to_symbol(f)}
      value = hash.select{|k,_v| std_fields.member?(k)}
      Prism.logger.info "extract row values: #{value}"
      value.with_indifferent_access
    end

    # def each
    #   table_data.each do |each_row_data|
    #     yield(each_row_data)
    #   end
    # end

    # current_row reset in the outer loop doens't get passed to the method that's
    # calling it which results in current_row keeping incrementing.
    # each_row_with_index() method is doing pagination properly by passing the
    # resetted index.
    # Paginiation may not work with the each_with_index.
    def each
      loop do
        current_row = 0
        page_element_exist?(@page_obj, @element)
        while current_row < row_length
          click_row(current_row)
          #TODO hack
          sleep 2
          yield(row_data(current_row))
          current_row += 1
        end
        break unless next_page?
      end
    end
    alias :each_row :each

    def get_row_panel_values(table_fields, panel_fields)
      self.inject([]) do |array, row|
        t_fields = get_row_values(table_fields, row)
        p_fields = get_panel_values(panel_fields, @page_obj)
        row_panel_values = t_fields.merge(p_fields)
        Prism.logger.info "extract row panel values: #{row_panel_values}"
        array << row_panel_values
        array
      end
    end

    def get_contact_values(table_fields, panel_fields)
      self.inject([]) do |array, row|
        t_fields = get_row_values(table_fields, row)
        p_fields = get_contact_panel_values(panel_fields, @page_obj)
        contact_type = get_contact_type(@page_obj)
        Prism.logger.info "extract contact values: #{t_fields}"
        array << t_fields.merge(p_fields).merge(contact_type)
        array
      end
    end

    def get_contact_type(page_obj)
      person_label = extract_value(page_obj, 'person_label')
      ipd_person = extract_value(page_obj, 'ipd_person')
      is_organisation(person_label, ipd_person) ? {'contact_type' => 'organisation'} : {'contact_type' => 'person'}
    end

    def is_organisation(person_label, ipd_person)
      person_label == '' && ipd_person == ''
    end

    def get_row_values(table_fields, row)
      hash = {}
      get_titles.each_with_index do |t, i|
      # table_fields.each_with_index do |t, i|
        val = @html_entities.decode(row[i])
        value = is_number?(val) ? format_num(val) : val
        hash.store(to_symbol(t), value)
      end
      std_fields = table_fields.map{|f| to_symbol(f)}
      value = hash.select{|k,_v| std_fields.member?(k)}
      Prism.logger.info "extract row values: #{value}"
      value.with_indifferent_access
    end

    def get_contact_panel_values(panel_fields, page_obj)
      return {} if panel_fields.nil?
      #TODO hack
      sleep 1
      panel_fields.inject({}) do |hash, field|
        panel_value = field == 'registered_for_gst' ? contact_registered_for_gst(field) : extract_value(page_obj, field)
        key         = to_symbol(field)
        val         = @html_entities.decode(panel_value)
        value       = is_number?(val) ? format_num(val) : val
        Prism.logger.info "extract: {#{key}: '#{value}'}"
        hash.store(key, value)
        hash
      end
    end

    def contact_registered_for_gst(field)
      diff_contacts = ['contact_organisation', 'contact_other', 'contact_person', 'contact_service_provider']
      diff_contacts.map{|screen_title|extract_value(get_page_obj(screen_title), field)}.inject(''){|string, ans| string = ans if !ans.empty?;string}
    end

    def get_panel_values(panel_fields, page_obj)
      return {} if panel_fields.nil?
      #TODO hack
      sleep 1
      panel_fields.inject({}) do |hash, field|
        panel_value = extract_value(page_obj, field)
        key         = to_symbol(field)
        val         = @html_entities.decode(panel_value)
        value       = is_number?(val) ? format_num(val) : val
        Prism.logger.info "extract: {#{key}: '#{value}'}"
        hash.store(key, value)
        hash
      end
    end

    def table_data
      table = []
      row_length.times{|row| table.push(row_data(row))}
      table
    end

    def click_checkbox(row_num, parent_element_id=nil)
      if parent_element_id
        js_trs = %| var div = document.getElementById('#{parent_element_id}').getElementsByClassName('x-grid-view x-fit-item x-grid-view-default')[0];
                  var trs = div.getElementsByTagName('tr');|
        js_trs_length = js_trs + 'return trs.length;'
      else
        js_trs = %| var div = document.getElementsByClassName('x-grid-view x-fit-item x-grid-view-default')[0];
                  var trs = div.getElementsByTagName('tr');|
        js_trs_length = js_trs + 'return trs.length;'
      end

      Prism.logger.debug("Select row with index: #{row_num} out of #{@page.execute_script(js_trs_length)} rows")
      js_checkbox_img = js_trs + "return trs[#{row_num}].getElementsByTagName('img');"
      js_checkbox_status = js_trs + "return trs[#{row_num}].getElementsByTagName('img')[0].className;"
      js_click_checkbox = js_trs + "trs[#{row_num}].getElementsByTagName('img')[0].click();"

      if @page.execute_script(js_checkbox_img).present? && @page.execute_script(js_checkbox_status) !~ /x-grid-checkcolumn-checked/
        @page.execute_script(js_click_checkbox)
      else
        Prism.logger.debug("No checkbox available for row with index: #{row_num}")
      end
    end

    def tick(row_num=0, parent_element_id=nil)
      if parent_element_id
        script = %| array = document.getElementById('#{parent_element_id}').getElementsByClassName('x-grid-checkcolumn'); array[#{row_num}].click(); |
      else
        script = %| array = document.getElementsByClassName('x-grid-checkcolumn'); array[#{row_num}].click(); |
      end
      @page.execute_script(script)
    end

    def click_elements_by_classname(child_class)
      script = %|
      var doc = document.getElementById("#{@id}");
      var array = doc.getElementsByClassName("#{child_class}");
      [].forEach.call(array, function (element) { element.click() })
      |
      @page.execute_script(script)
    end

    def move_first
      script = %|
        var comp = Ext.getCmp(Ext.getCmp("#{@id}").gwPagingId);
        return comp.ownerCt.moveFirst();
      |
      Prism.logger.debug("Going to first page within the table")
      @page.execute_script(script)
    end

    def has_multiple_pages?
      script = %|
        var comp = Ext.getCmp("#{@id}");
        return comp.gwPagingId;
      |
      Prism.logger.debug("Checking if table has multiple pages")
      @page.execute_script(script)
    end

    def next_page?
      script = %|
        var comp = Ext.getCmp(Ext.getCmp("#{@id}").gwPagingId);
        //(typeof(comp.ownerCt) !== 'undefined') ? return comp.ownerCt.moveNext(); : return false;
        return comp.ownerCt.moveNext();
      |
      begin
        Prism.logger.debug("Going to next page within the table")
        @page.execute_script(script).tap { |_| ExtjsHandler.new.wait_for_ajax }
      rescue Exception => e
        Prism.logger.debug("Exception ocurred when try to go to next page within the table")
        Prism.logger.debug(e)
        false
      end
    end

    def extract_value(page_obj, field)
      begin
        page_element_exist?(page_obj, field, 1)
        element_text(page_obj, field)
      rescue => e
        Prism.logger.info "'#{field}' field value not found setting as empty string. Exception: #{e}"
        ''
      end
    end

    def click_row(num)
      script = %|
        var comp = Ext.getCmp("#{@id}");
        comp.getSelectionModel().select(#{num});
      |
      @page.execute_script(script).tap{ |_| ExtjsHandler.new.wait_for_ajax }
    end

    def columns(id=nil)
      script = %|
        var array = [];
        Ext.each(Ext.getCmp("#{@id}").columns, function(i){
              array.push(i.text);
        });
        return array;
      |
      @page.execute_script(script)
    end

    def data_indexed_columns(id=nil)
      script = %|
        var array = [];
        Ext.each(Ext.getCmp("#{@id}").columns, function(i){
          if (i.text != "&#160;") {array.push(i.dataIndex);}
        });
        return array;
      |
      @page.execute_script(script)
    end

    def row_length
      script = %|
        var comp = Ext.getCmp("#{@id}");
        rows = comp.view.dataSource.data.items;
        return rows.length;
      |
      begin
        @page.execute_script(script)
      rescue Exception => e
        @raise_exception ? raise(e) : 0
      end
    end

    def row_data(row)
      array = []
      begin
        data_indexed_columns(@id).each_with_index {|column_name,index| array.push(cell_data(row, index, column_name))}
        array
      rescue
        Prism.logger.info "row_data error"
        array
      end
    end

    def row_hash(row)
      Hash[get_titles.zip(row)]
    end

    def cell_data(row, index, column_name=nil)
      script = %|
        var comp = Ext.getCmp("#{@id}");
        var rows = comp.view.dataSource.data.items;
        var columns = rows['#{row}'].raw
        if (columns.hasOwnProperty('c#{index}')) {
          return columns.c#{index};
        } else if (columns.hasOwnProperty('#{column_name}')) {
          return columns['#{column_name}'];
        } else {
          return ''
        }
      |
      cell_data_text(@page.execute_script(script))
    end

    def cell_data_text(data)
      if data.is_a?(Array)
        data.first['text']
      elsif data.is_a?(Hash)
        data['items'].is_a?(Array) ? data['items'].first['text'] : data['text']
      else
        data
      end
    end

  end
end
