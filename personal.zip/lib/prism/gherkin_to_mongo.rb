module Prism
  class GherkinToMongo

    attr_accessor :gherkin_criteria

    def initialize(gherkin_criteria)
      @gherkin_criteria = gherkin_criteria
    end

    def mongofy
      nested_doc_query = {}
      Hash[gherkin_criteria.map do |key, value|
        value =~ gherkin_operator_regex
        if $1 && $2
          value = { mongo_operator($1) => $2.is_number? ? $2.to_f : $2 }
          value = value if value.present?
        else
          value = value
          value = /#{value}/i if value.present?
        end
        if key.include?('.') # If it's a nested doc query
          key, value, nested_doc_query = build_nested_doc_query(key, value, nested_doc_query)
        end
        [key, value]
      end].tap { |c| Prism.logger.debug("Mongofied criteria: #{c}") }
    end

    # Example: { contacts: { "$elemMatch" => { roles: /Service Provider/i, registered_for_gst: 'No' } } }
    def build_nested_doc_query(key, mongofied_value, nested_doc_query)
      mongofied_key, nested_query_key = key.split('.')
      # A new nested doc query, clear the previous query
      nested_doc_query = {} unless nested_doc_query.keys.include?(mongofied_key)
      mongofied_value = build_nested_doc_query_value(nested_query_key, mongofied_value)
      nested_doc_query.deep_merge!({ mongofied_key => mongofied_value })
      mongofied_value = nested_doc_query.values.first
      [mongofied_key, mongofied_value, nested_doc_query]
    end

    # Example: { "$elemMatch" => { roles: /Service Provider/i } }
    def build_nested_doc_query_value(key, value)
      { '$elemMatch' => { key => value } }
    end

    def gherkin_operator_regex
      /(>=|<=|>|<|size|not)\s*(.*)/
    end

    def mongo_operator(key)
      { '>=' => 'gte', '<=' => 'lte', '>' => '$gt', '<' => '$lt', 'not' => '$ne', 'size' => '$size' }[key.to_s]
    end

  end
end