module Prism
  module PageHandler

    def set_current_page(page)
      if page.is_a?(String)
        @page_obj = get_page_obj(page)
      elsif page.is_a?(Object)
        @page_obj = page
      else
        raise(RuntimeError, 'Cannot initialize a valid page object')
      end
    end

    def get_page_obj(screen_title)
      Prism.logger.debug("Getting page object for #{screen_title}.")
      class_name  = to_symbol(screen_title).to_s.camelize
      get_app_name.const_get("#{class_name}").new(Prism.capybara.page.driver.browser)
    end

    ##
    # Returns the current application name
    # Usually translates to the application class or module object
    # Ex: ClaimCenter or Opus or ORM etc..
    def get_app_name
      Prism.app
    end

    def re_get_page_obj(page_obj)
      page_obj.class.new(Prism.capybara.page.driver.browser)
    end

    def wait_retry(error_msg=nil, count=Prism.max_tries, raise_exception=true, &block)
      wait_till_page_load
      begin
        block.call
      rescue => e
        Prism.error_to_report = e
        Prism.logger.info "#{error_msg} (#{e}) (Retry countdown: #{count})"
        sleep Prism.retry_sleep
        retry unless (count -= 1).zero? || e.message == 'Element is read-only and so may not be used for actions'
        raise_exception ? handle_exception(e) : nil
      end
    end

    def wait_till_page_load
      #Prism.logger.debug "wait till page load"
      counter = 0
      while page_still_loading? && counter < Prism.max_tries
        sleep 1
        counter += 1
        Prism.logger.info "waiting for page load...retry: #{counter}"
      end
    end

    def page_still_loading?
      begin
        document_state = Prism.capybara.page.execute_script('return document.readyState')
        document_state != 'complete' || ajax_in_progress?
      rescue Exception => e
        handle_exception(e)
      end
    end

    def ajax_in_progress?
      ## should return true if false if page is ready, should return true if ajax in progress
      if Prism.capybara.page.execute_script("return typeof Ext != 'undefined';")
        ### Ext JS is defined
        script = "return Ext.Ajax.isLoading();"
      elsif Prism.capybara.page.execute_script("return $.active != undefined;")
        script = "return $.active == 0 ? false : true"
      elsif Prism.capybara.page.execute_script("return typeof gwAjax != 'undefined';")
        script = "return gwAjax.hasPendingAjaxRequests.length == 0 ? false : true"
      elsif Prism.capybara.page.execute_script("return typeof angular != 'undefined';")
        ### Angular JS is defined
        script = "return angular.element(document.body).injector().get(\'$http\').pendingRequests.length == 0 ? false : true"
      elsif Prism.capybara.page.execute_script("return typeof JQuery != 'undefined';")
        script = "return jQuery.active ? true : false"
      else
        script = "false;"
      end
      Prism.capybara.page.execute_script(script)
    end

    def wait_for_ajax
      wait_retry("Waiting for ajax request to complete.") { raise if ajax_in_progress? }
    end

    def element_symbol(button)
      to_symbol("#{button}_element")
    end

    def page_element_exist?(page_obj, element, count=Prism.max_tries, raise_exception=true)
      wait_retry("page_element_exist?('#{page_obj.class}', '#{element}')", count, raise_exception) do
        page_obj.send(element_symbol(element)).visible? ? true : raise(RuntimeError, "#{element} not visible")
      end
    end

    # No exception thrown
    def page_element_exist(page_obj, element, count=Prism.min_tries)
      return false if count == 0
      begin
        element = page_obj.send(element_symbol(element))
        element.visible? ? true : page_element_exist(page_obj, element, count-1)
      rescue
        false
      end
    end

    def any_page_element_exist?(page_obj, *elements)
      wait_retry("page_element_exist?('#{page_obj.class}', '#{elements}')", Prism.max_tries) do
        any_element = elements.inject(false) do |bool, element|
          bool = bool || page_obj.send(element_symbol(element)).visible?
          bool
        end
        any_element ? true : raise(RuntimeError, "any_element? #{any_element}")
      end
    end

    def element(page_obj, element)
      wait_retry("element('#{page_obj.class}', '#{element}')") do
        elem = page_obj.send(element_symbol(element))
        elem.nil? ? raise(RuntimeError, "Did not find element: #{element}") : elem
      end
    end

    def element_text(page_obj, element)
      actual_element = wait_retry("element('#{page_obj.class}', '#{element}')") do
        elem = page_obj.send(element_symbol(element))
        elem.nil? ? raise(RuntimeError, "Did not find element: #{element}") : elem
      end
      actual_element.text
    end

    def invoke_checkbox(page_obj, element)
      page_element_exist?(re_get_page_obj(page_obj), element)
      ext = Prism::ExtjsHandler.new
       begin
        ext.click_checkbox(element)
       rescue Exception => e
         Prism.logger.debug("Exception raised when trying to call the checkbox: #{e}")
         page_element_exist?(re_get_page_obj(page_obj), element)
         element(page_obj,element).send_keys(:space)
       end
    end

    def generate_code(number)
      charset = Array('A'..'Z') + Array('a'..'z')
      Array.new(number) { charset.sample }.join
    end

    def continuous_press(page_obj, element, stop_condition)
      count = 5
      page_element_exist(page_obj, element, 10)
      begin
        Prism.logger.info "click_button('#{element}')"
        re_get_page_obj(@page_obj).send(to_symbol(element))
        sleep 5
        stop_condition.call() ? true : raise(RuntimeError, 'Still loading')
      rescue => e
        Prism.logger.info e
        sleep 5
        retry unless (count -= 1).zero?
      end
    end

    def set_element(page_obj, element, value)
      page_element_exist?(page_obj, element)
      wait_retry("set_element('#{page_obj.class}', '#{element}',  '#{value}')") do
        re_get_page_obj(page_obj).send("#{to_symbol(element).to_s}=", value)
        re_get_page_obj(page_obj).send(to_symbol(element)) == value ? true : raise(RuntimeError, "Value #{value} not set")
      end
    end

    def js_set_element(js_handler, element_id, value)
      wait_retry { js_handler.set_value(element_id, value) }
    end

    def get_element_id(page_obj, element)
      wait_retry("Failed: get_element_id('#{page_obj}', '#{element}')") do
        page_obj.send(to_symbol("#{element}_element")).id
      end
    end

    def set_radio(page_obj, field, button)
      ext = Prism.app::JSHandler.new
      page_element_exist?(page_obj, field)
      id = get_element_id(page_obj, field)
      begin
        index = ext.get_radio_index(id, button)
        ext.select_radio_group(id, index)
      rescue Exception => exp
        if exp.message =~ /Ext is not defined/i
          page_obj.send(element_symbol(field)).click
        else
          raise StandardError.new("Unable to find radio button")
        end
      end
    end

    def get_radio(page_obj, field, button)
      page_element_exist?(page_obj, field)
      Prism::ExtjsHandler.new.get_radio_index(get_element_id(page_obj, field), button)
    end

    def get_std_insured(value)
      value.gsub(/.*: /, '')
    end

    def handle_exception(e)
      exception_to_raise = e
      begin
        Prism.capybara.page.source
      rescue => ex
        exception_to_raise = ex
      end
      if Prism.exception_whitelist.find { |i| exception_to_raise.respond_to?(:message) ? exception_to_raise.message =~ /#{i}/ : exception_to_raise == i }
        Prism.logger.info "Exception has been whitelisted: #{exception_to_raise}"
      else
        Prism.logger.info "Exception is not whitelisted: #{exception_to_raise}"
        raise exception_to_raise
      end
    end

    def click_multiple_radio_buttons(radio_button_value)
      client_questions = page.all(find_element(radio_button_value).last, wait: 5)
      return unless client_questions.present?
      row_counter = 0
      while client_questions.length > row_counter
        client_questions[row_counter].click
        ExtjsHandler.new.wait_for_ajax
        client_questions = page.all(find_element(radio_button_value).last, wait: 5)
        row_counter += 1
      end
    end

    def count_policy_objects
      Prism.logger.debug("Counting returned policies on #{self}.")
      policy_count = all(:xpath, "//tr//*[contains(text(),'Select') or contains(text(),'Unselect')]").count
      Prism.logger.info "A total of #{policy_count} results were returned"
      policy_count
    end

    def to_symbol(string)
      val = string.class  == Symbol ? string.to_s : string
      camel = val.gsub(/.*:/, '').split.join('_').camelize.strip
      camel.gsub(/([A-Z]+)([A-Z][a-z])/,'\1_\2').
          gsub(/([a-z\d])([A-Z])/,'\1_\2').
          tr("-", "_").
          downcase.
          to_sym
    end
  end
 end
