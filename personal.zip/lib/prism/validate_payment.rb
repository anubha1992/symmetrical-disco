module Prism
  class ValidatePayment

    def initialize(screen_title)
     @page_obj = get_page_obj(screen_title)
    end

    def is_stored?(amount=nil)
      table = Prism::TableExtjs.new(@page_obj, :financials_table)
      rows = table.get_row_panel_values(['Gross Amount'], [])
      Prism.logger.info "Payment details: #{rows[0]}"
      if amount
        expect(amount.to_i).to eq(rows[0][:gross_amount].to_i)
      else
        expect(rows[0][:gross_amount]).to be > 0
      end
      end

    def is_stored_with_doc?(amount=nil,docs)
      table = Prism::TableExtjs.new(@page_obj, :financials_table)
      rows = table.get_row_panel_values(['Gross Amount'], [])
      doc = table.get_row_panel_values(['Docs'], [])
      Prism.logger.info "Payment details: #{rows[0]}"
      Prism.logger.info "Document linked: #{doc[0]}"
      if amount
        expect(amount.to_i).to eq(rows[0][:gross_amount].to_i)
      else
        expect(rows[0][:gross_amount]).to be > 0
      end
      expect(docs).to eq(doc[0][:docs])
    end

  end
end
