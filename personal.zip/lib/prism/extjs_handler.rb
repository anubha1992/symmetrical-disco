module Prism
  class ExtjsHandler

    def initialize
      @page = Prism.capybara.page
    end

    def get_type_code(id, select_item)
      ## Example: options = [["", "<none selected>"], ["AU_ACT", "ACT"], ["AU_NSW", "NSW"], ["AU_NT", "NT"], ["AU_QLD", "QLD"], ["AU_SA", "SA"], ["AU_TAS", "TAS"], ["AU_VIC", "VIC"], ["AU_WA", "WA"]]
      # Look for exact first in all select list options
      # If not check if the value includes your search value
      # Finally, if there is no match in the previous steps, search through the typecode
      options = get_dropdown_options(id)
      options.inject(nil) do |type_code, option|
        return option[0] if select_item.downcase == option[1].downcase
      end
      options.inject(nil) do |type_code, option|
        return option[0] if option[1].downcase.include? select_item.downcase
      end
      options.inject(nil) do |type_code, option|
        return option[0] if select_item.downcase == option[0].downcase
      end
    end

    def get_dropdown_readonly_value(id)
      script = %|
        var comboBox = Ext.getCmp("#{id}");
        return comboBox.value;
      |
      @page.execute_script(script)
    end

    def get_dropdown_options(id)
      script = %|
        var comboBox = Ext.getCmp("#{id}");
        var options = comboBox.getStore().data.items;
        var array   = []
        Ext.each(options, function(i){
            array.push([i.data.field1, i.data.field2]);
        });
        return array;
      |
      @page.execute_script(script)
    end

    def get_dropdown_keys(id)
      script = %|
        var comboBox = Ext.getCmp("#{id}");
        var options = comboBox.getStore().data.items;
        var array   = []
        Ext.each(options, function(i){
            array.push([i.data.field1]);
        });
        return array;
      |
      @page.execute_script(script)
    end

    def get_dropdown_values(id)
      script = %|
        var comboBox = Ext.getCmp("#{id}");
        var options = comboBox.getStore().data.items;
        var array   = []
        Ext.each(options, function(i){
            array.push([i.data.field2]);
        });
        return array;
      |
      @page.execute_script(script)
    end

    def set_value_text_field(id, value)
      script = %|
        var txtField = Ext.getCmp("#{id}");
        txtField.setValue("#{value}");
      |
      @page.execute_script(script)
    end

    def set_value(id, value)
      script = %|document.getElementById("#{id}").value = "#{value}";|
      @page.execute_script(script)
      wait_for_ajax if Prism.app == 'policy_center'
    end

    def js_select(id, value)
      value.strip!
      script = %|document.getElementById("#{id}").value = "#{value}";|
      @page.execute_script(script)
      script = %|document.getElementById("#{id}").onchange()|
      @page.execute_script(script)
    end

    def set_dropdown(id, value)
      value.strip!
      wait_retry("store_loading.....") do
        raise(RuntimeError, "#{id} is still loading...") if widget_is_loading?(id)
      end
      script = %|
        var comboBox = Ext.getCmp("#{id}");
        var record   = comboBox.store.getById("#{id}");
        comboBox.select("#{value}");
        comboBox.fireEvent('select', comboBox, record);
      |
      @page.execute_script(script)
      wait_for_ajax
    end

    def is_table_empty?(over_reaching_div_id)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        return comp.getStore().getRange().length == 0 ? true : false;
      |
      @page.execute_script(script)
    end

    def get_table_cell_type(over_reaching_div_id, row_num, column_name)
      field_value = title_text_to_value(over_reaching_div_id, column_name)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        return models[#{row_num}].data.#{field_value}.xtype;
      |
      @page.execute_script(script)
    end

    def get_table_cell_value(over_reaching_div_id, row_num, column_name)
      field_value = title_text_to_value(over_reaching_div_id, column_name)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        return models[#{row_num}].data.#{field_value}.value;
      |
      @page.execute_script(script)
    end

    def set_table_cell(over_reaching_div_id, row_num, column_name, value)
      field_value = title_text_to_value(over_reaching_div_id, column_name)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        models[#{row_num}].set("#{field_value}", "#{value}")
      |
      wait_retry("store_loading.....") do
        widget_is_loading?(over_reaching_div_id) ? raise(RuntimeError, 'Store is did not load') : @page.execute_script(script)
      end
      wait_for_ajax
    end

    def set_table_dropdown(over_reaching_div_id, row_number, column_name, value)
      field_value = title_text_to_value(over_reaching_div_id, column_name)
      options     = get_options(over_reaching_div_id, row_number, field_value)
      Prism.logger.debug("Dropdown list options: #{options}")
      cell_value  = field_display_to_value(value, options)
      set_table_cell(over_reaching_div_id, row_number, column_name, cell_value)
    end

    def get_table_columns(over_reaching_div_id)
      script = %|
        var col_headers = new Array();
        var grid = Ext.getCmp("#{over_reaching_div_id}");
        var tb_columns = grid.getView().getGridColumns();
        tb_columns.forEach(function(col_obj) { col_headers.push(col_obj.text) } )
        return col_headers;
      |
      @page.execute_script(script)
    end

    def get_table_row_with_select_btn(over_reaching_div_id, column_header, cell_value, select_button='')
      script = %|
        var table_data = new Array();
        var grid = Ext.getCmp("#{over_reaching_div_id}");
        var tb_columns = grid.getView().getGridColumns();
        var tb_rows = grid.getStore().getRange();
        var row_to_select = '';
        tb_rows.forEach(function(row_obj, index) {
          if( typeof(row_obj.data["#{column_header}"].text) == "undefined" && typeof(row_obj.data["#{column_header}"].items) == "object" ) {
            if(row_obj.data["#{column_header}"].items[0].text == "#{cell_value}") {
              row_to_select = select_button.replace('<row_num>',index)
            }
          } else {
            if(row_obj.data["#{column_header}"].text == "#{cell_value}") {
              row_to_select = select_button.replace('<row_num>',index)
            }
          }
        });
        return row_to_select;
      |
      @page.execute_script(script)
    end

    def get_table_row(over_reaching_div_id, column_header, cell_value)
      script = %|
        var table_data = new Array();
        var grid = Ext.getCmp("#{over_reaching_div_id}");
        var tb_columns = grid.getView().getGridColumns();
        var tb_rows = grid.getStore().getRange();
        var row_index = '';
        tb_rows.forEach(function(row_obj, index) {
          if( typeof(row_obj.data["#{column_header}"].text) == "undefined" && typeof(row_obj.data["#{column_header}"].items) == "object" ) {
            if(row_obj.data["#{column_header}"].items[0].text == "#{cell_value}") {
              row_index = index;
            }
          } else {
            if(row_obj.data["#{column_header}"].text == "#{cell_value}") {
              row_index = index;
            }
          }
        });
        return row_index;
      |
      @page.execute_script(script)
    end

    def get_visible_table_data(over_reaching_div_id)
      script = %|
        var table_data = new Array();
        var grid = Ext.getCmp("#{over_reaching_div_id}");
        var tb_columns = grid.getView().getGridColumns();
        var tb_rows = grid.getStore().getRange();
        tb_rows.forEach(function(row_obj) {
          var row_hash = new Object();
          tb_columns.forEach(function(col_obj) {
            if( typeof(row_obj.data[col_obj.dataIndex].text) == "undefined" && typeof(row_obj.data[col_obj.dataIndex].items) == "object" ) {
              row_hash[col_obj.dataIndex] = row_obj.data[col_obj.dataIndex].items[0].text;
            } else {
              row_hash[col_obj.dataIndex] = row_obj.data[col_obj.dataIndex].text;
            }
          });
          table_data.push(row_hash);
        });
        return table_data;
      |
      @page.execute_script(script)
    end

    def is_row_edited?(over_reaching_div_id, row_num)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        return models[#{row_num}].dirty
      |
      @page.execute_script(script)
    end

    def widget_is_loading?(over_reaching_div_id)
      store_loading = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        return comp.store.isLoading();
      |
      @page.execute_script(store_loading)
    end

    def wait_for_page_load
      wait_retry do
        @page.evaluate_script('document.readyState') == 'complete' ? true: raise(RuntimeError, 'Page not loaded')
      end
    end

    def get_dropdown_value(over_reaching_div_id)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        return comp['rawValue'];
      |
      @page.execute_script(script)
    end

    def get_cell_value(over_reaching_div_id, row_num, column_num)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        return models[#{row_num}].data.c#{column_num}.text;
      |
      @page.execute_script(script)
    end

    def set_cell_value(over_reaching_div_id, row_num, column_num, value)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        return models[#{row_num}].set('c#{column_num}', '#{value}');
      |
      @page.execute_script(script)
    end

    def model_length(over_reaching_div_id)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models = comp.getStore().getRange();
        return models.length;
      |
      @page.execute_script(script)
    end

    def show_menu(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        comp.showMenu();
      |
      @page.execute_script(script)
    end

    def handle_web_alert(id, button)
      Prism.logger.debug "Attempting to close dialog box"
      script = %|
        var comp = Ext.getCmp("#{id}");
        if(comp && comp.isVisible()) {
          comp.onPromptKey(comp, "#{button}");
        }
      |
      @page.execute_script(script)
    end

    def select_radio_group(id, item_number)
      radio_selected?(id, item_number) ? true : radio_select(id, item_number)
    end

    def radio_select(id, item_number)
      script = %|
        var comp = Ext.getCmp("#{id}");
        comp.items.items[#{item_number}].setValue(true);
      |
      @page.execute_script(script)
      wait_for_ajax
    end

    def get_element_type(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        return comp.ariaRole;
      |
      @page.execute_script(script)
    end

    def element_disabled?(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        return comp.disabled;
      |
      @page.execute_script(script)
    end

    def is_selectable?(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        return /combo/.test(comp.xtype) && !comp.disabled;
      |
      @page.execute_script(script)
    end

    def is_enabled?(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        return !comp.disabled;
      |
      @page.execute_script(script)
    end

    def radio_selected?(id, item_number)
      script = %|
        var comp = Ext.getCmp("#{id}");
        return comp.items.items[#{item_number}].checked;
      |
      @page.execute_script(script)
    end

    def get_radio_index(id, name)
      script = %|
        var comp = Ext.getCmp("#{id}");
        ans = -1
        Ext.each(comp.items.items, function(items, index){
            if("#{name}" == items.boxLabel){
                ans = index;
            };
        });
        return ans;
      |
      ans = @page.execute_script(script)
      ans == -1 ? raise(RuntimeError, "get_radio_index(id, name) name not found: '#{name}'") : ans
    end

    ## Ex: Basic Information and Incident screen - new contact next to reported_by or injured person etc.
    def show_new_contact(base_element_id,contact_type_text='New Person')
      script = %|
        var comp = Ext.getCmp("#{base_element_id}");
        comp.item.menu.show();
        Ext.each(comp.item.menu.items.items, function(item, index){
          if(item.text == "#{contact_type_text}"){
            Ext.getElementById(item.id).click();
          };
        });
      |
      @page.execute_script(script)
    end

    ## Ex: FNOL Parties Involved - new contact button
    def show_new_contact_opt_2(base_element_id,contact_type_text='New Person')
      script = %|
        var comp = Ext.getCmp("#{base_element_id}");
        comp.menu.show();
        Ext.each(comp.menu.items.items, function(item, index){
          if(item.text == "#{contact_type_text}"){
            Ext.getElementById(item.id).click();
          };
        });
      |
      @page.execute_script(script)
    end

    def select_button(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        comp.fireEvent('click', comp);
      |
      @page.execute_script(script)
      wait_till_page_load
    end

    def click_button(id)
      script = %|
        var comp = Ext.getElementById("#{id}");
        comp.click();
      |
      @page.execute_script(script)
      wait_till_page_load
    end

    def click_checkbox(id)
      script = %|
        var comp = Ext.getElementById("#{id}");
        comp.click();
      |
      @page.execute_script(script)
      wait_till_page_load
    end

    def click_radio_via_input_value(value)
      script = %|
        Ext.select("input[inputvalue=#{value}]").elements[0].click();
      |
      @page.execute_script(script)
    end

    def get_radio_input_value(over_reaching_div_id, row_number, column_number, label_name)
      options = get_radio_options(over_reaching_div_id, row_number, column_number)
      value = nil
      options.each { |option| value = option[1] if label_name == option[0]}
      value.nil? ? raise(RuntimeError, "Option not found for: #{label_name}") : value
    end

    def expand_all_documents(id)
      script = %|
        var comp = Ext.getCmp("#{id}");
        comp.expandAll();
      |
      @page.execute_script(script)
    end

    def get_options(over_reaching_div_id, row_number, field_value)
      if field_value =~ /recipient/i
        ## this is for selecting values from 'add pc/bcc' recipient dropdown
        ## while sending outbound documents
        script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        return comp.store.data.items[#{row_number}].data.recipient.items[0].store;
      |
      else
        script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        return comp.store.data.items[#{row_number}].data.#{field_value}.store;
      |
      end
      wait_retry("store_loading.....") do
        widget_is_loading?(over_reaching_div_id) ? raise(RuntimeError, 'Store is did not load') : @page.execute_script(script)
      end
    end

    def title_text_to_value(over_reaching_div_id, column_name)
      return "c#{column_name}" if column_name.class == Fixnum
      column_number = title_column_number(over_reaching_div_id, column_name)
      raise(RuntimeError, "Title '#{column_name}' not found") if column_number == -1
      title_value(over_reaching_div_id, column_number)
    end

    def scroll_by(index1, index2)
      script = %|
        window.scrollBy(#{index1}, #{index1});
      |
      # window.scrollTo(0, document.body.scrollHeight);
      @page.execute_script(script)
    end


    private

    def get_radio_options(over_reaching_div_id, row_number, column_number)
      script = %|
        var comp    = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var models  = comp.getStore().getRange();
        var options = models[#{row_number}].data.c#{column_number}.items
        var array   = []
        Ext.each(options, function(i){
            array.push([i.boxLabel, i.inputValue]);
        });
        return array;
      |
      @page.execute_script(script)
    end

    def field_display_to_value(display_name, options)
      # remove empty/none selected value
      _options = options.first[0].present? ? options : options[1..-1]
      if display_name == ">pick_first<"
        value = _options.first[0]
      elsif display_name == '>pick_random<'
        value = _options.sample[0]
      elsif display_name == '>not_unknown_and_not_applicable<'
        value = _options.select { |option| !['Unknown', 'Not Applicable'].include?(option.last) }.sample.first
      else
        value = _options.inject(nil) do |ans, tuple|
          ans = tuple[0] if tuple[1] == display_name
          ans
        end
      end
      value.nil? ? raise(RuntimeError, "Display name not found: '#{display_name}'") : value
    end

    def title_column_number(over_reaching_div_id, column_name)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        var ans = -1;
        Ext.each(comp.visibleColumnManager.columns, function(i, column_number){
            if(i.text == "#{column_name}"){
                ans = column_number;
            };
        });
        return ans;
      |
      @page.execute_script(script)
    end

    def title_value(over_reaching_div_id, column_number)
      script = %|
        var comp = Ext.ComponentManager.get("#{over_reaching_div_id}");
        return comp.visibleColumnManager.columns[#{column_number}].dataIndex;
      |
      #return comp.visibleColumnManager.columns[#{column_number}].stateId;
      @page.execute_script(script)
    end

  end
end
