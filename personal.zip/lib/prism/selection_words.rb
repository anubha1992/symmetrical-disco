module Prism
  class SelectionWords

    def initialize(page_obj, ref_data=nil)
      @page_obj      = page_obj
      @extjs_handler = Prism::ExtjsHandler.new
      @html_entities = HTMLEntities.new
      @ref_data      = ref_data
    end

    def select_dropdown(element, value)
      # In some cases '+' is added by Claims Application, which is now showing in the dropdown list
      # Therefore, it needs to be filtered when select by value.
      trimmed_value = value.gsub(/\+$/, '').strip
      wait_till_page_load
      @element_id = get_element_id(@page_obj, element)
      value_to_select = select(trimmed_value, element)
      Prism.logger.debug("Select value: #{trimmed_value}, Transformed value: #{value_to_select}")
      Prism.store_to_mongo[element] = value_to_select
      if value_to_select.present?
        @extjs_handler.set_dropdown(@element_id, value_to_select)
        is_selected?(trimmed_value, value_to_select, element)
      else
        Prism.logger.info("The select list does not have any options to select")
      end
      wait_till_page_load
    end

    def select(value, element)
      if respond_to?(value.to_s) == true
        send(value.to_s.parameterize.underscore, element)
      else
        if value =~ />pick_except</i
          text = value.split("_").last
          value = ">pick_except<"
        end
        case value
          when '>pick_first<'
            pick(0, element)
          when '>pick_second<'
            pick(1, element)
          when '>pick_insured<'
            pick_insured(element)
          when '>pick_claim_owner<'
            pick_claim_owner(element)
          when '>pick_random<'
            pick('random', element)
          when '>pick_location<'
            pick('random', element)
          when '>pick_except<'
            pick(text, element)
          else
            @extjs_handler.get_type_code(@element_id, value)
        end
      end
    end

    def get_picking_table(table_id, enter_data, element)
      @table_id = table_id
      case enter_data
        when '>pick_first<'
          table_picker(0, element)
        when '>pick_second<'
          table_picker(1, element)
        when '>pick_insured<'
          pick_insured
        else
          enter_data
      end
    end

    def pick_risk(element)
      page_element_exist?(@page_obj, element)
      @page_obj = re_get_page_obj(@page_obj)
      id        = get_element_id(@page_obj, element)
      options   = @extjs_handler.get_dropdown_options(id)
      values    = options.map{|x| x[1]}
      if Prism.policy.suitable_risks && Prism.policy.suitable_risks.any?
        risk_unit = Prism.policy.suitable_risks.first['risk_unit']
        indices = values.each_index.select { |index| (values[index] =~ /^#{risk_unit}/) }
      else
        indices = values.each_index.select { |index| values[index] !~ /New...|ANYWHERE WITHIN AUSTRALIA|<none selected>/i}
      end
      options[indices.sample][0]
    end

    def pick_location(element)
      pick('random', element)
    end

    def pick_insured(element)
      if get_page_obj('Menu').insured?
        value = get_std_insured(get_page_obj('Menu').insured_element.text)
      else
        value = pick(0, element)
      end
      # value = get_std_insured(insured_text)
      @extjs_handler.get_type_code(@element_id, value)
    end

    def pick_claim_owner(element)
      if @ref_data.claim.present? && @ref_data.claim.primary_claim_owner.present?
        value = @ref_data.claim.primary_claim_owner
      elsif get_page_obj('Menu').claim_owner?
        value = get_std_insured(get_page_obj('Menu').claim_owner.text)
      else
        value = pick(0, element)
      end
      @extjs_handler.get_type_code(@element_id, value)
    end

    private

    def is_selected?(value, select, element)
      # value == print_select(element) || select == print_select(element) ? true : raise(RuntimeError, "Did not pick value: '#{value}'")
      picked = print_select(element)
      (value == picked) ||(picked != "<none selected>" && picked != "New..."  && picked != "") ? picked : raise(RuntimeError, "Did not pick value: '#{value}'")
    end

    def pick(num, element)
      page_element_exist?(@page_obj, element)
      @page_obj = re_get_page_obj(@page_obj)
      id        = get_element_id(@page_obj, element)
      options   = @extjs_handler.get_dropdown_options(id)
      values    = options.map{|x| x[1]}
      if num.to_s !~ /0|1|random/
        indices = values.each_index.select { |index| values[index] !~ /New...|ANYWHERE WITHIN AUSTRALIA|<none selected>|#{num}/i}
      else
        indices = values.each_index.select { |index| values[index] !~ /New...|ANYWHERE WITHIN AUSTRALIA|<none selected>/i}
      end
      if indices.any?
        if num == 0
          options[indices.first][0]
        elsif num == 1
          indices.second.present? ? options[indices.second][0] : options[indices.first][0]
        else
          options[indices.sample][0]
        end
      else
        ''
      end
    end

    def table_picker(num, element)
      field_value = @extjs_handler.title_text_to_value(@table_id, element)
      options = @extjs_handler.get_options(@table_id, num, field_value)
      get_picked_option_label(options, num)
    end

    def get_picked_option_label(options, num)
      options.select{|op| op[1] != "<none selected>"}[num][1]
    end

    # def get_picked_option_typecode(options, num)
    #   options.select{|op| op[1] != "<none selected>"}[num][0]
    # end

    def print_select(element)
      dropdown_id    = get_element_id(@page_obj, element)
      dropdown_value = @extjs_handler.get_dropdown_value(dropdown_id)
      value          = @html_entities.decode(dropdown_value).gsub(/<br>*/, ' ')
      Prism.logger.debug "Picked: '#{value}'"
      value
    end

  end
end
