module Prism
  class NgHandler

    def initialize
      @page = Prism.capybara.page
    end

    def click_repx_booking(id, element_style)
      script = %|
        var comp = $("[bookingid=#{id}][class='editOutcome editOutcome#{element_style}']")[0];
        var evt = document.createEvent("MouseEvents");
        evt.initMouseEvent("click", true, true, window, 0,0,0,0,0, false, false, false, false, 0, null);
        comp.dispatchEvent(evt);
      |
      @page.execute_script(script)
      wait_for_ajax
    end

    def click_ok_button
      script = %|
         var comp = $("#claim_info_reallocationConfirmationDialog").siblings().find('.ui-button');
         comp.click();
      |
      @page.execute_script(script)
      wait_for_ajax
    end


    def select_start_date
      script = %|
         var comp = $('#claim_info_repair_tracking-instance_repair_start_date').datepicker().datepicker('setDate',"1W");
      |
      @page.execute_script(script)
      wait_for_ajax
    end

  def select_end_date
    script = %|
         var comp = $('#claim_info_repair_tracking-instance_repair_end_date').datepicker().datepicker('setDate',"1W+1");
      |
    @page.execute_script(script)
    wait_for_ajax
  end

    def damage_count_claim_selection(claim_number)
      script = %|
      $("span:contains#(claim_number}").click()
      |
      @page.execute_script(script)
      wait_for_ajax
    end

  end
end