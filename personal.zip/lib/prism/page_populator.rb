module Prism
  class PagePopulator
    attr_accessor :page_obj, :ref_data

    def initialize(page, ref_data=nil)
      set_current_page(page)
      @ref_data = ref_data
    end

    #
    # Populates all matched page elements from the Hash passed as an argument.
    # Elements are matched by the Hash key to the name provided when declaring
    # the element on the page object.
    #
    # @example
    #   text_field(:username, id: 'Login-LoginScreen-LoginDV-username')
    #   text_field(:password, id: 'Login-LoginScreen-LoginDV-password')
    #   ...
    #   element_hash = {:username => 'a name', :password => 'a password'}
    #   page_populator = PagePopulator.new('page_name')
    #   page_populator.populate_page_with(element_hash)
    #
    # @param data [Hash] the data to use to populate page elements.
    # Key can be a String or Symbol.  Value can be a String, Hash or Array.
    #
    def populate_page_with(data)
      Prism.logger.info "Page populator hash: #{data}"
      data.each do |key, value|
        key = key.to_s.parameterize.underscore
        value.respond_to?(:to_h) ? populate_elements(key, value) : populate_element(key, value)
      end
      wait_till_page_load
    end

    def populate_elements(key, value)
      if table?(key)
        populate_table(key, value)
      elsif value.is_a? Hash
        value.each { |k,v| populate_page_with(k=>v) }
      else #Array
        value.each { |v| populate_page_with(key=>v) }
      end
    end

    def populate_element(key, value)
      wait_till_page_load
      Prism.logger.info "Populate element: #{key} => #{value}"
      if key =~ /^page/i
        set_current_page(value)
      elsif element?(key) or elements?(key)
        populate_value(key, value)
      elsif @page_obj.respond_to?(key)
        custom_action(key, value)
      else
        special_action(key, value)
      end
    end

    def populate_value(key, value)
      begin
        element = element(key)
        element.scroll_into_view if element.present? && element.visible? and element.respond_to?('scroll_into_view')
      rescue Exception => e
        Prism.logger.debug "Scroll into view exception received: #{e.message}"
      end
      case
      when select_list?(key)  then populate_select_list(key, value)
      when text_field?(key)   then populate_text_field(key, value)
      when radio_button?(key) then populate_radio_button(key, value)
      when checkbox?(key)     then populate_checkbox(key, value)
      else element_action(key, value)
      end
    end

    def element_action(key, value)
      element = element(key)
      case
        when value.to_s.downcase == "click_twice"
          element_click(key)
          wait_till_page_load
          element_click(key) if element.present?
        when value.to_s.downcase    == "should_click"  then element_click(key)
        when value.to_s.downcase    == "hover_over"    then element.hover
        when element.data_gw_getset == 'radio'         then element.label_element(text: value).click
        when element.data_gw_getset == 'checkboxgroup' then element.checkbox_element(value: value).click
        else Prism.logger.debug "No element action found for key: #{key}, value: #{value}"
      end
    end

    def element_click(key)
      element = element(key)
      if element.class.to_s =~ /Div/ && element.div_elements.any? && (element.attributes[:role].blank? || element.attributes[:role] != "button")
        sleep 1
        element.div_element(role: "button").exists? ? element.div_element(role: "button").click : element.click
      else
        element.click
      end
    end
    #
    # def element_action(key, value)
    #   case
    #     when value.to_s.downcase == "click_twice"
    #       element(key).click
    #       wait_till_page_load
    #       element(key).click if  element(key).present?
    #     when value.to_s.downcase    == "should_click"  then  element(key).click
    #     when value.to_s.downcase    == "hover_over"    then  element(key).hover
    #     when element.data_gw_getset == 'radio'         then  element(key).label_element(text: value).click
    #     when element.data_gw_getset == 'checkboxgroup' then  element(key).checkbox_element(value: value).click
    #     else Prism.logger.debug "No element action found for key: #{key}, value: #{value}"
    #   end
    # end

    def custom_action(key, value)
      Prism.logger.debug "Custom page method..."
      value.blank? or value =~ /blank/i ? @page_obj.send(key) : @page_obj.send(key, value)
    end

    def special_action(key, value)
      Prism.logger.debug "Special action..."
      if key =~ /^wait|^sleep|^stop|^pause|^hold/i
        Prism.logger.info "Stop and wait for #{value} seconds"
        sleep(value.to_i)
      elsif key =~ /^v&v_|v_v_(.*)/i
        element_ref = $1
        validate_element(element_ref, value)
      else
        generic_action(key, value)
      end
    end

    def generic_action(key, value)
      Prism.logger.debug "Generic action..."
      @page_obj.populate_page_with(key => value)
      @page_obj.send("#{key}_element").send_keys :tab
    end

    ###############
    ## Elements
    ###############

    def element(key)       @page_obj.send("#{key}_element")         end
    def elements(key)      @page_obj.send("#{key}_elements")        end
    def element?(key)      @page_obj.respond_to?("#{key}_element")  end
    def elements?(key)     @page_obj.respond_to?("#{key}_elements") end
    def select_list?(key)  @page_obj.respond_to?("#{key}_options")  end
    def text_field?(key)   @page_obj.respond_to?("#{key}=")         end
    def radio_button?(key) @page_obj.respond_to?("select_#{key}")   end
    def checkbox?(key)     @page_obj.respond_to?("check_#{key}")    end
    def table?(key)        element?(key) and PageObject::Elements::Table === element(key) end

    ###############
    ## Select list
    ###############

    def populate_select_list(key, value)
      select_list_element = element(key)
      select_dropdown(select_list_element.element, value)
    end
    alias_method :fill_dropdown, :populate_select_list

    def dropdown_value(element, value)
      index = case value
              when '>pick_first<'
                element.options.first.value.present? ? 0 : 1
              when '>pick_second<'
                element.options.first.value.present? ? 1 : 2
              when '>pick_random<'
                i = element.options.first.value.present? ? 0 : 1
                rand(i...element.options.count)
              end
      index ? element.options[index].text : value
    end

    # TODO - update to work with table elements
    # Calling select on element attribute to ensure method directs to Watir::Select
    def select_dropdown(element, value)
      value = dropdown_value(element, value)
      Prism.logger.debug "Select dropdown: #{value}"
      element.select_value(value)
      element.send_keys(:tab)
      # element.select sometimes throws Ambiguous match, found 'n' number of elements matching visible option "<some value>"
      # something like -> element= or element.select_value should work
      # using direct call to avoid losing the handle during send_keys "tab"
      # @page_obj.send("#{key}=", value)
      # @page_obj.send(element_symbol(key)).send_keys :tab
    end

    # def fill_dropdown(key, value)
    #   @page_obj.send("#{key}_element").select(value)
    #   Prism.logger.debug "Select list employed. Element => #{key}, Value => #{value}"
    # end
    #
    # def fill_dropdown_by_value(key, value)
    #   @page_obj.send("#{key}_element").select_value(value)
    #   Prism.logger.debug "Select list by value employed. Element => #{key}, Value => #{value}"
    # end

    # Finds a match and returns value/text pair
    # Ex: {"Person:134427"=>"NANCYHPACP1 FWKNSW (Insured)"}
    # def select_get_match(element_ref, value, type='text')
    #   if type == 'text'
    #     @page_obj.send("#{element_ref}_element").options.map {|el| el.text =~ /^#{value}/ ? {el.value => el.text} : nil}.compact.first
    #   else
    #     @page_obj.send("#{element_ref}_element").options.map {|el| el.value =~ /^#{value}/ ? {el.value => el.text} : nil}.compact.first
    #   end
    # end

    ###############
    ## Text field
    ###############

    def populate_text_field(key, value)
      text_element = element(key)
      return set_text_field_value(text_element, value) unless key == "address_search"
      select_autocomplete(text_element, value)
    end

    def set_text_field_value(element, value)
      count = 2
      value = text_value(value)
      begin
        set_text(element, value)
        wait_till_page_load
        raise if element.value != value
      rescue
        Prism.logger.debug "Retry - value not set. Expected: #{value}, Actual: #{element.value}"
        retry unless (count -= 1).zero?
      end
    end

    def text_value(value)
      case value
      when 'today', 'tomorrow', 'yesterday', 'current'
        Date.send(value).strftime('%d/%m/%Y')
      when /^next_day|^prev_day|^next_month|^prev_month|^next_year|^prev_year/i
        get_date(value)
      when /(.*)days/i
        get_future_or_past_date(value)
      when /(.*)months/i
        get_date_future_month(value)
      when /(.*)year/i
        get_future_or_past_year(value)
      else
        value
      end
    end

    def set_text(element, value)
      Prism.logger.debug "Set text: #{value}"
      element.value = value
      element.send_keys :tab
    end

    # Selects the closest match from an autocomplete dropdown
    def select_autocomplete(element, value)
      element.value = value
      closest_match = nil
      @page_obj.wait_until(5) do
        closest_match = @page_obj.browser.find_elements(:class, "gw-autocomplete--entry")[1]
      end
      closest_match.click
      element.send_keys :tab
      Prism.session_vars["selected_address"] = 1
      Prism.logger.debug "Autocomplete selected: #{element.value}"
    end

    ###############
    ## Radio button
    ###############

    def populate_radio_button(key, value)
      radio_element = elements?(key) ? elements(key) : element(key)
      select_radio(radio_element, value)
    end

    def select_radio(element, value)
      value = radio_value(value)
      Prism.logger.debug "Select radio: #{value}"
      return set_radio(element) unless element.respond_to?(:count)
      element.each { |el| break set_radio(el) if el.value == value }
    end

    def radio_value(value)
      return 'true'  if value.downcase == 'yes'
      return 'false' if value.downcase == 'no'
      value
    end

    def set_radio(element)
      element.click
    end

    ###############
    ## Checkbox
    ###############

    def populate_checkbox(key, value=nil)
      value = false if value.to_s.downcase == 'no'
      Prism.logger.debug "Set checkbox: #{value}"
      value ? @page_obj.send("check_#{key}") : @page_obj.send("uncheck_#{key}")
    end

    ###############
    ## Table
    ###############

    def populate_table(key, value)
      wait_till_page_load
      Prism.logger.debug "Populate table: #{key}, #{value}"
      table = element(key)
      column_headers = []
      table.first.each {|cell| column_headers << cell.element.text}
      row_index = value[:row_index] ? get_row_index(table, column_headers, value[:row_index]) : table.count - 1

      value.each do |col,val|
        next if col == 'row_index'
        column_index = column_headers.index(col)
        populate_table_cell(table, row_index, column_index, val)
      end
    end

    def populate_table_cell(table_element, row_index, column_index, value)
      cell = table_element[row_index][column_index]
      if cell.options.count > 0
        select_dropdown(cell.select_list, value)
        #cell.select_list.select_value value
        #cell.select_list.send_keys :tab
      elsif cell.text_fields.count > 0
        set_text_field_value(cell.text_field_element, value)
        #set_text(cell.text_field_element, value)
      elsif cell.radios.count > 0
        select_radio(cell.radios, value)
        #cell.div_elements(data_gw_getset: 'radio').first.label_element(text: value).click
      elsif cell.checkboxes.count > 0
        # TODO
      else
        # TODO
      end
    end

    def get_row_index(table, column_headers, value)
      if value.is_a? Hash
        column_index = column_headers.index(value.keys.first)
        table.row_elements.each_with_index do |row, index|
          return index if row[column_index].element.text == value.values.first
        end
        Prism.logger.debug "Row not found: #{value}"
      end
      value.to_i
    end

    def get_table_data(table_ref)
      @page_obj.send("#{table_ref}_element").hashes
    end

    # def select_cell_by_text(text_value, frame=nil)
    #   page.driver.browser.switch_to.frame "#{frame}" if frame.present?
    #   get_cell_by_text(text_value).click
    # end
    #
    # def select_row(row_num, table_ref, frame=nil)
    #   Prism.logger.debug "Going to select row '#{row_num}' from table '#{table_ref}'"
    #   page.driver.browser.switch_to.frame "#{frame}" if frame.present?
    #   @page_obj.send(element_symbol(table_ref))[row_num.to_i].click
    # end
    #
    # def select_row_by_text(text_value, frame=nil)
    #   page.driver.browser.switch_to.frame "#{frame}" if frame.present?
    #   get_cell_by_text(text_value).click
    # end
    #
    # def get_cell_by_text(text_value)
    #   @page_obj.cell_element(text: text_value)
    # end
    #
    # def get_row_by_text(text_value, table_refernce)
    #   matched_row = @page_obj.send("#{table_refernce}_element").find {|row| row.text.include? text_value}
    #   fail "Could not locate the row with value #{text_value}" if matched_row.nil?
    #   matched_row
    # end

    ###############
    ## Date formatting
    ###############

    # Get date from value using Date class methods. Can include a spaced integer argument.
    # Examples: 'next_day 21', 'prev_day 7', 'next_month', 'next_month 6', 'prev_month', 'next_year', 'prev_year 2'
    def get_date(value)
      value = value.downcase.split
      if value.count == 1
        Date.current.send(value[0]).strftime('%d/%m/%Y')
      else
        Date.current.send(value[0], value[1].to_i).strftime('%d/%m/%Y')
      end
    end

    def get_date_future_month(value)
      value = value.split('')[0]
      (DateTime.now() >> value.to_i).strftime('%d/%m/%Y')
    end

    def get_future_or_past_date(value)
      date = ""
      value = value.split(' ')
      if value[0] =~ /after/
        future_date = (Date.today+value[1].to_i).strftime('%d/%m/%Y')
        date = future_date
      else
        past_date = (Date.today-value[1].to_i).strftime('%d/%m/%Y')
        date = past_date
      end
      date
    end

    def get_future_or_past_year(value)
      value = value.split(' ')
      if value[0] =~ /after/
        future_date = value[1].to_i.years.since.strftime('%d/%m/%Y')
        date = future_date
      else
        past_date = value[1].to_i.years.ago.strftime('%d/%m/%Y')
        date = past_date
      end
      date
    end

    ###############
    ## Verify and validate
    ###############

    def validate_page_with(ref_data_fragment)
      Prism.logger.info "Page validator: Hash: #{ref_data_fragment}"
      wait_till_page_load
      ref_data_fragment.each do |key, value|
        if key == "page"
          ######## Set current page ##########
          Prism.logger.debug "Page validator: Set page to #{value}"
          set_current_page(value)
        else
          validate_element(key, value)
        end
      end
    end

    def validate_element(element_ref, value)
      Prism.logger.info "Page validator: Element: #{element_ref}, Value: #{value}"

      if value =~ /is_present/i
        Prism.logger.info "Page validator => Expect element '#{element_ref}' to be present"
        expect(@page_obj.send(element_symbol(element_ref)).exists?).to be true
      elsif value=~ /is_not_present/i
        Prism.logger.info "Page validator => Expect element '#{element_ref}' not to be present"
        expect(@page_obj.send(element_symbol(element_ref)).exists?).to be false
      else
        element_txt = @page_obj.send(element_symbol(element_ref)).text
        Prism.logger.info "Page validator => Expected: '#{value}', Actual: '#{element_txt}'"
        # expect(element_txt).to eql(value)
        expect(element_txt).to include(value)
      end
    end

  end
end