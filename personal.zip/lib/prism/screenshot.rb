module Prism
  class Screenshot

    attr_reader :path
    def initialize(path="#{Rails.root}/log/reports/%s.png")
      @path = path
    end

    def take_step_snapshot(snapshot_path=Prism.step_snapshot_path)
      snap snapshot_path
    end

    def take_screenshot(screenshot_path=nil)
      snap(screenshot_path)
    end

    def take_outbound_snapshot(doc_type, snapshot_path="#{Rails.root}/log/reports/outbound_#{doc_type}_#{Time.now.strftime('%F_%H-%M-%S')}.png")
      snap snapshot_path
    end

    private

    def snap(file_path=nil)
      screenshot_path = file_path || path
      
      # check if screenshot_path has a %s escape in it - if so populate with timestamp
      if screenshot_path.match(/%s/)
        screenshot_path = sprintf(screenshot_path, Time.now.strftime('screenshot_%F_%H-%M-%S'))
      end

      begin
        Prism.capybara.page.save_screenshot(screenshot_path, full: true)
        Base64.encode64(File.open(screenshot_path, "rb").read)
      rescue Exception => e
        Prism.logger.info "An error has occurred with screenshot: #{e}"
      end
    end
  end
end
