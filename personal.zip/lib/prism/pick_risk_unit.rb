module Prism
  class PickRiskUnit

    def initialize(screen_title, ref_data)
      @ref_data   = ref_data
      @page_obj   = get_page_obj(screen_title)
      @table_elements = @page_obj.send(to_symbol("risks_table_elements"))
      @page       = Prism.capybara.page
      @extjs      = Prism::ExtjsHandler.new
      raise(RuntimeError, "Risk selection tables not visible") if @table_elements.count == 0
    end

    def extract_coverage_types(ref_data)
      # Use either coverage type or coverage subtype to calculate risk unit
      ref_data['incidents'].inject([]) do |array, i|
        coverage = i['coverage_type'].present? ? i['coverage_type'] : i['coverage_subtype']
        array << get_coverage_type_number(coverage) unless coverage.nil?
        # array << coverage unless coverage.nil?
        array
      end
    end

    def select(policy_coverage_types, coverage_types)
      @table_elements.each do |table_element|
        @table_id = table_element.id
        if table_element.id =~ /NewClaimVehiclesLV/
          @table_name = 'vehicle_risks_table'
          @table = Prism::TableExtjs.new(@page_obj, @table_name)
          risk_units = get_one_matching_risk_unit(policy_coverage_types, coverage_types).uniq
          risk_units.map!(&:to_s)
          selected_risks = tick_first_matching_risk_unit(risk_units)
          break if selected_risks > 0
        elsif table_element.id =~ /CGU_NewClaimLocationsLV/
          @table_name = 'location_risks_table'
          @table = Prism::TableExtjs.new(@page_obj, @table_name)
          risk_units = get_all_matching_risk_units(policy_coverage_types, coverage_types).uniq
          risk_units.map!(&:to_s)
          selected_risks = tick_all_risk_units(risk_units)
          break if selected_risks > 0
        elsif table_element.id =~ /CGU_NewClaimTripsLV/
          @table_name = 'trip_risks_table'
          @table = Prism::TableExtjs.new(@page_obj, @table_name)
          risk_units = get_all_matching_risk_units(policy_coverage_types, coverage_types).uniq
          risk_units.map!(&:to_s)
          selected_risks = tick_all_risk_units(risk_units)
          break if selected_risks > 0
        end
      end
    end

    def select_from_ref_data(ref_data)
      risk_units = get_risk_units_from_ref_data(ref_data).uniq
      risk_units.map!(&:to_s)

      @table_elements.each do |table_element|
        @table_id = table_element.id
        if table_element.id =~ /NewClaimVehiclesLV/
          @table_name = 'vehicle_risks_table'
          @table = Prism::TableExtjs.new(@page_obj, @table_name)
          selected_risks = tick_first_matching_risk_unit(risk_units)
          break if selected_risks.present? and selected_risks > 0
        elsif table_element.id =~ /CGU_NewClaimLocationsLV/
          @table_name = 'location_risks_table'
          @table = Prism::TableExtjs.new(@page_obj, @table_name)
          if ref_data['claim_lob'] =~ /Workers' Comp/i
            selected_risks = tick_first_matching_risk_unit(risk_units)
          else
            selected_risks = tick_all_risk_units(risk_units)
          end
          break if selected_risks.present? and selected_risks > 0
        elsif table_element.id =~ /CGU_NewClaimTripsLV/
          @table_name = 'trip_risks_table'
          @table = Prism::TableExtjs.new(@page_obj, @table_name)
          if ref_data['claim_lob'] =~ /Workers' Comp/i
            selected_risks = tick_first_matching_risk_unit(risk_units)
          else
            selected_risks = tick_all_risk_units(risk_units)
          end
          break if selected_risks.present? and selected_risks > 0
        end
      end
    end

    private

    #############################################################################
    # For non PMS policy systems, the policies will have a 'risk_types' attribute and
    # suitable_risks attribute calculated at the time of finding a policy
    # suitable_risks are accurate as
    # 'risk_types' of "farm_motor" can have mix of comprehensive, 3rd party coverages etc.
    # Example: {
    #  "farm_motor"=>[1001, 6001, 41001, 42001, 43001, 44001],
    #  "per_motor"=>[2001, 34001],
    #  "comm_motor"=>[3001, 4001],
    #  "motor_cycle"=>[12001]
    # }
    # For PMS, risk unit info can be hard coded in the scenario/ref_data if that policy is not in mongoDB
    # This can be within the incidents or on the base structure
    ##############################################################################
    def get_risk_units_from_ref_data(ref_data)
      if Prism.policy.suitable_risks
        Prism.policy.suitable_risks.map {|x| x['risk_unit']}.compact
      elsif ref_data['risk_type'].present?
        Prism.policy.risk_types[@ref_data.risk_type]
      elsif ref_data['risk_unit'].present?
        if ref_data['risk_unit'].is_a?(Array)
          ref_data['risk_unit']
        else
          [ref_data['risk_unit']]
        end
      else
        ref_data['incidents'].inject([]) do |array, i|
          if i['risk_unit'].present?
            array << i['risk_unit']
          end
          array
        end
      end
    end

    def get_one_matching_risk_unit(policy_coverage_types=[], coverage_types)
      risk_perl_map = Hash.new
      return_risk_units = []
      policy_coverage_types.map {|i| (risk_perl_map[i['risk_unit']] ||= []).push(i["major_peril"])}
      risk_perl_map.each do |risk_unit, major_perils|
        return_risk_units << risk_unit.to_s if (coverage_types.uniq - major_perils.uniq).empty?
      end
      return_risk_units
    end

    def get_all_matching_risk_units(policy_coverage_types=[], coverage_types)
      coverage_types.uniq.inject([]) do |array, coverage_type|
        policy_coverage_types.each{|c| array << c['risk_unit'].to_s if c['major_peril'] == coverage_type}
        array
      end
    end

    def tick_all_risk_units(risk_units)
      Prism.logger.info "Selecting all risk unit(s) : #{risk_units}"
      Prism.store_to_mongo[:risk_units] = risk_units
      selected_risks = 0
      risk_units.each do |risk_unit|
        ##Goto the first page before each selection
        @table.move_first if @table.has_multiple_pages?
        @table.each_row_with_index do |row, index|
          if row.include?(risk_unit) && row.include?("Active-Not Selected")
            selected_risks += 1
            @table.click_checkbox(index,@table_id)
            wait_till_page_load
            break #Break after a risk selection
          end
        end
      end
      selected_risks
    end

    def tick_first_matching_risk_unit(risk_units)
      Prism.logger.info "Selecting one risk unit(s) from: #{risk_units}"
      Prism.store_to_mongo[:risk_units] = risk_units
      wait_till_page_load
      @table.move_first if @table.has_multiple_pages?
      @table.each_row_with_index do |row, index|
        Prism.logger.debug("Index: #{index}, Risks: #{risk_units}, Row: #{row}")
        if (risk_units & row).any? && row.include?("Active-Not Selected")
          Prism.logger.debug("click on checkbox with index #{index}")
          @table.click_checkbox(index,@table_id)
          return 1
        end
      end
    end

    def tick_first
      @table.tick(0,@table_id)
    end

  end
end