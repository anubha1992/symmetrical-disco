module Prism
  class Populator

    def self.build(page_obj)
      new(page_obj.class.to_s)
    end

    def initialize(page)
      if page.is_a?(String)
        @page_obj = get_page_obj(page)
      elsif page.is_a?(Object)
        @page_obj = page
      else
        raise(RuntimeError, 'Cannot initialize a valid page object')
      end
      @extjs_handler = Prism::ExtjsHandler.new
      @html_entities = HTMLEntities.new
      @selection_words = Prism::SelectionWords.new(@page_obj)
    end

    def check_checkbox(field)
      Prism.logger.info "select_checkbox('#{field}')"
      invoke_checkbox(@page_obj, field)
    end

    def click_radio_button(field, button)
      Prism.logger.info "click_radio_button('#{field}', '#{button}')"
      set_radio(@page_obj, field, button)
    end

    def get_radio_button(field, button)
      Prism.logger.info "Get Radio Button ('#{field}', '#{button}')"
      get_radio(@page_obj, field, button)
    end

    def get_element(element)
      element(@page_obj, element)
    end

    def fill_field(element, value)
      Prism.logger.info "fill_field('#{element}', '#{value}')"
      Prism.store_to_mongo[element] = value
      if value == '>today<'
        today_value = get_today
        #set_element(@page_obj, element, today_value)
        js_set_element(@extjs_handler, get_element_id(@page_obj, element), today_value)
        today_value.to_s == print_field(element) ? true : raise(RuntimeError, "Did not fill field value: '#{today_value}'")
      else
        #set_element(@page_obj, element, value)
        js_set_element(@extjs_handler, get_element_id(@page_obj, element), value)
        value.to_s == print_field(element) ? true : raise(RuntimeError, "Did not fill field value: '#{value}'")
      end
    end

    def fill_dropdown(element, value)
      Prism.logger.info "fill_dropdown('#{element}', '#{value}')"
      if is_not_set(element, value)
        value = @selection_words.select_dropdown(element, value)
      else
        value
      end
      Prism.store_to_mongo[element] = value
      value
    end

    def table_fill_with_refdata(ref_data)
      ref_data.each do |key, val|
        if key =~ /what_happened/i
          message = format("%s%s%s\n%s%s\n%s","*** AUTOMATED CLAIM *** \nThis is an automated claim created for scenario id \"", ref_data.scenario_id.to_s, "\".\n","Executed on: ", Time.zone.now.to_s, ref_data.what_happened.to_s)
          puts message
          fill_in(@page_obj.what_happened_element.id, with: message)
        elsif key =~ /country/i
          Prism.app::AddClaimInformation.new(Prism.capybara.page.driver.browser).handle_alert
          sleep(5)
        elsif
          #####
          # Skip if ref data does not have value for the element
          # Required to have elastic data entry (snippets/features should not be too closely tied up to the data fields)
          # Note: If ref_data has value specified for the element, the element should exist. Cannot be optional
          #####
          Prism.logger.debug "Ref Data present for element: '#{key}'. Enter value: '#{val}'"
          set_element_value(key, val)
        end
      end
    end

    def set_text_field(element, ref_data)
      value = get_element_value(element, ref_data)
      Prism.logger.debug "set element '#{element}' with  '#{value}'"
      id     = get_element_id(@page_obj, element)
      @extjs_handler.set_value_text_field(id, value)
    end

    def set_element_value(element, value)
      wait_till_page_load
      element = (element =~ /Registered for GST/) ? "Registered for GST" : element
      page_element_exist?(@page_obj, element)
      case element_type?(element, value)
        when PageObject::Elements::RadioButton
          click_radio_button(element, value)
        when PageObject::Elements::TextField
          fill_field(element, value)
        when PageObject::Elements::TextArea
          fill_field(element, value)
        when PageObject::Elements::SelectList
          fill_dropdown(element, value)
        when PageObject::Elements::CheckBox
          check_checkbox(element) if value == "true"
        when PageObject::Elements::Button
          @page_obj.send(to_symbol(element))
        when PageObject::Elements::Link
          @page_obj.send(to_symbol(element))
        else
          raise(RuntimeError, "Page-object element '#{element}' not supported.")
      end
    end

    def set_element_value_if_exists(element, value)
      wait_till_page_load
      element = (element =~ /Registered for GST/) ? "Registered for GST" : element
      if @page_obj.send(element_symbol(element)).visible? && @page_obj.send(element_symbol(element)).enabled? && value.present?
        case element_type?(element, value)
          when PageObject::Elements::RadioButton
            click_radio_button(element, value)
          when PageObject::Elements::TextField
            fill_field(element, value)
          when PageObject::Elements::TextArea
            fill_field(element, value)
          when PageObject::Elements::SelectList
            fill_dropdown(element, value)
          when PageObject::Elements::Button
            @page_obj.send(to_symbol(element))
          when PageObject::Elements::Link
            @page_obj.send(to_symbol(element))
          else
            raise(RuntimeError, "Page-object element '#{element}' not supported.")
        end
      else
        Prism.logger.debug "Element '#{element}' not visible nor enabled, Value: '#{value}'"
      end
    end

    private

    def is_not_set(element, value)
      val = @extjs_handler.get_dropdown_value(get_element_id(@page_obj, element))
      val != value
    end

    def print_field(element)
      @page_obj.send(to_symbol(element))
    end

    def element_type?(element, value)
      count = 2
      begin
        @page_obj.send(element_symbol(element))
      rescue
        sleep 1
        retry unless (count -= 1).zero?
        @page_obj.send(element_symbol("#{element} #{value}"))
      end
    end
  end
end
