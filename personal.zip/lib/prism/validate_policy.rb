module Prism
  class ValidatePolicy

    def initialize(screen_title)
      class_name = to_symbol(screen_title).to_s.camelize
      @page_obj = get_app_name::class_eval(class_name).new(Prism.capybara.page.driver.browser)
    end

    def validate_policy_number_format_on_summary(ref_data)
      page_element_exist?(@page_obj, 'policy_number')
      policy_number = @page_obj.policy_number
      correct_format?(policy_number,ref_data) ? policy_number : raise(RuntimeError, 'Policy Number error')
    end

    private

    def correct_format?(policy_number,ref_data)
      length = policy_number.length != 14 ? raise(RuntimeError, "Policy Number length error: #{policy_number}") : true
      format = /[A-Z]{4}\d{10}/.match(policy_number).nil? ? raise(RuntimeError, "Policy Number format error: #{policy_number}") : true
      lob = (ref_data[:line_of_business] =~ /Car Insurance/) ? "MOT" : "HOM"
      prefix = (policy_number.slice(0, 4).eql? (lob<<ref_data[:brand].slice(0, 1))) ? true : raise(RuntimeError, "Policy Number prefix error: #{policy_number}")
      length && format && prefix
    end
  end
end
