module Prism
  class Clicker

    def self.build(page_obj)
      new(page_obj.class.to_s)
    end

    def initialize(page, raise_exception=true)
      set_current_page(page)
    end

    # It performs a click action on a button/link and fires the event attached.
    # This might be handy if a link doesn't have an href and explicit action triggering
    # is required.
    def click_button(button)
      Prism.logger.debug "click_button('#{button}')"
      re_get_page_obj(@page_obj).send(element_symbol(button)).click
    end

    # It performs a click action on a button/link using page object without explicitly firing the event
    def click_element(element)
      wait_till_page_load
      Prism.logger.debug "Current page object: #{@page_obj}"
      @page_obj.send(element_symbol(element)).when_visible.click
      Prism.logger.debug "Element #{element} is clicked"
      wait_for_ajax
    end

    def click_element_if_exists(element)
      wait_till_page_load
      Prism.logger.debug "Current page object: #{@page_obj}"
      if @page_obj.send(element_symbol(element)).visible? && @page_obj.send(element_symbol(element)).enabled?
        @page_obj.send(element_symbol(element)).click
        Prism.logger.debug "Found Element #{element} and clicked"
        wait_for_ajax
      else
        Prism.logger.debug "Element #{element} not found"
      end
    end

    def click_checkbox(checkbox)
        page_element_exist?(@page_obj, checkbox)
        Prism.logger.debug "select_checkbox('#{checkbox}')"
        re_get_page_obj(@page_obj).send(to_symbol(checkbox))
    end

    def page_obj_click(button)
      page_element_exist?(re_get_page_obj(@page_obj), button)
      re_get_page_obj(@page_obj).send(to_symbol(button))
    end

    #TODO hack if not on same page
    def select_button(tries=Prism.max_tries)
      element = 'select'
      page_element_exist?(@page_obj, element)
      stop_condition = ->(){!re_get_page_obj(@page_obj).send(to_symbol("#{element}_element")).visible?}
      continuous_press(@page_obj, element, stop_condition)
    end

    def duplicate_payment(button)
      count = 5
      @page_obj = get_page_obj('EnterPaymentInformation')
      begin
        Prism.logger.debug "Duplicate message: '#{re_get_page_obj(@page_obj).duplicate_payment_element.text}'"
        if re_get_page_obj(@page_obj).duplicate_payment_element.visible?
          click_button(button)
        else
          raise(RuntimeError, 'duplicate panel not found')
        end
      rescue
        sleep 1
        retry unless (count -= 1).zero?
        Prism.logger.debug 'No duplicate panel found'
      end
    end

  end
end
