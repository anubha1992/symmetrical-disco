module Prism
  class PictImporter
    attr_accessor :jenkins_job_name, :jenkins_build_number, :excel_parser

    def initialize(*args)
      @jenkins_job_name, @jenkins_build_number = args
    end

    def import_file
      file_url = "https://swlibrary.iag.com.au/nexus/content/repositories/thirdparty/au/com/iag/datacreation/#{jenkins_job_name}/#{jenkins_build_number}/#{jenkins_job_name}-#{jenkins_build_number}.zip"
      scenario_tag = "pict_#{jenkins_job_name}_#{jenkins_build_number}"
      open(file_url) do |temp_file|
        Zip::File.open(temp_file.path) do |zip_file|
          zip_file.each do |entry|
            Prism.logger.info "Extracting #{entry.name}"

            # Read from-into memory
            file_content_array = entry.get_input_stream.read.split("\n")
            col_headers = file_content_array.shift.split(/\t|\r/)
            file_content_array.each_with_index do |row, index|
              scenario_id = "#{scenario_tag}_#{index}"
              scenario_hash = {
                scenario_id: scenario_id,
                scenario_tag: scenario_tag,
              }
              Prism.logger.info "Loading row: #{index} of #{file_content_array.count}" if index % 100 == 0
              Scenario.create!(scenario_hash.merge!(Hash[[col_headers, row.split(/\t|\r/)].transpose]))
            end
          end
        end
      end
    end

  end
end
