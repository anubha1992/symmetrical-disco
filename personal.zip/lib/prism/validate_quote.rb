module Prism
  class ValidateQuote

    def initialize(screen_title)
      class_name = to_symbol(screen_title).to_s.camelize
      @page_obj = get_app_name::class_eval(class_name).new(Prism.capybara.page.driver.browser)
    end

    def validate_quote_number_format_on_summary(ref_data)
      page_element_exist?(@page_obj, 'submission_number')
      quote_number = @page_obj.submission_number
      correct_format?(quote_number,ref_data) ? quote_number : raise(RuntimeError, 'Quote Number error')
    end

    private

    def correct_format?(quote_number,ref_data)
      brand = ref_data[:brand].present? ? ref_data[:brand] : ref_data[:account_information][0]['brand']
      length = quote_number.length != 14 ? raise(RuntimeError, "Quote Number length error: #{quote_number}") : true
      format = /[A-Z]{4}\d{10}/.match(quote_number).nil? ? raise(RuntimeError, "Quote Number format error: #{quote_number}") : true
      prefix = (quote_number.slice(0, 4).eql? ("QTE"<<brand.slice(0, 1))) ? true : raise(RuntimeError, "Quote Number prefix error: #{quote_number}")
      length && format && prefix
    end
  end
end
