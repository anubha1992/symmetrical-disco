module Prism
  class AlertHandler

    def initialize
      @page = Prism.capybara.page
    end

    def accept_alert
      wait = Selenium::WebDriver::Wait.new(:timeout => 30)
      wait.until {
        begin
          @page.driver.browser.switch_to.alert
          true
        rescue Selenium::WebDriver::Error::NoSuchAlertError
          false
        end
      }
      @page.driver.browser.switch_to.alert.accept
      wait_for_ajax
    end

    def cancel_alert
      wait = Selenium::WebDriver::Wait.new(:timeout => 30)
      wait.until {
        begin
          @page.driver.browser.switch_to.alert
          true
        rescue Selenium::WebDriver::Error::NoSuchAlertError
          false
        end
      }
      @page.driver.browser.switch_to.alert.dismiss
      wait_for_ajax
    end

   end
end