module Prism
  class XmlDiff

    def difference(xml_org, xml_new)
      is_passed = true
      xml_org.diff(xml_new) do |change, node|
        if change != ' '
          Prism.logger.info "=================== diff start ==================="
          Prism.logger.info "#{change} #{node.to_html}".ljust(30)
          Prism.logger.info "=================== diff stop ===================="
          is_passed = false
        end
      end
      Prism.logger.info "Policies are identical" if is_passed
      is_passed.should == true
    end

  end
end
