module Digital
  class DigitalLib

    def get_date_value(value)
      case value
      when 'today', 'tomorrow', 'yesterday', 'current'
        Date.send(value)
      when /^next_day|^prev_day|^next_month|^prev_month|^next_year|^prev_year/i
        value = value.downcase.split
        if value.count == 1
          Date.current.send(value[0])
        else
          Date.current.send(value[0], value[1].to_i)
        end
      when /(.*)days/i
        value = value.split(' ')
        if value[0] =~ /after/
          future_date = (Date.today+value[1].to_i)
        else
          past_date = (Date.today-value[1].to_i)
        end
      when /(.*)months/i
        value = value.split('')[0]
        (DateTime.now() >> value.to_i)
      when /(.*)year/i
        value = value.split(' ')
        if value[0] =~ /after/
          future_date = value[1].to_i.years.since
        else
          past_date = value[1].to_i.years.ago
        end
      else
        value
      end
    end

  end
end