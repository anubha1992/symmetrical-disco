require 'capybara'
require 'capybara/dsl'
require 'configuration'
require 'require_all'

require_all 'lib'

include Capybara::DSL
include RSpec::Matchers
include Prism::PageHandler
include ActionView::Helpers::NumberHelper

module Prism
  attr_accessor :logger

  class << self
    attr_accessor :configuration
  end

  def self.logger
    @logger ? @logger : logger_config
  end

  def self.logger_config
    @logger = Log4r::Logger.new('cc_logger')
    @logger.outputters = Log4r::Outputter.stdout
    if (ENV['CC_STATIC_LOG'])
      log_name = "#{Rails.root.join('log/reports/')}#{ENV['CC_STATIC_LOG']}.log"
    else
      log_name = "#{Rails.root.join('log/reports/')}#{Time.now.strftime('%F_%H-%M-%S')}.log"
    end
    log_file = Log4r::FileOutputter.new('cc_log_file', :filename => log_name)
    @logger.outputters << log_file

    # Set log level. Log level order is DEBUG < INFO < WARN < ERROR < FATAL
    @logger.level = "Log4r::#{Rails.application.secrets.test_config[:log_level].upcase}".constantize
    @logger
  end

  def self.configure
    self.configuration ||= Configuration.new
    yield(configuration)
    self.configuration.load_config
    unless (ENV['CC_SILENT'])
      Prism.logger.debug "CC config settings:"
      self.configuration.instance_values.each {|key, value| Prism.logger.debug "#{key} = #{value}"}
    end
    self.configuration
  end

  def self.change_configure
    self.configuration = Configuration.new
    yield(configuration)
    self.configuration.load_config
    unless (ENV['CC_SILENT'])
      Prism.logger.debug "CC config settings: #{self.configuration.instance_values}"
    end
    self.configuration
  end

  def self.load_configure
    Prism.logger.debug 'CC loading config settings....'
    self.configuration.load_config
    self.configuration
  end

  def self.method_missing(m, *args, &block)
    self.configuration.instance_variable_get("@#{m}") if self.configuration.instance_variable_names.include?("@#{m}")
  end

  def close_alerts(action='true')
    begin
      page.execute_script("window.confirm = function() { return #{action}; }")
      sleep 1
    rescue Selenium::WebDriver::Error::NoSuchAlertError => e
      Prism.logger.debug("No alert dialog present.")
    end
  end

end
