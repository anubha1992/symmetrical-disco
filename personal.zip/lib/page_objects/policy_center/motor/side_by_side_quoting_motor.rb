module PolicyCenter
  class SideBySideQuotingMotor
    include PageObject

    div(:quote_all, id: /SideBySideScreen-SideBySideToolbarButtonSet-QuoteAll/)
    div(:validate_all, id: /SideBySideScreen-SideBySideToolbarButtonSet-ValidateAll/)
    div(:add_side_by_side_version, id: /SideBySideScreen-SideBySideToolbarButtonSet-NewVersion/)
    div(:save_all, id: /SideBySideScreen-SideBySideToolbarButtonSet-SaveAll/)


    ##Tabs
    div(:name, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-BranchNameLabelId/)
    div(:policy_premium, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-InstallmentId/)

    ##Version 1
    div(:select_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-ActionButtonSetsId-0-SelectButtonId$/)
    div(:view_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-errorWarningPeriodInfoIterator-0-Resolve$/)
    select(:cover_type_version1, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehCoverTypeValue-0-coverTypeId$/)
    radio_group(:sum_insured_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-0-vehSumInsuredId/)
    text_field(:agreed_value_version1, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehAgreedValueId-0-AgreedValue_DV$/)
    checkbox(:choice_of_repairer_version1, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-0-vehCovRow-0-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:glass_extension_version1, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-1-vehCovRow-0-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:hire_vehicle_or_alternative_transport_after_incident_version1, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-2-vehCovRow-0-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    select(:vehicle_excess_version1, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehExcessTypeValue-0-coverTypeId$/)
    div(:fortnightly_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-FortNightlyItrId-0-FortNightly$/)
    div(:monthly_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-MonthlyItrId-0-FortNightly$/)
    div(:quarterly_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-QuarterlyItrId-0-Quarterly$/)
    div(:annual_debit_card_version1, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-AnnualItrId-0-Quarterly$/)
    span(:sum_insured_selected_version1, xpath: '//input[contains(@name,"JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-0-vehSumInsuredId") and @checked]/following::span[1][@class="gw-label--inner"]')

    ##Version 2
    div(:select_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-ActionButtonSetsId-1-SelectButtonId$/)
    div(:view_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-errorWarningPeriodInfoIterator-1-Resolve$/)
    select(:cover_type_version2, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehCoverTypeValue-1-coverTypeId$/)
    radio_group(:sum_insured_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-1-vehSumInsuredId/)
    text_field(:agreed_value_version2, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehAgreedValueId-1-AgreedValue_DV$/)
    checkbox(:choice_of_repairer_version2, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-0-vehCovRow-1-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:glass_extension_version2, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-1-vehCovRow-1-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:hire_vehicle_or_alternative_transport_after_incident_version2, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-2-vehCovRow-1-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    select(:vehicle_excess_version2, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehExcessTypeValue-1-coverTypeId$/)
    div(:fortnightly_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-FortNightlyItrId-1-FortNightly$/)
    div(:monthly_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-MonthlyItrId-1-FortNightly$/)
    div(:quarterly_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-QuarterlyItrId-1-Quarterly$/)
    div(:annual_debit_card_version2, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-AnnualItrId-1-Quarterly$/)
    span(:sum_insured_selected_version2, xpath: '//input[contains(@name,"JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-1-vehSumInsuredId") and @checked]/following::span[1][@class="gw-label--inner"]')


    ##Version 3
    div(:select_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-ActionButtonSetsId-2-SelectButtonId$/)
    div(:view_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-errorWarningPeriodInfoIterator-2-Resolve$/)
    select(:cover_type_version3, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehCoverTypeValue-2-coverTypeId$/)
    radio_group(:sum_insured_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-2-vehSumInsuredId/)
    text_field(:agreed_value_version3, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehAgreedValueId-2-AgreedValue_DV$/)
    checkbox(:choice_of_repairer_version3, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-0-vehCovRow-2-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:glass_extension_version3, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-1-vehCovRow-2-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:hire_vehicle_or_alternative_transport_after_incident_version3, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-2-vehLevelCoverages-2-vehCovRow-0-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    select(:vehicle_excess_version3, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehExcessTypeValue-2-coverTypeId$/)
    div(:fortnightly_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-FortNightlyItrId-2-FortNightly$/)
    div(:monthly_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-MonthlyItrId-2-FortNightly$/)
    div(:quarterly_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-QuarterlyItrId-2-Quarterly$/)
    div(:annual_debit_card_version3, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-AnnualItrId-2-Quarterly$/)
    span(:sum_insured_selected_version3, xpath: '//input[contains(@name,"JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-2-vehSumInsuredId") and @checked]/following::span[1][@class="gw-label--inner"]')


    ##Version 4
    div(:select_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-ActionButtonSetsId-3-SelectButtonId$/)
    div(:view_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-errorWarningPeriodInfoIterator-3-Resolve$/)
    select(:cover_type_version4, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehCoverTypeValue-3-coverTypeId$/)
    radio_group(:sum_insured_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-3-vehSumInsuredId/)
    text_field(:agreed_value_version4, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehAgreedValueId-3-AgreedValue_DV$/)
    checkbox(:choice_of_repairer_version4, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-0-vehCovRow-3-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:glass_extension_version4, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-1-vehCovRow-3-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    checkbox(:hire_vehicle_or_alternative_transport_after_incident_version4, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-2-vehCovRow-3-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId$/)
    select(:vehicle_excess_version4, name: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehExcessTypeValue-3-coverTypeId$/)
    div(:fortnightly_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-FortNightlyItrId-3-FortNightly$/)
    div(:monthly_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-MonthlyItrId-3-FortNightly$/)
    div(:quarterly_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-QuarterlyItrId-3-Quarterly$/)
    div(:annual_debit_card_version4, id: /JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-AnnualItrId-3-Quarterly$/)
    span(:sum_insured_selected_version4, xpath: '//input[contains(@name,"JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehSumInsuredValue-3-vehSumInsuredId") and @checked]/following::span[1][@class="gw-label--inner"]')


    div(:validation_results_tab, id: /wsTabBar-wsTab_0/)
    div(:clear, id: /ClearButton/)


    ##Payment Frequency And Installments
    def get_payment_frequency_and_installments(version)
      ph = Class.new.extend(Prism::PageHandler)
      page_obj = ph.get_page_obj('SideBySideQuotingMotor')
      payment_frequency = Hash.new
      fortnightly = page_obj.send("fortnightly_version#{version}")
      monthly = page_obj.send("monthly_version#{version}")
      quarterly = page_obj.send("quarterly_version#{version}")
      annual_debit_card = page_obj.send("annual_debit_card_version#{version}")
      payment_frequency.merge!({'fortnightly' => "#{fortnightly}"})
      payment_frequency.merge!({'monthly' => "#{monthly}"})
      payment_frequency.merge!({'quarterly' => "#{quarterly}"})
      payment_frequency.merge!({'annual' => "#{annual_debit_card}"})
      payment_frequency
    end

    def get_quote_data(version)
      expected_quote_details = {}
      @page_obj = get_page_obj('SideBySideQuotingMotor')
      cover_type = @page_obj.send(element_symbol("cover_type_version#{version}")).selected_options[0]
      sum_insured = @page_obj.send("sum_insured_selected_version#{version}")
      if sum_insured =~ /Agreed Value/
        agreed_value = @page_obj.send("agreed_value_version#{version}")
        sum_insured = "$" << agreed_value << ".00"
      end
      vehicle_excess = @page_obj.send(element_symbol("vehicle_excess_version#{version}")).selected_options[0]
      vehicle_excess = "$"<<vehicle_excess
      expected_quote_details.merge!({'cover_type' => "#{cover_type}"})
      expected_quote_details.merge!({'sum_insured' => "#{sum_insured}"})
      expected_quote_details.merge!({'vehicle_excess' => "#{vehicle_excess}"})
      expected_quote_details
    end

   # def select_cover_type(version,cover_type)
   #   element_id = 'SubmissionWizard-JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-vehicleSetsId-0-vehCoverTypeValue-'+version.to_s+'-coverTypeId'
   #   wait = Selenium::WebDriver::Wait.new(:timeout => 10)
   #   browser = Prism.capybara.page.driver.browser
   #   select_list = wait.until {
   #     element = browser.find_element(:id, element_id)
   #     element if element.displayed?
   #   }
   #   sleep(5)
   #   # select_list.select "#{cover_type}"
   #   select_list.select "#{cover_type}", :match => :prefer_exact
   # end

    # def select_sum_insured(version,value)
    #   val = (value =~ /false|Agreed Value/i) ? 1 : 0
    #   element_id = 'SubmissionWizard-JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-vehicleSetsId-0-vehSumInsuredValue-'+version.to_s+'-vehSumInsuredId_'+val.to_s
    #   wait = Selenium::WebDriver::Wait.new(:timeout => 10)
    #   browser = Prism.capybara.page.driver.browser
    #   radio_button = wait.until {
    #     element = browser.find_element(:id, element_id)
    #     element if element.displayed?
    #   }
    #   sleep(5)
    #   radio_button.click
    # end
    #
    # def enter_agreed_value(version,value)
    #   element_id = 'SubmissionWizard-JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-vehicleSetsId-0-vehAgreedValueId-'+version.to_s+'-AgreedValue_DV'
    #   wait = Selenium::WebDriver::Wait.new(:timeout => 10)
    #   browser = Prism.capybara.page.driver.browser
    #   text_field = wait.until {
    #     element = browser.find_element(:id, element_id)
    #     element if element.displayed?
    #   }
    #   text_field.set "#{value}"
    # end

    def select_optional_coverage(version,optional_coverage_type)
      version = version.to_i - 1
      optional_coverage_type.each do |key, value|
        optional_coverages = {"Choice of Repairer" => "0", "Glass Extension" => "1", "Hire Vehicle or Alternative Transport after Incident" => "2"}
        if value =~ /Yes/i
          coverage_type = optional_coverages["#{key}"]
          sleep(3)
          # optional_coverage_checkbox = 'SubmissionWizard-JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-'+coverage_type.to_s+'-vehCovRow-'+version.to_s+'-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId'
          optional_coverage_checkbox = '//div[contains(@name, "JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-0-vehLevelCoverages-'+coverage_type.to_s+'-vehCovRow-'+version.to_s+'-targetedCovTermId-SideBySideCovTermInputSet-covTermEnabledId")]'
          Prism.logger.info "selecting optional coverage => #{key}"
          wait = Selenium::WebDriver::Wait.new(:timeout => 15)
          browser = Prism.capybara.page.driver.browser
          checkbox = wait.until {
            element = browser.find_element(:xpath, optional_coverage_checkbox)
            element if element.displayed?
          }
          sleep(5)
          checkbox.click
        end
      end
    end

    # def select_vehicle_excess(version,excess)
    #   element_id = 'SubmissionWizard-JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-vehicleSetsId-0-vehExcessTypeValue-'+version.to_s+'0-coverTypeId'
    #   wait = Selenium::WebDriver::Wait.new(:timeout => 10)
    #   browser = Prism.capybara.page.driver.browser
    #   select_list = wait.until {
    #     element = browser.find_element(:id, element_id)
    #     element if element.displayed?
    #   }
    #   select_list.select "#{excess}"
    # end

    def select_version(version)
      version = version.to_i - 1
      # element_id = 'SubmissionWizard-JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-ActionButtonSetsId-'+version.to_s+'-SelectButtonId'
      element_id = '//div[contains(@id, "JobWizardToolsMenuWizardStepSet-SideBySideScreen-SideBySideTableLayoutDV-Iag_SideBySidePaymentFrequencyInputSet-ActionButtonSetsId-'+version.to_s+'-SelectButtonId")]'
      wait = Selenium::WebDriver::Wait.new(:timeout => 10)
      browser = Prism.capybara.page.driver.browser
      button = wait.until {
        element = browser.find_element(:xpath, element_id)
        element if element.displayed?
      }
      button.click
    end


  end
end