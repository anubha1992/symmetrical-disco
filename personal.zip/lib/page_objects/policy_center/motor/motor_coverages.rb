module PolicyCenter
  class MotorCoverages
    include PageObject

    div(:warning_msg, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-_msgs/)
    div(:next, id: /Next/)
    div(:quote, id: /QuoteTypeToolbarButtonSet-Quote/)
    div(:back, id: /Prev/)
    div(:save, id: /Draft/)
    div(:close_options, id: /CloseOptions/)
    div(:withdrawn, id: /CloseOptions-WithdrawJob/)
    div(:edit_pol_transaction, id: 'RenewalWizard-LOBWizardStepGroup-LineWizardStepSet-Iag_PMLineCoveragesScreen-JobWizardToolbarButtonSet-EditPolicyWorkflow')

    div(:embargo_text, id: /EmbargoWarning/)

    select(:cover_type, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-Iag_ProdModel_Variation/)

    # Vehicle table
    div(:vehicle_table_div, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV$/)
    table(:vehicle_table) {vehicle_table_div_element.table_element}
    rows(:vehicle_table_rows, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV-\d+-\d+/)

    #Sum Insured
    radio_group(:sum_insured, name: /Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-Suminsured_DV/)
    div(:base, id: /-Iag_PM_VehicleBaseValue$/)
    div(:minimum, id: /-Iag_PM_VehicleMinValue$/)
    div(:maximum, id: /-Iag_PM_VehicleMaxValue$/)
    text_field(:agreed_value, xpath: '//input[contains(@name,"-AgreedValue_DV")]')

    #Tabs
    div(:coverage_details_tab, xpath: '//div[contains(@id,"VehicleCoverageDetailsCardTab")]')
    div(:embargo_conditions_tab, xpath: '//div[contains(@id,"ExclusionsCoverageDetailsCardTab")]')
    div(:special_conditions_tab, xpath: '//div[contains(@id,"ConditionalExclusionCardTab")]')


    #Excess table
    select(:vehicle_excess, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-VehicleExcess/)
    text_field(:imposed_vehicle_excess, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-ImposedVehicleExcess/)
    div(:additional_driver_excess_table_div, xpath: '//div[contains(text(),"Additional Driver")]/following::div[contains(@id,"Iag_PMVehicleExcessPanelSet")][1]')
    text_field(:imposed_driver_excess, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-0-DriverImposed/)
    div(:undisclosed_driver_over_25, xpath: '//div[contains(@id,"Undisclosedabove25")]/descendant::div[@class="gw-value-readonly-wrapper"]')
    div(:undisclosed_driver_under_25, xpath: '//div[contains(@id,"UndisclosedBelow25")]/descendant::div[@class="gw-value-readonly-wrapper"]')

    #Discounts
    div(:online_discount, xpath: '//div[contains(@id,"OnlineDiscount")]/descendant::div[@class="gw-value-readonly-wrapper"]')
    div(:staff_discount, xpath: '//div[contains(@id,"StaffDiscount")]/descendant::div[@class="gw-value-readonly-wrapper"]')

    #Overrides & Loadings
    text_field(:percentage, name: /Percentage/)
    select(:percentage_duration, name: /PercentageDuration/)
    select(:percentage_reason, name: /PercentageReason/)
    text_field(:dollar, name: /Dollar/)
    select(:dollar_duration, name: /DollarDuration/)
    select(:dollar_reason, name: /DollarReason/)

    # Optional Coverages
    checkbox(:any_repairer_option, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-AUPMVehicleExcess-Iag_PMVehicleOptionalCovs-Iag_PMVehicleCoverageDetailDV-0-CoverageInputSet-CovPatternInputGroup-_checkbox$/)
    checkbox(:glass_extension, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-AUPMVehicleExcess-Iag_PMVehicleOptionalCovs-Iag_PMVehicleCoverageDetailDV-1-CoverageInputSet-CovPatternInputGroup-_checkbox$/)
    checkbox(:hire_vehicle, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-AUPMVehicleExcess-Iag_PMVehicleOptionalCovs-Iag_PMVehicleCoverageDetailDV-2-CoverageInputSet-CovPatternInputGroup-_checkbox$/)

    ##For Side-By-Side Quote(sbsq)
    div(:cover_type_sbsq, id: /LOBWizardStepGroup-LineWizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-Iag_ProdModel_Variation$/)
    div(:sum_insured_sbsq, id: /LOBWizardStepGroup-LineWizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-Suminsured_DV$/)
    div(:agreed_value_sbsq, id: /LOBWizardStepGroup-LineWizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-AgreedValue_DV$/)
    div(:vehicle_excess_sbsq, id: /LOBWizardStepGroup-LineWizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-Iag_PMVehicleExcessPanelSet-VehicleExcessID$/)

    #Embargo
    div(:embargo_conditions_tab, id: /Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-VehicleExclusionsCoverageDetailsCardTab/)
    div(:embargo_warning_msg, xpath: '//div[@class="gw-message" and contains(text(),"Embargo Conditions")]')

    #hard stop for sum insured policy change
    div(:sum_insured_hard_stop_beyond_cooling_off, xpath: '//div[@class="gw-message" and contains(text(),"Changes to sum insured are only acceptable during cooling off period")]')
    div(:sum_insured_hard_stop_within_cooling_off, xpath: '//div[@class="gw-message" and contains(text(),"Changes to sum insured must be effective the same date as the policy effective date")]')

    #Validation Results
    div(:validation_results_tab, id: 'wsTabBar-wsTab_0')
    div(:clear, id: 'WebMessageWorksheet-WebMessageWorksheetScreen-WebMessageWorksheet_ClearButton')
    div(:warning_message, id: /WebMessageWorksheet-WebMessageWorksheetScreen-grpMsgs/)

    #digital
    divs(:vehicle_numbers, xpath: '//div[contains(@id,"VehicleNumber") and @class="gw-TextValueWidget gw-styleTag--CellWidget gw-ValueWidget gw-readonly"]')
    radio(:sum_insured_selected, xpath: '//input[contains(@name,"Suminsured_DV") and @checked]')

    #side_menu
    div(:coverages_side_menu,id:/LineCoverages/)

    #warning
    div(:generic_warning, xpath:'//div[@class="gw-subGroupLabel gw-text" and contains(text(),"Warnings:")]')

    def cover_types
      options = self.send("cover_type_element").options.collect(&:inner_html)
      return options
    end

    def select_vehicle(vehicle_no)
      self.vehicle_table_element.cell_element(text: vehicle_no.to_s).click
    end

    ##Get Selected Optional Coverages for Side By Side Quote
    def get_selected_optional_coverages
      script = %|
      var values = [];
      var labels = document.querySelectorAll('.gw-InputGroup--header, .gw-InputGroupCheckboxValueWidget gw-placeholder gw-value-ph')
      labels.forEach(label => {
          values.push(label.textContent)
      });
       return values;
      |
      @page.execute_script(script)
    end

    ##To get list of all Standard Coverages from UI
    def standard_coverages
      script = %|
        var values = [];
        var labels = document.querySelectorAll('.gw-label.gw-boldLabel')
        labels.forEach(label => {
        if (!label.textContent.endsWith("Excess") && !label.textContent.endsWith("Excesses") && !label.textContent.includes("Adjustment")){
        values.push(label.textContent)
         }
        });
       return values
      |
      @page.execute_script(script)
    end

    ##To get list of all Optional Coverages from UI
    def optional_coverages
      script = %|
         var uncheckedValues = [];
           document.querySelectorAll('input[type=checkbox]:not(:checked)').forEach(checked => {
	        var labelParent = checked.parentElement.parentElement.parentElement;
	       uncheckedValues.push(labelParent.querySelector('.gw-InputGroup--header--label').textContent)
	      });
       return uncheckedValues;
      |
      @page.execute_script(script)
    end

    ##To Check all the Optional Coverages
    # def check_optional_coverages
    #   script = %|
    #      	var uncheckedValues = document.querySelectorAll('input[type=checkbox]:not(:checked)')
    #       uncheckedValues.forEach(checkbox=>checkbox.click());
    #    |
    #   @page.execute_script(script)
    # end

    ##Select all the Optional Coverages checkbox
    def check_all_optional_coverages
      begin
        wait = Selenium::WebDriver::Wait.new(:timeout => 15)
        browser = Prism.capybara.page.driver.browser
        optional_coverages_list = '//div[@class="gw-InputGroup--header"]'
        browser.find_elements(:xpath, optional_coverages_list)
        optional_coverages_list_size = wait.until {
          list = browser.find_elements(:xpath, optional_coverages_list)
          count = list.length
          count if count > 0
        }

        (0..optional_coverages_list_size-1).each do |index|
          optional_coverage_checkbox = 'SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-Iag_PMLineCoveragesScreen-Iag_PMPerVehiclePanelSet-VehiclesListDetailPanel-VehicleCoverageDetailsCV-AUPMVehicleExcess-Iag_PMVehicleOptionalCovs-Iag_PMVehicleCoverageDetailDV-'+index.to_s+'-CoverageInputSet-CovPatternInputGroup-_checkbox'
          Prism.logger.debug "Selected ##{index+1} checkbox from the Optional Coverages List"
          coverage = wait.until {
            element = browser.find_element(:name, optional_coverage_checkbox)
            element if element.displayed?
          }
          sleep(3)
          coverage.click
        end
      rescue Exception => e
        Prism.logger.info "An error has occurred while selecting an optional coverage: #{e}"
      end
    end

    ##To uncheck all the Optional Coverages checkbox
    def uncheck_optional_coverages
      script = %|
         	var uncheckedValues = document.querySelectorAll('input[type=checkbox]:checked')
          uncheckedValues.forEach(checkbox=>checkbox.click());
       |
      @page.execute_script(script)
    end

    ##To get list of Cover Limits of Standard and Optional Coverages together
    def coverage_limits
      script = %|
        var values = {};
			  var labels = document.querySelectorAll('.gw-InputGroup--header--label, .gw-InputWidget>.gw-label')
				labels.forEach(label => {
		  	var parent = label.parentElement
		  	var value = parent.querySelector("div.gw-RangeValue, div.gw-value")
		    if(value === null){value = ""}
		      else{value = value.textContent}
		  	if(!label.textContent.includes("Cover Type") && !label.textContent.endsWith("after Incident") && !label.textContent.includes("Excess")
           && !label.textContent.includes("Driver") && !label.textContent.includes("Adjustment") && !label.textContent == ""
           && !label.textContent.includes("Value") && !label.textContent.startsWith("Sum Insured") && !label.textContent.startsWith("Dollar") && !label.textContent.startsWith("Percentage")){
			   values[label.textContent] = value
			  }});
        if ("Hire Vehicle Limit" in values)
            {values["Hire Vehicle or Alternative Transport after Incident"] = values["Hire Vehicle Limit"]
             delete values["Hire Vehicle Limit"]
            };
         return values;
         |
      @page.execute_script(script)
    end

    def check_date(date_str)
      to = Time.now.strftime('%Y')
      from = 1.years.ago.strftime('%Y')
      is_present = (from..to).include?(date_str)
      if is_present == true
        return 1
      else
        to = 1.years.ago.strftime('%Y')
        from = 2.years.ago.strftime('%Y')
        is_present1 = (from..to).include?(date_str)
        if is_present1 == true
          return 2
        else
          to = 2.years.ago.strftime('%Y')
          from = 3.years.ago.strftime('%Y')
          is_present2 = (from..to).include?(date_str)
          if is_present2 == true
            return 3
          end
        end
      end
    end

    def round_off_excess_values(excess_value)
      @found = 0
      @point = 50
      @excess_number =0
      if excess_value % 50 == 0 || excess_value == 0
        @excess_number = excess_value
        Prism.logger.info "Excess value is : #{@excess_number}"
      else
        excess_value_final = excess_value - 0
        if excess_value_final.abs < 25
          @found = 1
          Prism.logger.info "Excess value is : 0"
          @excess_number = 0
        end
        while @found == 0 do
          diff = excess_value.abs - @point
          diff = diff.abs
          Prism.logger.info "Difference is : #{diff}"
          if diff < 25
            @found = 1
            Prism.logger.info "Excess value is : #{@point}"
            @excess_number = @point
          end
          if diff == 25
            @found = 1
            Prism.logger.info "Excess value is : #{@point + 50}"
            @excess_number = @point + 50
          end
          @point = @point + 50
        end

      end
      return @excess_number
    end

    ##To check optional coverages
    def select_optional_coverage(optional_coverage_type)
      optional_coverage_type.each do |key, value|
        if value =~ /Yes/i
          coverage_type = key
          optional_coverage_checkbox = "//div[@class='gw-InputGroup--header--label' and contains(text(),'"+coverage_type+"')]/preceding::input[1][contains(@name,'CoverageInputSet-CovPatternInputGroup-_checkbox')]/ancestor::div[contains(@id,'CovPatternInputGroup-_checkbox')]"
          Prism.logger.info "selecting optional coverage => #{key}"
          wait = Selenium::WebDriver::Wait.new(:timeout => 15)
          browser = Prism.capybara.page.driver.browser
          coverage_checkbox = wait.until {
            element = browser.find_element(:xpath, optional_coverage_checkbox)
            element if element.displayed?
          }
          sleep(5)
          coverage_checkbox.click
        end
      end
    end

    def validate_embargo_conditions_and_override(embargo_data)
      self.embargo_conditions_tab_element.click
      sleep 2
      reason_dropdown_xpath = ""
      embargo_condition_xpath = ""
      actual_embargo_data = []
      expected_embargo_data = []
      puts "@embargo_data #{embargo_data}"
      embargo_data.each_with_index do |embargo, count|
        expected_embargo_text = {}
        actual_embargo_text = {}
        puts "embargo #{embargo}"
        peril = embargo[:peril]
        @severity = embargo[:embargo_severity]
        end_date = Date.parse(embargo[:embargo_end_date]).strftime("%d/%m/%Y")

        if @severity == "E"
        embargo_condition_xpath = "//div[@class='gw-label gw-boldLabel' and text() = 'Damages by #{peril}']"
        elsif @severity == "R"
        embargo_condition_xpath = "//div[@class='gw-label gw-boldLabel' and text() = 'Policy Refusal']"
        end
        if @severity == "E"
          peril_txt = peril == "Storm Surge" ? "S" : peril
          embargo_end_date = "//div[contains(@id,'#{peril_txt}ValidUntil')]//following::div[@class='gw-value-readonly-wrapper']"
        elsif @severity == "R"
          embargo_end_date = "//div[contains(@id,'RefusalValidUntil')]//following::div[@class='gw-value-readonly-wrapper']"
        end

        wait = Selenium::WebDriver::Wait.new(:timeout => 15)
        browser = Prism.capybara.page.driver.browser
        @element_present = @browser.find_elements(:xpath, embargo_condition_xpath).count
        expect(@element_present).to eq 1

        #Validate Embargo text
        actual_embargo_condition = @browser.find_element(:xpath, embargo_condition_xpath).text
        actual_embargo_text[:embargo_condition] = actual_embargo_condition

        if @severity == "E"
          expected_embargo_condition = "Damages by #{peril}"
        elsif @severity == "R"
          expected_embargo_condition = "Policy Refusal"
        end
        expected_embargo_text[:embargo_condition] = expected_embargo_condition

        Prism.logger.info "Expected Embargo text - #{expected_embargo_text}, Actual Embargo text - #{actual_embargo_text}"
        expect(actual_embargo_text).to eql(expected_embargo_text)

        #Validate Embargo End Date
        actual_embargo_end_date = @browser.find_element(:xpath, embargo_end_date).text
        actual_embargo_text[:embargo_end_date] = actual_embargo_end_date
        expected_embargo_end_date = "#{end_date}"
        expected_embargo_text[:embargo_end_date] = expected_embargo_end_date
        actual_embargo_data << actual_embargo_text
        expected_embargo_data << expected_embargo_text
      end
      Prism.logger.info "Expected Embargo end date - #{expected_embargo_data}, Actual Embargo end date - #{actual_embargo_data}"
      expect(actual_embargo_data.sort_by { |h| h.first.first }).to eql(expected_embargo_data.sort_by { |h| h.first.first })

      ##Select embargo override reason
      if @element_present > 0
        self.select_embargo_override_reason
      end

    end

    ##override the embargo
    def select_embargo_override_reason
      reason_dropdown_xpath = "//select[contains(@name, 'Iag_PMEmbargoExclusionDV')]"
      wait = Selenium::WebDriver::Wait.new(:timeout => 15)
      select_reason = wait.until {
        element = browser.find_element(:xpath, reason_dropdown_xpath)
        element if element.displayed?
      }
      sleep(5)
      # select_reason.all(:css, 'option').find {|o| o.text = 'UW Override'}.select_option
      options=select_reason.find_elements(:tag_name => "option")
      options.each do |opt|
        if opt.text == "UW Override"
          opt.click
          break
        end
      end
      Prism.logger.info "Selected reason"
    end

    #To unselect motor exclusion
    def unselect_motor_exclusion(exclusion)
      motor_exclusion_checkbox = "//div[@class='gw-InputGroup--header--label' and contains(text(),'"+exclusion+"')]/preceding::input[1][contains(@name,'CoverageInputSet-CovPatternInputGroup-_checkbox')]/ancestor::div[contains(@id,'CovPatternInputGroup-_checkbox')]"
      Prism.logger.info "Unselecting motor exclusion => #{exclusion}"
      wait = Selenium::WebDriver::Wait.new(:timeout => 15)
      browser = Prism.capybara.page.driver.browser
      exclusion_checkbox = wait.until {
        element = browser.find_element(:xpath, motor_exclusion_checkbox)
        element if element.displayed?
      }
      sleep(5)
      exclusion_checkbox.click
    end

    #To get motor exclusion header text
    def get_motor_exclusion_header(exclusion)
      motor_exclusion_header = "//div[@class='gw-InputGroup--header--label' and contains(text(),'"+exclusion+"')]"
      Prism.logger.info "Get motor exclusion header text for => #{exclusion}"
      wait = Selenium::WebDriver::Wait.new(:timeout => 15)
      browser = Prism.capybara.page.driver.browser
      exclusion_header = wait.until {
        element = browser.find_element(:xpath, motor_exclusion_header)
        element if element.displayed?
      }
      sleep(5)
      exclusion_header_text = exclusion_header.text
    end

    #To get motor exclusion description
    def get_motor_exclusion_description(exclusion)
      motor_exclusion_description = "//div[@class='gw-value-readonly-wrapper' and contains(text(),'"+exclusion+"') and not(contains(text(),'Exclude'))]"
      Prism.logger.info "Get motor exclusion description for => #{exclusion}"
      wait = Selenium::WebDriver::Wait.new(:timeout => 15)
      browser = Prism.capybara.page.driver.browser
      exclusion_description = wait.until {
        element = browser.find_element(:xpath, motor_exclusion_description)
        element if element.displayed?
      }
      sleep(5)
      exclusion_description_text = exclusion_description.text
    end


  end
end


