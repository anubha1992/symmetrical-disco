module PolicyCenter
  class Drivers
    include PageObject

    div(:warning_msg, id: /SubmissionWizard-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-_msgs/)
    div(:next, id: /Next/)
    div(:edit_policy_transaction, id: /EditPolicy$/)
    div(:quote, id: /JobWizardToolbarButtonSet-QuoteTypeToolbarButtonSet-Quote/)
    div(:save, id: /Draft/)
    div(:close_options, id: /JobWizardToolbarButtonSet-CloseOptions/)
    div(:withdrawn, id: /CloseOptions-WithdrawJob/)

    div(:embargo_text, id: /EmbargoWarning/)
    ## Add driver
    div(:driver_name, id: /Iag_PMDriversScreen-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV-0-Name/)
    div(:add_driver_button, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV_tb-AddDriver/)
    divs(:driver_menu_items) { add_driver_button_element.div_elements(:id => /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV_tb-AddDriver/) }
    div(:other_contacts, id: /Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV_tb-AddDriver-AddExistingContact$/)
    div(:select_contact, id: /Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV_tb-AddDriver-AddExistingContact-0-UnassignedDriver/)

    ##Tabs
    div(:driver_details_tab, id:/'Iag_PMNewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactRoleDetailCardTab/)
    div(:roles_tab, id: /-LOBWizardStepGroup-Line.*WizardStepSet-IagPM_DriversScreen-IagPM_DriversPanelSet-DriversListDetailPanel-DriverDetailsCV-RolesCardTab/)
    div(:addresses_tab, id: /-LOBWizardStepGroup-Line.*WizardStepSet-IagPM_DriversScreen-IagPM_DriversPanelSet-DriversListDetailPanel-DriverDetailsCV-AddressDetailCardTab/)

    ##Driver Details Tab
    text_field(:first_name, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalPersonNameInputSet-FirstName$/)
    text_field(:last_name, name:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalPersonNameInputSet-LastName$/)
    text_field(:date_of_birth, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-PolicyContactRoleNameInputSet-DateOfBirth$/)
    select_list(:gender, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-PolicyContactRoleNameInputSet-Iag_Gender$/)
    select_list(:title, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-PolicyContactRoleNameInputSet-Iag_GlobalContactTitleInputSet-Prefix$/)
    text_field(:address1, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_AddressInputSet-Iag_Address1$/)
    text_field(:suburb, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_AddressInputSet-Iag_Suburb$/)
    text_field(:state, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_AddressInputSet-Iag_State$/)
    text_field(:postcode, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_AddressInputSet-Iag_PostCode$/)

    ##Driver Questions
    text_field(:at_what_age_did_you_obtain_drivers_license, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_LicObtAge/)
    text_field(:age_drivers_license_obtained, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_LicObtAge/)
    radio_group(:any_at_fault_incidents, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_AtFaultIncident$/)
    div(:incident_details_add_btn, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-IncidentDetailsLV_tb-Add$/)
    radio_group(:license_disqualified_cancelled_or_suspended, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_IsLicCancelled$/)
    div(:event_details_add_btn, id:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-EventDetailsLV_tb-Add$/)
    text_field(:event_date, xpath: '//input[@type="text" and contains(@name,"Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-EventDetailsLV") and @value=""]')
    select(:event_type, xpath: '//option[@selected and @value=""]/parent::select[contains(@name,"Iag_LicenceEventTypeID")]')
    text_field(:incident_date,xpath: '//input[@type="text" and contains(@name,"Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-IncidentDetailsLV") and @value=""]')
    select(:event_length, xpath: '//option[@selected and @value=""]/parent::select[contains(@name,"Iag_LicEventLengthID")]')
    div(:incident_count,xpath:'(//div[contains(@id,"IncidentNum")]/descendant::div[@class="gw-value-readonly-wrapper"])[position()=last()]')
    div(:event_count,xpath:'(//div[contains(@id,"EventNumber")]/descendant::div[@class="gw-value-readonly-wrapper"])[position()=last()]')

    # Vehicle table
    div(:vehicle_table_div, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-VehiclesLV$/)
    table(:vehicle_table) { vehicle_table_div_element.table_element }
    divs(:vehicle_numbers,xpath:'//div[contains(@id,"VehicleNumber") and @class="gw-TextValueWidget gw-styleTag--CellWidget gw-ValueWidget gw-readonly"]')
    rows(:vehicle_table_rows, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-VehiclesLV-\d+-\d+/)

    #driver table
    div(:driver_table_div,id: /^.*LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV$/)
    table(:driver_table){drivers_table_div_element.table_elements[0]}
    divs(:driver_table_rows,xpath:'//div[contains(@id,"Name") and @class="gw-TextValueWidget gw-styleTag--CellWidget gw-ValueWidget gw-readonly"]')
    div(:driver_name,xpath:'//div[contains(@id,"Name") and @class="gw-TextValueWidget gw-styleTag--CellWidget gw-ValueWidget gw-readonly"]/descendant::div[@class="gw-value-readonly-wrapper"]')
    div(:driver_age, xpath:'//div[contains(@id,"Iag_Age")]/descendant::div[@class="gw-value-readonly-wrapper"]')
    checkboxes(:driver_checkbox, xpath:'//input[contains(@name,"_Checkbox") and @data-gw-click="noOp"]')
    div(:remove, id: /tb-Remove/)
    checkbox(:drivers_selection, name: /Iag_PMDriversPanelSet-DriversListDetailPanel-DriversLV-_Checkbox/)

    #faults and offence
    div(:fault_table_div, id:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-IncidentDetailsLV$/)
    table(:fault_table){fault_table_div_element.table_elements[0]}
    div(:offence_table_div, id:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-8$/)
    table(:offence_table){offence_table_div_element.table_elements[0]}
    div(:incident_table_div, id:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-IncidentDetailsLV$$/)
    table(:incident_table){incident_table_div_element.table_element}
    div(:event_table_div, id:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-EventDetailsLV$$/)
    table(:event_table) {event_table_div_element.table_element}

    span(:at_fault_incidents_selected_text, xpath:'//input[contains(@name,"Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_AtFaultIncident") and @checked]/following::span[1][@class="gw-label--inner"]')
    span(:is_licence_disqualified_selected_text, xpath:'//input[contains(@name,"Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-Iag_IsLicCancelled") and @checked]/following::span[1][@class="gw-label--inner"]')
    text_fields(:incident_dates, xpath:'//input[contains(@name,"IncidentDate")]')
    text_fields(:event_dates, xpath:'//input[contains(@name,"EventDate")]')


    #Incident Selected Text
    text_field(:event_date_entered, xpath: '//input[@type="text" and contains(@name,"Iag_PMDriversScreen-Iag_PMVehicleDriverPanelSet-VehiclesListDetailPanel-Iag_PMDriversPanelSet-DriversListDetailPanel-DriverDetailsCV-Iag_PolicyContactDetailsDV-EventDetailsLV")]')
    select(:event_type_selected, xpath: '//option[@selected]/parent::select[contains(@name,"Iag_LicenceEventTypeID")]')
    select(:event_length_selected, xpath: '//option[@selected]/parent::select[contains(@name,"Iag_LicEventLengthID")]')

    #digital
    radio(:license_obtained_checked, xpath: '//input[contains(@name,"Iag_IsLicCancelled") and @checked]')

    def add_driver(driver_type='New Person')
      self.add_driver_button_element.click
      self.driver_menu_items_elements.each_with_index do |menu_element, index|
        if menu_element.element.text =~ /^#{driver_type}$/i
          if driver_type =~ /^Other Contacts$/i
            ## open sub menu, get the first driver and assign as driver type to be picked
            menu_element.element.hover
            existing_driver_name = menu_element.element.text.split("\n")
            driver_type = existing_driver_name[1] if existing_driver_name.any?
          else
            ## no sub menu, select the driver
            menu_element.click
            break
          end
        end
      end
    end

    def driver_add(menu_item)
      self.add_driver_button_element.click
      self.other_contacts_element.hover
      self.add_driver_button_element.div_element(text: menu_item).click
    end

    def random_date_in_three_years()
      to = Time.now
      from  = 3.years.ago
      rand_time = Time.at(from + rand * (to.to_f - from.to_f))
      rand_date = rand_time.strftime('%Y')
      rand_date
    end

    def add_incidents(incidents)
      incidents.each_with_index do |incident,incident_count|
        add_incidents = {page:'Drivers'}
        add_incidents[:incident_details_add_btn] = "should_click"
        add_incidents[:incident_type] = incident[:incident_type] if incident[:incident_type].present?
        add_incidents[:incident_date] = random_date_in_three_years if incident[:incident_date].present?
        page_populator = Prism.app::PagePopulator.new('Drivers', @ref_data)
        page_populator.populate_page_with(add_incidents.with_indifferent_access)
      end
    end

    def add_events(events)
      events.each_with_index do |event, event_count|
        add_events = {page:'Drivers'}
        add_events[:event_details_add_btn] = "should_click"
        add_events[:event_type] = event[:event_type] if event[:event_type].present?
        add_events[:event_length] = event[:event_length] if event[:event_length].present?
        add_events[:event_date] = event[:event_date].present? ? event[:event_date] : random_date_in_three_years
        page_populator = Prism.app::PagePopulator.new('Drivers', @ref_data)
        page_populator.populate_page_with(add_events.with_indifferent_access)
      end
    end

    def get_gender_dropdown_values
      options = self.send("gender_element").options.collect(&:inner_html)
      return options
    end

    def get_title_dropdown_values
      options = self.send("title_element").options.collect(&:inner_html)
      return options
    end

    def select_vehicle(vehicle_no)
      self.vehicle_table_element.cell_element(text: vehicle_no.to_s).click
    end

    def get_event_data
      event_data = Hash.new
      event_type = self.send('event_type_selected_element').selected_options[0]
      event_length = self.send('event_length_selected_element').selected_options[0]
      event_date = self.send('event_date_entered')

      event_data.merge!({"event_type" => "#{event_type}"})
      event_data.merge!({"event_length" => "#{event_length}"})
      event_data.merge!({"event_date" => "#{event_date}"})
      event_data
    end

  end
end