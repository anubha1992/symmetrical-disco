module PolicyCenter
  class FinanceProvider
    include PageObject

    # div(:error_msg, id: /-ContactDetailScreen-_msgs-0-0/)
    # div(:ok, id: /Update/)
    # div(:cancel, id: /Cancel/)
    select(:finance_provider_name, name: 'Iag_FinanceProviderListPopup-FinanceProvider')


    # ##Tabs
    # div(:contact_detail_tab, id: /NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactRoleDetailCardTab/)
    # div(:phone_details_tab, id: /NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_PhonelDetailTab/)
    # div(:additional_details_tab, id: /NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_AdditionalDetailTab/)
    # div(:addresses_tab, id: /NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-AddressesCardTab/)

    ##Contact Detail
    ##Person & Company
    # text_field(:company_name, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalContactNameInputSet-Name')
    # text_field(:first_name, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalPersonNameInputSet-FirstName')
    # text_field(:last_name, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalPersonNameInputSet-LastName')
    # text_field(:date_of_birth, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-DateOfBirth')
    # select(:gender, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-Iag_Gender')
    # select(:title, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-Iag_GlobalContactTitleInputSet-Prefix')
    # text_field(:primary_email, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-EmailAddress1')
    #
    #
    # ##Address
    # select(:country, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Country')
    # text_field(:building_name, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_BuildingName')
    # text_field(:address_search, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_AddressSearch')
    # checkbox(:manual_address_entry, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_ManualFlag')
    # select(:flat_unit_type, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-FlatUnitType')
    # text_field(:flat_unit_number, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-FlatUnitNumber')
    # select(:floor_level_type, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-FloorLevelType')
    # text_field(:floor_level_number, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-FloorLevelNumber')
    # text_field(:lot_number, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-LotNumber')
    # text_field(:street_number, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-StreetNumber')
    # text_field(:street_name, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-StreetName')
    # select(:street_type, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-StreetType')
    # select(:street_direction, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-StreetDirection')
    # text_field(:suburb, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_Suburb')
    # select(:state, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-State')
    # text_field(:postcode, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-PostalCode')
    # select(:organization_type, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-Iag_OrgType')
    # text_field(:abn, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-Iag_ABN')
    # text_field(:acn, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-Iag_ACN')
    #
    # ##Phone Details
    # select(:phone_type, name:/PhoneDetailLV-0-Type/)
    # text_field(:phone_number, name: /-Iag_PhoneDetailPanelSet-PhoneDetailLV-0-Number/)
    #
    # ##Additional Detail
    # text_field(:employee_id, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_ContactAddDetail-Iag_CreateContactAddDetailDV-Iag_EmployeeID')
    # select(:employee_type, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_ContactAddDetail-Iag_CreateContactAddDetailDV-Iag_EmployeeType')
    # select(:declined_or_referred, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_InsuranceType')
    # select(:classification, name: 'NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_ProtectedAccType')
    # select(:brand, name: /NewAdditionalInterestPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_Brand/)
    #
    # def get_gender_dropdown_values
    #   options = self.send("gender_element").options.collect(&:inner_html)
    #   return options
    # end

    # def get_title_dropdown_values
    #   options = self.send("title_element").options.collect(&:inner_html)
    #   return options
    # end

  end
end