module PolicyCenter
  module VehicleSearch
    include PageObject

    div(:return_to_vehicle_screen, id: /Iag_PMVehicleSearchPopup-__crumb__/)

    ##Search Options
    radio_group(:search_option, name: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_SearchOption')
    radio_button(:vin, id: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_SearchOption_0')
    radio_button(:registration_number_and_state, id: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_SearchOption_1')
    radio_button(:manual_lookup, id: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_SearchOption_2')

    text_field(:vin_number_search, name: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_VehSrch-Iag_PMVehicleSearchCriteriaInputSet-Iag_SearchVin')
    select(:registration_state_search, name: /Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_VehSrch-Iag_PMVehicleSearchCriteriaInputSet-Iag_.*State/)
    text_field(:registration_number_search, name: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_VehSrch-Iag_PMVehicleSearchCriteriaInputSet-Iag_RegNo')
    select(:year_search, name: /-Iag_Year/)
    select(:make_search, name: /-Iag_Make/)
    select(:model_search, name: /-Iag_Model/)
    div(:search, id: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-SearchAndResetInputSet-SearchLinksInputSet-Search')
    div(:reset, id: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-SearchAndResetInputSet-SearchLinksInputSet-Reset')
    div(:select, id: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-RegistrationSearchResultsLV-0-_Select')

  end
end