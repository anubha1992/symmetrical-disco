module PolicyCenter
  module LocationInformation
    include PageObject

    div(:ok, id: /Update/)
    div(:cancel, id: /Cancel/)
    div(:return_to_vehicle_screen, id: /LocationPopup-__crumb__/)

    div(:details_tab, id: /LocationDetailCV-GeneralInfoCardTab/)
    select(:country, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-Country/)
    text_field(:building_name, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_BuildingName/)
    text_field(:address_search, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_AddressSearch/)
    div(:address_autofill, id: /globalAddressContainer-GlobalAddressInputSet-Iag_AddressSearch-AutoFillIcon/)
    checkbox(:manual_address_entry, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_ManualFlag/)
    checkbox(:migrated_risk, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_MigratedRisk/)
    text_field(:address1, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-AddressLine1/)
    select(:flat_unit_type, name:/-GlobalAddressInputSet-FlatUnitType/)
    text_field(:flat_unit_number, name:/-GlobalAddressInputSet-FlatUnitNumber/)
    select(:floor_level_type, name:/-GlobalAddressInputSet-FloorLevelType/)
    text_field(:floor_level_number, name:/-GlobalAddressInputSet-FloorLevelNumber/)
    text_field(:lot_number, name:/-GlobalAddressInputSet-LotNumber/)
    text_field(:street_number, name: /GlobalAddressInputSet-HouseNumber/)
    text_field(:street_name, name:/-GlobalAddressInputSet-StreetName/)
    select(:street_type, name: /-GlobalAddressInputSet-StreetType/)
    select(:street_direction, name:/-GlobalAddressInputSet-StreetDirection/)
    text_field(:suburb, name: /-GlobalAddressInputSet-Iag_Suburb/)
    select_list(:state, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-State/)
    text_field(:postcode, name: /LocationPopup-LocationScreen-LocationDetailPanelSet-LocationDetailCV-LocationDetailDV-LocationDetailInputSet-TargetedAddressInputSet-globalAddressContainer-GlobalAddressInputSet-PostalCode/)

  end
end