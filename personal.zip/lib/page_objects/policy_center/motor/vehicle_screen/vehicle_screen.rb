require_relative '../vehicle_screen/vehicle_search'
require_relative '../vehicle_screen/location_information'
module PolicyCenter
   class VehicleScreen
     include PageObject
     include PolicyCenter::VehicleSearch
     include PolicyCenter::LocationInformation

     div(:warning_msg, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-_msgs/)
     div(:next, id: /Next/)
     div(:back, id: /Prev/)
     div(:save, id: /Draft/)
     div(:quote, id: /JobWizardToolbarButtonSet-QuoteTypeToolbarButtonSet-Quote/)
     div(:close_options, id: /JobWizardToolbarButtonSet-CloseOptions/)
     div(:edit_pol_transaction, id: /RenewalWizard-LOBWizardStepGroup-LineWizardStepSet-Iag_PMVehicleScreen-JobWizardToolbarButtonSet-EditPolicy/)
     div(:withdrawn, id: /CloseOptions-WithdrawJob/)
     div(:decline, id: /CloseOptions-Decline/)
     div(:not_taken, id: /CloseOptions-NotTakenJob/)
     div(:renew_workflow_label, id: 'RenewalWizard-JobWizardInfoBar-WorkflowLabel')

     #Validation Results
     div(:validation_results_tab, id: 'wsTabBar-wsTab_0')
     div(:clear, id: 'WebMessageWorksheet-WebMessageWorksheetScreen-WebMessageWorksheet_ClearButton')
     # div(:warning_msg, id: 'WebMessageWorksheet-WebMessageWorksheetScreen-grpMsgs-0-0')
     # div(:warning_msg, id: /-LOBWizardStepGroup-LineWizardStepSet-Iag_PMVehicleScreen-_msgs-0-0/)


     div(:embargo_text, id: /EmbargoWarning/)
     div(:add_vehicle_btn, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV_tb-IagPM_Button_Dynamic/)
     div(:motor_vehicle, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV_tb-IagPM_Button_Dynamic-0-ConcreteRiskType/)


     ##Basic Vehicle Information
     text_field(:vin_number, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Vin_DV$/)
     text_field(:registration_number, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-LicensePlate_DV$/)
     select(:registration_state, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-RegState_DV/)
     select(:shape, name: 'Iag_PMVehicleSearchPopup-Iag_VehicleSearchScreen-Iag_PMVehicleSearchDV-Iag_VehSrch-Iag_PMVehicleSearchCriteriaInputSet-Iag_Shape')
     div(:year, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Year_DV$/)
     div(:make, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Make_DV$/)
     div(:model, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Model_DV$/)
     div(:shape_text, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Shape_DV$/)
     div(:equipment, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Equipement_DV$/)
     div(:series, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Series_DV$/)
     div(:tare_weight, id: /SubmissionWizard-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-TareWeight_DV$/)
     div(:engine_type, id: /SubmissionWizard-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-EngineType_DV$/)
     div(:engine_size, id: /SubmissionWizard-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-EngineSize_DV$/)
     div(:engine_cc, id: /SubmissionWizard-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_EngineCC$/)
     div(:transmission_type, id: /SubmissionWizard-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_TransmissionType$/)

     ##Risk Location
     div(:risk_address_lookup, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_PMGarageLocationInputSet-Iag_PMGarageLocationInput-Iag_PMGarageLocationInputMenuIcon/)
     div(:new_location, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_PMGarageLocationInputSet-Iag_PMGarageLocationInput-NewGarageLocation/)
     select(:risk_address, name: /LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_PMGarageLocationInputSet-Iag_PMGarageLocationInput/)

     radio_group(:vehicle_modifications, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVehicleModified_DV/)
     radio_group(:custom_or_specialised_paint, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVeh$/)
     radio_group(:roll_bar, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVehHaveRollbar/)
     radio_group(:suspension_adjustment_completed, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVehHaveSuspention/)
     radio_group(:customised_or_special_body_work, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVehBodyModified/)
     radio_group(:higher_engine_performance, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVehEngineModified/)
     radio_group(:unrepaired_hail_damage, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-VehicleModifiedHailDamage_DV/)
     radio_group(:panel_dents_or_scratches, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-IsVehicleModifiedPanelDent_DV/)

     ##Additional Information
     select(:expected_annual_kilometers, name: /-annualmiles_DV/)
     div(:vehicle_use, id: /-Iag_AUVehFields-Iag_VehUse$/)
     radio_group(:main_use_of_vehicle, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_AUVehFields-Iag_MainUse/)
     checkbox(:purpose_of_vehicle, name: /-Iag_AUVehFields-Iag_VehUse/)
     text_field(:average_hours_of_use, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_AUVehFields-Iag_Hours/)
     radio_group(:exempt_from_stamp_duty, name: /-Iag_AUVehFields-Iag_ExemptFromStampDuty/)
     radio_group(:finance, name: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Finance_DV/)
     div(:add_finance_provider_button, id: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_FinanceProviderInputSet-FinanceProvider_LV_tb-FinanceProviderAdd/)
     divs(:finance_provider_menu_items) { add_finance_provider_button_element.div_elements(:id => /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_FinanceProviderInputSet-FinanceProvider_LV_tb-FinanceProviderAdd/) }
     # table(:finance_provider_table, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-FinanceProvider_LV/)
     table(:finance_provider_table, id: /-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_FinanceProviderInputSet-FinanceProvider_LV/)
     select(:vehicle_parked, name: /^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-CarPark$/)
     div(:vehicle_table_div,id:/^.*-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV$/)
     table(:vehicle_table) { vehicle_table_div_element.table_elements[0] }
     rows(:vehicle_table_rows,id:/-LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV-\d+-\d+/)
     div(:vehicle_number,xpath:'//*[contains(@id,"Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-VehicleNumber_DV")]/div/div')
     divs(:vehicle_numbers,xpath:'//div[contains(@id,"VehicleNumber") and @class="gw-TextValueWidget gw-styleTag--CellWidget gw-ValueWidget gw-readonly"]')
     span(:main_use_of_vehicle_selected_text,xpath:'//input[contains(@name,"Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_AUVehFields-Iag_MainUse") and @checked]/following::span[1][@class="gw-label--inner"]')
     checkboxes(:vehicle_checkbox, xpath:'//input[contains(@name,"_Checkbox") and @data-gw-click="noOp"]')
     divs(:vehicle_checkboxes, id: /VehiclesLV-\d+-_Checkbox/)
     div(:remove, id: /tb-Remove/)
     div(:total_loss_btn, id: /Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesLV_tb-Iag_TotalLossButton/)

     #Warnings messages
     div(:warning_msg_agreed_value_decline, xpath: '//div[@class="gw-message" and contains(text(),"Agreed Value is greater than $300,000 and will be declined")]')
     div(:warning_msg_agreed_value_approve, xpath: '//div[@class="gw-message" and contains(text(),"Agreed Value is greater than $250,000 and less than $300,000 and will be referred for approval")]')

     #Policy number link
     div(:policy_number_link, xpath:'//div[@id ="PolicyChangeWizard-JobWizardInfoBar-PolicyNumber"]/child::div[@class="gw-label gw-infoValue"]')

     #Embargoes warning
     # div(:embargoes_warning, xpath: '//div[@class="gw-message" and contains(text(),"Due to current conditions")]')
     div(:embargoes_warning, id: /LOBWizardStepGroup-Line.*WizardStepSet-Iag_PMVehicleScreen-_msgs/)

     ##Digital Implementation
     checkboxes(:vehicle_usage, xpath:'//input[contains(@name,"VehUse") and @checked]')

     ##vehicle modifications
     radio(:vehicle_modification_checked, xpath: '//input[contains(@name,"Modified_DV") and @checked]')
     radio(:custom_checked, xpath: '//div[contains(text(),"Custom or")]/following-sibling::div//input[contains(@id,"Iag_PMVehicleDV-IsVeh") and @checked]')
     radio(:roll_cage_checked, xpath: '//input[contains(@name,"IsVehHaveRollbar") and @checked]')
     radio(:other_engine_checked, xpath: '//input[contains(@name,"IsVehHaveSuspention") and @checked]')
     radio(:significant_suspension_adjustment_checked, xpath: '//input[contains(@name,"IsVehBodyModified") and @checked]')
     radio(:structural_checked, xpath: '//input[contains(@name,"IsVehEngineModified") and @checked]')

     #vehicle damages
     radio(:unrepaired_hail_damage_checked, xpath:'//input[contains(@name,"_PMVehicleDV-VehicleModifiedHailDamage_DV") and @checked]')
     radio(:panel_dent_or_scratches_checked, xpath:'//input[contains(@name,"PanelDent_DV") and @checked]')

     #financed
      radio(:financed_checked, xpath:'//input[contains(@name,"Finance_DV") and @checked]')
     div(:financed_provider_list, id: 'SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-Iag_PMVehicleScreen-Iag_PMVehiclePanelSet-VehiclesListDetailPanel-VehiclesDetailsCV-Iag_PMVehicleDV-Iag_FinanceProviderInputSet-FinanceProvider_LV')

     #side menu
     div(:vehicle_screen_side_menu, id:'SubmissionWizard-LOBWizardStepGroup-Iag_PMVehicle')

     def add_finance_provider(finance_provider_type='From Address Book')
       self.add_finance_provider_button_element.click
       sleep(5)
       self.finance_provider_menu_items_elements.each_with_index do |menu_element, index|
         if menu_element.element.text =~ /^#{finance_provider_type}$/i
            ## selecting the menu option then exit
             menu_element.click
             break
         end
       end
     end

     ##To check the vehicle usages checkboxes
     def select_vehicle_usage(vehicle_usages)
       vehicle_usages = vehicle_usages.is_a?(Array) ? vehicle_usages : [vehicle_usages]
       vehicle_usages.each_with_index do |usage, count|
         vehicle_usage_checkbox = "//label[contains(normalize-space(),'"+usage+"')]/child::input[contains(@name,'-Iag_AUVehFields-Iag_VehUse')]"
         Prism.logger.info "selecting vehicle usage => #{usage}"
         wait = Selenium::WebDriver::Wait.new(:timeout => 10)
         browser = Prism.capybara.page.driver.browser
         usage_checkbox = wait.until {
           sleep(3)
           ele = browser.find_element(:xpath, vehicle_usage_checkbox)
           ele if ele.displayed?
         }
         sleep(3)
         usage_checkbox.click
       end
     end


     #To select vehicle for Total Loss scenario
     def select_vehicle(vehicle)
       Prism.logger.info "Select vehicle => #{vehicle}"
       vehicle_table_data = self.vehicle_table_div_element.table_elements[0].hashes
       vehicle_data = vehicle_table_data.each_with_index {|row, index|
         sleep 2
         if row['Vehicle #'].eql?(vehicle)
           self.vehicle_checkboxes_elements[index].click
         end
       }
     end

   end
end