module PolicyCenter
  class NewDriver
    include PageObject

    div(:return_to_drivers, id: 'IagPM_NewPolicyDriverPopup-__crumb__')
    div(:ok, id: /Update/)
    div(:cancel, id: /Cancel/)

    ##Tabs
    div(:contact_detail_tab, id: /Iag_PMNewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactRoleDetailCardTab/)
    div(:phone_details_tab, id: /Iag_PMNewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_PhonelDetailTab/)
    div(:additional_detail_tab, id: /Iag_PMNewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_AdditionalDetailTab/)
    div(:addresses_tab, id: /Iag_PMNewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-AddressesCardTab/)


    ##Contact Details
    text_field(:first_name, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalPersonNameInputSet-FirstName/)
    text_field(:last_name, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-GlobalPersonNameInputSet-LastName/)
    text_field(:date_of_birth, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-DateOfBirth/)
    select(:gender, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-Iag_Gender/)
    select(:title, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-PolicyContactRoleNameInputSet-Iag_GlobalContactTitleInputSet-Prefix/)
    text_field(:building_name, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_BuildingName/)
    text_field(:address_search, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_AddressSearch/)
    checkbox(:manual_address_entry, name: /PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_ManualFlag/)
    text_field(:street_name, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-StreetNam/)
    select(:street_type, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-StreetType/)
    text_field(:suburb, name: /PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-Iag_Suburb/)
    select(:state, name: /PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-State/)
    text_field(:postcode, name: /PolicyContactDetailsDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-PostalCode/)
    text_field(:primary_email, name: /-EmailAddress1/)
    select(:license_number, name: /Iag_.*NewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-PolicyContactDetailsDV-Iag_LicenceNumber/)

    ##Additional Detail
    select(:brand, name: /Iag_PMNewPolicyDriverPopup-ContactDetailScreen-NewPolicyContactRoleDetailsCV-Iag_Brand/)

    ##Phone Details
    select(:phone_type, name:/PhoneDetailLV-0-Type/)
    text_field(:phone_number, name: /-Iag_PhoneDetailPanelSet-PhoneDetailLV-0-Number/)

  end
end