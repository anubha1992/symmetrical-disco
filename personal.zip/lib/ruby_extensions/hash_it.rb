##########################################
## Convert hash elements to methods
## Example: @base_config = HashIt.new(Prism.settings.wsdl_endpoints.apigee.send(rest_application))
##########################################
class HashIt
  def initialize(hash)
    hash.each do |k,v|
      case v
        when Hash; self.instance_variable_set("@#{k}", HashIt.new(v))
        else; self.instance_variable_set("@#{k}", v)
      end
      self.class.send(:define_method, k, proc{ self.instance_variable_get("@#{k}") })
      self.class.send(:define_method, "#{k}=", proc{ |v| self.instance_variable_set("@#{k}", v)})
    end
  end
end