class Symbol

  def methodize
    to_s.methodize
  end

end
