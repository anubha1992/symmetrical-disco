class Hash
  def compact
    self.delete_if { |_, v| !v.present? }
  end

  def deep_diff(b)
    a = self
    (a.keys | b.keys).inject({}) do |diff, k|
      if a[k] != b[k]
        if a[k].respond_to?(:deep_diff) && b[k].respond_to?(:deep_diff)
          diff[k] = a[k].deep_diff(b[k])
        else
          diff[k] = [a[k], b[k]]
        end
      end
      diff
    end
  end

  #################################################################
  # Flatten nested hashes
  # From: {
  #         "description"=>"2006 TOYOTA COASTER DELUXE (LWB) XZB50R BUS 5 SP MANUAL 4.0L DT4 4CYL DIESEL TURBO F/INJ",
  #         "registration_state"=>"AU_WA",
  #         "specification"=>{"model_type"=>"COASTER", "model_year"=>2006, "make"=>"TOYOTA", "vehicle_class"=>"specialvehicles"}
  #       }
  # To: {
  #       "description"=>"2006 TOYOTA COASTER DELUXE (LWB) XZB50R BUS 5 SP MANUAL 4.0L DT4 4CYL DIESEL TURBO F/INJ",
  #       "registration_state"=>"AU_WA",
  #       "model_type"=>"COASTER",
  #       "model_year"=>2006,
  #       "make"=>"TOYOTA",
  #       "vehicle_class"=>"specialvehicles"
  #     }
  #################################################################
  def flatten_hash(hash, results = {}, parent_key = '')
    return results unless hash.kind_of?(Hash)

    hash.keys.each do |key|
      # current_key = "#{parent_key}[#{key}]" # uncomment this if you want to keep parent key as a partof key for flattened hash (csv column name)
      current_key = key
      if hash[key].kind_of?(Hash)
        results = flatten_hash(hash[key], results, current_key)
      else
        if hash[key].kind_of?(Array)
          results[current_key] = hash[key].reject(&:empty?).join("; ")
        else
          results[current_key] = hash[key]
        end
      end
    end

    results
  end
end