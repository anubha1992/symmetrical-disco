class Range
  def intersect(other)
    return nil if (self.max < other.begin or other.max < self.begin)
    [self.begin, other.begin].max..[self.max, other.max].min
  end

  def median
    self.begin.to_time + (self.end.to_time - self.begin.to_time) / 2
  end
end