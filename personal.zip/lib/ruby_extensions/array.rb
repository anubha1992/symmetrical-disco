class Array

  # Convert array of hashes to one hash with the values as key-value pair
  # e.g. h = [{"ElementName"=>"Role", "Value"=>"Third Party"}]
  # h.to_hash => {"Role"=>"Third Party"}
  def to_hash_by_values(ref_data=nil)
    Hash[self.map { |i| ref_lookup(i.values, ref_data) }].with_indifferent_access
  end

  private
  def ref_lookup(values, ref_data=nil)
    if ref_data && values.last == 'db_data'
      return [values.first, ref_data[values.first.parameterize.underscore]]
    elsif ref_data && values.last =~ /db_data (\w+) (\w+)/
      return [values.first, ref_data[values.first.parameterize.underscore].public_send($1)[$2]]
    end
    values
  end
end