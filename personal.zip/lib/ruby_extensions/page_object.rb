module PageObject

  # convert the element path to something that Capybara#find can use
  def find_element(element)
    style, path_to = path(element)

    type      = map_style style
    type_path = map_path(style, path_to)

    [type, type_path]
  end

  def map_style(style)
    case style
    when :link_text
      :link
    when :href
      :xpath
    when :value
      :button
    when *identity_styles
      style
    else
      fail "unknown type for element with style #{style}"
    end
  end

  def map_path(type, path_to)
    case type
    when :class
      ".#{path_to}"
    when :id
      "##{path_to}"
    when :href
      "//a[@href='#{path_to}']"
    else
      path_to
    end
  end

  def value_of(element)
    send "#{element.methodize}"
  end

  def element(element)
    send "#{element.methodize}_element"
  end

  def path(element)
    send "#{element.methodize}_path"
  end

  def options(element)
    send "#{element.methodize}_options"
  end

  def assign(element, value)
    send "#{element.methodize}=", value
  end

  def identity_styles
    [:css, :xpath, :id, :class, :src, :alt, :index, :name, :text]
  end
end
