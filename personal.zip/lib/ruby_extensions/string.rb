class String

  def is_number?
    self.to_f.to_s == self.to_s || self.to_i.to_s == self.to_s
  end

  def methodize
    parameterize.underscore
  end

  def single_word?
    !self.strip.include? " "
  end
end