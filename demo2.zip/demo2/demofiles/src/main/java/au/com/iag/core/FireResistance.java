package au.com.iag.core;

import static org.springframework.boot.SpringApplication.run;

import java.net.InetAddress;
import java.net.UnknownHostException;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import au.com.iag.core.model.exception.SystemException;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableCircuitBreaker
@EnableSwagger2
public class FireResistance {

    private static final String LOG_NAME_PROPERTY = "log.name";

    public static void main(String[] args) {
        new FireResistance().go(args);
    }

    private void go(String[] args) {
        try {
            System.setProperty(LOG_NAME_PROPERTY, InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            throw new SystemException("Could not resolve host name. Exiting.");
        }
        run(FireResistance.class, args);
    }
}
