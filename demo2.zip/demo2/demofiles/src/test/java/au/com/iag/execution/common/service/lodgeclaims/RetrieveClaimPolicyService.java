package au.com.iag.execution.common.service.lodgeclaims;

import org.springframework.stereotype.*;

@Service
public class RetrieveClaimPolicyService {

}
