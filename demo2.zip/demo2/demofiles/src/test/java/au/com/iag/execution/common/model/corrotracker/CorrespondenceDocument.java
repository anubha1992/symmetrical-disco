package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CorrespondenceDocument {

	@JsonProperty("sourceSystemDocumentId")
	private String sourceSystemDocumentId;

	@JsonProperty("sequenceNumber")
	private int sequenceNumber;

	@JsonProperty("classificationCode")
	private String classificationCode;

	@JsonProperty("generationTime")
	private String generationTime;

	@JsonProperty("messageHierarchy")
	private String messageHierarchy;

	@JsonProperty("attachmentType")
	private String attachmentType;

	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@JsonProperty("subclassificationCode")
	private String subclassificationCode;

	@JsonProperty("title")
	private String title;

	@JsonProperty("productDocumentId")
	private String productDocumentId;

	public void setSourceSystemDocumentId(String sourceSystemDocumentId){
		this.sourceSystemDocumentId = sourceSystemDocumentId;
	}

	public String getSourceSystemDocumentId(){
		return sourceSystemDocumentId;
	}

	public void setSequenceNumber(int sequenceNumber){
		this.sequenceNumber = sequenceNumber;
	}

	public int getSequenceNumber(){
		return sequenceNumber;
	}

	public void setClassificationCode(String classificationCode){
		this.classificationCode = classificationCode;
	}

	public String getClassificationCode(){
		return classificationCode;
	}

	public void setGenerationTime(String generationTime){
		this.generationTime = generationTime;
	}

	public String getGenerationTime(){
		return generationTime;
	}

	public void setMessageHierarchy(String messageHierarchy){
		this.messageHierarchy = messageHierarchy;
	}

	public String getMessageHierarchy(){
		return messageHierarchy;
	}

	public void setAttachmentType(String attachmentType){
		this.attachmentType = attachmentType;
	}

	public String getAttachmentType(){
		return attachmentType;
	}

	public void setSourceSystem(String sourceSystem){
		this.sourceSystem = sourceSystem;
	}

	public String getSourceSystem(){
		return sourceSystem;
	}

	public void setSubclassificationCode(String subclassificationCode){
		this.subclassificationCode = subclassificationCode;
	}

	public String getSubclassificationCode(){
		return subclassificationCode;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return title;
	}

	public void setProductDocumentId(String productDocumentId){
		this.productDocumentId = productDocumentId;
	}

	public String getProductDocumentId(){
		return productDocumentId;
	}

	@Override
	public String toString(){
		return
				"DocumentsItem{" +
						"sourceSystemDocumentId = '" + sourceSystemDocumentId + '\'' +
						",sequenceNumber = '" + sequenceNumber + '\'' +
						",classificationCode = '" + classificationCode + '\'' +
						",generationTime = '" + generationTime + '\'' +
						",messageHierarchy = '" + messageHierarchy + '\'' +
						",attachmentType = '" + attachmentType + '\'' +
						",sourceSystem = '" + sourceSystem + '\'' +
						",subclassificationCode = '" + subclassificationCode + '\'' +
						",title = '" + title + '\'' +
						",productDocumentId = '" + productDocumentId + '\'' +
						"}";
	}
}