package au.com.iag.execution.common.exception;

public class InvalidDataException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidDataException(String ex) {
		super(ex);
	}
}
