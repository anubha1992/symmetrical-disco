package au.com.iag.execution.claimupdateapi;

import au.com.iag.execution.claimupdateapi.builders.*;
import au.com.iag.execution.claimupdateapi.configurations.*;
import au.com.iag.execution.claimupdateapi.model.*;
import au.com.iag.execution.claimupdateapi.service.*;
import au.com.iag.execution.claimupdateapi.verifiers.*;
import au.com.iag.execution.common.constants.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;

@SpringBootTest()
@ExtendWith({SpringExtension.class, GladosRunnerExtension.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = {ClaimUpdateConfiguration.class})
@Tags({@Tag("assessmentServiceRequestTest"), @Tag("claim-update-api")})
public class AssessmentServiceRequestTest {

    @Autowired
    ClaimUpdateRequestBuilder claimUpdateRequestBuilder;

    @Autowired
    ClaimUpdateService claimUpdateService;

    @Autowired
    ClaimUpdateVerifier claimUpdateVerifier;

    AssessmentServiceRequestArtifact assessmentServiceRequestArtifact;

    @BeforeEach
    public void setUpEach(){
        assessmentServiceRequestArtifact = claimUpdateRequestBuilder.buildAssessmentServiceRequest();
    }

    @Test
    public void updateAssessmentServiceRequestTest(){
        Response response = claimUpdateService.executeUpdateAssessmentServiceRequest(assessmentServiceRequestArtifact, SC_OK);
    }

    @Test
    public void invalidSystemToken() {

        String invalidToken = assessmentServiceRequestArtifact.getHeaders().get(X_IAG_AUTH_CONSUMER_SYSTEM) + "i";
        assessmentServiceRequestArtifact.getHeaders().put(X_IAG_AUTH_CONSUMER_SYSTEM, invalidToken);
        Response response = claimUpdateService.executeUpdateAssessmentServiceRequest(assessmentServiceRequestArtifact, SC_UNAUTHORIZED);
        claimUpdateVerifier.verifyErrorResponse(response, ApiConstants.INVALID_SYSTEM_TOKEN);
    }

    @Test
    public void removeSystemToken() {
        assessmentServiceRequestArtifact.getHeaders().remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimUpdateService.executeUpdateAssessmentServiceRequest(assessmentServiceRequestArtifact, SC_UNAUTHORIZED);
    }

    @Test
    public void invalidUserToken() {

        String invalidToken = assessmentServiceRequestArtifact.getHeaders().get(X_IAG_AUTH_USER) + "i";
        assessmentServiceRequestArtifact.getHeaders().put(X_IAG_AUTH_USER, invalidToken);
        Response response = claimUpdateService.executeUpdateAssessmentServiceRequest(assessmentServiceRequestArtifact, SC_UNAUTHORIZED);
        claimUpdateVerifier.verifyErrorResponse(response, ApiConstants.INVALID_USER_TOKEN);
    }

    @Test
    public void removeUserToken() {
        assessmentServiceRequestArtifact.getHeaders().remove(X_IAG_AUTH_USER);
        Response response = claimUpdateService.executeUpdateAssessmentServiceRequest(assessmentServiceRequestArtifact, SC_UNAUTHORIZED);
    }
}
