package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class AskIf implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("conditions")
    private java.util.List<Condition> conditions = new java.util.ArrayList<Condition>();

  
    @ApiModelProperty(
        value = "Condition that if evaluates to true indicates this question should be asked.",
        required = false
    )
    public java.util.List<Condition> getConditions() {
       return conditions;
    }
 

}