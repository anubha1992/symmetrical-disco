package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ValidationMessage implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("category")
    private String category ;
    @JsonProperty("code")
    private String code ;
    @JsonProperty("description")
    private String description ;
    @JsonProperty("exclusion_end_date_time")
    private java.time.ZonedDateTime exclusionEndDateTime ;
    @JsonProperty("field")
    private String field ;
    @JsonProperty("rule_id")
    private String ruleId ;
    @JsonProperty("severity")
    private String severity ;

  
    @ApiModelProperty(
        value = "Category of the message. (validation_failed | business_rule_failed | kickout ). &amp;amp;#x60;validation_failed&amp;amp;#x60; for validation rules and, &amp;amp;#x60;business_rule_failed&amp;amp;#x60; for referrals and &amp;amp;#x27;kickout&amp;amp;#x27; is business rule error which can&amp;amp;#x27;t be fixed.",
        example = "validation_failed",
        required = false
    )
    public String getCategory() {
       return category;
    }
 
    @ApiModelProperty(
        value = "Message code. (mandatory_value_missing | value_out_of_range | value_not_supported, etc)",
        example = "mandatory",
        required = false
    )
    public String getCode() {
       return code;
    }
 
    @ApiModelProperty(
        value = "message description",
        example = "Vehicle year must be specified.",
        required = false
    )
    public String getDescription() {
       return description;
    }
 
    @ApiModelProperty(
        value = "Exclusion end timestamp",
        example = "2020-06-30T15:47:55.123+10:00",
        required = false
    )
    public java.time.ZonedDateTime getExclusionEndDateTime() {
       return exclusionEndDateTime;
    }
 
    @ApiModelProperty(
        value = "Path to field",
        example = "assets.vehicle_assets[0].vehicle.year",
        required = false
    )
    public String getField() {
       return field;
    }
 
    @ApiModelProperty(
        value = "Unique rule identifier.",
        example = "V00010",
        required = false
    )
    public String getRuleId() {
       return ruleId;
    }
 
    @ApiModelProperty(
        value = "severity of the message. (info | warning | error)",
        example = "warning",
        required = false
    )
    public String getSeverity() {
       return severity;
    }
 

}