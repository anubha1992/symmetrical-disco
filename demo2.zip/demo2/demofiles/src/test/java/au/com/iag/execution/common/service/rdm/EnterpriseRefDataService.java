package au.com.iag.execution.common.service.rdm;

import au.com.iag.execution.common.model.rdm.*;
import au.com.iag.glados.common.GladosEnrichmentService;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.QueryStringService;
import au.com.iag.glados.service.SecurityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static au.com.iag.glados.model.constants.GladosConstants.*;

@Service
public class EnterpriseRefDataService {

    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityService securityService;
    @Autowired private QueryStringService queryStringService;
    @Autowired private JsonMapperService jsonMapperService;

    public static final String JSON_POLICY_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

    @Value("${test.security.consumer}")
    private String consumerSystem;
    @Value("${test.security.provider}")
    private String providerSystem;
    @Value("${test.api.brand}")
    private String brand;

    public EnterpriseReferenceDataPayload retrieveReferenceTypes(String name, String effectiveDate, int statusCode) throws IOException {
        Response response = gladosEnrichmentService.sendPostRequest(buildRetrieveReferenceTypesHeaders(),
                "/services/v1/enterprise/reference-data/reference-types",
                getEnterpriseReferenceDataRequest(name, effectiveDate),
                statusCode);
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), EnterpriseReferenceDataPayload.class);
    }

    public EnterpriseReferenceDataPayload retrieveReferenceTypes(String name, String effectiveDate, String filterName, String filterValue, int statusCode) throws IOException {
        Response response = gladosEnrichmentService.sendPostRequest(buildRetrieveReferenceTypesHeaders(),
                "/services/v1/enterprise/reference-data/reference-types",
                getEnterpriseReferenceDataRequest(name, effectiveDate, filterName, filterValue),
                statusCode);
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), EnterpriseReferenceDataPayload.class);
    }

    public List<Brand> getCorrespondenceBrands(String brand, String distributionChannel
            , String portfolio, String product, int statusCode) throws IOException {
        Response response = gladosEnrichmentService.sendGetRequest(buildRetrieveReferenceTypesHeaders(),
                "/services/v1/enterprise/reference-data/correspondence/brands",
                buildRefDataLookupQueryString(brand, distributionChannel, portfolio, product),
                statusCode);
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get())
                , objectMapper.getTypeFactory().constructCollectionType(List.class, Brand.class));
    }

    public List<CorrespondenceType> getCorrespondenceTypes(int statusCode) throws IOException {
        Response response = gladosEnrichmentService.sendGetRequest(buildRetrieveReferenceTypesHeaders(),
                "/services/v1/enterprise/reference-data/correspondence/types",
                "",
                statusCode);
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get())
                , objectMapper.getTypeFactory().constructCollectionType(List.class, CorrespondenceType.class));
    }

    public List<Insert> getCorrespondenceInserts(List<String> listOfInsertIds, String effectiveFrom, int statusCode) throws IOException {
        StringBuffer url = new StringBuffer();
        url = queryStringService.getQueryString(url, "?effective_from", effectiveFrom);
        Response response = gladosEnrichmentService.sendGetRequest(buildRetrieveReferenceTypesHeaders(),
                "/services/v1/enterprise/reference-data/correspondence/inserts/"+StringUtils.join(listOfInsertIds, ','),
                url.toString(),
                statusCode);
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get())
                , objectMapper.getTypeFactory().constructCollectionType(List.class, Insert.class));
    }

    private String buildRefDataLookupQueryString(String brand, String distributionChannel, String portfolio, String product) {
        StringBuffer url = new StringBuffer();
        url = queryStringService.getQueryString(url, "?brand", brand);
        url = queryStringService.getQueryString(url, "distribution_channel", distributionChannel);
        url = queryStringService.getQueryString(url, "portfolio", portfolio);
        url = queryStringService.getQueryString(url, "product", product);
        return url.toString();
    }

    private Map<String, Object> buildRetrieveReferenceTypesHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM,
                securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(X_IAG_SALES_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_JURISDICTION, "AU");
        requestHeaders.put(X_IAG_SESSION_ID, UUID.randomUUID().toString());
        return requestHeaders;
    }

    private EnterpriseReferenceDataRequest getEnterpriseReferenceDataRequest(String name, String effectiveDate){
        EnterpriseReferenceDataRequest enterpriseReferenceDataRequest = new EnterpriseReferenceDataRequest();
        enterpriseReferenceDataRequest.setEffectiveDate(formatDateTime(effectiveDate));
        List<EnterpiseReferenceDataType> types = new ArrayList<>();
        EnterpiseReferenceDataType enterpiseReferenceDataType = new EnterpiseReferenceDataType();
        enterpiseReferenceDataType.setName(name);
        types.add(enterpiseReferenceDataType);
        enterpriseReferenceDataRequest.setTypes(types);
        return enterpriseReferenceDataRequest;
    }

    private EnterpriseReferenceDataRequest getEnterpriseReferenceDataRequest(String name, String effectiveDate, String filterName, String filterValue){
        EnterpriseReferenceDataRequest enterpriseReferenceDataRequest = new EnterpriseReferenceDataRequest();
        enterpriseReferenceDataRequest.setEffectiveDate(formatDateTime(effectiveDate));
        List<EnterpiseReferenceDataType> types = new ArrayList<>();
        EnterpiseReferenceDataType enterpiseReferenceDataType = new EnterpiseReferenceDataType();
        enterpiseReferenceDataType.setName(name);
        List<EnterpiseReferenceDataTypeFilter> filters = new ArrayList<>();
        EnterpiseReferenceDataTypeFilter enterpiseReferenceDataTypeFilter = new EnterpiseReferenceDataTypeFilter();
        enterpiseReferenceDataTypeFilter.setName(filterName);
        enterpiseReferenceDataTypeFilter.setValue(filterValue);
        filters.add(enterpiseReferenceDataTypeFilter);
        enterpiseReferenceDataType.setFilters(filters);
        types.add(enterpiseReferenceDataType);
        enterpriseReferenceDataRequest.setTypes(types);
        return enterpriseReferenceDataRequest;
    }

    private String formatDateTime(String effectiveDate){
        LocalDate localDate = LocalDate.parse(effectiveDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dateTimeStr = DateTimeFormatter.ofPattern(JSON_POLICY_DATE_FORMAT).format(localDate.atStartOfDay(ZoneId.systemDefault()));
        return dateTimeStr;
    }
}
