package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StreetAddress{

	@JsonProperty("buildingName")
	private String buildingName;

	@JsonProperty("streetName")
	private String streetName;

	@JsonProperty("streetType")
	private String streetType;

	@JsonProperty("flatUnitType")
	private String flatUnitType;

	@JsonProperty("floorLevelNumber")
	private String floorLevelNumber;

	@JsonProperty("floorLevelType")
	private String floorLevelType;

	@JsonProperty("houseNumber")
	private String houseNumber;

	@JsonProperty("flatUnitNumber")
	private String flatUnitNumber;

	@JsonProperty("lotNumber")
	private String lotNumber;

	@JsonProperty("streetDirection")
	private String streetDirection;

	public void setBuildingName(String buildingName){
		this.buildingName = buildingName;
	}

	public String getBuildingName(){
		return buildingName;
	}

	public void setStreetName(String streetName){
		this.streetName = streetName;
	}

	public String getStreetName(){
		return streetName;
	}

	public void setStreetType(String streetType){
		this.streetType = streetType;
	}

	public String getStreetType(){
		return streetType;
	}

	public void setFlatUnitType(String flatUnitType){
		this.flatUnitType = flatUnitType;
	}

	public String getFlatUnitType(){
		return flatUnitType;
	}

	public void setFloorLevelNumber(String floorLevelNumber){
		this.floorLevelNumber = floorLevelNumber;
	}

	public String getFloorLevelNumber(){
		return floorLevelNumber;
	}

	public void setFloorLevelType(String floorLevelType){
		this.floorLevelType = floorLevelType;
	}

	public String getFloorLevelType(){
		return floorLevelType;
	}

	public void setHouseNumber(String houseNumber){
		this.houseNumber = houseNumber;
	}

	public String getHouseNumber(){
		return houseNumber;
	}

	public void setFlatUnitNumber(String flatUnitNumber){
		this.flatUnitNumber = flatUnitNumber;
	}

	public String getFlatUnitNumber(){
		return flatUnitNumber;
	}

	public void setLotNumber(String lotNumber){
		this.lotNumber = lotNumber;
	}

	public String getLotNumber(){
		return lotNumber;
	}

	public void setStreetDirection(String streetDirection){
		this.streetDirection = streetDirection;
	}

	public String getStreetDirection(){
		return streetDirection;
	}

	@Override
 	public String toString(){
		return 
			"StreetAddress{" + 
			"buildingName = '" + buildingName + '\'' + 
			",streetName = '" + streetName + '\'' + 
			",streetType = '" + streetType + '\'' + 
			",flatUnitType = '" + flatUnitType + '\'' + 
			",floorLevelNumber = '" + floorLevelNumber + '\'' + 
			",floorLevelType = '" + floorLevelType + '\'' + 
			",houseNumber = '" + houseNumber + '\'' + 
			",flatUnitNumber = '" + flatUnitNumber + '\'' + 
			",lotNumber = '" + lotNumber + '\'' + 
			",streetDirection = '" + streetDirection + '\'' + 
			"}";
		}
}