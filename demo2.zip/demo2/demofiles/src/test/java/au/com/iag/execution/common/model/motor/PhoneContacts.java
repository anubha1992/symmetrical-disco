package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PhoneContacts implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("mobile_numbers")
    private java.util.List<MobileNumber> mobileNumbers = new java.util.ArrayList<MobileNumber>();
    @JsonProperty("phone_numbers")
    private java.util.List<PhoneNumber> phoneNumbers = new java.util.ArrayList<PhoneNumber>();

  
    @ApiModelProperty(
        value = "List of mobile numbers of the individual",
        required = false
    )
    public java.util.List<MobileNumber> getMobileNumbers() {
       return mobileNumbers;
    }
 
    @ApiModelProperty(
        value = "List of phone numbers of the individual",
        required = false
    )
    public java.util.List<PhoneNumber> getPhoneNumbers() {
       return phoneNumbers;
    }
 

}