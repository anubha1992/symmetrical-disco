package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ReferenceData implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("code")
    private String code;
    @JsonProperty("description")
    private String description;
    @JsonProperty("position")
    private Integer position;
    @JsonProperty("short_description")
    private String shortDescription;

  
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getCode() {
       return code;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getDescription() {
       return description;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public Integer getPosition() {
       return position;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getShortDescription() {
       return shortDescription;
    }
 

}