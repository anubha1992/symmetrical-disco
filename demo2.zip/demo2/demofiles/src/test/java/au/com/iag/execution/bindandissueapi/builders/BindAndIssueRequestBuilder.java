package au.com.iag.execution.bindandissueapi.builders;

import au.com.iag.execution.bindandissueapi.model.BindAndIssueArtifact;

import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueRequest;

import au.com.iag.execution.common.quotes.builders.MotorQuoteBuilder;
import au.com.iag.execution.common.quotes.service.MotorQuoteService;
import au.com.iag.execution.motorapi.model.business.PolicyDetails;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import au.com.iag.glados.service.SecurityService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static au.com.iag.execution.propertyvaluationapi.model.PropertyValuationsConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static org.apache.http.HttpStatus.SC_CREATED;
import static org.apache.http.HttpStatus.SC_OK;

@Component
public class BindAndIssueRequestBuilder {

    @Autowired private SecurityService securityService;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;

    @Autowired private MotorQuoteBuilder motorQuoteBuilder;
    @Autowired private MotorQuoteService motorQuoteService;

    @Value("${test.api.route}") private String route;
    @Value("${test.api.request}") private String bindAndIssueRequest;

    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;

    public BindAndIssueArtifact setupRequestDefaults(String quoteNumber) throws IOException {
        BindAndIssueArtifact bindAndIssueArtifact = new BindAndIssueArtifact();
        bindAndIssueArtifact.setHeaders(buildMandatoryHeaders());
        bindAndIssueArtifact.setPath(route + "/bind-and-issue");
        bindAndIssueArtifact.setBindAndIssueRequest(buildRequestBody());
        bindAndIssueArtifact.getBindAndIssueRequest().setTransactionNumber(quoteNumber);
        return bindAndIssueArtifact;
    }

    public String createMotorQuote() throws IOException {
        final PolicyDetails createMotorQuoteRequest = motorQuoteBuilder.buildMotorQuoteRequest();
        return motorQuoteService.createMotorQuote(createMotorQuoteRequest)
                .getPolicyDetails()
                .getPolicyNumber();
    }

    public void offerMotorQuote(final String quoteNumber) throws IOException {
        final PolicyDetails offerMotorQuoteRequest = motorQuoteBuilder.buildMotorQuoteRequest();
        motorQuoteService.offerMotorQuote(offerMotorQuoteRequest, quoteNumber);
    }

    public Map<String, Object> buildOptionalHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_BRAND, "RANDOM");
        requestHeaders.put(X_IAG_CHANNEL,"RANDOM");
        requestHeaders.put(X_IAG_PRODUCT, "RANDOM");
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_AUTH_USER, consumerSystem);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "RANDOM");
        requestHeaders.put(X_IAG_JURISDICTION, "RANDOM");
        requestHeaders.put(X_IAG_SESSION_ID, "RANDOM");
        requestHeaders.put(X_IAG_USER, "RANDOM");
        requestHeaders.put(X_IAG_SALES_CHANNEL, "RANDOM");
        requestHeaders.put(X_IAG_DISTRIBUTION_CHANNEL, "RANDOM");
        return requestHeaders;
    }

    private Map<String, Object> buildMandatoryHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        return requestHeaders;
    }

    private BindAndIssueRequest buildRequestBody() throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(bindAndIssueRequest), BindAndIssueRequest.class);
    }

}