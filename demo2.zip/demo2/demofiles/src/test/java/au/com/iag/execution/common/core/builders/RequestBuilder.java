package au.com.iag.execution.common.core.builders;

import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class RequestBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;

    public <T> T buildRequest(String path, Class<T> clazz) throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(path), clazz);
    }
}
