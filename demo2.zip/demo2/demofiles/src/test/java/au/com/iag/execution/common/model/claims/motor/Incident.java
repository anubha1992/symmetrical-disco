package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.As.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonTypeInfo(use = NAME, include = PROPERTY, property = "incident_code", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = VehicleIncident.class, name = "VEHICLE_INCIDENT")
})
public class Incident  implements Serializable {

    private String lossPartyType;
    private String incidentId;
    private String incidentCode;
    private String description;
    private RiskUnit riskUnit;
    private List<Exposure> exposures;
    private Boolean noDamage;


    public Boolean isNoDamage() {
        return noDamage;
    }

    public void setNoDamage(Boolean noDamage) {
        this.noDamage = noDamage;
    }

    public String getLossPartyType() {
        return lossPartyType;
    }

    public void setLossPartyType(String lossPartyType) {
        this.lossPartyType = lossPartyType;
    }

    public String getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(String incidentId) {
        this.incidentId = incidentId;
    }

    public String getIncidentCode() {
        return incidentCode;
    }

    public void setIncidentCode(String incidentCode) {
        this.incidentCode = incidentCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RiskUnit getRiskUnit() {
        return riskUnit;
    }

    public void setRiskUnit(RiskUnit riskUnit) {
        this.riskUnit = riskUnit;
    }

    public List<Exposure> getExposures() {
        return exposures;
    }

    public void setExposures(List<Exposure> exposures) {
        this.exposures = exposures;
    }
}
