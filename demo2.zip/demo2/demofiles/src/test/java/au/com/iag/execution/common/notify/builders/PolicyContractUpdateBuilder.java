package au.com.iag.execution.common.notify.builders;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import au.com.iag.execution.common.core.builders.RequestBuilder;
import au.com.iag.execution.notifyapi.model.business.AssetPartyRole;
import au.com.iag.execution.notifyapi.model.business.MailingAddress;
import au.com.iag.execution.notifyapi.model.business.PartyRole;
import au.com.iag.execution.notifyapi.model.business.Policy;

import static java.util.Map.*;

@Component
public class PolicyContractUpdateBuilder {

    @Autowired private RequestBuilder requestBuilder;

    private final Map<String, String> endpointMapper = ofEntries(
        entry("motor", "requests/notify-api/motor.json"),
        entry("home", "requests/notify-api/home.json"),
        entry("address", "requests/notify-api/address.json")
    );

    private final Map<String, String> policyPurgeMapper = ofEntries(
            entry("motor", "requests/notify-api/purgeMotorRequest.json"),
            entry("home", "requests/notify-api/purgeHomeRequest.json")
    );

    public Policy buildPolicyContractUpdate(String assetType) throws IOException {
        return requestBuilder.buildRequest(endpointMapper.get(assetType), Policy.class);
    }

    public Policy buildPurgePolicyRequest(final String assetType) throws IOException {
        return requestBuilder.buildRequest(policyPurgeMapper.get(assetType), Policy.class);
    }

    public Policy buildPolicyContractUpdate(String partyId, String addressId, String role) throws IOException {
        Policy policy = requestBuilder.buildRequest(endpointMapper.get("motor"), Policy.class);
        au.com.iag.execution.notifyapi.model.business.Individual notifyInd = new au.com.iag.execution.notifyapi.model.business.Individual();
        notifyInd.setPartyId(partyId);
        notifyInd.setAddresses(new ArrayList<>());
        notifyInd.getAddresses().add(buildMailingAddress(addressId));
        policy.getParties().getIndividuals().add(notifyInd);
        policy.getAssets().getVehicleAssets().stream().findFirst()
            .ifPresent(motor -> motor.getParties().getPartyRoles().add(buildAssetPartyRole(partyId, role)));
        policy.getParties().getPartyRoles().add(buildPartyRole(partyId, role));
        return policy;
    }

    private MailingAddress buildMailingAddress(String addressId) throws IOException {
        MailingAddress address = requestBuilder.buildRequest(endpointMapper.get("address"), MailingAddress.class);
        address.setAddressId(addressId);
        return address;
    }

    private AssetPartyRole buildAssetPartyRole(String partyId, String role) {
        AssetPartyRole assetPartyRole = new AssetPartyRole();
        assetPartyRole.setPartyId(partyId);
        assetPartyRole.setRole(role);
        return assetPartyRole;
    }

    private PartyRole buildPartyRole(String partyId, String role) {
        PartyRole partyRole = new PartyRole();
        partyRole.setPartyId(partyId);
        partyRole.setRole(role);
        return partyRole;
    }
}
