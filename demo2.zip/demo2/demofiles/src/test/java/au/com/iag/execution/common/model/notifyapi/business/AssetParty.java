package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class AssetParty implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("party_roles")
    private java.util.List<AssetPartyRole> partyRoles;

  
    @ApiModelProperty(
        value = "List of party roles",
        required = false
    )
    public java.util.List<AssetPartyRole> getPartyRoles() {
       return partyRoles;
    }
 

}