package au.com.iag.execution.common.quotes.builders;

import au.com.iag.execution.common.core.builders.RequestBuilder;
import au.com.iag.execution.motorapi.model.business.PolicyDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class MotorQuoteBuilder {

    @Autowired private RequestBuilder requestBuilder;

    private static final String IDENTIFIED_MOTOR_QUOTE_REQUEST = "requests/motor-api/commonIdentifiedMotorQuoteRequest.json";

    public PolicyDetails buildMotorQuoteRequest() throws IOException {
        return requestBuilder.buildRequest(IDENTIFIED_MOTOR_QUOTE_REQUEST, PolicyDetails.class);
    }

    public PolicyDetails buildMotorQuoteRequest(final String request) throws IOException {
        return requestBuilder.buildRequest(request, PolicyDetails.class);
    }
}
