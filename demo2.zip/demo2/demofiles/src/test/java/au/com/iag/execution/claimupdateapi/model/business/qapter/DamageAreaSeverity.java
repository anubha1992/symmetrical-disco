package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DamageAreaSeverity {
    @ApiModelProperty(
            value = "damage area.https://confluence.iag.com.au/display/GICP/CC+Vehicle+Damaged+Area",
            example = "A pillar passenger")
    private String damageArea;
    @ApiModelProperty(
            value = "damage severity.https://confluence.iag.com.au/display/GICP/CC+Vehicle+Damage+Severity",
            example = "Burnt Out")
    private String severity;
}
