package au.com.iag.execution.common.constants;

public class WimpConstants {
    public static final String DB_IDENTIFIER = "IDENTIFIER";
    public static final String DB_SUBURB = "UNSTRUCTUREDADDRESSCITYSUBURB";
    public static final String DB_STREET_NAME = "UNSTRUCTUREDADDRESS";
    public static final String DB_STREET_NAME_LINE1 = "UNSTRUCTUREDADDRESSLINE1";
    public static final String DB_STATE = "UNSTRUCTUREDADDRESSSTATE";
    public static final String DB_POST_CODE = "UNSTRUCTUREDADDRESSPOSTCODE";

    public static final String DB_POLICY_NUMBER = "POLICYNUM";
    public static final String DB_VEHICLE_REGISTRATION = "POLICYITEMDESC";
    public static final String DB_POLICY_INCEPTION = "INCEPTIONDATE";
    public static final String DB_POLICY_EXPIRY = "EXPIRYDATE";

    public static final String FORMAT_UTF = "UTF-8";
    public static final String CHARSET = "charset";
}
