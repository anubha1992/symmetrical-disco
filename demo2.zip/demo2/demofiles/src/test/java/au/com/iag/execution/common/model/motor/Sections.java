package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Sections implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("dynamic_ranges")
    private java.util.List<DynamicRange> dynamicRanges = new java.util.ArrayList<DynamicRange>();
    @JsonProperty("dynamic_ref_data_lists")
    private java.util.List<DynamicReferenceDataList> dynamicRefDataLists = new java.util.ArrayList<DynamicReferenceDataList>();
    @JsonProperty("dynamic_sections")
    private java.util.List<DynamicSectionMetadata> dynamicSections = new java.util.ArrayList<DynamicSectionMetadata>();
    @JsonProperty("root_section")
    private RootSection rootSection = new RootSection();
    @JsonProperty("sections")
    private java.util.List<SectionMetadata> sections = new java.util.ArrayList<SectionMetadata>();

  
    @ApiModelProperty(
        value = "List of dynamic ranges",
        required = false
    )
    public java.util.List<DynamicRange> getDynamicRanges() {
       return dynamicRanges;
    }
 
    @ApiModelProperty(
        value = "List of dynamic reference data list",
        required = false
    )
    public java.util.List<DynamicReferenceDataList> getDynamicRefDataLists() {
       return dynamicRefDataLists;
    }
 
    @ApiModelProperty(
        value = "List of dynamic sections",
        required = false
    )
    public java.util.List<DynamicSectionMetadata> getDynamicSections() {
       return dynamicSections;
    }
 
    @ApiModelProperty(
        value = "The top level section in the data block",
        required = false
    )
    public RootSection getRootSection() {
       return rootSection;
    }
 
    @ApiModelProperty(
        value = "List of sections",
        required = false
    )
    public java.util.List<SectionMetadata> getSections() {
       return sections;
    }
 

}