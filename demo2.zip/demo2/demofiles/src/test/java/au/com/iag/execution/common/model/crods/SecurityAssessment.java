package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SecurityAssessment{

	@JsonProperty("expiryDate")
	private String expiryDate;

	@JsonProperty("reviewDate")
	private String reviewDate;

	@JsonProperty("referredDeclined")
	private String referredDeclined;

	@JsonProperty("effectiveDate")
	private String effectiveDate;

	public void setExpiryDate(String expiryDate){
		this.expiryDate = expiryDate;
	}

	public String getExpiryDate(){
		return expiryDate;
	}

	public void setReviewDate(String reviewDate){
		this.reviewDate = reviewDate;
	}

	public String getReviewDate(){
		return reviewDate;
	}

	public void setReferredDeclined(String referredDeclined){
		this.referredDeclined = referredDeclined;
	}

	public String getReferredDeclined(){
		return referredDeclined;
	}

	public void setEffectiveDate(String effectiveDate){
		this.effectiveDate = effectiveDate;
	}

	public String getEffectiveDate(){
		return effectiveDate;
	}

	@Override
 	public String toString(){
		return 
			"SecurityAssessment{" + 
			"expiryDate = '" + expiryDate + '\'' + 
			",reviewDate = '" + reviewDate + '\'' + 
			",referredDeclined = '" + referredDeclined + '\'' + 
			",effectiveDate = '" + effectiveDate + '\'' + 
			"}";
		}
}