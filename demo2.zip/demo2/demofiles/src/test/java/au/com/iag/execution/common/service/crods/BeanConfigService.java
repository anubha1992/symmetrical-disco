package au.com.iag.execution.common.service.crods;

import org.springframework.boot.context.properties.*;
import org.springframework.context.annotation.*;
import org.springframework.stereotype.*;
import java.util.*;

@Component
@ConfigurationProperties(prefix = "test")
public class BeanConfigService {

    private HashMap<String, CrodDataSource> crods;

    @Bean
    public HashMap<String, CrodDataSource> crodsConfigHashMap(){
        return getCrods();
    }

    public HashMap<String, CrodDataSource> getCrods() {
        return crods;
    }

    public void setCrods(HashMap<String, CrodDataSource> crods) {
        this.crods = crods;
    }
}
