package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.PolicyDates;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAmount;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.JSON_POLICY_DATE_FORMAT;

@Component
public class PolicyDatesBuilder {

    public PolicyDates getPolicyDates(){
        PolicyDates policyDates = new PolicyDates();
        LocalDateTime localDateTime = LocalDateTime.now();
        policyDates.setOfferCreationDate(formatDateTime(localDateTime, Period.ofDays(-1)));
        policyDates.setOfferExpiryDate(formatDateTime(localDateTime, Period.ofDays(7)));
        policyDates.setPeriodEffectiveFrom(formatDateTime(localDateTime, Period.ofDays(0)));
        policyDates.setTermExpiryDate(formatDateTime(localDateTime, Period.ofYears(1)));
        policyDates.setTermInceptionDate(formatDateTime(localDateTime, Period.ofDays(0)));
        return policyDates;
    }

    private String formatDateTime(LocalDateTime localDateTime, TemporalAmount amount){
        LocalDateTime localDateTimeUpdated = localDateTime.plus(amount);
        String dateTimeStr = DateTimeFormatter.ofPattern(JSON_POLICY_DATE_FORMAT).format(localDateTimeUpdated.atZone(ZoneId.systemDefault()));
        return dateTimeStr;
    }
}
