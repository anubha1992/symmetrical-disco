package au.com.iag.execution.common.party.service;

import au.com.iag.execution.common.builders.security.SecurityTokenBuilder;
import au.com.iag.execution.common.party.builders.PartyBuilder;

import au.com.iag.execution.partyapi.model.business.Individual;
import au.com.iag.glados.common.GladosEnrichmentService;

import au.com.iag.glados.service.RandomContentService;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

import java.util.HashMap;
import java.util.Map;

import static au.com.iag.glados.model.constants.GladosConstants.*;

import static org.apache.http.HttpStatus.SC_CREATED;

@Service
public class PartyService {

    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityTokenBuilder securityTokenBuilder;
    @Autowired private PartyBuilder partyBuilder;

    public Response createIndividual() throws IOException {
        return gladosEnrichmentService.sendPostRequest(
                buildPartyHeaders(), "/services/v1/legal-entity/party/individuals", partyBuilder.buildIndividual(), SC_CREATED);
    }

    private Map<String, Object> buildPartyHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityTokenBuilder.getSystemSecurityToken(false));
        requestHeaders.put(X_IAG_SALES_CHANNEL, "ONLINE");
        requestHeaders.put(X_IAG_USER, "WEBCGU");
        requestHeaders.put(X_IAG_AGENT_ID, "IT");
        return requestHeaders;
    }
}
