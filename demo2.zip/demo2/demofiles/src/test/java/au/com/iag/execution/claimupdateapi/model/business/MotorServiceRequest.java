package au.com.iag.execution.claimupdateapi.model.business;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class MotorServiceRequest {

    private String claimIdentifier;

    List<ServiceRequest> serviceRequests;
}
