package au.com.iag.execution.common.party.builders;

import au.com.iag.execution.common.core.builders.RequestBuilder;
import au.com.iag.execution.partyapi.model.business.*;

import au.com.iag.glados.service.RandomContentService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class PartyBuilder {

    @Autowired private RandomContentService randomContentService;
    @Autowired private RequestBuilder requestBuilder;

    public Individual buildIndividual() throws IOException {
        Individual individual = requestBuilder.buildRequest(
                "requests/party-api/individualRequest.json", Individual.class);

        individual.getNames().getDetails().forEach(individualNameDetails -> {
            individualNameDetails.setFirstName(randomContentService.getRandomText(10));
            individualNameDetails.setLastName(randomContentService.getRandomText(10));
        });
        return individual;
    }
}
