package au.com.iag.execution.claimdetailsapi;


import au.com.iag.execution.claimdetailsapi.builders.*;
import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tags({@Tag("RecoveryJourney"), @Tag("RetrieveClaimTest"), @Tag("ClaimDetails")})
public class RetrieveClaimBrandTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    ClaimDetailService claimDetailService;
    @Autowired
    ClaimsDbService claimsDbService;
    @Autowired
    WimpDbService wimpDbService;

    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    List<Map<String, Object>> claimIdDetails;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;

    private ClaimDetailsArtifact claimDetailsArtifact;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimResultSet(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        setClaimDetailsArtifact(claimDetailsRequestBuilder.setUpClaimDetails());
    }

    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @Test
    public void retrieveBrandForInvalidClaimId() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimBrand("CLAIM00000"), SC_NOT_FOUND);
    }

    @Test
    public void inValidSecuritySystemRetrieveClaimBrand() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimBrand("CLAIM00000"), SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityConsumerSystemRetrieveClaimBrand() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimBrand("CLAIM00000"), SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityTokenRetrieveClaimBrand() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimBrand("CLAIM00000"), SC_UNAUTHORIZED);
    }

    @Test
    public void inValidSecurityTokenRetrieveClaimBrand() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimBrand("CLAIM00000"), SC_UNAUTHORIZED);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveBrandForValidClaimId() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();

        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimBrand(claimId), SC_OK);
        claimDetailsVerifier.verifyClaimDetailsRetrieveBrandResponse(response);

    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveBrandForValidClaimIdExternal() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.buildClaimDetailsExternal(getClaimDetailsArtifact());
        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);

        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToRetrieveClaimBrand(claimId), SC_OK);
        claimDetailsVerifier.verifyClaimDetailsRetrieveBrandResponse(response);

    }

    public ClaimDetailsArtifact getClaimDetailsArtifact() {
        return claimDetailsArtifact;
    }

    public void setClaimDetailsArtifact(ClaimDetailsArtifact claimDetailsArtifact) {
        this.claimDetailsArtifact = claimDetailsArtifact;
    }

    private String createRequestToRetrieveClaimBrand(String claimId) {
        StringBuffer url = new StringBuffer();
        url.append("/"+claimId+"/brand");
        return url.toString();
    }
}
