package au.com.iag.execution.common.builders.motor;

import au.com.iag.execution.common.model.motor.PolicyDetails;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class MotorQuoteBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    private static final String CREATE_ANONYMOUS_QUOTE_REQUEST = "requests/motor-api/createAnonymousMotorQuoteRequest.json";
    private static final String OFFER_IDENTIFIED_QUOTE_REQUEST = "requests/motor-api/identifiedMotorQuoteRequest.json";

    public PolicyDetails buildCreateMotorQuoteRequest() throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService
                        .generateStringFromResource(CREATE_ANONYMOUS_QUOTE_REQUEST), PolicyDetails.class);
    }

    public PolicyDetails buildOfferMotorQuoteRequest() throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService
                        .generateStringFromResource(OFFER_IDENTIFIED_QUOTE_REQUEST), PolicyDetails.class);
    }
}
