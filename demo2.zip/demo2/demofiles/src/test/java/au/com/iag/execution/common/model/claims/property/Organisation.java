package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Organisation extends Party {
    private List<OrganisationName> organizationName = new ArrayList<>();

    public List<OrganisationName> getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(List<OrganisationName> organizationName) {
        this.organizationName = organizationName;
    }
}