package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class CardDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("card_holder_name")
    private String cardHolderName ;
    @JsonProperty("nonce")
    private String nonce ;
    @JsonProperty("token")
    private String token ;

  
    @ApiModelProperty(
        value = "Name of the card holder",
        required = false
    )
    public String getCardHolderName() {
       return cardHolderName;
    }
 
    @ApiModelProperty(
        value = "One time payment token for payment gateway",
        required = false
    )
    public String getNonce() {
       return nonce;
    }
 
    @ApiModelProperty(
        value = "Token associated with the card",
        required = false
    )
    public String getToken() {
       return token;
    }
 

}