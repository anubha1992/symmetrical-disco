package au.com.iag.execution.claimdetailsapi.model;

import lombok.Data;

import java.util.Map;

@Data
public class VerifyClaimUserArtifact {

    private Map<String, Object> headers;
    private String claimId;
    private String path;

}
