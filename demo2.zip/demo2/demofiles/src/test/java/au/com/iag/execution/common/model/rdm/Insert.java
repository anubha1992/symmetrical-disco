package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Insert implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("asset_type")
    private String assetType ;
    @JsonProperty("brand")
    private String brand ;
    @JsonProperty("distribution_channel")
    private String distributionChannel ;
    @JsonProperty("document_inclusion_method")
    private String documentInclusionMethod ;
    @JsonProperty("effective_from_date")
    private String effectiveFromDate ;
    @JsonProperty("insert_classification")
    private String insertClassification ;
    @JsonProperty("insert_type")
    private String insertType ;
    @JsonProperty("minimum_envelope_size")
    private String minimumEnvelopeSize ;
    @JsonProperty("portfolio")
    private String portfolio ;
    @JsonProperty("product")
    private String product ;
    @JsonProperty("sc_s3")
    private String scS3 ;
    @JsonProperty("stock_identifier")
    private String stockIdentifier ;
    @JsonProperty("thickness")
    private Double thickness ;
    @JsonProperty("version")
    private String version ;
    @JsonProperty("vrd_asset_name")
    private String vrdAssetName ;
    @JsonProperty("vrd_document_identifier")
    private String vrdDocumentIdentifier ;
    @JsonProperty("weight")
    private Double weight ;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getAssetType() {
        return assetType;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getBrand() {
        return brand;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getDistributionChannel() {
        return distributionChannel;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getDocumentInclusionMethod() {
        return documentInclusionMethod;
    }

    @ApiModelProperty(
            value = "",
            example = "2018-01-01T15:47:55.123+10:00",
            required = false
    )
    public String getEffectiveFromDate() {
        return effectiveFromDate;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getInsertClassification() {
        return insertClassification;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getInsertType() {
        return insertType;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getMinimumEnvelopeSize() {
        return minimumEnvelopeSize;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPortfolio() {
        return portfolio;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getProduct() {
        return product;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getScS3() {
        return scS3;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getStockIdentifier() {
        return stockIdentifier;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Double getThickness() {
        return thickness;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getVersion() {
        return version;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getVrdAssetName() {
        return vrdAssetName;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getVrdDocumentIdentifier() {
        return vrdDocumentIdentifier;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Double getWeight() {
        return weight;
    }


}