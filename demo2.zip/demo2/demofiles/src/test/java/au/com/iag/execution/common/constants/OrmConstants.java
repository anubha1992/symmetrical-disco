package au.com.iag.execution.common.constants;

import org.springframework.stereotype.*;

@Component
public class OrmConstants {

    //ORM database
    public static final String DB_ORM_TXT_VEHICLEREGISTRATION = "TXT_VEHICLEREGISTRATION";
    public static final String DB_ORM_CDE_CLAIM = "CDE_CLAIM";
    public static final String DB_ORM_NUM_SUPPLIER = "NUM_SUPPLIER";
    public static final String DB_ORM_TXT_DOCUMENT = "TXT_DOCUMENT";
    public static final String DB_ORM_NUM_REQUESTFORQUOTE = "NUM_REQUESTFORQUOTE";
}
