package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class BasicCoverage implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("category")
    private String category ;
    @JsonProperty("limit")
    private String limit ;
    @JsonProperty("premium_details")
    private PremiumDetails premiumDetails = new PremiumDetails();
    @JsonProperty("selected")
    private Boolean selected ;

  
    @ApiModelProperty(
        value = "The category of coverage. [Ref Data: coverage_categories]",
        example = "STANDARD",
        required = false
    )
    public String getCategory() {
       return category;
    }
 
    @ApiModelProperty(
        value = "Limit for this cover.e.g. Hire car value per day 80.00",
        example = "80",
        required = false
    )
    public String getLimit() {
       return limit;
    }
 
    @ApiModelProperty(
        value = "Premium Details",
        required = false
    )
    public PremiumDetails getPremiumDetails() {
       return premiumDetails;
    }
 
    @ApiModelProperty(
        value = "Indicates this coverage is selected by the customer for this cover type",
        example = "true",
        required = false
    )
    public Boolean getSelected() {
       return selected;
    }
 

}