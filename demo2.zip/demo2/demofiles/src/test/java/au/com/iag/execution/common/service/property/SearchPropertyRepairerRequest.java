package au.com.iag.execution.common.service.property;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.util.*;

@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class SearchPropertyRepairerRequest {

    private Boolean isMakeSafe;
    private String postcode;
    private List<String> specialities = new ArrayList<>();
    private String suburb;
}

