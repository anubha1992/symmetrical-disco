package au.com.iag.execution.claimupdateapi.verifiers;

import au.com.iag.execution.totallossapi.model.business.ValidationMessage;
import au.com.iag.glados.service.JsonMapperService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@Component
public class ClaimUpdateVerifier {

    @Autowired
    private JsonMapperService jsonMapperService;

    public void verifyValidationErrorMessages(Response response, String field, String code, String desc) throws IOException {
        ValidationMessage expectedMessage = buildValidationMessage(field, code, desc, "missing_field");
        verifyValidationMessages(List.of(expectedMessage), response);
    }

    public void verifyValidationErrorMessagesForMandatory(Response response, String field, String code, String desc) throws IOException {
        ValidationMessage expectedMessage = buildValidationMessageForSendCorrespondence(field, code, desc);
        verifyValidationMessages(List.of(expectedMessage), response);
    }

    public void verifyRefDataValidationMessagesForCreateActivity(Response response, String field, String code, String desc) throws IOException {
        ValidationMessage expectedMessage = buildValidationMessage(field, code, desc, "refdata_value_not_found");
        verifyValidationMessages(List.of(expectedMessage), response);
    }

    private ValidationMessage buildValidationMessage(String field, String code, String description, String category) {
        ValidationMessage validationMessage = new ValidationMessage();
        validationMessage.setField(field);
        validationMessage.setCode(code);
        validationMessage.setCategory(category);
        validationMessage.setSeverity("error");
        validationMessage.setDescription(description);

        return validationMessage;
    }

    private ValidationMessage buildValidationMessageForSendCorrespondence(String field, String code, String description) {
        ValidationMessage validationMessage = new ValidationMessage();
        validationMessage.setField(field);
        validationMessage.setCode(code);
        validationMessage.setDescription(description);

        return validationMessage;
    }



    public void verifyValidationMessages(final List<ValidationMessage> expected, final Response response) throws IOException {
        List<ValidationMessage> actual = getValidationMessages(response);

        assertThat(expected.size())
                .as("Assert -> validationMessages:size")
                .isEqualTo(actual.size());

        assertThat(expected)
                .as("Assert -> validationMessage")
                .containsExactlyInAnyOrderElementsOf(actual);
    }

    public void verifyErrorResponse(Response response, String errorMessage) {
        Assert.assertEquals(errorMessage, response.path("message"));
    }

    private List<ValidationMessage> getValidationMessages(final Response response) throws IOException {
        ObjectMapper mapper = jsonMapperService.getObjectMapper();
        final String validationMessages = mapper.writeValueAsString(response.path("validation_errors"));
        return mapper.readValue(
                validationMessages,
                mapper.getTypeFactory().constructCollectionType(ArrayList.class, ValidationMessage.class)
        );
    }
}
