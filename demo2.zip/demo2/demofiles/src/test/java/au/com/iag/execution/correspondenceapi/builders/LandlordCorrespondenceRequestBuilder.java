package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.CorrespondenceParties;
import au.com.iag.execution.correspondenceapi.model.business.Parties;
import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.RandomContentService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class LandlordCorrespondenceRequestBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private RandomContentService randomContentService;
    @Autowired private BaseRequestBuilder baseRequestBuilder;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private PartyBuilder partyBuilder;

    public PolicyCorrespondence getLandlordCorrespondenceRequest(final String correspondenceType, String primaryRecipientType
            , List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = readLandlordCorrespondenceFromConfig(correspondenceType);
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));

        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        parties.setDrivers(null);
        policyCorrespondence.getPolicyDetails().setParties(parties);

        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence readLandlordCorrespondenceFromConfig(final String correspondenceType) throws IOException{
        switch (correspondenceType){
            case CORRESPONDENCE_TYPE_NEW_BUSINESS:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceLandlordNewBusiness.json")
                                , PolicyCorrespondence.class);
            case CORRESPONDENCE_TYPE_RENEWAL:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceLandlordRenewal.json")
                                , PolicyCorrespondence.class);
            case CORRESPONDENCE_TYPE_AMENDMENT:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceLandlordAmendment.json")
                                , PolicyCorrespondence.class);
            default:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceLandlordQuotation.json")
                                , PolicyCorrespondence.class);
        }
    }
}
