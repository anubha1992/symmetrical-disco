package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class QuoteResponse implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("metadata")
    private Sections metadata = new Sections();
    @JsonProperty("policy_details")
    private PolicyDetails policyDetails = new PolicyDetails();
    @JsonProperty("validation_messages")
    private java.util.List<ValidationMessage> validationMessages = new java.util.ArrayList<ValidationMessage>();

  
    @ApiModelProperty(
        value = "Metadata for Policy Details",
        required = false
    )
    public Sections getMetadata() {
       return metadata;
    }
 
    @ApiModelProperty(
        value = "Policy details",
        required = false
    )
    public PolicyDetails getPolicyDetails() {
       return policyDetails;
    }
 
    @ApiModelProperty(
        value = "List of validation messages",
        required = false
    )
    public java.util.List<ValidationMessage> getValidationMessages() {
       return validationMessages;
    }
 

}