package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.As.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)

@JsonTypeInfo(use = NAME, include = PROPERTY, property = "loss_items", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = LossEstimateItem.class, name = "Loss_Estimate_Item_Dwelling")
})
//@ApiModel(value = "LossEstimateItemDwelling", parent = LossEstimateItem.class)
public class LossEstimateItemDwelling extends LossEstimateItem {


}