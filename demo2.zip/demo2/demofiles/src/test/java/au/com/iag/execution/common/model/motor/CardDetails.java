package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class CardDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("card_holder_name")
    private String cardHolderName ;
    @JsonProperty("card_number")
    private String cardNumber ;
    @JsonProperty("expiry_date_month")
    private String expiryDateMonth ;
    @JsonProperty("expiry_date_year")
    private String expiryDateYear ;
    @JsonProperty("nonce")
    private String nonce ;

  
    @ApiModelProperty(
        value = "Name of the card holder",
        example = "John Smith",
        required = false
    )
    public String getCardHolderName() {
       return cardHolderName;
    }
 
    @ApiModelProperty(
        value = "Credit or Debit card number",
        example = "5217123456787890",
        required = false
    )
    public String getCardNumber() {
       return cardNumber;
    }
 
    @ApiModelProperty(
        value = "Month of the expiry date",
        example = "07",
        required = false
    )
    public String getExpiryDateMonth() {
       return expiryDateMonth;
    }
 
    @ApiModelProperty(
        value = "Year of the expiry date",
        example = "2022",
        required = false
    )
    public String getExpiryDateYear() {
       return expiryDateYear;
    }
 
    @ApiModelProperty(
        value = "One time use reference for payment information",
        required = false
    )
    public String getNonce() {
       return nonce;
    }
 

}