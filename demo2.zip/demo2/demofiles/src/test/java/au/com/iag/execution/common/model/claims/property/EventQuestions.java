package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class EventQuestions implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("is_property_habitable")
    private String propertyHabitable;
    @JsonProperty("reason_property_not_habitable")
    private String propertyHabitableReason;
    private String temporaryAccommodationRequired;
    private Integer temporaryAccommodationAdults;
    private Integer temporaryAccommodationChildren;
    @JsonProperty("food_spoilage_only")
    private String foodSpoilage;
    @JsonProperty("origin_of_water_damage")
    private String originOfWater;

    @JsonProperty("damage_related_to_contamination")
    private String damageRelatedToContamination;
    @JsonProperty("damage_related_to_unauthorised_alterations")
    private String damageRelatedToUnauthorisedAlterations;
    @JsonProperty("tenant_responsible_for_damage")
    private String tenantResponsibleForDamage;
    @JsonProperty("damage_related_to_tenants_pet")
    private String damageRelatedToTenantsPet;
    @JsonProperty("fracture_extends_entire_thickness")
    private String fractureExtendsEntireThickness;
    @JsonProperty("item_is_covered_by_warranty")
    private String itemIsCoveredByWarranty;
    @JsonProperty("lease_agreement_in_place")
    private String leaseAgreementInPlace;

    @JsonProperty("police_incident_number_obtained")
    private String policeIncidentNumberObtained;
    @JsonProperty("reason_incident_number_not_obtained")
    private String reasonIncidentNumberNotObtained;

    @JsonProperty("theft_burglary_discovered_by")
    private Person theftBurglaryDiscoveredBy;
    @JsonProperty("age_of_fused_motor")
    private String ageOfFusedMotor;

    @JsonProperty("were_pipes_frozen")
    private String werePipesFrozen;

    public String getAgeOfFusedMotor() {  return ageOfFusedMotor; }

    public void setAgeOfFusedMotor(String ageOfFusedMotor) { this.ageOfFusedMotor = ageOfFusedMotor; }

    public Person getTheftBurglaryDiscoveredBy() { return theftBurglaryDiscoveredBy; }

    public void setTheftBurglaryDiscoveredBy(Person theftBurglaryDiscoveredBy) { this.theftBurglaryDiscoveredBy = theftBurglaryDiscoveredBy;}

    public String getPropertyHabitable() {
        return propertyHabitable;
    }

    public void setPropertyHabitable(String propertyHabitable) {
        this.propertyHabitable = propertyHabitable;
    }

    public String getPropertyHabitableReason() {
        return propertyHabitableReason;
    }

    public void setPropertyHabitableReason(String propertyHabitableReason) {
        this.propertyHabitableReason = propertyHabitableReason;
    }

    public String getTemporaryAccommodationRequired() {
        return temporaryAccommodationRequired;
    }

    public void setTemporaryAccommodationRequired(String temporaryAccommodationRequired) {
        this.temporaryAccommodationRequired = temporaryAccommodationRequired;
    }

    public Integer getTemporaryAccommodationAdults() {
        return temporaryAccommodationAdults;
    }

    public void setTemporaryAccommodationAdults(Integer temporaryAccommodationAdults) {
        this.temporaryAccommodationAdults = temporaryAccommodationAdults;
    }

    public Integer getTemporaryAccommodationChildren() {
        return temporaryAccommodationChildren;
    }

    public void setTemporaryAccommodationChildren(Integer temporaryAccommodationChildren) {
        this.temporaryAccommodationChildren = temporaryAccommodationChildren;
    }

    public String getFoodSpoilage() {
        return foodSpoilage;
    }

    public void setFoodSpoilage(String foodSpoilage) {
        this.foodSpoilage = foodSpoilage;
    }

    public String getOriginOfWater() {
        return originOfWater;
    }

    public void setOriginOfWater(String originOfWater) {
        this.originOfWater = originOfWater;
    }

    public String getDamageRelatedToContamination() {
        return damageRelatedToContamination;
    }

    public void setDamageRelatedToContamination(String damageRelatedToContamination) {
        this.damageRelatedToContamination = damageRelatedToContamination;
    }

    public String getDamageRelatedToTenantsPet() {
        return damageRelatedToTenantsPet;
    }

    public void setDamageRelatedToTenantsPet(String damageRelatedToTenantsPet) {
        this.damageRelatedToTenantsPet = damageRelatedToTenantsPet;
    }

    public String getDamageRelatedToUnauthorisedAlterations() {
        return damageRelatedToUnauthorisedAlterations;
    }

    public void setDamageRelatedToUnauthorisedAlterations(String damageRelatedToUnauthorisedAlterations) {
        this.damageRelatedToUnauthorisedAlterations = damageRelatedToUnauthorisedAlterations;
    }

    public String getFractureExtendsEntireThickness() {
        return fractureExtendsEntireThickness;
    }

    public void setFractureExtendsEntireThickness(String fractureExtendsEntireThickness) {
        this.fractureExtendsEntireThickness = fractureExtendsEntireThickness;
    }

    public String getItemIsCoveredByWarranty() {
        return itemIsCoveredByWarranty;
    }

    public void setItemIsCoveredByWarranty(String itemIsCoveredByWarranty) {
        this.itemIsCoveredByWarranty = itemIsCoveredByWarranty;
    }

    public String getLeaseAgreementInPlace() {
        return leaseAgreementInPlace;
    }

    public void setLeaseAgreementInPlace(String leaseAgreementInPlace) {
        this.leaseAgreementInPlace = leaseAgreementInPlace;
    }

    public String getTenantResponsibleForDamage() {
        return tenantResponsibleForDamage;
    }

    public void setTenantResponsibleForDamage(String tenantResponsibleForDamage) {
        this.tenantResponsibleForDamage = tenantResponsibleForDamage;
    }

    public String getPoliceIncidentNumberObtained() {
        return policeIncidentNumberObtained;
    }

    public void setPoliceIncidentNumberObtained(String policeIncidentNumberObtained) {
        this.policeIncidentNumberObtained = policeIncidentNumberObtained;
    }

    public String getReasonIncidentNumberNotObtained() {
        return reasonIncidentNumberNotObtained;
    }

    public void setReasonIncidentNumberNotObtained(String reasonIncidentNumberNotObtained) {
        this.reasonIncidentNumberNotObtained = reasonIncidentNumberNotObtained;
    }

    public String getWerePipesFrozen() { return werePipesFrozen;   }

    public void setWerePipesFrozen(String werePipesFrozen) { this.werePipesFrozen = werePipesFrozen;   }
}
