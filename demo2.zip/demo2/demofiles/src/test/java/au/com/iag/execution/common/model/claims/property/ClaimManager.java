package au.com.iag.execution.common.model.claims.property;


import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ClaimManager implements Serializable {

    private static final long serialVersionUID = 3799991429960148662L;
    private Person partyDetails;

    public Person getPartyDetails() {
        return partyDetails;
    }

    public void setPartyDetails(Person partyDetails) {
        this.partyDetails = partyDetails;
    }
}
