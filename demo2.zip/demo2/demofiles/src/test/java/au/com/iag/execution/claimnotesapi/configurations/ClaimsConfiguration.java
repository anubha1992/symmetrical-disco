package au.com.iag.execution.claimnotesapi.configurations;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan({
        "au.com.iag.glados*",
        "au.com.iag.execution.claimnotesapi",
        "au.com.iag.execution.common.constants*",
        "au.com.iag.execution.common.service.claims",
        "au.com.iag.execution.common.service.lodgeclaims",
        "au.com.iag.execution.common.service.crods",
        "au.com.iag.execution.common.service.wimp",
        "au.com.iag.execution.common.model.huon",
        "au.com.iag.execution.common.service.huon",
        "au.com.iag.execution.common.model.claims"
})
public class ClaimsConfiguration {

}
