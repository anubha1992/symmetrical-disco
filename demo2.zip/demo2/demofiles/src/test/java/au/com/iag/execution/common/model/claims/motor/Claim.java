package au.com.iag.execution.common.model.claims.motor;

import au.com.iag.glados.common.serializers.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.io.*;
import java.time.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class Claim implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonDeserialize(using = CustomDateDeserializer.class)
    @JsonSerialize(using = CustomDateSerializer.class)
    private OffsetDateTime dateOfLoss;
    private ClaimReporter claimReporter = new ClaimReporter();
    private MainContact primaryContact = new MainContact();
    private List<Party> relatedContacts;
    private String generalNatureOfLoss;
    private String descriptionOfLoss;
    private String fullDescriptionOfLoss;
    private String causeOfLoss;
    private String lodgementLineOfBusiness;
    private ReportingChannel reportingChannel;
    private Address locationOfLoss = new Address();
    private String atFaultParty;
    private String waiveExcess;
    private String policyIdentifier;
    private Indicator claimIndicator;
    private List<Note> notes = new ArrayList<>();
    private List<Incident> incidents = new ArrayList<>();
    private String declarationConfirmed;
    private Boolean vehicleHasDualInsurance;
    private Boolean insuredHasPreviousLoss;
    private String currentLocationOfVehicle;
    private String wasTheFireDeliberatelyLit;
    private String policeIncidentNumberObtained;
    private String reasonIncidentNumberNotObtained;
    private Boolean responsiblePersonKnown;
    private Party responsibleParty;
    private Party vehicleRecoveredBy;
    private Boolean frontWindscreenDamageOnly;
    private String coveragePendingReason;
    private List<Official> officials;
    private Boolean hasGlassBeenReplaced;
}
