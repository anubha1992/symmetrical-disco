package au.com.iag.execution.common.model.notifyapi;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class PartyRequestArtifact<T> implements Serializable {
    private Map<String, Object> headers;
    private String path;
    private T request;
}
