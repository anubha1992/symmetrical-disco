package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ReferenceDataFilter implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("field_reference")
    private FieldReference fieldReference = new FieldReference();
    @JsonProperty("field_value")
    private String fieldValue ;
    @JsonProperty("name")
    private String name ;
    @JsonProperty("value")
    private String value ;

  
    @ApiModelProperty(
        value = "Field Reference to a field whose value will be passed. E.G. Individual.gender.",
        required = false
    )
    public FieldReference getFieldReference() {
       return fieldReference;
    }
 
    @ApiModelProperty(
        value = "Path to a field whose value will be passed. E.G. Individual.gender.",
        required = false
    )
    public String getFieldValue() {
       return fieldValue;
    }
 
    @ApiModelProperty(
        value = "Name or type of the filter. E.G. GENDER",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "Static value for the filter. E.G. MALE",
        required = false
    )
    public String getValue() {
       return value;
    }
 

}