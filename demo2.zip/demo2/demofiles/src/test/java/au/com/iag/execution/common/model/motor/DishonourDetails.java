package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class DishonourDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("original_direct_debit_date")
    private java.time.LocalDate originalDirectDebitDate ;
    @JsonProperty("reattempt_direct_debit_date")
    private java.time.LocalDate reattemptDirectDebitDate ;

  
    @ApiModelProperty(
        value = "Original date when direct debit was attempted",
        required = false
    )
    public java.time.LocalDate getOriginalDirectDebitDate() {
       return originalDirectDebitDate;
    }
 
    @ApiModelProperty(
        value = "Reattempt date for direct debit",
        required = false
    )
    public java.time.LocalDate getReattemptDirectDebitDate() {
       return reattemptDirectDebitDate;
    }
 

}