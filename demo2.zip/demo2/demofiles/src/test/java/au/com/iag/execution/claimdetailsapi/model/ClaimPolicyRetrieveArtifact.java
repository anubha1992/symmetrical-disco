package au.com.iag.execution.claimdetailsapi.model;

import lombok.Data;
import java.util.*;

@Data
public class ClaimPolicyRetrieveArtifact {
    private Map<String, Object> headers;
    private String path;
}
