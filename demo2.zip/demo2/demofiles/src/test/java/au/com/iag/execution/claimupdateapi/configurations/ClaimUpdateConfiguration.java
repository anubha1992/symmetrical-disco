package au.com.iag.execution.claimupdateapi.configurations;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({
        "au.com.iag.glados*",
        "au.com.iag.execution.claimupdateapi",
        "au.com.iag.execution.common.constants*",
        "au.com.iag.execution.common.service.claims",
        "au.com.iag.execution.common.service.lodgeclaims",
        "au.com.iag.execution.common.service.wimp",
        "au.com.iag.execution.common.model.claims",
        "au.com.iag.execution.common.model.huon",
        "au.com.iag.execution.common.service.crods",
        "au.com.iag.execution.common.service.huon"
})
public class ClaimUpdateConfiguration {
}
