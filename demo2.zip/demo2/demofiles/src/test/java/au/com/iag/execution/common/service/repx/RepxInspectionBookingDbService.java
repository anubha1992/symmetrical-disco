package au.com.iag.execution.common.service.repx;

import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.artifacts.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.glados.model.artifacts.DatabaseConnectionArtifact.*;
import java.sql.*;
import java.util.*;

import static junit.framework.TestCase.fail;

@Service
public class RepxInspectionBookingDbService {

    @Autowired
    private DatabaseClient databaseClient;

    @Value("${repx.inspection.datasource.username}")
    private String username;
    @Value("${repx.inspection.datasource.password}")
    private String password;
    @Value("${repx.inspection.datasource.url}")
    private String connectionString;
    @Value("${repx.datasource.driver-class-name}")
    private String driverName;

    public List<Map<String, Object>> getRepairerBookingDetails(String repairerId) throws SQLException, ClassNotFoundException {

        String query = "select booking.*, booking_slot.* from booking "
                + "inner join booking_slot "
                + "on booking.booking_slot_id = booking_slot.booking_slot_id "
                + "where booking_slot.orm_supplier_id = '" + repairerId + "' "
                + "Order by booking.booking_slot_id Desc";

        List<Map<String, Object>> resultList = executeQuery(query);
        if (!(resultList.size() > 0)) {
            fail("---------No Repairer is found in REPX DB ------------");
        }
        return resultList;
    }

    public List<Map<String, Object>> getRepairer() throws SQLException, ClassNotFoundException {

        String query = "select booking.*, booking_slot.* from booking "
                + "inner join booking_slot "
                + "on booking.booking_slot_id = booking_slot.booking_slot_id "
                + "where booking_slot.orm_supplier_id is not null "
                + "And Trim(booking_slot.orm_supplier_id) not like '' "
                + "Order by booking.booking_slot_id Desc "
                + "Fetch first 100 rows only";

        List<Map<String, Object>> resultList = executeQuery(query);
        if (!(resultList.size() > 0)) {
            fail("---------No Repairer is found in REPX DB ------------");
        }
        return resultList;
    }

    public List<Map<String, Object>> checkNumberOfBookingsForRepairerId(String repairerId, String dateString) throws SQLException, ClassNotFoundException {

        String sqlQuery = "select booking.*, booking_slot.* from booking "
                + "inner join booking_slot "
                + "on booking.booking_slot_id = booking_slot.booking_slot_id "
                + "where booking_slot.orm_supplier_id = '" + repairerId + "' "
                + "And booking_slot.booking_day = '" + dateString + "' "
                + "Order by booking.booking_slot_id Desc";
        List<Map<String, Object>> resultList = executeQuery(sqlQuery);
        return resultList;
    }

    private List<Map<String, Object>> executeQuery(String sqlQuery) throws SQLException, ClassNotFoundException{
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        return databaseClient.executeQuery(connection, sqlQuery);
    }

    private DatabaseConnectionArtifact buildDatabaseConnectionDetails() {
        return builder().connectionString(connectionString)
                .jdbcClassName(driverName)
                .username(username)
                .password(password)
                .build();
    }
}
