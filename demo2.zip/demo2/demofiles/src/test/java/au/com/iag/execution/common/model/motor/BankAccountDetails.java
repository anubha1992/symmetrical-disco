package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class BankAccountDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("bsb")
    private String bsb ;
    @JsonProperty("name")
    private String name ;
    @JsonProperty("number")
    private String number ;

  
    @ApiModelProperty(
        value = "Bank State Branch Number",
        example = "063012",
        required = false
    )
    public String getBsb() {
       return bsb;
    }
 
    @ApiModelProperty(
        value = "Customer Account Name",
        example = "John Smith",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "Bank account number",
        example = "12345678",
        required = false
    )
    public String getNumber() {
       return number;
    }
 

}