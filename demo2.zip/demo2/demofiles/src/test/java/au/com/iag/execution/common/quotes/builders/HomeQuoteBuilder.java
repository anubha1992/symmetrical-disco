package au.com.iag.execution.common.quotes.builders;

import au.com.iag.execution.common.core.builders.RequestBuilder;

import au.com.iag.execution.homeapi.model.business.PolicyDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class HomeQuoteBuilder {

    @Autowired private RequestBuilder requestBuilder;

    public PolicyDetails buildHomeQuoteRequest() throws IOException {
        return requestBuilder.buildRequest(
                "requests/home-api/commonIdentifiedHomeQuoteRequest.json", PolicyDetails.class);
    }

    public PolicyDetails buildHomeQuoteRequest(final String request) throws IOException {
        return requestBuilder.buildRequest(request, PolicyDetails.class);
    }

    public PolicyDetails buildOktaHomeQuoteRequest() throws IOException {
        return requestBuilder.buildRequest(
                "requests/home-api/authUserIdentifiedHomeQuote.json", PolicyDetails.class);
    }
}
