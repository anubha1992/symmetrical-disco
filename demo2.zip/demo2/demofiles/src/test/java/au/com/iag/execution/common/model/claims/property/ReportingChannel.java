package au.com.iag.execution.common.model.claims.property;

import au.com.iag.glados.common.serializers.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.time.*;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ReportingChannel implements Serializable {
    private static final long serialVersionUID = 8761574908825017086L;
    private String claimReportedMethod;
    private String sourceId;
    private Organisation sourcePartyDetails;
    private String sourceEventId;
    private String sourceEventName;
    @JsonDeserialize(using = CustomDateDeserializer.class)
    @JsonSerialize(using = CustomDateSerializer.class)
    private OffsetDateTime sourceReportedDate;
    private String reasonForDelayInReporting;

    public String getClaimReportedMethod() {
        return claimReportedMethod;
    }

    public void setClaimReportedMethod(String claimReportedMethod) {
        this.claimReportedMethod = claimReportedMethod;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public Organisation getSourcePartyDetails() {
        return sourcePartyDetails;
    }

    public void setSourcePartyDetails(Organisation sourcePartyDetails) {
        this.sourcePartyDetails = sourcePartyDetails;
    }

    public String getSourceEventId() {
        return sourceEventId;
    }

    public void setSourceEventId(String sourceEventId) {
        this.sourceEventId = sourceEventId;
    }

     public String getSourceEventName() {
        return sourceEventName;
    }

    public void setSourceEventName(String sourceEventName) {
        this.sourceEventName = sourceEventName;
    }

    public OffsetDateTime getSourceReportedDate() {
        return sourceReportedDate;
    }

    public void setSourceReportedDate(OffsetDateTime sourceReportedDate) {
        this.sourceReportedDate = sourceReportedDate;
    }

    public String getReasonForDelayInReporting() {
        return reasonForDelayInReporting;
    }

    public void setReasonForDelayInReporting(String reasonForDelayInReporting) {
        this.reasonForDelayInReporting = reasonForDelayInReporting;
    }
}
