package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class VehicleIncident implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("damage_area")
    private DamageArea damageArea;
    @JsonProperty("exposures")
    private java.util.List<Exposure> exposures;
    @JsonProperty("hire_car")
    private HireCar hireCar;
    @JsonProperty("incident_id")
    private String incidentId;
    @JsonProperty("loss_party_type")
    private String lossPartyType;
    @JsonProperty("owner")
    private Party owner;
    @JsonProperty("possible_total_loss")
    private Boolean possibleTotalLoss;
    @JsonProperty("risk_unit")
    private RiskUnit riskUnit;
    @JsonProperty("taxi_benefit")
    private TaxiBenefit taxiBenefit;
    @JsonProperty("vehicle_parked")
    private Boolean vehicleParked;
    @JsonProperty("vehicle_towed")
    private Boolean vehicleTowed;
    @JsonProperty("wind_screen_only")
    private Boolean windScreenOnly;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public DamageArea getDamageArea() {
        return damageArea;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public java.util.List<Exposure> getExposures() {
        return exposures;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public HireCar getHireCar() {
        return hireCar;
    }

    @ApiModelProperty(
            value = "unique identifier for the vehicle incident",
            example = "CC:123456",
            required = false
    )
    public String getIncidentId() {
        return incidentId;
    }

    @ApiModelProperty(
            value = "Party type in relationship to IAG/NRMA. ref data - https://confluence.iag.com.au/display/GICP/CC+Loss+Party+Type",
            example = "insured",
            required = false
    )
    public String getLossPartyType() {
        return lossPartyType;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Party getOwner() {
        return owner;
    }

    @ApiModelProperty(
            value = "Indicates if this is likely to be a total loss claim",
            example = "true",
            required = false
    )
    public Boolean getPossibleTotalLoss() {
        return possibleTotalLoss;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public RiskUnit getRiskUnit() {
        return riskUnit;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public TaxiBenefit getTaxiBenefit() {
        return taxiBenefit;
    }

    @ApiModelProperty(
            value = "indicates if the vehicle was parked at time of incident",
            required = false
    )
    public Boolean getVehicleParked() {
        return vehicleParked;
    }

    @ApiModelProperty(
            value = "indicates if the vehicle was towed",
            required = false
    )
    public Boolean getVehicleTowed() {
        return vehicleTowed;
    }

    @ApiModelProperty(
            value = "indicates if the vehicle has only windscreen damage",
            example = "true",
            required = false
    )
    public Boolean getWindScreenOnly() {
        return windScreenOnly;
    }


}