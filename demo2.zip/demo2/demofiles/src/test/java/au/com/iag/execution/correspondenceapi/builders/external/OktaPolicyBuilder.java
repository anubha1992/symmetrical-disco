package au.com.iag.execution.correspondenceapi.builders.external;

import au.com.iag.execution.common.model.motor.PolicyDetails;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class OktaPolicyBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;

    public PolicyDetails buildRequest() throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService
                        .generateStringFromResource("requests/correspondence-api/motor-api/authUserIdentifiedMotorQuoteRequest.json")
                        , PolicyDetails.class);
    }
}
