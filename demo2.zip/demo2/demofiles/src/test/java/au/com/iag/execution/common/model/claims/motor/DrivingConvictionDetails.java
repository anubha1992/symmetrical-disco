package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import com.fasterxml.jackson.datatype.jsr310.deser.*;
import lombok.Data;
import java.io.*;
import java.time.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class DrivingConvictionDetails implements Serializable {


    private String type;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate date;

    private String sentence;
}
