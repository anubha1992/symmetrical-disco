package au.com.iag.execution.common.service.motor;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.math.*;

@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class SearchMotorRepairerRequest {
    private String causeOfLoss;
    private Boolean damageSeverity;
    private String generalNatureOfLoss;
    private Integer numberOfResults;
    private String postcode;
    private String suburb;
    private String typeOfWork;
    private String vehicleClass;
    private String vehicleMake;
    private BigDecimal vehicleValue;
    private Integer vehicleYear;
    private Boolean isInsuredVehicle;
    private String requesterId;
    private Boolean vehicleSafeToDrive;
}
