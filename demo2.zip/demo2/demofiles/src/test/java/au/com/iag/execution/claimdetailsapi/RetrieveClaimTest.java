package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.*;
import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.execution.common.service.lodgeclaims.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@Tags({@Tag("RecoveryJourney"), @Tag("RetrieveClaimTest"), @Tag("ClaimDetails"),@Tag("NZClaimDetails")})
public class RetrieveClaimTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    ClaimDetailService claimDetailService;
    @Autowired
    ClaimsDbService claimsDbService;
    @Autowired
    WimpDbService wimpDbService;
    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    @Autowired
    LodgeMotorClaimService lodgeMotorClaimService;

    @Autowired
            LodgePropertyClaimService lodgePropertyClaimService;

    List<Map<String, Object>> claimIdDetails;
    private String claimId;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;

    @Value("${test.api.source.system}")
    private String apiSourceSystem;

    private ClaimDetailsArtifact claimDetailsArtifact;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimResultSet(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        if (claimIdDetails.isEmpty()){
            Assertions.fail("Could not find claims for product " +productCode);
        }
        claimId = claimDetailsRequestBuilder.getClaimId(claimIdDetails, productCode);
        claimDetailsArtifact = claimDetailsRequestBuilder.setUpRetrieveClaimDetails();
    }

    /*
    JAPI-423 : Service should return 401 when there is no/Invalid token and 404 when invalid claimid is input.
     */
    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @Test
    public void retrieveClaimDetailsForInvalidClaimId() {
        claimId = "CLAIM00000";
        claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_NOT_FOUND);
    }

    @Test
    public void inValidSecuritySystemRetrieveClaimDetails() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityConsumerSystemRetrieveClaimDetails() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityTokenRetrieveClaim() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void inValidSecurityTokenRetrieveClaim() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void noUserSecurityTokenRetrieveClaim() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_USER);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_UNAUTHORIZED);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveClaimDetailsForValidClaimId() throws Exception {
        claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyRetrieveClaim(response, claimId, productCode);
    }
    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveClaimDetailsForValidClaimIdTwo() throws Exception {
        claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyRetrieveClaim(response, claimId, productCode);
    }

    /*JAPI-403 : Add "allocation_exists" flag to the claim details retrieve claim operation
     * New Setup method added because setup method in beforeeach was setpe is not querying claims having ServiceRequest
     * Assertion to verify the flag value has been added within test method as other claims without service request will have false
     */
    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveClaimDetailsWithServiceReq() throws Exception {
        setUpDataWithServiceReq();
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyRetrieveClaim(response, claimId, productCode);
    }

    /*JAPI-69 :View Loss Items
    Assertion of lossitems is covered within this test as
    claims retrieved in other tests may not be having loss items
 */
    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveClaimDetailsWithLossItems() throws Exception {
        setUpDataWithLossItems();
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyRetrieveClaim(response, claimId, productCode);
        try {
            assertThat(response.jsonPath().getList("claim.incidents.exposures.coverage.loss_items").size(), greaterThan(0));
        } catch (AssertionError ex) {
            ex.printStackTrace();
            fail("Loss Items array size not matched in response ");
        }
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void retrieveClaimDetailsForNZClaimId() throws Exception {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyRetrieveClaim(response, claimId, productCode);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void retrieveClaimDetailsForValidClaimIdExternal() throws Exception {
        claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        claimDetailsRequestBuilder.buildClaimDetailsExternal(claimDetailsArtifact);

        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToRetrieveClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyRetrieveClaim(response, claimId, productCode);
    }

    private void setUpDataWithServiceReq() throws Exception {
        List<Map<String, Object>> claimIdDetailsForServiceReq = claimsDbService.getClaimsHavingServiceRequest(productCode);
        if (claimIdDetailsForServiceReq.isEmpty()){
            Assertions.fail("Could not find claims having service request for product " +productCode);
        }

        claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetailsForServiceReq, brand);
    }

    private void setUpDataWithLossItems() throws Exception {
        List<Map<String, Object>> claimIdDetailsForLossItems = claimsDbService.getClaimsHavingLossItems(productCode);
        if (claimIdDetailsForLossItems.isEmpty()){
            Assertions.fail("Could not find claims having loss items for product " +productCode);
        }

        claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetailsForLossItems, brand);
    }

    private String createRequestToRetrieveClaimDetails(String claimId) {
        StringBuffer url = new StringBuffer();
        url.append("/get/"+claimId);
        return url.toString();
    }
}
