package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class AssetGroup implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("vehicle_assets")
    private java.util.List<MotorVehicleAsset> vehicleAssets = new java.util.ArrayList<MotorVehicleAsset>();

  
    @ApiModelProperty(
        value = "List of vehicle assets",
        required = false
    )
    public java.util.List<MotorVehicleAsset> getVehicleAssets() {
       return vehicleAssets;
    }
 

}