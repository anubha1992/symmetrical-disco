package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleDriver implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("imposed_excess")
    private Double imposedExcess ;
    @JsonProperty("party_id")
    private String partyId ;
    @JsonProperty("total_excess")
    private Double totalExcess ;

  
    @ApiModelProperty(
        value = "Additional imposed excess amount applicable for this driver",
        example = "250.0",
        required = false
    )
    public Double getImposedExcess() {
       return imposedExcess;
    }
 
    @ApiModelProperty(
        value = "Driver party id",
        example = "12345567890",
        required = false
    )
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Total excess amount applicable for this driver",
        example = "1000.0",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Double getTotalExcess() {
       return totalExcess;
    }
 

}