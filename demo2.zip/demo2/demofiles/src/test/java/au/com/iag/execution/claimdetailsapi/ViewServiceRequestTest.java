package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.*;
import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.hamcrest.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static au.com.iag.core.model.security.BaseSecurityConstants.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@Tags({@Tag("RecoveryJourney"), @Tag("ViewServiceRequest"), @Tag("ClaimDetails"), @Tag("NZClaimDetails")})
public class ViewServiceRequestTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    ClaimDetailService claimDetailService;
    @Autowired
    ClaimsDbService claimsDbService;
    @Autowired
    WimpDbService wimpDbService;
    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    List<Map<String, Object>> claimIdDetails;
    private String claimId;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;
    private ClaimDetailsArtifact claimDetailsArtifact;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimsHavingServiceRequest(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        if (claimIdDetails.isEmpty()){
            Assertions.fail("Could not find claims having service request for product " +productCode);
        }
        claimId = claimIdDetails.get(new Random().nextInt(claimIdDetails.size())).get(DB_CC_CLAIMNUMBER).toString();
        setClaimDetailsArtifact(claimDetailsRequestBuilder.setUpClaimDetails());

    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @Test
    public void viewServiceRequest() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_OK);
        responseFieldVerification(response);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void viewNZServiceRequest() {
        String claimId = setUpNZData();
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_OK);
        responseFieldVerification(response);
    }

    @Test
    public void viewServiceRequestWithInvalidClaimId() {
        claimId = "COMO99900000";
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_NOT_FOUND);
    }

    @Test
    public void inValidSecuritySystemViewServiceRequest() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityConsumerSystemViewServiceRequest() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityTokenViewServiceRequest() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_UNAUTHORIZED);
    }

    @Test
    public void inValidSecurityTokenViewServiceRequest() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_UNAUTHORIZED);

    }

    /*
     *JAPI-419 : Authenticate User has access to specific claim ID
     * when retrieving service requests
     */
    @Test
    public void validSecurityTokenDiffClaimViewServiceRequest() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveServiceRequests("COL300000001"), SC_UNAUTHORIZED);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void viewServiceRequestExternal() {

        claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        claimDetailsRequestBuilder.buildClaimDetailsExternal(claimDetailsArtifact);
        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToRetrieveServiceRequests(claimId), SC_OK);
        responseFieldVerification(response);
    }


    public ClaimDetailsArtifact getClaimDetailsArtifact() {
        return claimDetailsArtifact;
    }

    public void setClaimDetailsArtifact(ClaimDetailsArtifact claimDetailsArtifact) {
        this.claimDetailsArtifact = claimDetailsArtifact;
    }

    private String createRequestToRetrieveServiceRequests(String claimId) {
        StringBuffer url = new StringBuffer();
        url.append("/get/"+claimId+"/service-request");
        return url.toString();
    }

    private String setUpNZData() {
        String claimIdentifier = null;
        if ((brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("NZSTATE") || brand.equalsIgnoreCase("STATE"))) {
            if (productCode.equalsIgnoreCase("MOT")) {
                claimIdentifier = "C3008852";
            } else {
                claimIdentifier = "C3000003";
            }
        } else if (brand.equalsIgnoreCase("AMI")) {
            if (productCode.equalsIgnoreCase("MOT")) {
                claimIdentifier = "C3006136";
            } else {
                claimIdentifier = "C3082228";
            }
        }
        return claimIdentifier;
    }

    private void responseFieldVerification(Response response) {
        assertNotNull(response.path("claim_identifier"));
        assertNotNull(response.path("service_requests.service_requests"));
        String responseClaimId = response.path("claim_identifier");
        try {
            assertThat(responseClaimId, Matchers.containsString(claimId));
        } catch (AssertionError ex) {
            ex.printStackTrace();
            fail("Claim  number not matched in response \n. Expected: " + claimId + " || Actual: " + responseClaimId);
        }
        if (productCode.equalsIgnoreCase("MOT")||productCode.equalsIgnoreCase("COM")) {
            assertNotNull(response.path("service_requests[0].service_providers[0].can_arrange_hire_car"));
            String relationship = response.path("service_requests[0].service_providers[0].contact_details[0].relationship").toString();
            if (response.path("service_requests[0].type").toString().equalsIgnoreCase("REQUEST_FOR_SERVICE_REPAIRER_ALLOCATION")) {
                if (relationship.equalsIgnoreCase("MOTOR_CLAIMS_MANAGEMENT_CENTRE")) {
                    assertThat(response.path("service_requests[0].service_providers[0].is_hub").toString(), Matchers.containsString("true"));
                } else {
                    assertThat(response.path("service_requests[0].service_providers[0].is_hub").toString(), Matchers.containsString("false"));
                }

                if (relationship.equalsIgnoreCase("PARTNER") || relationship.equalsIgnoreCase("EXCLUSIVE_PARTNER") || relationship.equalsIgnoreCase("MOTOR_CLAIMS_MANAGEMENT_CENTRE")) {
                    assertThat(response.path("service_requests[0].service_providers[0].can_arrange_hire_car").toString(), Matchers.containsString("true"));
                }
                else{
                    assertThat(response.path("service_requests[0].service_providers[0].can_arrange_hire_car").toString(), Matchers.containsString("false"));
                }
            }
            else{
                assertThat(response.path("service_requests[0].service_providers[0].can_arrange_hire_car").toString(), Matchers.containsString("false"));
            }
        }
        else if (productCode.equalsIgnoreCase("COH")||productCode.equalsIgnoreCase("COL")){
            assertNotNull(response.path("service_requests.allocations.external_status"));
            assertNotNull(response.path("service_requests.allocations.purchase_order_type"));
        }
    }
}
