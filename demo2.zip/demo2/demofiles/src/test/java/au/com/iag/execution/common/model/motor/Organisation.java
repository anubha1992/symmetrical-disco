package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Organisation implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("addresses")
    private java.util.List<MailingAddress> addresses = new java.util.ArrayList<MailingAddress>();
    @JsonProperty("email_contacts")
    private EmailContacts emailContacts = new EmailContacts();
    @JsonProperty("names")
    private java.util.List<OrganisationName> names = new java.util.ArrayList<OrganisationName>();
    @JsonProperty("party_id")
    private String partyId ;
    @JsonProperty("phone_contacts")
    private PhoneContacts phoneContacts = new PhoneContacts();
    @JsonProperty("preferences")
    private PreferenceDetails preferences = new PreferenceDetails();
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("registered_numbers")
    private java.util.List<RegisteredNumber> registeredNumbers = new java.util.ArrayList<RegisteredNumber>();
    @JsonProperty("temp_id")
    private String tempId ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "List of addresses of the organisation",
        required = false
    )
    public java.util.List<MailingAddress> getAddresses() {
       return addresses;
    }
 
    @ApiModelProperty(
        value = "Email contact details of the organisation",
        required = false
    )
    public EmailContacts getEmailContacts() {
       return emailContacts;
    }
 
    @ApiModelProperty(
        value = "List of names of the organisation",
        required = false
    )
    public java.util.List<OrganisationName> getNames() {
       return names;
    }
 
    @ApiModelProperty(
        value = "Party identifier of this organisation party. Identified customer party id has IAG recognised MDM party identifier. Anonymous customer party id prefixed with either TEMP or ANON",
        example = "IAG0000000461981222",
        required = false
    )
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Phone contact details",
        required = false
    )
    public PhoneContacts getPhoneContacts() {
       return phoneContacts;
    }
 
    @ApiModelProperty(
        value = "Marketing related preferences of the individual",
        required = false
    )
    public PreferenceDetails getPreferences() {
       return preferences;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "pc:581922",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "List of registered numbers for this organisation",
        required = false
    )
    public java.util.List<RegisteredNumber> getRegisteredNumbers() {
       return registeredNumbers;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000222",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 
    @ApiModelProperty(
        value = "Type of Organisation for example privately limited [Ref Data: organisation_types]",
        example = "PTY_LTD",
        required = false
    )
    public String getType() {
       return type;
    }
 

}