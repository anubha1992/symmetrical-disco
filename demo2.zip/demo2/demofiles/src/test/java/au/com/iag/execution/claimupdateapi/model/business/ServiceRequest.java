package au.com.iag.execution.claimupdateapi.model.business;

import au.com.iag.execution.common.model.claims.motor.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.time.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class ServiceRequest {

    private String type;
    private String jobType;
    private String specialInstruction;
    private Boolean collectExcess;
    private String supplierId;
    private List<Incident> incidents;
    private Boolean customerAcknowledgement;
    private String serviceRequestId;
    private String createdByAssessor;
    private LocalDateTime creationDate;
    private Boolean reportFeeRequired;
    private String serviceProviderType;
    private String speciality;
    private String status;
    private String mobilityOption;

}
