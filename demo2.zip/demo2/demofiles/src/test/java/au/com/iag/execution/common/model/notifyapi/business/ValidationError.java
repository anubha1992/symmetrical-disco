package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class ValidationError implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("category")
    private String category;
    @JsonProperty("code")
    private String code;
    @JsonProperty("description")
    private String description;
    @JsonProperty("field")
    private String field;
    @JsonProperty("rule_id")
    private String ruleId;
    @JsonProperty("rule_name")
    private String ruleName;
    @JsonProperty("severity")
    private String severity;

  
    @ApiModelProperty(
        value = "Category is optional",
        example = "validation_failed",
        required = false
    )
    public String getCategory() {
       return category;
    }
 
    @ApiModelProperty(
        value = "Code representing the validation rule that failed",
        example = "IN123",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getCode() {
       return code;
    }
 
    @ApiModelProperty(
        value = "Description of the validation error",
        example = "Name cannot be blank",
        required = false
    )
    public String getDescription() {
       return description;
    }
 
    @ApiModelProperty(
        value = "The name of the input field that triggered a validation error",
        example = "firstName",
        required = false
    )
    public String getField() {
       return field;
    }
 
    @ApiModelProperty(
        value = "Rule Id is optionally",
        example = "Rule001",
        required = false
    )
    public String getRuleId() {
       return ruleId;
    }
 
    @ApiModelProperty(
        value = "Rule Name is optionally",
        example = "Storage Type",
        required = false
    )
    public String getRuleName() {
       return ruleName;
    }
 
    @ApiModelProperty(
        value = "Severity: error or warning",
        example = "error",
        required = false
    )
    public String getSeverity() {
       return severity;
    }
 

}