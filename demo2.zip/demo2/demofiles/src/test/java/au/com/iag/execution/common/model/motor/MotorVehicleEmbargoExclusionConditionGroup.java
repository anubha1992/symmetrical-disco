package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class MotorVehicleEmbargoExclusionConditionGroup implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("embargo_exclusions")
    private EmbargoExclusions embargoExclusions = new EmbargoExclusions();
    @JsonProperty("exclusions")
    private MotorVehicleExclusions exclusions = new MotorVehicleExclusions();

  
    @ApiModelProperty(
        value = "Embargo exclusions",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusions getEmbargoExclusions() {
       return embargoExclusions;
    }
 
    @ApiModelProperty(
        value = "Motor vehicle exclusions",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public MotorVehicleExclusions getExclusions() {
       return exclusions;
    }
 

}