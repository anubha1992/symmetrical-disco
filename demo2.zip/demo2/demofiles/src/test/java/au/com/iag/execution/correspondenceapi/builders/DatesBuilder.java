package au.com.iag.execution.correspondenceapi.builders;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.DATE_FORMAT;
import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.JSON_POLICY_DATE_FORMAT;

@Component
public class DatesBuilder {

    public String formatInsertEffectiveDate(String dateAsYyyyMmDd){
        try {
            LocalDateTime localDateTimeUpdated = getLocalDate(dateAsYyyyMmDd).atTime(20, 21, 34);
            return DateTimeFormatter.ofPattern(JSON_POLICY_DATE_FORMAT).format(localDateTimeUpdated.atZone(ZoneId.systemDefault()));
        }
        catch (DateTimeParseException dateTimeParseException){
            return null;
        }
    }

    public String formatInsertEffectiveDate(LocalDate localDate){
        try {
            LocalDateTime localDateTimeUpdated = localDate.atTime(20,21,34);
            return DateTimeFormatter.ofPattern(JSON_POLICY_DATE_FORMAT).format(localDateTimeUpdated.atZone(ZoneId.systemDefault()));
        }
        catch (DateTimeParseException dateTimeParseException){
            return null;
        }
    }

    public String formatInsertEffectiveDateForEnterpriseRefDataQuery(String date){
        try {
            if (date != null)
                return DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX").format(DateTimeFormatter.ofPattern(JSON_POLICY_DATE_FORMAT).parse(date));
        }
        catch (DateTimeParseException dateTimeParseException){
            //Just ignore and return null
        }
        return null;
    }

    private LocalDate getLocalDate(String date){
        final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        return LocalDate.parse(date, dateTimeFormatter);
    }
}
