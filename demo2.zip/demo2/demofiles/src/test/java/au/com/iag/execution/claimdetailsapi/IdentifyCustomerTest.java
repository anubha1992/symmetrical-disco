package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.*;

import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tags({@Tag("RecoveryJourney"), @Tag("IdentifyCustomerTest"), @Tag("ClaimDetails")})
public class IdentifyCustomerTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    ClaimDetailService claimDetailService;

    @Autowired
    WimpDbService wimpDbService;

    @Autowired
    ClaimsDbService claimsDbService;

    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    private ClaimDetailsArtifact claimDetailsArtifact;

    List<Map<String, Object>> claimIdDetails;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimResultSet(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        setClaimDetailsArtifact(claimDetailsRequestBuilder.setUpClaimDetails());
    }

    @Test
    public void identifyCustomerDetailsForInvalidClaimId() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToIdentifyClaimDetails("CLAIM00000"), SC_NOT_FOUND);
        String errorMessage = "Could not find Claim 'CLAIM00000'";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    @Test
    public void inValidSecuritySystemIdentifyCustomerDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToIdentifyClaimDetails("CLAIM00000"), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_VALIDATION_FAILURE);
    }

    @Test
    public void noSecurityConsumerSystemIdentifyCustomerDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToIdentifyClaimDetails("CLAIM00000"), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_SYSTEM);
    }

    @Test
    public void noSecurityTokenIdentifyCustomerDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToIdentifyClaimDetails("CLAIM00000"), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_TOKEN_MISSING);
    }

    @Test
    public void inValidSecurityTokenIdentifyCustomerDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToIdentifyClaimDetails("CLAIM00000"), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, "Security Token Validation Failure: Invalid System Token provided ");
    }

    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @Test
    public void identifyCustomerDetailsForValidClaimId() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();

        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToIdentifyClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyClaimDetailsResponse(response);
    }

    @Test
    public void identifyCustomerDetailsForValidClaimIdExternal() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.buildClaimDetailsExternal(getClaimDetailsArtifact());

        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);

        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToIdentifyClaimDetails(claimId), SC_OK);
        claimDetailsVerifier.verifyClaimDetailsResponse(response);
    }

    public ClaimDetailsArtifact getClaimDetailsArtifact() {
        return claimDetailsArtifact;
    }

    public void setClaimDetailsArtifact(ClaimDetailsArtifact claimDetailsArtifact) {
        this.claimDetailsArtifact = claimDetailsArtifact;
    }

    private String createRequestToIdentifyClaimDetails(String claimId) {
        StringBuffer url = new StringBuffer();
        url.append("/"+claimId+"/authorised-parties");
        return url.toString();
    }

}
