package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "Contains coverage information for strata")
public class StrataAsset implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("asset_number")
    private String assetNumber;
    @JsonProperty("building")
    private StrataBuildingDetails building;
    @JsonProperty("contents")
    private StrataContentsDetails contents;
    @JsonProperty("location")
    private Address location;
    @JsonProperty("parties")
    private AssetParty parties;

  
    @ApiModelProperty(
        value = "Asset Number",
        example = "12345",
        required = false
    )
    public String getAssetNumber() {
       return assetNumber;
    }
 
    @ApiModelProperty(
        value = "Detailed information of home building",
        required = false
    )
    public StrataBuildingDetails getBuilding() {
       return building;
    }
 
    @ApiModelProperty(
        value = "Detailed information of home contents",
        required = false
    )
    public StrataContentsDetails getContents() {
       return contents;
    }
 
    @ApiModelProperty(
        value = "Location of the Asset",
        required = false
    )
    public Address getLocation() {
       return location;
    }
 
    @ApiModelProperty(
        value = "Parties on the asset e.g. Financier, Owner",
        required = false
    )
    public AssetParty getParties() {
       return parties;
    }
 

}