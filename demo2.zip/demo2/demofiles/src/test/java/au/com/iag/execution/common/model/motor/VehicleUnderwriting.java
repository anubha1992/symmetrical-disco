package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleUnderwriting implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("family")
    private String family ;
    @JsonProperty("risk_category")
    private String riskCategory ;

  
    @ApiModelProperty(
        value = "Vehicle Family",
        required = false
    )
    public String getFamily() {
       return family;
    }
 
    @ApiModelProperty(
        value = "Vehicle Asset Category",
        required = false
    )
    public String getRiskCategory() {
       return riskCategory;
    }
 

}