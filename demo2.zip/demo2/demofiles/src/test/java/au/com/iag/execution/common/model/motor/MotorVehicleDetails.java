package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains vehicle details")
public class MotorVehicleDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("body_type")
    private String bodyType ;
    @JsonProperty("damages")
    private java.util.List<String> damages = new java.util.ArrayList<String>();
    @JsonProperty("engine")
    private VehicleEngineDetails engine = new VehicleEngineDetails();
    @JsonProperty("equipment_level")
    private String equipmentLevel ;
    @JsonProperty("external_references")
    private VehicleExternalReferences externalReferences = new VehicleExternalReferences();
    @JsonProperty("family")
    private String family ;
    @JsonProperty("high_theft")
    private Boolean highTheft ;
    @JsonProperty("include_modifications")
    private Boolean includeModifications ;
    @JsonProperty("make")
    private String make ;
    @JsonProperty("model")
    private String model ;
    @JsonProperty("modifications")
    private java.util.List<String> modifications = new java.util.ArrayList<String>();
    @JsonProperty("provenance")
    private java.util.List<String> provenance = new java.util.ArrayList<String>();
    @JsonProperty("rating")
    private String rating ;
    @JsonProperty("registration_number")
    private String registrationNumber ;
    @JsonProperty("registration_state")
    private String registrationState ;
    @JsonProperty("series")
    private String series ;
    @JsonProperty("tare_weight")
    private Integer tareWeight ;
    @JsonProperty("valuation_region")
    private VehicleValuationRegion valuationRegion = new VehicleValuationRegion();
    @JsonProperty("vehicle_identifier")
    private String vehicleIdentifier ;
    @JsonProperty("vehicle_underwriting")
    private VehicleUnderwriting vehicleUnderwriting = new VehicleUnderwriting();
    @JsonProperty("vehicle_valuation")
    private VehicleValuation vehicleValuation = new VehicleValuation();
    @JsonProperty("vin_number")
    private String vinNumber ;
    @JsonProperty("year")
    private Integer year ;

  
    @ApiModelProperty(
        value = "Vehicle body/shape type",
        example = "SUV",
        required = false
    )
    public String getBodyType() {
       return bodyType;
    }
 
    @ApiModelProperty(
        value = "Damages on the vehicle. [Ref Data: vehicle_damages]",
        required = false
    )
    public java.util.List<String> getDamages() {
       return damages;
    }
 
    @ApiModelProperty(
        value = "Engine details",
        required = false
    )
    public VehicleEngineDetails getEngine() {
       return engine;
    }
 
    @ApiModelProperty(
        value = "Equipment details of the vehicle given by manufacturer",
        example = "Luxury",
        required = false
    )
    public String getEquipmentLevel() {
       return equipmentLevel;
    }
 
    @ApiModelProperty(
        value = "External Reference details",
        required = false
    )
    public VehicleExternalReferences getExternalReferences() {
       return externalReferences;
    }
 
    @ApiModelProperty(
        value = "Vehicle Family",
        required = false
    )
    public String getFamily() {
       return family;
    }
 
    @ApiModelProperty(
        value = "Indicator for high theft",
        required = false
    )
    public Boolean getHighTheft() {
       return highTheft;
    }
 
    @ApiModelProperty(
        value = "Indicator to include modifications",
        required = false
    )
    public Boolean getIncludeModifications() {
       return includeModifications;
    }
 
    @ApiModelProperty(
        value = "Vehicle make. [Constraint: &#x60;vehicle_make&#x60;]",
        example = "Mazda",
        required = false
    )
    public String getMake() {
       return make;
    }
 
    @ApiModelProperty(
        value = "Vehicle model. [Constraint: &#x60;vehicle_model&#x60;]",
        example = "CX-9",
        required = false
    )
    public String getModel() {
       return model;
    }
 
    @ApiModelProperty(
        value = "List of modifications done on vehicle. [Ref Data: vehicle_modification]",
        required = false
    )
    public java.util.List<String> getModifications() {
       return modifications;
    }
 
    @ApiModelProperty(
        value = "Provenance indicates data source provider or user edited [Ref Data: provenance]",
        required = false
    )
    public java.util.List<String> getProvenance() {
       return provenance;
    }
 
    @ApiModelProperty(
        value = "Vehicle Rating Details",
        example = "5 Star",
        required = false
    )
    public String getRating() {
       return rating;
    }
 
    @ApiModelProperty(
        value = "Vehicle Registration Number",
        example = "BS46LL",
        required = false
    )
    public String getRegistrationNumber() {
       return registrationNumber;
    }
 
    @ApiModelProperty(
        value = "Vehicle rego state",
        example = "VIC",
        required = false
    )
    public String getRegistrationState() {
       return registrationState;
    }
 
    @ApiModelProperty(
        value = "Series of the vehicle given by manufacturer",
        example = "Azami",
        required = false
    )
    public String getSeries() {
       return series;
    }
 
    @ApiModelProperty(
        value = "Vehicle Tare Weight",
        required = false
    )
    public Integer getTareWeight() {
       return tareWeight;
    }
 
    @ApiModelProperty(
        value = "Valuation Region details",
        required = false
    )
    public VehicleValuationRegion getValuationRegion() {
       return valuationRegion;
    }
 
    @ApiModelProperty(
        value = "National Vehicle Identification Code",
        example = "ABC0001",
        required = false
    )
    public String getVehicleIdentifier() {
       return vehicleIdentifier;
    }
 
    @ApiModelProperty(
        value = "Vehicle underwriting details",
        required = false
    )
    public VehicleUnderwriting getVehicleUnderwriting() {
       return vehicleUnderwriting;
    }
 
    @ApiModelProperty(
        value = "Vehicle valuation details",
        required = false
    )
    public VehicleValuation getVehicleValuation() {
       return vehicleValuation;
    }
 
    @ApiModelProperty(
        value = "Vehicle Identification Number",
        example = "JHFTA03H900001083",
        required = false
    )
    public String getVinNumber() {
       return vinNumber;
    }
 
    @ApiModelProperty(
        value = "Year vehicle was manufactured. [Constraint: &#x60;vehicle_year&#x60;]",
        example = "2019",
        required = false
    )
    public Integer getYear() {
       return year;
    }
 

}