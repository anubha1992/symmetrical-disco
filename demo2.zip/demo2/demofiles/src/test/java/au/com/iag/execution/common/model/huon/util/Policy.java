package au.com.iag.execution.common.model.huon.util;

import au.com.iag.execution.common.exception.*;
import org.apache.commons.collections.map.*;
import java.lang.reflect.*;
import java.text.*;
import java.util.*;

public class Policy {
    //Distributors
    public final static String NRMA = "NRMA";
    public final static String NRMAQLD = "NRMAQLD";
    public final static String SGIC = "SGIC";
    public final static String SGIO = "SGIO";
    public final static String RACV = "RACV";

    //Risk types
    public final static String CRCP = "CRCP";
    public final static String CRCP_PLUS = "CRCP+";
    public final static String CRFT = "CRFT";
    public final static String CRTP = "CRTP";
    public final static String BKCP = "BKCP";
    public final static String BKTP = "BKTP";

    public final static String BLDG = "BLDG";
    public final static String BLDG_PLUS = "BLDG+";
    public final static String CONT = "CONT";
    public final static String CONT_PLUS = "CONT+";
    public final static String HPAC = "HPAC";
    public final static String HPAC_PLUS = "HPAC+";
    public final static String LAND = "LAND";

    public final static String BOT = "BOT";
    public final static String ONS = "ONS";
    public final static String TOU = "TOU";
    public final static String TRL = "TRL";

    public final static String VVC = "VVC";        //Both product name and risk type name
    public final static String MOTOR = "MOTOR";
    public final static String HOME = "HOME";
    public final static String CTP = "CTP";
    public final static String BOAT = "BOAT";
    public final static String CARAVAN = "CARAVAN";


    //Payment options
    public final static String ANNUAL = "Annual";
    public final static String MONTHLY = "Monthly";
    public final static String PAID = "Paid";
    public final static String UNPAID = "Unpaid";
    public final static String RECEIPT_NO_BATCH = "Receipt no batch";
    public final static String QUOTE = "Quote";        //By now, not used by HUON

    //Policy status
    public final static String CURRENT = "CURRENT";
    public final static String RENEWAL = "RENEWAL";

    //Policy capture levels
    /**
     * Capture basic information for a policy:
     * 1. Policy header
     * 2. Property or vehicle information
     * 3. U/W information
     * 4. Owners and drivers, but without drive experience and claim history
     * 5. Bill plan, status and premium
     */
    public final static int CAPTURE_BASIC = 1;

    /**
     * In addition to basic, it also capture:
     * 1. Owners and drivers: driver experience and claim history
     */
    public final static int CAPTURE_INTERMEDIATE = 2;

    /**
     * [RESERED] not used now
     */
    public final static int CAPTURE_ADVANCED = 3;
    /**
     * [RESERED] not used now
     */
    public final static int CAPTURE_FULL = 4;


    //	protected boolean registerSsc;
//	protected boolean eDocConsent;
    protected String distributor = "";
    protected String customerNumber = "";
    protected String customerDateOfBirth = "";


    protected String customerPhoneNumber = "";

    protected String riskType = "";
    protected Date effectiveDate;  //Initialize in constructor
    protected String policyNumber = "";
    protected String rmspolicyNumber = "";

    protected boolean newRiskLocation = false;        //used by HUON to indicate the policy's risk address is different to owner's address
    protected Address riskAddress = new Address();
    protected Address mailingAddress = new Address();
    protected String mailingAddressString = "";
    protected String mailingAddressCustname = "";
    protected String insuredName = "";

    protected String ncb = "";
    protected String coverNcbProtect = "N";
    protected String ncbOverrideReason = "";
    protected String ncbOverridePolicy = "";

    //layUpMonth
    protected String layUpMonth = "";
    protected String isLayUp = "";

    //online discount amount
    protected String onlineDiscountAmount = "";

    //other Party Type
    protected String otherPartyType = "";

    //For RACV and before GO Discount
    protected String mpd = "N";
    protected String lpd = "N";
    protected String yoi = "";

    //Previous insurer
    protected String previousInsurer = "AAMI";
    protected static HashMap<String, String> insurerMap = null;
    HashMap<String, String> manualreview = null;

    //Do authorization or not
    protected boolean doAuthorization = true;

    protected String paymentOption = PAID;
    protected String billPlan = ANNUAL;
    protected int instalments = 0;        //HUON use only: 0 means pay all instalments

    protected String quoteNumber = "";
    protected String status = "";
    protected String reason = "";
    protected String amendBillingPlanFlag = "No";
    protected String NextActivityStatus = "";
    private String manualReviewFlag;

    private String vehicleRegistrationNumber;
    private String suburb;
    private String postcode;

    private String streetName;

    public Policy(String policyNumber) {
        this.policyNumber = policyNumber;
        //Today's date as default
        Calendar cal = Calendar.getInstance();
        effectiveDate = cal.getTime();

        initInsurerMap();
        initmanualreviewMap();
    }

//	protected String email;
//	protected String confirmEmail;
//	protected String mobile;

    public String getManualReviewFlag() {

        switch (manualReviewFlag) {

            case "P":
                manualReviewFlag = "Product";
                break;
            case "W":
                manualReviewFlag = "Claims (Wollongong)";
                break;
            case "A":
                manualReviewFlag = "Claims (Parramatta)";
                break;
            case "B":
                manualReviewFlag = "Niche Products (Boat, Caravan, Trailer)";
                break;
            case "C":
                manualReviewFlag = "CTP";
                break;
            case "D":
                manualReviewFlag = "SCV/DQ Risk Address";
                break;
            case "E":
                manualReviewFlag = "Claims (Newcastle)";
                break;
            case "F":
                manualReviewFlag = "Price Certainty";
                break;
            case "G":
                manualReviewFlag = "Beat by 10 Percent (Renewal)";
                break;
            case "H":
                manualReviewFlag = "Claims (Hurstville)";
                break;
            case "L":
                manualReviewFlag = "Claims (Property Loss)";
                break;
            case "O":
                manualReviewFlag = "Other Areas";
                break;
            case "Q":
                manualReviewFlag = "Claims U/W (PLI States)";
                break;
            case "R":
                manualReviewFlag = "Claims (Canberra)";
                break;
            case "S":
                manualReviewFlag = "S&M";
                break;
            case "N":
                manualReviewFlag = "Not Selected";
                break;
            case "V":
                manualReviewFlag = "Claims U/W (Victoria)";
                break;
            default:
                manualReviewFlag = "Not Selected";

        }
        return manualReviewFlag;

    }

    public void setmanualReviewFlag(String manualReviewFlag) {
        this.manualReviewFlag = manualReviewFlag;

    }

    public String getNextActivityStatus() {
        return this.NextActivityStatus;
    }

    public void setNextActivityStatus(String nextActivityStatus) {
        this.NextActivityStatus = nextActivityStatus;
    }

    /**
     * Normally, it is not called directly. We should call its sub-classes constructors.
     *
     * @param distributor
     * @param riskType
     */
    public Policy(String distributor, String riskType) {
//		registerSsc = false;
//		eDocConsent = true;
        this.distributor = distributor;
        this.riskType = riskType;

        //Today's date as default
        Calendar cal = Calendar.getInstance();
        effectiveDate = cal.getTime();

        initInsurerMap();
        initmanualreviewMap();

//		email = "test@iag.com.au";
//		confirmEmail = "test@iag.com.au";
//		mobile = "";
    }

    public List<SuperOwnerDriver> getSuperOwnerDrivers() {
        return getSuperOwnerDrivers();
    }

    public List<SuperOwnerDriver> getSuperOwnersOnly() {
        return getSuperOwnersOnly();
    }

    public String getDistributor() {
        return distributor;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerDateOfBirth() {
        return customerDateOfBirth;
    }

    public void setCustomerDateOfBirth(String customerDateOfBirth) {
        this.customerDateOfBirth = customerDateOfBirth;
    }

    public String getCustomerPhoneNumber() {
        return customerPhoneNumber;
    }

    public void setCustomerPhoneNumber(String customerPhoneNumber) {
        this.customerPhoneNumber = customerPhoneNumber;
    }

    public String getSubcoy() {
        String subcoy = "";

        switch (distributor) {
            case NRMA:
                if (riskAddress.getState().equalsIgnoreCase("TAS"))
                    subcoy = "100";
                else
                    subcoy = "200";
                break;
            case NRMAQLD:
                subcoy = "100";
                break;
            case RACV:
                subcoy = "300";
                break;
            case SGIC:
                subcoy = "500";
                break;
            case SGIO:
                subcoy = "600";
                break;
        }

        return subcoy;
    }

    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    public Address getMailingAddress() {
        return mailingAddress;
    }

    public void setMailingAddress(Address mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    public String getMailingAddressString() {
        return mailingAddressString;
    }

    public void setMailingAddressString(String mailingAddressString) throws InvalidDataException {
        this.mailingAddressString = mailingAddressString;
    }

    public String getMailingAddressCustname() {
        return mailingAddressCustname;
    }

    public void setMailingAddressCustname(String mailingAddressCustname) throws InvalidDataException {
        this.mailingAddressCustname = mailingAddressCustname;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }


    public String getVehicleRegistrationNumber() {
        return vehicleRegistrationNumber;
    }

    public void setVehicleRegistrationNumber(String vehicleRegistrationNumber) {
        this.vehicleRegistrationNumber = vehicleRegistrationNumber;
    }

    /**
     * Get HUON agent.
     *
     * @return like "CIT"
     */
    public String getHuonAgent() {
        String agent = "";

        if (getProductType().equalsIgnoreCase(BOAT) || getProductType().equalsIgnoreCase(CARAVAN) || getProductType().equalsIgnoreCase(VVC)) {
            if (distributor.equalsIgnoreCase(RACV))
                agent = "PLR";
            else
                agent = "PLI";
            return agent;
        }


        switch (distributor) {
            case NRMA:
                if (riskAddress.getStateCode().endsWith("7"))
                    agent = "TAT";
                else
                    agent = "CIT";
                break;
            case NRMAQLD:
                agent = "BNE";
                break;
            case SGIC:
                agent = "ADE";
                break;
            case SGIO:
                agent = "PER";
                break;
            case RACV:
                agent = "RNP";
                break;

        }
        return agent;
    }

    /**
     * Get HUON Section.
     *
     * @return like "MTN"
     * @throws InvalidDataException
     */
    public String getHuonSection() throws InvalidDataException {
        String section = "";

        if (this.riskType.equalsIgnoreCase(Policy.CTP))
            return "CTP";

        String lastLetter = "";
        String distributor = getDistributor();
        switch (distributor) {
            case NRMA:
                lastLetter = "N";
                if (riskAddress.getState().equals("TAS"))
                    lastLetter = "T";
                break;
            case NRMAQLD:
                lastLetter = "Q";
                break;
            case SGIC:
                lastLetter = "S";
                break;
            case SGIO:
                lastLetter = "W";
                break;
            case RACV:
                lastLetter = "R";
                break;
        }

        String product = "";
        switch (riskType) {
            case CRCP:
            case CRCP_PLUS:
            case CRFT:
            case CRTP:
            case BKCP:
            case BKTP:
                product = "MT";
                break;
            case BLDG:
            case BLDG_PLUS:
            case CONT:
            case CONT_PLUS:
            case HPAC:
            case HPAC_PLUS:
            case LAND:
                product = "HM";
                break;
            case BOT:
                product = "BT";
                break;
            case ONS:
                product = "OS";
                break;
            case TOU:
                product = "TO";
                break;
            case TRL:
                product = "TR";
                break;
            case "VVC":
                product = "VV";
                break;
            default:
                throw new InvalidDataException("Risk type --- " + riskType + " is invalid.");
        }

        section = product + lastLetter;

        return section;
    }

    public String getRiskType() {
        return riskType;
    }

    static public String getDefaultDistributor(String riskState) {
        String defaultDistributor = NRMA;

        switch (riskState.trim().toUpperCase()) {
            case "NSW":
            case "TAS":
            case "ACT":
                defaultDistributor = NRMA;
                break;
            case "QLD":
                defaultDistributor = NRMAQLD;
                break;
            case "SA":
                defaultDistributor = SGIC;
                break;
            case "WA":
                defaultDistributor = SGIO;
                break;
            case "VIC":
                defaultDistributor = RACV;
                break;
        }

        return defaultDistributor;
    }

    /**
     * Get default state by distributor
     *
     * @param distributor
     * @return
     */
    public static String getDefautState(String distributor) {
        String state = "";
        switch (distributor) {
            case NRMA:
                state = "NSW";
                break;
            case NRMAQLD:
                state = "QLD";
                break;
            case SGIC:
                state = "SA";
                break;
            case SGIO:
                state = "WA";
                break;
            case RACV:
                state = "VIC";
                break;

        }
        return state;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType.toUpperCase();
    }

    /**
     * get risk type by component name and full name
     *
     * @param componentName     like "COMPREHENSIVE COVER"
     * @param componentFullName like "Car Comprehensive"
     */
    static public String getRiskTypeByComponentName(String componentName, String componentFullName) {
        String risk = "";
        switch (componentName.trim().toUpperCase()) {
            case "COMPREHENSIVE COVER":
                if (componentFullName.toLowerCase().startsWith("car")) {
                    if (componentFullName.toLowerCase().contains("plus"))
                        risk = CRCP_PLUS;
                    else
                        risk = CRCP;
                } else {
                    //bike
                    risk = BKCP;
                }

                break;
            case "THIRD PARTY FIRE &amp; THEFT":
            case "THIRD PARTY FIRE & THEFT":
                risk = CRFT;
                break;
            case "THIRD PARTY PROPERTY DAMAGE":
                if (componentFullName.toLowerCase().startsWith("car"))
                    risk = CRTP;
                else
                    risk = BKTP;
                break;
        }

        return risk;
    }

    /**
     * Get coverage name based on risk type
     *
     * @return like "COMP", TPPD", etc
     */
    public static String getCoverageName(String riskType) {
        String coverageName = "";

        switch (riskType) {
            case Policy.CRCP:
            case Policy.CRCP_PLUS:
            case Policy.BKCP:
            case Policy.VVC:
                coverageName = "COMP";
                break;
            case Policy.CRFT:
                coverageName = "TPFT";
                break;
            case Policy.CRTP:
            case Policy.BKTP:
                coverageName = "TPPD";
                break;
        }

        return coverageName;
    }

    /**
     * Get coverage long name like "Comprehensive Cover" for for COMP
     *
     * @param riskType
     * @return
     * @throws InvalidDataException
     */
    public static String getCoverageLongName(String riskType) throws InvalidDataException {
        String coverageLongName = "";

        switch (riskType) {
            case Policy.CRCP:
            case Policy.CRCP_PLUS:
            case Policy.BKCP:
                coverageLongName = "COMPREHENSIVE COVER";
                break;
            case Policy.CRFT:
                coverageLongName = "THIRD PARTY FIRE  &amp; THEFT";
                break;
            case Policy.CRTP:
            case Policy.BKTP:
                coverageLongName = "THIRD PARTY PROPERTY DAMAGE";
                break;
            default:
                throw new InvalidDataException("This risk type hasn't been handled by Policy.getCoverageLongName: " + riskType);
        }

        return coverageLongName;
    }


    public static String getCoverageFullName(String riskType) throws InvalidDataException {
        String fullName = "";

        switch (riskType) {
            case Policy.CRCP:
                fullName = "Car Comprehensive";
                break;
            case Policy.CRCP_PLUS:
                fullName = "Car Comprehensive Plus";
                break;
            case Policy.CRFT:
                fullName = "Car Third Party Fire &amp; Theft";
                break;
            case Policy.CRTP:
                fullName = "Car Third Party Property Damage";
                break;
            case Policy.BKCP:
                fullName = "Bike Comprehensive";
                break;
            case Policy.BKTP:
                fullName = "Bike Third Party Property Damage";
                break;
            case Policy.BLDG:
                fullName = "Home Buildings";
                break;
            case Policy.BLDG_PLUS:
                fullName = "Home Buildings Plus";
                break;
            case Policy.CONT:
                fullName = "Home Contents";
                break;
            case Policy.CONT_PLUS:
                fullName = "Home Contents Plus";
                break;
            case Policy.HPAC:
                fullName = "Home Combines";
                break;
            case Policy.HPAC_PLUS:
                fullName = "Home Combines Plus";
                break;
            default:
                throw new InvalidDataException("This risk type hasn't been handled by Policy.getCoverageFullName: " + riskType);
        }

        return fullName;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    /*
     * Return effective date as string format "dd/MM/yyyy"
     */
    public String getEffectiveDateString() {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(this.effectiveDate);
    }

    public String getEffectiveDateStringInLocalDateFormat() {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//	        return formatter.format(DateUtils.addDays(this.effectiveDate, 1));
        return formatter.format(this.effectiveDate);
    }

    public String getEffectiveDatePlusOneDay() {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(this.effectiveDate);
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Set effective date
     * Format is "", or "dd/MM/yyyy", or "today", or "tomorrow", or "Dn+"
     *
     * @param effectiveDate acceptable input are (case insensitive):
     *                      - "" or "today"
     *                      - "dd/MM/yyyy": a specific date
     *                      - "tomorrow"
     *                      - "yesterday"
     *                      - "today-last-year"
     *                      - "today-next-year"
     *                      - "tomorrow-last-year"
     *                      - "tomorrow-next-year"
     *                      - "yesterday-last-year"
     *                      - "yesterday-next-year"
     *                      - "n" or "+n": n days after today
     *                      - "-n": n days before today
     */
    public void setEffectiveDate(String effectiveDate) throws ParseException {
        switch (effectiveDate.toLowerCase()) {
            case "":
            case "today":
                this.effectiveDate = DataHandler.today();
                break;
            case "tomorrow":
                this.effectiveDate = DataHandler.tomorrow();
                break;
            case "yesterday":
                this.effectiveDate = DataHandler.yesterday();
                break;
            case "today-last-year":
                this.effectiveDate = DataHandler.todayLastYear();
                break;
            case "today-next-year":
                this.effectiveDate = DataHandler.todayNextYear();
                break;
            case "tomorrow-last-year":
                this.effectiveDate = DataHandler.tomorrowLastYear();
                break;
            case "tomorrow-next-year":
                this.effectiveDate = DataHandler.tomorrowNextYear();
                break;
            case "yesterday-last-year":
                this.effectiveDate = DataHandler.yesterdayLastYear();
                break;
            case "yesterday-next-year":
                this.effectiveDate = DataHandler.yesterdayNextYear();
                break;
            case "last-quarter":
                this.effectiveDate = DataHandler.lastQuarter();
                break;
            case "last-half-year":
                this.effectiveDate = DataHandler.lastHalfYear();
                break;
            default:
                //check whether it is an integer
                boolean isInt = false;
                int n;
                try {
                    n = Integer.parseInt(effectiveDate);
                    isInt = true;
                } catch (NumberFormatException nfe) {
                    n = 0;
                    isInt = false;
                }

                if (isInt) {
                    if (n > 3650 || n < -3650) {
                        throw new ParseException("The offeset date for policy effective date is more than 10 years", 0);
                    }
                }

                if (isInt) {
                    this.effectiveDate = DataHandler.dateOffset(effectiveDate);
                } else {
                    // assume it is "dd/MM/yyyy" or "yyyy-MM-dd"
                    if (effectiveDate.contains("-")) {
                        DateFormat formatter;
                        if (effectiveDate.length() <= 8)
                            formatter = new SimpleDateFormat("yy-MM-dd");
                        else
                            formatter = new SimpleDateFormat("yyyy-MM-dd");
                        this.effectiveDate = formatter.parse(effectiveDate);
                    } else {
                        DateFormat formatter;
                        if (effectiveDate.length() <= 8)
                            formatter = new SimpleDateFormat("dd/MM/yy");
                        else
                            formatter = new SimpleDateFormat("dd/MM/yyyy");
                        this.effectiveDate = formatter.parse(effectiveDate);
                    }
                }
                break;
        }

    }


    public boolean isNewRiskLocation() {
        return newRiskLocation;
    }


    public void setNewRiskLocation(boolean newRiskLocation) {
        this.newRiskLocation = newRiskLocation;
    }


    public Address getRiskAddress() {
        return riskAddress;
    }

    /**
     * Set policy's risk address
     *
     * @param riskAddress
     * @param differentToOwner true - it is a different address with the owner's address; false - it is same address as owner's address
     * @throws InvalidDataException
     */
    public void setRiskAddress(Address riskAddress, boolean differentToOwner) throws InvalidDataException {
        this.riskAddress = riskAddress;
        this.newRiskLocation = differentToOwner;
    }

    /**
     * Set risk address with indicator and unit no
     *
     * @param indicator
     * @param unitNo
     * @param streetNo
     * @param StreetName
     * @param StreetType
     * @param suburb
     * @param postcode
     * @param state
     * @param differentToOwner
     * @throws InvalidDataException
     */
    public void setRiskAddress(String indicator, String unitNo, String streetNo, String StreetName,
                               String StreetType, String suburb, String postcode, String state,
                               boolean differentToOwner) throws InvalidDataException {

        this.riskAddress = new Address(indicator, unitNo, streetNo, StreetName, StreetType, suburb, postcode, state);
        this.newRiskLocation = differentToOwner;

    }

    /**
     * Set address
     *
     * @param streetNo
     * @param StreetName
     * @param StreetType
     * @param suburb
     * @param postcode
     * @param state
     * @param differentToOwner
     * @throws InvalidDataException
     */
    public void setRiskAddress(String streetNo, String StreetName,
                               String StreetType, String suburb, String postcode, String state,
                               boolean differentToOwner) throws InvalidDataException {

        this.riskAddress = new Address(streetNo, StreetName, StreetType, suburb, postcode, state);
        this.newRiskLocation = differentToOwner;

    }

    /**
     * Set address by only surburb, postcode and state.
     * Street address is set to 1 Fake ST
     *
     * @param suburb
     * @param postcode
     * @param state
     * @param differentToOwner
     * @throws InvalidDataException
     */
    public void setRiskAddress(String suburb, String postcode, String state,
                               boolean differentToOwner) throws InvalidDataException {

        this.riskAddress = new Address("1", "Fake", "ST", suburb, postcode, state);
        this.newRiskLocation = differentToOwner;

    }

    /**
     * Set address by only state.
     * Suburb will be the capital city and stree is 1 Fake ST
     *
     * @param state
     * @param differentToOwner
     * @throws InvalidDataException
     */
    public void setRiskAddress(String state,
                               boolean differentToOwner) throws InvalidDataException {

        String suburb = "";
        String postcode = "";
        switch (state.toUpperCase()) {
            case "NSW":
                suburb = "Sydney";
                postcode = "2000";
                break;
            case "ACT":
                suburb = "Canberra";
                postcode = "2600";
                break;
            case "VIC":
                suburb = "Melbourne";
                postcode = "3000";
                break;
            case "QLD":
                suburb = "Brisbane";
                postcode = "4000";
                break;
            case "SA":
                suburb = "Adelaide";
                postcode = "5000";
                break;
            case "WA":
                suburb = "Perth";
                postcode = "6000";
                break;
            case "TAS":
                suburb = "Hobart";
                postcode = "7000";
                break;
        }

        this.riskAddress = new Address("1", "Fake", "ST", suburb, postcode, state);
        this.newRiskLocation = differentToOwner;

    }

    public String getNcb() {
        return ncb;
    }

    public void setNcb(String ncb) {
        this.ncb = ncb;
    }

    public String getCoverNcbProtect() {
        return coverNcbProtect.toUpperCase();
    }


    public void setCoverNcbProtect(String coverNcbProtect) {
        if (coverNcbProtect.equalsIgnoreCase("Y") || coverNcbProtect.equalsIgnoreCase("Yes"))
            coverNcbProtect = "P";
        this.coverNcbProtect = coverNcbProtect;
    }

    public String getNCBOverrideReason() {
        return ncbOverrideReason;
    }

    public void setNCBOverrideReason(String ncbOverrideReason) {
        this.ncbOverrideReason = ncbOverrideReason;
    }

    public String getNCBOverridePolicy() {
        return ncbOverridePolicy;
    }

    public void setNCBOverridePolicy(String ncbOverridePolicy) {
        this.ncbOverridePolicy = ncbOverridePolicy;
    }

    //layUpMonth

    public String getLayUpMonth() {
        return layUpMonth;
    }

    public void setLayUpMonth(String layUpMonth) {
        this.layUpMonth = layUpMonth;
    }

    public String getOnlineDiscountAmount() {
        return onlineDiscountAmount;
    }

    public void setOnlineDiscountAmount(String onlineDiscountAmount) {
        this.onlineDiscountAmount = onlineDiscountAmount;
    }

    public String getotherPartyType() {
        return otherPartyType;
    }

    public void setotherPartyType(String otherPartyType) {
        this.otherPartyType = otherPartyType;
    }

    public String getIsLayUp() {
        return isLayUp;
    }

    public void setIsLayUp(String isLayUp) {
        this.isLayUp = isLayUp;
    }


    public String getMpd() {
        return mpd;
    }

    public void setMpd(String mpd) {
        this.mpd = mpd;
    }

    public String getLpd() {
        return lpd;
    }

    public void setLpd(String lpd) {
        this.lpd = lpd;
    }

    public String getYoi() {
        return yoi;
    }

    public void setYoi(String yoi) {
        this.yoi = yoi;
    }

    /**
     * Get previous insurer with HUON format like "AAMI"
     *
     * @return
     */
    public String getHuonPreviousInsurer() {
        String huonInsurer = "";

        for (Map.Entry<String, String> entry : insurerMap.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(this.previousInsurer) || entry.getValue().equalsIgnoreCase(this.previousInsurer)) {
                huonInsurer = entry.getKey();
                break;
            }
        }

        return huonInsurer;
    }

    /**
     * Get previous insurer with Web format like "AAMI INSURANCE"
     *
     * @return
     */
    public String getWebPreviousInsurer() {
        String webInsurer = "";

        for (Map.Entry<String, String> entry : insurerMap.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(this.previousInsurer) || entry.getValue().equalsIgnoreCase(this.previousInsurer)) {
                webInsurer = entry.getValue();
                break;
            }
        }

        return webInsurer;
    }

    /**
     * Set previous insurer
     *
     * @param previousInsurer it can be HUON format or web format
     */
    public void setPreviousInsurer(String previousInsurer) {
        this.previousInsurer = previousInsurer.trim().toUpperCase();
    }


    public boolean isDoAuthorization() {
        return doAuthorization;
    }


    public void setDoAuthorization(boolean doAuthorization) {
        this.doAuthorization = doAuthorization;
    }

    public void setDoAuthorization(String doAuthorization) {
        if (doAuthorization.equalsIgnoreCase("N") || doAuthorization.equalsIgnoreCase("No") || doAuthorization.equalsIgnoreCase("false"))
            this.doAuthorization = false;
        else
            this.doAuthorization = true;
    }


    public String getPaymentOption() {
        return paymentOption;
    }

    public void setPaymentOption(String paymentOption) {
        if (!paymentOption.isEmpty())
            this.paymentOption = paymentOption;
    }

    public String getBillPlan() {
        return billPlan;
    }

    public void setBillPlan(String billPlan) {
        if (!billPlan.isEmpty()) {
            if (billPlan.equalsIgnoreCase("PBTM")) {
                billPlan = "Monthly";
            }
            this.billPlan = billPlan;
        }
    }

    //code to add
    public void setBillPlan(String billPlan, boolean amendBillingPlan) {
        this.billPlan = billPlan;
        this.amendBillingPlanFlag = "Yes";
    }

    public String getAmendBillingPlanFlag() {
        return amendBillingPlanFlag;
    }

    /**
     * Get how many instalments to pay for monthly only
     *
     * @return
     */
    public int getInstalments() {
        return instalments;
    }

    /**
     * Set how many instalments to pay for monthly only
     *
     * @param instalments
     */
    public void setInstalments(int instalments) {
        this.instalments = instalments;
    }


    public String getQuoteNumber() {
        return quoteNumber;
    }

    public void setQuoteNumber(String quoteNumber) {
        this.quoteNumber = quoteNumber.replaceAll(" ", "");
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber.replaceAll(" ", "");
    }


    public void setRMSPolicyNumber(String rmspolicyNumber) {
        this.rmspolicyNumber = rmspolicyNumber.replaceAll(" ", "");
    }


//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public String getConfirmEmail() {
//		return confirmEmail;
//	}
//
//	public void setConfirmEmail(String confirmEmail) {
//		this.confirmEmail = confirmEmail;
//	}
//
//	public String getMobile() {
//		return mobile;
//	}
//
//	public void setMobile(String mobile) {
//		this.mobile = mobile;
//	}

    public String getStatus() {
        return status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setStatus(String status) {
        if (status.toUpperCase().startsWith("RENEW"))
            this.status = RENEWAL;

        else if (status.equalsIgnoreCase("Current") || status.isEmpty())
            this.status = CURRENT;
        else
            this.status = status;
    }

    public String getProductType() {
        String product = "";

        switch (riskType) {
            case CRCP:
            case CRCP_PLUS:
            case CRFT:
            case CRTP:
            case BKCP:
            case BKTP:
                product = MOTOR;
                break;
            case BLDG:
            case BLDG_PLUS:
            case CONT:
            case CONT_PLUS:
            case HPAC:
            case HPAC_PLUS:
            case LAND:
                product = HOME;
                break;
            case CTP:
                product = CTP;
                break;
            case BOT:
                product = BOAT;
                break;
            case ONS:
            case TOU:
            case TRL:
                product = CARAVAN;
                break;
            case VVC:
                product = VVC;
                break;
        }

        return product;
    }

    public String getHuonProductType() {
        String huonProduct = "";

        String product = getProductType();
        switch (product) {
            case Policy.MOTOR:
                huonProduct = "MOT";
                break;
            case Policy.HOME:
                huonProduct = "HOM";
                break;
            case Policy.BOAT:
                huonProduct = "BOT";
                break;
            case Policy.CARAVAN:
                huonProduct = "CVT";
                break;
            case Policy.VVC:
                huonProduct = "VVC";
                break;
        }

        return huonProduct;
    }


    public void initInsurerMap() {
        if (insurerMap == null)
            insurerMap = new HashMap<String, String>();

        insurerMap.put("AAMI", "AAMI INSURANCE");
        insurerMap.put("ALLI", "ALLIANZ INSURANCE");
        insurerMap.put("ANZ", "ANZ");
        insurerMap.put("APIA", "AUSTRALIAN PENSIONERS INSURANCE AGENCY");
        insurerMap.put("AXA", "AXA INSURANCE");
        insurerMap.put("BUDG", "BUDGETDIRECT");
        insurerMap.put("CBA", "COMMONWEALTH BANK");
        insurerMap.put("CGU", "CGU INSURANCE");
        insurerMap.put("DCTD", "DIRECDIAL INSURANCE");
        insurerMap.put("ELD", "ELDERS");
        insurerMap.put("GIO", "GIO INSURANCE");
        insurerMap.put("HBF", "HBF");
        insurerMap.put("INHS", "INSURANCE HISTORY IS STORED AGAINST CLIENT");
        insurerMap.put("JCIA", "JUST CAR INSURANCE AGENCY PTY LTD");
        insurerMap.put("LUML", "LUMLEY GENERAL INSURANCE");
        insurerMap.put("MM", "QBE MERCANTILE MUTUAL");
        insurerMap.put("NAB", "NATIONAL AUSTRALIA");
        insurerMap.put("NPI", "NO PREVIOUS INSURER");
        insurerMap.put("NRMA", "NRMA INSURANCE");
        insurerMap.put("RACQ", "RACQ INSURANCE");
        insurerMap.put("RACT", "RACT (TASMANIA)");
        insurerMap.put("RACV", "RACV");
        insurerMap.put("RASA", "RAASA (SOUTH AUSTRALIA)");
        insurerMap.put("RAWA", "RAC (WESTERN AUSTRALIA)");
        insurerMap.put("RSAI", "ROYAL AND SUN ALLIANCE");
        insurerMap.put("SC", "SHANNONS CORPORATION PTY LTD");
        insurerMap.put("SGIC", "SGIC");
        insurerMap.put("SGIO", "SGIO");
        insurerMap.put("STG", "ST GEORGE BANK");
        insurerMap.put("SUNC", "SUNCORP INSURANCE");
        insurerMap.put("SWAN", "SWANN INSURANCE PTY LTD");
        insurerMap.put("UNKN", "ANY OTHER/INSURER UNKNOWN");
        insurerMap.put("WQBE", "WQBE");
        insurerMap.put("ZUR", "ZURICH");

    }

    public void initmanualreviewMap() {

        if (manualreview == null)
            manualreview = new HashMap<String, String>();

        manualreview.put("P", "Product");
        manualreview.put("W", "Claims (Wollongong)	");
        manualreview.put("A", "Claims (Parramatta)");
        manualreview.put("B", "Niche Products (Boat, Caravan, Trailer)	");
        manualreview.put("C", "CTP");
        manualreview.put("D", "SCV/DQ Risk Address	");
        manualreview.put("E", "Claims (Newcastle)");
        manualreview.put("F", "Price Certainty");
        manualreview.put("G", "Beat by 10 Percent (Renewal)	");
        manualreview.put("H", "Claims (Hurstville)	");
        manualreview.put("L", "Claims (Property Loss)");
        manualreview.put("O", "Other Areas");
        manualreview.put("Q", "Claims U/W (PLI States)");
        manualreview.put("R", "Claims (Canberra)");
        manualreview.put("S", "S&M");
        manualreview.put("V", "Claims U/W (Victoria)");

    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
//		sb.append(super.toString());

        Class<?> myClass = this.getClass();
        String thisName = Policy.class.getName();
        while (!myClass.getName().equalsIgnoreCase(thisName)) {
            myClass = myClass.getSuperclass();
        }

        try {
            Field[] fields = myClass.getDeclaredFields();

            for (Field field : fields) {
                String fieldName = field.getName();
                if (fieldName.equalsIgnoreCase("vehicle") || fieldName.equalsIgnoreCase("purpose") || fieldName.equalsIgnoreCase("ownerDrivers"))
                    continue;
                if (Modifier.isStatic(field.getModifiers()))
                    continue;
                field.setAccessible(true);
                sb.append(field.getName());
                sb.append("=");

                if (field.getType().getName().endsWith("Date")) {
                    Date date = (Date) field.get(this);
                    if (date != null) {
                        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                        sb.append(formatter.format(date));
                    } else {
                        sb.append("");
                    }
                } else {
                    sb.append(field.get(this));
                }
                sb.append("; ");
            }
        } catch (IllegalAccessException iae) {

        }
        return sb.toString();
    }

    /**
     * Copy information to this policy object
     *
     * @param policy
     * @throws IllegalAccessException
     * @throws IllegalArgumentException
     */
    public void copy(Policy policy) throws IllegalArgumentException, IllegalAccessException {
        Class<?> thisClass = this.getClass();
        String thisName = Policy.class.getName();
        while (!thisClass.getName().equalsIgnoreCase(thisName)) {
            thisClass = thisClass.getSuperclass();
        }
        Class<?> thatClass = policy.getClass();
        while (!thatClass.getName().equalsIgnoreCase(thisName)) {
            thatClass = thatClass.getSuperclass();
        }
//		Method[] methods = thisClass.getMethods();
        Field[] thisFields = thisClass.getDeclaredFields();
        Field[] thatFields = thatClass.getDeclaredFields();
        for (int i = 0; i < thisFields.length; i++) {
            if (Modifier.isStatic(thisFields[i].getModifiers()))
                continue;

            if (thisFields[i].getClass().getName().equalsIgnoreCase("Address"))
                System.out.println(thatFields[i].get(policy));
            thisFields[i].setAccessible(true);
            thatFields[i].setAccessible(true);
            thisFields[i].set(this, thatFields[i].get(policy));
//			System.out.println(field.getName() + " = " + field.get(this));

        }

//		this.setRiskType(policy.getRiskType());
//		this.setEffectiveDate(policy.getEffectiveDate());
//		this.setPolicyNumber(policy.getPolicyNumber());
//		this.setRiskAddress(policy.getRiskAddress(), true);
//		this.setNcb(policy.getNcb());
//		this.setCoverNcbProtect(policy.getCoverNcbProtect());
//		this.setPreviousInsurer(policy.getHuonPreviousInsurer());
//		this.setDoAuthorization(policy.isDoAuthorization());
//		this.setPaymentOption(policy.getPaymentOption());
//		this.setBillPlan(policy.getBillPlan());
//		this.setInstalments(policy.getInstalments());
//		this.setQuoteNumber(policy.getQuoteNumber());

    }

//	@Override
//	public String toString() {
//		StringBuilder sb = new StringBuilder("[");
//		
//		sb.append("distributor=");
//		sb.append(distributor);
//		sb.append(";");
//		
//		sb.append("riskType=");
//		sb.append(riskType);
//		sb.append(";");
//		
//		sb.append("effectiveDate=");
//		sb.append(effectiveDate);
//		sb.append(";");
//		
//		sb.append("newRiskLocation=");
//		sb.append(newRiskLocation);
//		sb.append(";");
//		
//		sb.append("riskAddress=");
//		sb.append(riskAddress);
//		sb.append(";");
//			
//		
//		sb.append("overrideNcb=");
//		sb.append(overrideNcb);
//		sb.append(";");
//			
//		
//		sb.append("coverNcbProtect=");
//		sb.append(coverNcbProtect);
//		sb.append(";");
//			
//		
//		sb.append("paymentOption=");
//		sb.append(paymentOption);
//		sb.append(";");
//		
//		sb.append("billPlan=");
//		sb.append(billPlan);
//		sb.append(";");
//		
//		sb.append("instalments=");
//		sb.append(instalments);
//		sb.append(";");
//		
//		sb.append("quoteNumber=");
//		sb.append(quoteNumber);
//		sb.append(";");
//		
//		sb.append("policyNumber=");
//		sb.append(policyNumber);
//		sb.append(";");
//			
//		sb.append("]");
//		return sb.toString();
//	}

    List list;
    public MultiValueMap mapRole = new MultiValueMap();

    public MultiValueMap getMapRole() {
        return mapRole;
    }

    public void setMapRole(MultiValueMap mapRole) {
        this.mapRole = mapRole;
    }
}
