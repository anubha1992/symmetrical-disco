package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Condition implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("field")
    private String field ;
    @JsonProperty("field_reference")
    private FieldReference fieldReference = new FieldReference();
    @JsonProperty("operator")
    private String operator ;
    @JsonProperty("value")
    private String value ;

  
    @ApiModelProperty(
        value = "The path to a dependent field whose value is to be compared in this condition.",
        required = false
    )
    public String getField() {
       return field;
    }
 
    @ApiModelProperty(
        value = "The field reference to a dependent field whose value is to be compared in this condition.",
        required = false
    )
    public FieldReference getFieldReference() {
       return fieldReference;
    }
 
    @ApiModelProperty(
        value = "Type of comparison to be performed. Values [EQUALS, NOT_EQUALS, GREATER_THAN, LESS_THAN, CONTAINS, NOT_CONTAINS]",
        required = false
    )
    public String getOperator() {
       return operator;
    }
 
    @ApiModelProperty(
        value = "Static value to evaluate the condition against",
        required = false
    )
    public String getValue() {
       return value;
    }
 

}