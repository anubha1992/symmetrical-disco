package au.com.iag.execution.common.model.huon.util;

import au.com.iag.execution.common.exception.*;
import java.lang.reflect.*;
import java.text.*;
import java.util.*;
import java.util.Map.*;

/**
 * A class of address used by client, contact or policy.
 * It handles different address format of website and HUON, like street type.
 */
public class Address {
    public final static String INDICATOR_HOUSE = "+";
    public final static String INDICATOR_UNIT = "U";
    public final static String INDICATOR_DUPLEX = "<";
    public final static String INDICATOR_FLAT = "(";
    public final static String INDICATOR_TOWNHOUSE = "{";
    public final static String INDICATOR_APT = "A";
    public final static String INDICATOR_LOT = "G";
    public final static String INDICATOR_PO_BOX = "P";
    public final static String INDICATOR_FARM = "R";
    public final static String INDICATOR_VILLA = "5";

    private String geoId = "";
    private String indicator = "";
    private String unitNo = "";
    private String indicator2 = "";
    private String unitNo2 = "";
    private String streetNo = "";
    private String streetName = "";
    private String streetType = "";        //Different for HUON and Web
    private String streetDirection = "";
    private String suburb = "";
    private String postcode = "";
    private String state = "";

    private String sequenceNumber = "";


    //A map of street types: key is HUON street type, and value is web street type
    private static HashMap<String, String> streetTypeMap = null;

    //Address indicator
    private static HashMap<String, String> indicatorMap = null;
    private static HashMap<String, String> streetDirectionMap = null;

    public Address() {
        geoId = "";
        indicator = "";
        unitNo = "";
        indicator2 = "";
        unitNo2 = "";
        streetNo = "";
        streetName = "";
        streetType = "";        //Different for HUON and Web
        streetDirection = "";
        suburb = "";
        postcode = "";
        state = "";
    }

    /**
     * Create an address with default street/suburb information.
     *
     * @param state
     */
    public Address(String state) {
        if (streetTypeMap == null) {
            streetTypeMap = new HashMap<String, String>();
            streetDirectionMap = new HashMap<String, String>();
            initializeStreetTypMap();
            initializeIndicatorMap();
            setDefault(state);
        }
    }

    /**
     * Create an address by provided suburb and street information.
     *
     * @param streetNo
     * @param streetName
     * @param streetType
     * @param suburb
     * @param postcode
     * @param state
     */
    public Address(String streetNo, String streetName, String streetType, String suburb, String postcode, String state) {
        if (streetTypeMap == null) {
            streetTypeMap = new HashMap<>();
            streetDirectionMap = new HashMap<>();
            initializeStreetTypMap();
            initializeIndicatorMap();
        }

        this.streetNo = streetNo.trim();
        this.streetName = streetName.trim();
        this.streetType = streetType.trim();
        this.suburb = suburb.trim();
        this.postcode = postcode.trim();
        this.state = state.trim();

    }

    public Address(String indicator, String unitNo, String streetNo, String streetName, String streetType, String suburb, String postcode, String state) throws InvalidDataException {
        if (streetTypeMap == null) {
            streetTypeMap = new HashMap<>();
            initializeStreetTypMap();
            initializeIndicatorMap();
        }

        setIndicator(indicator.trim());
        this.unitNo = unitNo.trim();
        this.streetNo = streetNo.trim();
        this.streetName = streetName.trim();
        this.streetType = streetType.trim();
        this.suburb = suburb.trim();
        this.postcode = postcode.trim();
        this.state = state.trim();

    }

    /**
     * Set default values for a client based on state
     *
     * @param state e.g. "NSW"
     */
    public void setDefault(String state) {
        Random random = new Random();
        ArrayList<String> streetNumbers = new ArrayList<>(Arrays.asList("232", "248", "206", "388"));
        ArrayList<String> streetNames = new ArrayList<>(Arrays.asList("George", "Pitt", "Kent"));
        streetNo = streetNumbers.get(random.nextInt(streetNumbers.size() - 1));
        streetName = streetNames.get(random.nextInt(streetNames.size() - 1));
        streetType = "Street";        //Different for HUON and Web
        switch (state.toUpperCase()) {
            case "NSW":
                suburb = "Sydney";
                postcode = "2000";
                break;
            case "ACT":
                suburb = "Canberra";
                postcode = "2601";
                break;
            case "QLD":
                suburb = "Brisbane";
                postcode = "4000";
                break;
            case "TAS":
                suburb = "Hobart";
                postcode = "7000";
                break;
            case "SA":
                suburb = "Adelaide";
                postcode = "5000";
                break;
            case "WA":
                suburb = "Perth";
                postcode = "6000";
                break;
            case "VIC":
                suburb = "Melbourne";
                postcode = "3000";
                break;
        }

        this.state = state;
    }

    /**
     * Get a full address string with format as: 388 George Street Sydney NSW 2000
     *
     * @return
     */
    public String getAddressFullString() {
        StringBuilder sb = new StringBuilder();
        if (!indicator.isEmpty()) {
            sb.append(indicator);
            sb.append(unitNo);
            sb.append(" ");
        }
        if (!indicator2.isEmpty()) {
            sb.append(indicator2);
            sb.append(unitNo2);
            sb.append(" ");
        }
        sb.append(streetNo);
        sb.append(" ");
        sb.append(streetName);
        sb.append(" ");
        sb.append(getHuonStreetType()); //Based on MQ request
        sb.append(" ");
        sb.append(suburb);
        sb.append(" ");
        sb.append(state);
        sb.append(" ");
        sb.append(postcode);

        return sb.toString();
    }

    /**
     * Get a full address string with format as: 388 George Street Sydney 2000 NSW
     *
     * @return
     * @throws InvalidDataException
     */
    public String getAddressFullString2() throws InvalidDataException {
        StringBuilder sb = new StringBuilder();
        if (!indicator.isEmpty()) {
            sb.append(indicator);
            sb.append(unitNo);
            sb.append(" ");
        }
        if (!indicator2.isEmpty()) {
            sb.append(indicator2);
            sb.append(unitNo2);
            sb.append(" ");
        }
        sb.append(streetNo);
        sb.append(" ");
        sb.append(streetName);
        sb.append(" ");
//		sb.append(getHuonStreetType()); //Based on MQ request
        sb.append(getWebStreetType());
        sb.append(" ");
        sb.append(suburb);
        sb.append(" ");
        sb.append(postcode);
        sb.append(" ");
        sb.append(state);


        return sb.toString();
    }


    /**
     * Extract street information from street string which does not include indicator/unit no
     *
     * @param streetString
     */
    public void extractStreet(String streetString) {

        while (true) {
            int index = streetString.indexOf("  ");
            if (index >= 0)
                streetString = streetString.replaceAll("  ", " ");
            else
                break;
        }

        String[] streets = streetString.split(" ");
        String streetNo = streets[0];
        //Direction
        boolean hasDirection = false;
        String huonDirection = "";
        for (Entry<String, String> entry : streetDirectionMap.entrySet()) {
            if (streets[streets.length - 1].equalsIgnoreCase(entry.getValue())) {
                huonDirection = entry.getKey();
                hasDirection = true;
                break;
            }
        }

        String streetType = "";
        String streetName = streets[1];
        if (hasDirection) {
            streetType = streets[streets.length - 2];
            if (streets.length > 4) {
                for (int i = 2; i < streets.length - 2; i++) {
                    streetName = streetName + " " + streets[i];
                }
            }
        } else {
            streetType = streets[streets.length - 1];
            if (streets.length > 3) {
                for (int i = 2; i < streets.length - 1; i++) {
                    streetName = streetName + " " + streets[i];
                }
            }
        }
        this.setStreetNo(streetNo);
        this.setStreetName(streetName);
        this.setStreetType(streetType, false);
        if (!huonDirection.isEmpty())
            this.setStreetDirection(huonDirection);
    }

    /**
     * Extract indicators/unit nos
     *
     * @param indicatorString like "SHED D1 UNIT U1"
     * @throws InvalidDataException
     */
    public void extractIndicators(String indicatorString) throws InvalidDataException {
        indicatorString = indicatorString.trim();
        if (indicatorString.isEmpty())
            return;

        String[] indicators = indicatorString.split(" ");
        if (indicators.length < 2)
            return;

        String indicator = "";
        String unitNo = "";
        String indicator2 = "";
        String unitNo2 = "";

        //Indicator and no
        for (Entry<String, String> entry : indicatorMap.entrySet()) {
            if (indicators[0].equalsIgnoreCase(entry.getValue())) {
                indicator = entry.getKey();
                unitNo = indicators[1];
                break;
            }
        }
        if (indicators.length >= 4) {
            for (Entry<String, String> entry : indicatorMap.entrySet()) {
                if (indicators[2].equalsIgnoreCase(entry.getValue())) {
                    indicator2 = entry.getKey();
                    unitNo2 = indicators[3];
                    break;
                }
            }
        }


        this.setIndicator(indicator);
        this.setUnitNo(unitNo);
        this.setIndicator2(indicator2);
        this.setUnitNo2(unitNo2);
    }

    /**
     * Extract each address field from a full address like "Unit U1 1 Fake Street"
     *
     * @param fullAddress
     * @throws InvalidDataException
     */
    public void extractAddressFromFullAddress(String fullAddress) throws InvalidDataException {
        if (fullAddress.isEmpty())
            return;

        fullAddress = fullAddress.trim().toUpperCase();

        //String indicator = "";
        //String unitNo = "";
        //String indicator2 = "";
        //String unitNo2 = "";

        //Indicator and no
        for (Entry<String, String> entry : indicatorMap.entrySet()) {
            if (fullAddress.startsWith(entry.getValue())) {
                indicator = entry.getKey();
                fullAddress = fullAddress.substring(entry.getValue().length() + 1).trim();
                int index = fullAddress.indexOf(" ");
                unitNo = fullAddress.substring(0, index);
                fullAddress = fullAddress.substring(index + 1).trim();
                break;
            }
        }
        for (Entry<String, String> entry : indicatorMap.entrySet()) {
            if (fullAddress.startsWith(entry.getValue())) {
                indicator2 = entry.getKey();
                fullAddress = fullAddress.substring(entry.getValue().length() + 1).trim();
                int index = fullAddress.indexOf(" ");
                unitNo2 = fullAddress.substring(0, index);
                fullAddress = fullAddress.substring(index + 1).trim();
                break;
            }
        }

        extractStreet(fullAddress);

        //		String[] streets = fullAddress.split(" ");
        //		String streetNo = streets[0];
        //		//Direction
        //		boolean hasDirection = false;
        //		String huonDirection = "";
        //		for (Map.Entry<String, String> entry : streetDirectionMap.entrySet()) {
        //			if (streets[streets.length-1].equalsIgnoreCase(entry.getValue())) {
        //				huonDirection = entry.getKey();
        //				hasDirection = true;
        //				break;
        //			}
        //		}
        //
        //		String streetType = "";
        //		String streetName = streets[1];
        //		if (hasDirection) {
        //			streetType = streets[streets.length-2];
        //			if (streets.length > 4) {
        //				for (int i = 2; i < streets.length-2; i++) {
        //					streetName = streetName + " " + streets[i];
        //				}
        //			}
        //		} else {
        //			streetType = streets[streets.length-1];
        //			if (streets.length > 3) {
        //				for (int i = 2; i < streets.length-1; i++) {
        //					streetName = streetName + " " + streets[i];
        //				}
        //			}
        //		}

        //this.setIndicator(indicator);
        //this.setUnitNo(unitNo);
        //this.setIndicator(indicator2);
        //this.setUnitNo(unitNo2);
        //		this.setStreetNo(streetNo);
        //		this.setStreetName(streetName);
        //		this.setStreetType(streetType, false);
        //		if (!huonDirection.isEmpty())
        //			this.setStreetDirection(huonDirection);
    }

    /**
     * Extract suburb, post code and state from a string
     *
     * @param suburbString like "SYDNEY NSW 2000"
     */
    public void extractSuburb(String suburbString) {
        String[] suburbs = suburbString.split(" ");
        String postcode = suburbs[suburbs.length - 1];
        String state = suburbs[suburbs.length - 2];
        String suburb = suburbs[0];
        if (suburbs.length > 3) {
            for (int i = 1; i < suburbs.length - 2; i++)
                suburb = suburb + " " + suburbs[i];
        }

        this.state = state;
        this.postcode = postcode;
        this.suburb = suburb;
    }

    /**
     * Get a street type's web type string from a HUON string
     *
     * @param huonStreetType a HUON street type string, e.g. "ST"
     * @return a Web String with the first letter upper case, e.g. "Street"
     */
    public String getWebStreetType(String huonStreetType) {
        String value = streetTypeMap.get(huonStreetType.toUpperCase());
        if (value == null)
            value = huonStreetType;

        if (value.isEmpty())
            return "";

        value = value.toLowerCase();
        value = value.substring(0, 1).toUpperCase() + value.substring(1);

        return value;
    }

    /**
     * Get a street type's HUON type string from a web string
     *
     * @param webStreetType a web string like "Street"
     * @return HUON string like "ST".
     */
    public String getHuonStreetType(String webStreetType) {
        String key = "";
        for (Entry<String, String> entry : streetTypeMap.entrySet()) {
            if (webStreetType.equalsIgnoreCase(entry.getValue())) {
                key = entry.getKey();
            }
        }

        return key;
    }


    /**
     * Get Indicator with HUON format, i.e. 1 charactor
     *
     * @return
     */
    public String getHuonIndicator() {
        if (this.indicator.trim().isEmpty())
            return "";

        String huonIndicator = "";
        if (this.indicator.length() == 1)
            huonIndicator = this.indicator;
        else {
            for (Entry<String, String> entry : indicatorMap.entrySet()) {
                if (entry.getValue().equalsIgnoreCase(this.indicator)) {
                    huonIndicator = entry.getKey();
                    break;
                }
            }
        }

        if (huonIndicator == null)
            huonIndicator = "";

        return huonIndicator;
    }

    /**
     * Get indicator with web format, i.e. a readable name
     *
     * @return
     */
    public String getWebIndicator() {
        if (this.indicator.trim().isEmpty())
            return "";

        String webIndicator = "";
        if (this.indicator.length() > 1)
            webIndicator = this.indicator;
        else {
            webIndicator = indicatorMap.get(this.indicator);
        }

        if (webIndicator == null)
            webIndicator = "";

        return webIndicator;
    }

    /**
     * Set indicator. It can be a HUON format or web format. The valid web
     * indicators:
     * <p>
     * <	DUPLEX
     * (	FLAT
     * +	HOUSE
     * &	MAISONETTE
     * $	PENTHOUSE
     * KIOSK
     * )	MARINE
     * ;	PRIVATE
     * >	SHED
     *
     * @param indicator
     * @throws InvalidDataException
     * @	STALL ~	REAR
     * {	TOWNHOUSE
     * A	APARTMENT
     * B	BOX
     * C	BUILDING
     * D	BAY
     * E	HANGAR
     * F	FLOOR
     * G	LOT
     * H	CABIN
     * I	PIER
     * }	RD
     * J	ROOM
     * K	FACTORY
     * L	LEVEL
     * M	MAILBAG
     * N	LODGE
     * O	OFFICE
     * P	PO
     * Q	RSD
     * R	FARM
     * S	SUITE
     * T	MS
     * U	UNIT
     * V	PMB
     * W	PORTION
     * X	POST
     * Y	RMB
     * Z	SHOP
     * 0	DIVISION
     * 1	COTTAGE
     * 2	SECTION
     * 3	SITE
     * 4	STUDIO
     * 5	VILLA
     * 6	BLOCK
     * 7	WARD
     * 8	CMB
     * 9	RSM
     */
    public void setIndicator(String indicator) throws InvalidDataException {
        if (indicator.trim().isEmpty()) {
            this.indicator = "";
            return;
        }

        if (indicator.trim().length() == 1) {
            boolean found = false;
            for (String key : indicatorMap.keySet()) {
                if (key.equalsIgnoreCase(indicator.trim())) {
                    this.indicator = indicator.trim();
                    found = true;
                    break;
                }
            }

            if (!found) {
                throw new InvalidDataException("The address indicator is invalid: " + indicator);
            }

        } else {
            boolean found = false;
            for (Entry<String, String> entry : indicatorMap.entrySet()) {
                if (entry.getValue().equalsIgnoreCase(indicator.trim())) {
                    this.indicator = entry.getKey();
                    found = true;
                    break;
                }
            }

            if (!found) {
                throw new InvalidDataException("The address indicator is invalid: " + indicator);
            }
        }
    }

    public String getUnitNo() {
        return unitNo;
    }

    public void setUnitNo(String unitNo) {
        this.unitNo = unitNo.trim();
    }

    /**
     * Get Indicator 2 with HUON format, i.e. 1 charactor
     *
     * @return
     */
    public String getHuonIndicator2() {
        if (this.indicator2.trim().isEmpty())
            return "";

        String huonIndicator = "";
        if (this.indicator2.length() == 1)
            huonIndicator = this.indicator2;
        else {
            for (Entry<String, String> entry : indicatorMap.entrySet()) {
                if (entry.getValue().equalsIgnoreCase(this.indicator2)) {
                    huonIndicator = entry.getKey();
                    break;
                }
            }
        }

        if (huonIndicator == null)
            huonIndicator = "";

        return huonIndicator;
    }

    /**
     * Get indicator with web format, i.e. a readable name
     *
     * @return
     */
    public String getWebIndicator2() {
        if (this.indicator2.trim().isEmpty())
            return "";

        String webIndicator = "";
        if (this.indicator2.length() > 1)
            webIndicator = this.indicator2;
        else {
            webIndicator = indicatorMap.get(this.indicator2);
        }

        if (webIndicator == null)
            webIndicator = "";

        return webIndicator;
    }

    /**
     * Set indicator. It can be a HUON format or web format. The valid web
     * indicators:
     * <p>
     * <	DUPLEX
     * (	FLAT
     * +	HOUSE
     * &	MAISONETTE
     * $	PENTHOUSE
     * KIOSK
     * )	MARINE
     * ;	PRIVATE
     * >	SHED
     *
     * @throws InvalidDataException
     * @	STALL ~	REAR
     * {	TOWNHOUSE
     * A	APARTMENT
     * B	BOX
     * C	BUILDING
     * D	BAY
     * E	HANGAR
     * F	FLOOR
     * G	LOT
     * H	CABIN
     * I	PIER
     * }	RD
     * J	ROOM
     * K	FACTORY
     * L	LEVEL
     * M	MAILBAG
     * N	LODGE
     * O	OFFICE
     * P	PO
     * Q	RSD
     * R	FARM
     * S	SUITE
     * T	MS
     * U	UNIT
     * V	PMB
     * W	PORTION
     * X	POST
     * Y	RMB
     * Z	SHOP
     * 0	DIVISION
     * 1	COTTAGE
     * 2	SECTION
     * 3	SITE
     * 4	STUDIO
     * 5	VILLA
     * 6	BLOCK
     * 7	WARD
     * 8	CMB
     * 9	RSM
     * <p>
     * //	 * @param indicator
     */
    public void setIndicator2(String indicator2) throws InvalidDataException {
        if (indicator2.trim().isEmpty()) {
            this.indicator2 = "";
            return;
        }

        if (indicator2.trim().length() == 1) {
            boolean found = false;
            for (String key : indicatorMap.keySet()) {
                if (key.equalsIgnoreCase(indicator2.trim())) {
                    this.indicator2 = indicator2.trim();
                    found = true;
                    break;
                }
            }

            if (!found) {
                throw new InvalidDataException("The address indicator is invalid: " + indicator2);
            }

        } else {
            boolean found = false;
            for (Entry<String, String> entry : indicatorMap.entrySet()) {
                if (entry.getValue().equalsIgnoreCase(indicator2.trim())) {
                    this.indicator2 = entry.getKey();
                    found = true;
                    break;
                }
            }

            if (!found) {
                throw new InvalidDataException("The address indicator is invalid: " + indicator2);
            }
        }
    }

    public String getUnitNo2() {
        return unitNo2;
    }

    public void setUnitNo2(String unitNo2) {
        this.unitNo2 = unitNo2.trim();
    }

    public String getStreetNo() {
        return streetNo;
    }

    public void setStreetNo(String streetNo) {
        this.streetNo = streetNo.trim();
    }

    public String getStreetName() {
        return DataHandler.formateWebString(streetName);
    }


    public void setStreetName(String streetName) {
        this.streetName = streetName.trim();
    }

    public String getStreetType() {
        return streetType;
    }

    public String getHuonStreetType() {
        String huonType = getHuonStreetType(this.streetType.trim());
        if (huonType.isEmpty())
            huonType = this.streetType.trim();

        return huonType;
    }

    public String getWebStreetType() {
        String webType = getWebStreetType(this.streetType);
        if (webType.isEmpty())
            webType = this.streetType;

        return webType;
    }

    /**
     * Set street type
     *
     * @param streetType
     * @param isHuon     true - it is HUON street type like "ST"; false - it is web street type like "Street"
     */
    public void setStreetType(String streetType, boolean isHuon) {
        if (isHuon) {
            streetType = getWebStreetType(streetType).trim();
        }
        this.streetType = streetType;
    }

    public String getHuonStreetDirection() {
        String huonDirection = "";
        for (Entry<String, String> entry : streetDirectionMap.entrySet()) {
            if (this.streetDirection.equalsIgnoreCase(entry.getValue())) {
                huonDirection = entry.getKey();
            }

            if (this.streetDirection.equalsIgnoreCase(entry.getKey())) {
                huonDirection = entry.getKey();
            }
            if (!huonDirection.isEmpty())
                break;
        }

        return huonDirection;
    }

    public String getWebStreetDirection() {
        String webDirection = "";
        for (Entry<String, String> entry : streetDirectionMap.entrySet()) {
            if (this.streetDirection.equalsIgnoreCase(entry.getValue())) {
                webDirection = entry.getValue();
            }

            if (this.streetDirection.equalsIgnoreCase(entry.getKey())) {
                webDirection = entry.getValue();
            }
            if (!webDirection.isEmpty())
                break;
        }

        return webDirection;
    }

    /**
     * Get a street Direction's HUON type string from a web string
     *
     * @param webStreetType a web string like "Street"
     * @return HUON string like "ST".
     */
    public String getHuonStreetDirection(String webStreetType) {
        String key = "";
        for (Entry<String, String> entry : streetTypeMap.entrySet()) {
            if (webStreetType.equalsIgnoreCase(entry.getValue())) {
                key = entry.getKey();
            }
        }

        return key;
    }

    public void setStreetDirection(String streetDirection) {
        this.streetDirection = streetDirection;
    }

    public String getSuburb() {
        return DataHandler.formateWebString(suburb);
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb.trim();
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state.trim();
    }

    /**
     * Set state by state code.
     *
     * @param code e.g. "02" or "2"
     */
    public void setStateByCode(String code) throws ParseException {
        switch (code.trim()) {
            case "01":
            case "1":
                this.state = "ACT";
                break;
            case "02":
            case "2":
                this.state = "NSW";
                break;
            case "03":
            case "3":
                this.state = "VIC";
                break;
            case "04":
            case "4":
                this.state = "QLD";
                break;
            case "05":
            case "5":
                this.state = "SA";
                break;
            case "06":
            case "6":
                this.state = "WA";
                break;
            case "07":
            case "7":
                this.state = "TAS";
                break;
            default:
                throw new ParseException("State code -- " + code + " -- is not a valid state code", 0);
        }

    }

    public String getStateCode() {
        String code = "";

        switch (this.state.trim()) {
            case "ACT":
                code = "01";
                break;
            case "NSW":
                code = "02";
                break;
            case "VIC":
                code = "03";
                break;
            case "QLD":
                code = "04";
                break;
            case "SA":
                code = "05";
                break;
            case "WA":
                code = "06";
                break;
            case "TAS":
                code = "07";
                break;
        }

        return code;
    }

    /**
     * Get state name like "NSW" from state code like "02" or "2"
     *
     * @param stateCode
     * @return
     */
    public static String getStateName(String stateCode) {
        String state = "";
        switch (stateCode) {
            case "01":
            case "1":
                state = "ACT";
                break;
            case "02":
            case "2":
                state = "NSW";
                break;
            case "03":
            case "3":
                state = "VIC";
                break;
            case "04":
            case "4":
                state = "QLD";
                break;
            case "05":
            case "5":
                state = "SA";
                break;
            case "06":
            case "6":
                state = "WA";
                break;
            case "7":
            case "07":
                state = "TAS";
                break;
        }
        return state;
    }


    public String getGeoId() {
        return geoId;
    }

    public void setGeoId(String geoId) {
        this.geoId = geoId;
    }

    /**
     * Get full suburb name.
     *
     * @return e.g. "Sydney 2000 NSW".
     */
    public String getFullSuburbName() {
        return suburb + " " + postcode + " " + state;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");

        Class<?> myClass = this.getClass();

        try {
            Field[] fields = myClass.getDeclaredFields();
            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers()))
                    continue;
                sb.append(field.getName());
                sb.append("=");
                sb.append(field.get(this));
                sb.append(";");
            }
        } catch (IllegalAccessException iae) {

        }
        sb.replace(sb.length() - 1, sb.length(), "]");
        //		sb.append("]");
        return sb.toString();
    }


    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    /**
     * whether 2 addresses are the same address (ignore street direction)
     *
     * @param anotherAddress
     * @return
     */
    public boolean equals(Address anotherAddress) {
        boolean equal = true;

        //postcode, suburb and state
        if (!this.getState().equalsIgnoreCase(anotherAddress.getState()))
            return false;
        if (!this.getPostcode().equalsIgnoreCase(anotherAddress.getPostcode()))
            return false;
        if (!this.getSuburb().equalsIgnoreCase(anotherAddress.getSuburb()))
            return false;

        //Indicators and unit nos
        if (!this.getHuonIndicator().equalsIgnoreCase(anotherAddress.getHuonIndicator()))
            return false;
        if (!this.getHuonIndicator2().equalsIgnoreCase(anotherAddress.getHuonIndicator2()))
            return false;
        if (!this.getUnitNo().equalsIgnoreCase(anotherAddress.getUnitNo()))
            return false;
        if (!this.getUnitNo2().equalsIgnoreCase(anotherAddress.getUnitNo2()))
            return false;

        //Street no, name, type
        if (!this.getStreetNo().equalsIgnoreCase(anotherAddress.getStreetNo()))
            return false;
        if (!this.getStreetName().equalsIgnoreCase(anotherAddress.getStreetName()))
            return false;
        if (!this.getHuonStreetType().equalsIgnoreCase(anotherAddress.getHuonStreetType()))
            return false;


        return equal;
    }

    private void initializeStreetTypMap() {
        streetTypeMap.put("ACCS", "ACCESS");
        streetTypeMap.put("ACWY", "ACCESSWAY");
        streetTypeMap.put("ALLY", "ALLEY");
        streetTypeMap.put("ALWY", "ALLEYWAY");
        streetTypeMap.put("ALYS", "ALLIES");
        streetTypeMap.put("AMBL", "AMBLE");
        streetTypeMap.put("ANCG", "ANCHORAGE");
        streetTypeMap.put("ANNX", "ANNEXE");
        streetTypeMap.put("APP", "APPROACH");
        streetTypeMap.put("ARC", "ARCADE");
        streetTypeMap.put("ARCH", "ARCH");
        streetTypeMap.put("ARM", "ARM");
        streetTypeMap.put("ART", "ARTERY");
        streetTypeMap.put("ATHL", "ATHOL");
        streetTypeMap.put("AVE", "AVENUE");
        streetTypeMap.put("BANK", "BANK");
        streetTypeMap.put("BASE", "BASE");
        streetTypeMap.put("BASN", "BASIN");
        streetTypeMap.put("BAY", "BAY");
        streetTypeMap.put("BCH", "BEACH");
        streetTypeMap.put("BDGE", "BRIDGE");
        streetTypeMap.put("BDWY", "BROADWAY");
        streetTypeMap.put("BELT", "BELT");
        streetTypeMap.put("BEND", "BEND");
        streetTypeMap.put("BLDG", "BUILDING");
        streetTypeMap.put("BLFF", "BLUFF");
        streetTypeMap.put("BLK", "BLOCK");
        streetTypeMap.put("BOG", "BOG");
        streetTypeMap.put("BRAE", "BRAE");
        streetTypeMap.put("BRCE", "BRACE");
        streetTypeMap.put("BRCH", "BRANCH");
        streetTypeMap.put("BRET", "BRETT");
        streetTypeMap.put("BRK", "BREAK");
        streetTypeMap.put("BROK", "BROOK");
        streetTypeMap.put("BROW", "BROW");
        streetTypeMap.put("BRRK", "BARRACKS");
        streetTypeMap.put("BRRS", "BRIARS");
        streetTypeMap.put("BTM", "BOTTOM");
        streetTypeMap.put("BVD", "BOULEVARD");
        streetTypeMap.put("BYPA", "BYPASS");
        streetTypeMap.put("BYWY", "BYWAY");
        streetTypeMap.put("CAMP", "CAMPUS");
        streetTypeMap.put("CAUS", "CAUSEWAY");
        streetTypeMap.put("CCT", "CIRCUIT");
        streetTypeMap.put("CDS", "CUL DE SAC");
        streetTypeMap.put("CH", "CHASE");
        streetTypeMap.put("CIR", "CIRCLE");
        streetTypeMap.put("CL", "CLOSE");
        streetTypeMap.put("CLDE", "COLLONADE");
        streetTypeMap.put("CLFS", "CLIFFS");
        streetTypeMap.put("CLM", "CLAIM");
        streetTypeMap.put("CLR", "CLEAR");
        streetTypeMap.put("CLT", "CIRCLET");
        streetTypeMap.put("CLWY", "CLEARWAY");
        streetTypeMap.put("CMMN", "COMMON");
        streetTypeMap.put("CNR", "CORNER");
        streetTypeMap.put("CNRS", "CORNERS");
        streetTypeMap.put("CNWY", "CENTREWAY");
        streetTypeMap.put("COLL", "COLLEGE");
        streetTypeMap.put("CON", "CONCOURSE");
        streetTypeMap.put("CORP", "CORP");
        streetTypeMap.put("COUR", "COURSE");
        streetTypeMap.put("COVE", "COVE");
        streetTypeMap.put("COWY", "CROSSWAY");
        streetTypeMap.put("CPE", "CAPE");
        streetTypeMap.put("CPS", "COPSE");
        streetTypeMap.put("CRCS", "CIRCUS");
        streetTypeMap.put("CRD", "CROSSROAD");
        streetTypeMap.put("CRES", "CRESCENT");
        streetTypeMap.put("CRK", "CREEK");
        streetTypeMap.put("CRPS", "CORPS");
        streetTypeMap.put("CRSG", "CROSSING");
        streetTypeMap.put("CRSS", "CROSS");
        streetTypeMap.put("CRST", "CREST");
        streetTypeMap.put("CRTS", "COURTS");
        streetTypeMap.put("CSO", "CORSO");
        streetTypeMap.put("CT", "COURT");
        streetTypeMap.put("CTGE", "COTTAGE");
        streetTypeMap.put("CTN", "CONNECTION");
        streetTypeMap.put("CTR", "CENTRE");
        streetTypeMap.put("CTTG", "CUTTING");
        streetTypeMap.put("CTYD", "COURTYARD");
        streetTypeMap.put("CUL", "CUL");
        streetTypeMap.put("CUWY", "CRUISEWAY");
        streetTypeMap.put("DALE", "DALE");
        streetTypeMap.put("DAM", "DAM");
        streetTypeMap.put("DELL", "DELL");
        streetTypeMap.put("DEVN", "DEVIATION");
        streetTypeMap.put("DIP", "DIP");
        streetTypeMap.put("DOCK", "DOCK");
        streetTypeMap.put("DR", "DRIVE");
        streetTypeMap.put("DRWY", "DRIVEWAY");
        streetTypeMap.put("DSTR", "DISTRIBUTOR");
        streetTypeMap.put("DUNE", "DUNE");
        streetTypeMap.put("DV", "DIVIDE");
        streetTypeMap.put("DWNS", "DOWNS");
        streetTypeMap.put("EASE", "EASEMENT");
        streetTypeMap.put("EDGE", "EDGE");
        streetTypeMap.put("ELB", "ELBOW");
        streetTypeMap.put("ELM", "ELM");
        streetTypeMap.put("END", "END");
        streetTypeMap.put("ENT", "ENTRANCE");
        streetTypeMap.put("ESP", "ESPLANADE");
        streetTypeMap.put("EST", "ESTATE");
        streetTypeMap.put("ESTS", "ESTATES");
        streetTypeMap.put("EXP", "EXPRESSWAY");
        streetTypeMap.put("EXTN", "EXTENSION");
        streetTypeMap.put("FALL", "FALL");
        streetTypeMap.put("FARE", "FARE");
        streetTypeMap.put("FARM", "FARM");
        streetTypeMap.put("FAWY", "FAIRWAY");
        streetTypeMap.put("FEN", "FEN");
        streetTypeMap.put("FERN", "FERN");
        streetTypeMap.put("FITR", "FIRETRAIL");
        streetTypeMap.put("FLAT", "FLAT");
        streetTypeMap.put("FLD", "FIELD");
        streetTypeMap.put("FLDS", "FIELDS");
        streetTypeMap.put("FLS", "FALLS");
        streetTypeMap.put("FLTS", "FLATS");
        streetTypeMap.put("FOLW", "FOLLOW");
        streetTypeMap.put("FORM", "FORMATION");
        streetTypeMap.put("FRD", "FORD");
        streetTypeMap.put("FRKS", "FORKS");
        streetTypeMap.put("FRMS", "FARMS");
        streetTypeMap.put("FRNT", "FRONT");
        streetTypeMap.put("FRST", "FOREST");
        streetTypeMap.put("FRTG", "FRONTAGE");
        streetTypeMap.put("FRY", "FERRY");
        streetTypeMap.put("FSHR", "FORESHORE");
        streetTypeMap.put("FT", "FORT");
        streetTypeMap.put("FTRK", "FIRE TRACK");
        streetTypeMap.put("FTWY", "FOOTWAY");
        streetTypeMap.put("FWY", "FREEWAY");
        streetTypeMap.put("GAP", "GAP");
        streetTypeMap.put("GDN", "GARDEN");
        streetTypeMap.put("GDNS", "GARDENS");
        streetTypeMap.put("GLD", "GLADE");
        streetTypeMap.put("GLEN", "GLEN");
        streetTypeMap.put("GLY", "GULLY");
        streetTypeMap.put("GR", "GROVE");
        streetTypeMap.put("GRA", "GRANGE");
        streetTypeMap.put("GRN", "GREEN");
        streetTypeMap.put("GRND", "GROUND");
        streetTypeMap.put("GTE", "GATE");
        streetTypeMap.put("GTES", "GATES");
        streetTypeMap.put("GTWY", "GATEWAY");
        streetTypeMap.put("HARB", "HARBOUR");
        streetTypeMap.put("HDLD", "HEADLAND");
        streetTypeMap.put("HEAD", "HEAD");
        streetTypeMap.put("HETH", "HEATH");
        streetTypeMap.put("HILL", "HILL");
        streetTypeMap.put("HLS", "HILLS");
        streetTypeMap.put("HOSP", "HOSPITAL");
        streetTypeMap.put("HOTL", "HOTEL");
        streetTypeMap.put("HRD", "HIGHROAD");
        streetTypeMap.put("HSE", "HOUSE");
        streetTypeMap.put("HSTL", "HOSTEL");
        streetTypeMap.put("HTS", "HEIGHTS");
        streetTypeMap.put("HUB", "HUB");
        streetTypeMap.put("HVEN", "HAVEN");
        streetTypeMap.put("HWY", "HIGHWAY");
        streetTypeMap.put("INTG", "INTERCHANGE");
        streetTypeMap.put("INTN", "INTERSECTION");
        streetTypeMap.put("IS", "ISLAND");
        streetTypeMap.put("JNC", "JUNCTION");
        streetTypeMap.put("KEY", "KEY");
        streetTypeMap.put("KNLL", "KNOLL");
        streetTypeMap.put("KNOB", "KNOB");
        streetTypeMap.put("LADR", "LADDER");
        streetTypeMap.put("LANE", "LANE");
        streetTypeMap.put("LDG", "LANDING");
        streetTypeMap.put("LDGE", "LODGE");
        streetTypeMap.put("LEA", "LEA");
        streetTypeMap.put("LEDR", "LEADER");
        streetTypeMap.put("LEES", "LEES");
        streetTypeMap.put("LGH", "LEIGH");
        streetTypeMap.put("LGTS", "LIGHTS");
        streetTypeMap.put("LINE", "LINE");
        streetTypeMap.put("LINK", "LINK");
        streetTypeMap.put("LKT", "LOOKOUT");
        streetTypeMap.put("LNES", "LINES");
        streetTypeMap.put("LNWY", "LANEWAY");
        streetTypeMap.put("LOOP", "LOOP");
        streetTypeMap.put("LT", "LITTLE");
        streetTypeMap.put("LWR", "LOWER");
        streetTypeMap.put("MAIL", "MAIL");
        streetTypeMap.put("MALL", "MALL");
        streetTypeMap.put("MDWS", "MEADOWS");
        streetTypeMap.put("MEAD", "MEAD");
        streetTypeMap.put("MESS", "MESS");
        streetTypeMap.put("MEW", "MEW");
        streetTypeMap.put("MEWS", "MEWS");
        streetTypeMap.put("MILE", "MILE");
        streetTypeMap.put("ML", "MILL");
        streetTypeMap.put("MLS", "MILLS");
        streetTypeMap.put("MNDR", "MEANDER");
        streetTypeMap.put("MOTU", "MOTU");
        streetTypeMap.put("MSN", "MISSION");
        streetTypeMap.put("MT", "MOUNT");
        streetTypeMap.put("MTL", "MOTEL");
        streetTypeMap.put("MTN", "MOUNTAIN");
        streetTypeMap.put("MWY", "MOTORWAY");
        streetTypeMap.put("NOOK", "NOOK");
        streetTypeMap.put("NRMA", "NRMA");
        streetTypeMap.put("NVS", "NEAVES");
        streetTypeMap.put("OAKS", "OAKS");
        streetTypeMap.put("ORCH", "ORCHARD");
        streetTypeMap.put("OTLK", "OUTLOOK");
        streetTypeMap.put("OVAL", "OVAL");
        streetTypeMap.put("OVRB", "OVERBRIDGE");
        streetTypeMap.put("PADK", "PADDOCK");
        streetTypeMap.put("PAKU", "PAKU");
        streetTypeMap.put("PARK", "PARK");
        streetTypeMap.put("PART", "PART");
        streetTypeMap.put("PASS", "PASS");
        streetTypeMap.put("PATH", "PATH");
        streetTypeMap.put("PDE", "PARADE");
        streetTypeMap.put("PHWY", "PATHWAY");
        streetTypeMap.put("PIAZ", "PIAZZA");
        streetTypeMap.put("PIER", "PIER");
        streetTypeMap.put("PKLD", "PARKLANDS");
        streetTypeMap.put("PKT", "POCKET");
        streetTypeMap.put("PKWY", "PARKWAY");
        streetTypeMap.put("PL", "PLACE");
        streetTypeMap.put("PLAT", "PLATEAU");
        streetTypeMap.put("PLMS", "PALMS");
        streetTypeMap.put("PLN", "PLAIN");
        streetTypeMap.put("PLNS", "PLAINS");
        streetTypeMap.put("PLZA", "PLAZA");
        streetTypeMap.put("PNNE", "PENINSULA");
        streetTypeMap.put("PNT", "POINT");
        streetTypeMap.put("PORT", "PORT");
        streetTypeMap.put("PRDE", "PARADISE");
        streetTypeMap.put("PROM", "PROMENADE");
        streetTypeMap.put("PRRS", "PRIORS");
        streetTypeMap.put("PSGE", "PASSAGE");
        streetTypeMap.put("PURS", "PURSUIT");
        streetTypeMap.put("QDGL", "QUADRANGLE");
        streetTypeMap.put("QDRT", "QUADRANT");
        streetTypeMap.put("QTRS", "QUARTERS");
        streetTypeMap.put("QUAD", "QUAD");
        streetTypeMap.put("QY", "QUAY");
        streetTypeMap.put("QYS", "QUAYS");
        streetTypeMap.put("RAMP", "RAMP");
        streetTypeMap.put("RAN", "RANAE");
        streetTypeMap.put("RCH", "REACH");
        streetTypeMap.put("RD", "ROAD");
        streetTypeMap.put("RDGE", "RIDGE");
        streetTypeMap.put("RDS", "ROADS");
        streetTypeMap.put("RDSD", "ROADSIDE");
        streetTypeMap.put("RDWY", "ROADWAY");
        streetTypeMap.put("REEF", "REEF");
        streetTypeMap.put("RES", "RESERVE");
        streetTypeMap.put("REST", "REST");
        streetTypeMap.put("RGWY", "RIDGEWAY");
        streetTypeMap.put("RIDE", "RIDE");
        streetTypeMap.put("RING", "RING");
        streetTypeMap.put("RISE", "RISE");
        streetTypeMap.put("RMBL", "RAMBLE");
        streetTypeMap.put("RND", "ROUND");
        streetTypeMap.put("RNDE", "RONDE");
        streetTypeMap.put("RNGE", "RANGE");
        streetTypeMap.put("ROW", "ROW");
        streetTypeMap.put("ROWE", "ROWE");
        streetTypeMap.put("ROWY", "RIGHT OF WAY");
        streetTypeMap.put("RPDS", "RAPIDS");
        streetTypeMap.put("RSBL", "ROSEBOWL");
        streetTypeMap.put("RSDN", "RESIDENCE");
        streetTypeMap.put("RTE", "ROUTE");
        streetTypeMap.put("RTRN", "RETURN");
        streetTypeMap.put("RTT", "RETREAT");
        streetTypeMap.put("RTY", "ROTARY");
        streetTypeMap.put("RUA", "RUA");
        streetTypeMap.put("RUE", "RUE");
        streetTypeMap.put("RUN", "RUN");
        streetTypeMap.put("RVR", "RIVER");
        streetTypeMap.put("RVRA", "RIVIERA");
        streetTypeMap.put("RVWY", "RIVERWAY");
        streetTypeMap.put("SBWY", "SUBWAY");
        streetTypeMap.put("SCHL", "SCHOOL");
        streetTypeMap.put("SDNG", "SIDING");
        streetTypeMap.put("SECT", "SECTION");
        streetTypeMap.put("SHL", "SHOAL");
        streetTypeMap.put("SHR", "SHORE");
        streetTypeMap.put("SHRS", "SHORES");
        streetTypeMap.put("SHT", "SHOOT");
        streetTypeMap.put("SHWY", "STATE HIGHWAY");
        streetTypeMap.put("SLPE", "SLOPE");
        streetTypeMap.put("SMT", "SUMMIT");
        streetTypeMap.put("SND", "SOUND");
        streetTypeMap.put("SPA", "SPA");
        streetTypeMap.put("SPG", "SPRING");
        streetTypeMap.put("SPGS", "SPRINGS");
        streetTypeMap.put("SPUR", "SPUR");
        streetTypeMap.put("SQ", "SQUARE");
        streetTypeMap.put("SQN", "SQUADRON");
        streetTypeMap.put("ST", "STREET");
        streetTypeMap.put("STAA", "STRAAT");
        streetTypeMap.put("STAT", "STATION");
        streetTypeMap.put("STEE", "STEEP");
        streetTypeMap.put("STEY", "STEYNE");
        streetTypeMap.put("STGT", "STRAIGHT");
        streetTypeMap.put("STP", "STEP");
        streetTypeMap.put("STPS", "STEPS");
        streetTypeMap.put("STRA", "STRAND");
        streetTypeMap.put("STRM", "STREAM");
        streetTypeMap.put("STRP", "STRIP");
        streetTypeMap.put("STRS", "STAIRS");
        streetTypeMap.put("STS", "STREETS");
        streetTypeMap.put("STUD", "STUD");
        streetTypeMap.put("SVLN", "SERVICE LANE");
        streetTypeMap.put("SWMP", "SWAMP");
        streetTypeMap.put("SWY", "SERVICEWAY");
        streetTypeMap.put("TARN", "TARN");
        streetTypeMap.put("TCE", "TERRACE");
        streetTypeMap.put("TCES", "TERRACES");
        streetTypeMap.put("THOR", "THOROUGHFARE");
        streetTypeMap.put("THWY", "THROUGHWAY");
        streetTypeMap.put("TKWY", "TRUNKWAY");
        streetTypeMap.put("TLWY", "TOLLWAY");
        streetTypeMap.put("TMWY", "TRAMWAY");
        streetTypeMap.put("TOP", "TOP");
        streetTypeMap.put("TOR", "TOR");
        streetTypeMap.put("TOWR", "TOWER");
        streetTypeMap.put("TRAM", "TRAM");
        streetTypeMap.put("TRCT", "TRACT");
        streetTypeMap.put("TRES", "TREES");
        streetTypeMap.put("TRI", "TRIANGLE");
        streetTypeMap.put("TRK", "TRACK");
        streetTypeMap.put("TRL", "TRAIL");
        streetTypeMap.put("TRLR", "TRAILER");
        streetTypeMap.put("TUNL", "TUNNEL");
        streetTypeMap.put("TURN", "TURN");
        streetTypeMap.put("TWRS", "TOWERS");
        streetTypeMap.put("UPAS", "UNDERPASS");
        streetTypeMap.put("UPR", "UPPER");
        streetTypeMap.put("VALE", "VALE");
        streetTypeMap.put("VDCT", "VIADUCT");
        streetTypeMap.put("VIEW", "VIEW");
        streetTypeMap.put("VLLG", "VILLAGE");
        streetTypeMap.put("VLLS", "VILLAS");
        streetTypeMap.put("VLLY", "VALLEY");
        streetTypeMap.put("VNUS", "VENUS");
        streetTypeMap.put("VSTA", "VISTA");
        streetTypeMap.put("VUE", "VUE");
        streetTypeMap.put("VWS", "VIEWS");
        streetTypeMap.put("WADE", "WADE");
        streetTypeMap.put("WALK", "WALK");
        streetTypeMap.put("WAY", "WAY");
        streetTypeMap.put("WDS", "WOODS");
        streetTypeMap.put("WHNA", "WHENUA");
        streetTypeMap.put("WHRF", "WHARF");
        streetTypeMap.put("WKWY", "WALKWAY");
        streetTypeMap.put("WOOD", "WOOD");
        streetTypeMap.put("WTRS", "WATERS");
        streetTypeMap.put("WYND", "WYND");
        streetTypeMap.put("YARD", "YARD");


        //		streetTypeMap.put("ACCS","ACCESS");
        //		streetTypeMap.put("ALLY","ALLEY");
        //		streetTypeMap.put("ALWY","ALLEYWAY");
        //		streetTypeMap.put("ALYS","ALLIES");
        //		streetTypeMap.put("AMBL","AMBLE");
        //		streetTypeMap.put("ANCG","ANCHORAGE");
        //		streetTypeMap.put("ANNX","ANNEXE");
        //		streetTypeMap.put("APP","APPROACH");
        //		streetTypeMap.put("ARC","ARCADE");
        //		streetTypeMap.put("ARCH","ARCH");
        //		streetTypeMap.put("ARM","ARM");
        //		streetTypeMap.put("ART","ARTERY");
        //		streetTypeMap.put("ATHL","ATHOL");
        //		streetTypeMap.put("AVE","AVENUE");
        //		streetTypeMap.put("BANK","BANK");
        //		streetTypeMap.put("BASE","BASE");
        //		streetTypeMap.put("BASN","BASIN");
        //		streetTypeMap.put("BAY","BAY");
        //		streetTypeMap.put("BCH","BEACH");
        //		streetTypeMap.put("BDGE","BRIDGE");
        //		streetTypeMap.put("BDWY","BROADWAY");
        //		streetTypeMap.put("BELT","BELT");
        //		streetTypeMap.put("BEND","BEND");
        //		streetTypeMap.put("BLDG","BUILDING");
        //		streetTypeMap.put("BLFF","BLUFF");
        //		streetTypeMap.put("BLK","BLOCK");
        //		streetTypeMap.put("BOG","BOG");
        //		streetTypeMap.put("BRAE","BRAE");
        //		streetTypeMap.put("BRCE","BRACE");
        //		streetTypeMap.put("BRCH","BRANCH");
        //		streetTypeMap.put("BRET","BRETT");
        //		streetTypeMap.put("BRK","BREAK");
        //		streetTypeMap.put("BROK","BROOK");
        //		streetTypeMap.put("BROW","BROW");
        //		streetTypeMap.put("BRRK","BARRACKS");
        //		streetTypeMap.put("BRRS","BRIARS");
        //		streetTypeMap.put("BTM","BOTTOM");
        //		streetTypeMap.put("BVD","BOULEVARD");
        //		streetTypeMap.put("BYPA","BYPASS");
        //		streetTypeMap.put("BYWY","BYWAY");
        //		streetTypeMap.put("CAMP","CAMPUS");
        //		streetTypeMap.put("CAUS","CAUSEWAY");
        //		streetTypeMap.put("CCT","CIRCUIT");
        //		streetTypeMap.put("CDS","CUL DE SAC");
        //		streetTypeMap.put("CH","CHASE");
        //		streetTypeMap.put("CIR","CIRCLE");
        //		streetTypeMap.put("CL","CLOSE");
        //		streetTypeMap.put("CLDE","COLLONADE");
        //		streetTypeMap.put("CLFS","CLIFFS");
        //		streetTypeMap.put("CLM","CLAIM");
        //		streetTypeMap.put("CLR","CLEAR");
        //		streetTypeMap.put("CLT","CIRCLET");
        //		streetTypeMap.put("CLWY","CLEARWAY");
        //		streetTypeMap.put("CMMN","COMMON");
        //		streetTypeMap.put("CNR","CORNER");
        //		streetTypeMap.put("CNRS","CORNERS");
        //		streetTypeMap.put("CNWY","CENTREWAY");
        //		streetTypeMap.put("COLL","COLLEGE");
        //		streetTypeMap.put("CON","CONCOURSE");
        //		streetTypeMap.put("CORP","CORP");
        //		streetTypeMap.put("COUR","COURSE");
        //		streetTypeMap.put("COVE","COVE");
        //		streetTypeMap.put("COWY","CROSSWAY");
        //		streetTypeMap.put("CPE","CAPE");
        //		streetTypeMap.put("CPS","COPSE");
        //		streetTypeMap.put("CRCS","CIRCUS");
        //		streetTypeMap.put("CRD","CROSSROAD");
        //		streetTypeMap.put("CRES","CRESCENT");
        //		streetTypeMap.put("CRK","CREEK");
        //		streetTypeMap.put("CRPS","CORPS");
        //		streetTypeMap.put("CRSG","CROSSING");
        //		streetTypeMap.put("CRSS","CROSS");
        //		streetTypeMap.put("CRST","CREST");
        //		streetTypeMap.put("CRTS","COURTS");
        //		streetTypeMap.put("CSO","CORSO");
        //		streetTypeMap.put("CT","COURT");
        //		streetTypeMap.put("CTGE","COTTAGE");
        //		streetTypeMap.put("CTN","CONNECTION");
        //		streetTypeMap.put("CTR","CENTRE");
        //		streetTypeMap.put("CTTG","CUTTING");
        //		streetTypeMap.put("CTYD","COURTYARD");
        //		streetTypeMap.put("CUL","CUL");
        //		streetTypeMap.put("CUWY","CRUISEWAY");
        //		streetTypeMap.put("DALE","DALE");
        //		streetTypeMap.put("DAM","DAM");
        //		streetTypeMap.put("DELL","DELL");
        //		streetTypeMap.put("DEVN","DEVIATION");
        //		streetTypeMap.put("DIP","DIP");
        //		streetTypeMap.put("DOCK","DOCK");
        //		streetTypeMap.put("DR","DRIVE");
        //		streetTypeMap.put("DRWY","DRIVEWAY");
        //		streetTypeMap.put("DSTR","DISTRIBUTOR");
        //		streetTypeMap.put("DUNE","DUNE");
        //		streetTypeMap.put("DV","DIVIDE");
        //		streetTypeMap.put("DWNS","DOWNS");
        //		streetTypeMap.put("EASE","EASEMENT");
        //		streetTypeMap.put("EDGE","EDGE");
        //		streetTypeMap.put("ELB","ELBOW");
        //		streetTypeMap.put("ELM","ELM");
        //		streetTypeMap.put("END","END");
        //		streetTypeMap.put("ENT","ENTRANCE");
        //		streetTypeMap.put("ESP","ESPLANADE");
        //		streetTypeMap.put("EST","ESTATE");
        //		streetTypeMap.put("ESTS","ESTATES");
        //		streetTypeMap.put("EXP","EXPRESSWAY");
        //		streetTypeMap.put("EXTN","EXTENSION");
        //		streetTypeMap.put("FALL","FALL");
        //		streetTypeMap.put("FARE","FARE");
        //		streetTypeMap.put("FARM","FARM");
        //		streetTypeMap.put("FAWY","FAIRWAY");
        //		streetTypeMap.put("FEN","FEN");
        //		streetTypeMap.put("FERN","FERN");
        //		streetTypeMap.put("FITR","FIRETRAIL");
        //		streetTypeMap.put("FLAT","FLAT");
        //		streetTypeMap.put("FLD","FIELD");
        //		streetTypeMap.put("FLDS","FIELDS");
        //		streetTypeMap.put("FLS","FALLS");
        //		streetTypeMap.put("FLTS","FLATS");
        //		streetTypeMap.put("FOLW","FOLLOW");
        //		streetTypeMap.put("FORM","FORMATION");
        //		streetTypeMap.put("FRD","FORD");
        //		streetTypeMap.put("FRKS","FORKS");
        //		streetTypeMap.put("FRMS","FARMS");
        //		streetTypeMap.put("FRNT","FRONT");
        //		streetTypeMap.put("FRST","FOREST");
        //		streetTypeMap.put("FRTG","FRONTAGE");
        //		streetTypeMap.put("FRY","FERRY");
        //		streetTypeMap.put("FSHR","FORESHORE");
        //		streetTypeMap.put("FT","FORT");
        //		streetTypeMap.put("FTRK","FIRE TRACK");
        //		streetTypeMap.put("FTWY","FOOTWAY");
        //		streetTypeMap.put("FWY","FREEWAY");
        //		streetTypeMap.put("GAP","GAP");
        //		streetTypeMap.put("GDN","GARDEN");
        //		streetTypeMap.put("GDNS","GARDENS");
        //		streetTypeMap.put("GLD","GLADE");
        //		streetTypeMap.put("GLEN","GLEN");
        //		streetTypeMap.put("GLY","GULLY");
        //		streetTypeMap.put("GR","GROVE");
        //		streetTypeMap.put("GRA","GRANGE");
        //		streetTypeMap.put("GRN","GREEN");
        //		streetTypeMap.put("GRND","GROUND");
        //		streetTypeMap.put("GTE","GATE");
        //		streetTypeMap.put("GTES","GATES");
        //		streetTypeMap.put("GTWY","GATEWAY");
        //		streetTypeMap.put("HARB","HARBOUR");
        //		streetTypeMap.put("HDLD","HEADLAND");
        //		streetTypeMap.put("HEAD","HEAD");
        //		streetTypeMap.put("HETH","HEATH");
        //		streetTypeMap.put("HILL","HILL");
        //		streetTypeMap.put("HLS","HILLS");
        //		streetTypeMap.put("HOSP","HOSPITAL");
        //		streetTypeMap.put("HOTL","HOTEL");
        //		streetTypeMap.put("HRD","HIGHROAD");
        //		streetTypeMap.put("HSE","HOUSE");
        //		streetTypeMap.put("HSTL","HOSTEL");
        //		streetTypeMap.put("HTS","HEIGHTS");
        //		streetTypeMap.put("HUB","HUB");
        //		streetTypeMap.put("HVEN","HAVEN");
        //		streetTypeMap.put("HWY","HIGHWAY");
        //		streetTypeMap.put("INTG","INTERCHANGE");
        //		streetTypeMap.put("INTN","INTERSECTION");
        //		streetTypeMap.put("IS","ISLAND");
        //		streetTypeMap.put("JNC","JUNCTION");
        //		streetTypeMap.put("KEY","KEY");
        //		streetTypeMap.put("KNLL","KNOLL");
        //		streetTypeMap.put("KNOB","KNOB");
        //		streetTypeMap.put("LADR","LADDER");
        //		streetTypeMap.put("LANE","LANE");
        //		streetTypeMap.put("LDG","LANDING");
        //		streetTypeMap.put("LDGE","LODGE");
        //		streetTypeMap.put("LEA","LEA");
        //		streetTypeMap.put("LEDR","LEADER");
        //		streetTypeMap.put("LEES","LEES");
        //		streetTypeMap.put("LGH","LEIGH");
        //		streetTypeMap.put("LINE","LINE");
        //		streetTypeMap.put("LINK","LINK");
        //		streetTypeMap.put("LKT","LOOKOUT");
        //		streetTypeMap.put("LNES","LINES");
        //		streetTypeMap.put("LNWY","LANEWAY");
        //		streetTypeMap.put("LOOP","LOOP");
        //		streetTypeMap.put("LT","LITTLE");
        //		streetTypeMap.put("LWR","LOWER");
        //		streetTypeMap.put("MAIL","MAIL");
        //		streetTypeMap.put("MALL","MALL");
        //		streetTypeMap.put("MDWS","MEADOWS");
        //		streetTypeMap.put("MEAD","MEAD");
        //		streetTypeMap.put("MESS","MESS");
        //		streetTypeMap.put("MEW","MEW");
        //		streetTypeMap.put("MEWS","MEWS");
        //		streetTypeMap.put("MILE","MILE");
        //		streetTypeMap.put("ML","MILL");
        //		streetTypeMap.put("MLS","MILLS");
        //		streetTypeMap.put("MNDR","MEANDER");
        //		streetTypeMap.put("MOTU","MOTU");
        //		streetTypeMap.put("MSN","MISSION");
        //		streetTypeMap.put("MT","MOUNT");
        //		streetTypeMap.put("MTL","MOTEL");
        //		streetTypeMap.put("MTN","MOUNTAIN");
        //		streetTypeMap.put("MWY","MOTORWAY");
        //		streetTypeMap.put("NOOK","NOOK");
        //		streetTypeMap.put("NRMA","NRMA");
        //		streetTypeMap.put("NVS","NEAVES");
        //		streetTypeMap.put("OAKS","OAKS");
        //		streetTypeMap.put("ORCH","ORCHARD");
        //		streetTypeMap.put("OTLK","OUTLOOK");
        //		streetTypeMap.put("OVAL","OVAL");
        //		streetTypeMap.put("OVRB","OVERBRIDGE");
        //		streetTypeMap.put("PADK","PADDOCK");
        //		streetTypeMap.put("PAKU","PAKU");
        //		streetTypeMap.put("PARK","PARK");
        //		streetTypeMap.put("PART","PART");
        //		streetTypeMap.put("PASS","PASS");
        //		streetTypeMap.put("PATH","PATH");
        //		streetTypeMap.put("PDE","PARADE");
        //		streetTypeMap.put("PHWY","PATHWAY");
        //		streetTypeMap.put("PIAZ","PIAZZA");
        //		streetTypeMap.put("PIER","PIER");
        //		streetTypeMap.put("PKLD","PARKLANDS");
        //		streetTypeMap.put("PKT","POCKET");
        //		streetTypeMap.put("PKWY","PARKWAY");
        //		streetTypeMap.put("PL","PLACE");
        //		streetTypeMap.put("PLAT","PLATEAU");
        //		streetTypeMap.put("PLMS","PALMS");
        //		streetTypeMap.put("PLN","PLAIN");
        //		streetTypeMap.put("PLNS","PLAINS");
        //		streetTypeMap.put("PLZA","PLAZA");
        //		streetTypeMap.put("PNNE","PENINSULA");
        //		streetTypeMap.put("PNT","POINT");
        //		streetTypeMap.put("PORT","PORT");
        //		streetTypeMap.put("PRDE","PARADISE");
        //		streetTypeMap.put("PROM","PROMENADE");
        //		streetTypeMap.put("PRRS","PRIORS");
        //		streetTypeMap.put("PSGE","PASSAGE");
        //		streetTypeMap.put("PURS","PURSUIT");
        //		streetTypeMap.put("QDGL","QUADRANGLE");
        //		streetTypeMap.put("QDRT","QUADRANT");
        //		streetTypeMap.put("QTRS","QUARTERS");
        //		streetTypeMap.put("QUAD","QUAD");
        //		streetTypeMap.put("QY","QUAY");
        //		streetTypeMap.put("QYS","QUAYS");
        //		streetTypeMap.put("RAMP","RAMP");
        //		streetTypeMap.put("RAN","RANAE");
        //		streetTypeMap.put("RCH","REACH");
        //		streetTypeMap.put("RD","ROAD");
        //		streetTypeMap.put("RDGE","RIDGE");
        //		streetTypeMap.put("RDS","ROADS");
        //		streetTypeMap.put("RDSD","ROADSIDE");
        //		streetTypeMap.put("RDWY","ROADWAY");
        //		streetTypeMap.put("REEF","REEF");
        //		streetTypeMap.put("RES","RESERVE");
        //		streetTypeMap.put("REST","REST");
        //		streetTypeMap.put("RGWY","RIDGEWAY");
        //		streetTypeMap.put("RIDE","RIDE");
        //		streetTypeMap.put("RING","RING");
        //		streetTypeMap.put("RISE","RISE");
        //		streetTypeMap.put("RMBL","RAMBLE");
        //		streetTypeMap.put("RND","ROUND");
        //		streetTypeMap.put("RNDE","RONDE");
        //		streetTypeMap.put("RNGE","RANGE");
        //		streetTypeMap.put("ROW","ROW");
        //		streetTypeMap.put("ROWE","ROWE");
        //		streetTypeMap.put("ROWY","RIGHT OF WAY");
        //		streetTypeMap.put("RPDS","RAPIDS");
        //		streetTypeMap.put("RSBL","ROSEBOWL");
        //		streetTypeMap.put("RSDN","RESIDENCE");
        //		streetTypeMap.put("RTE","ROUTE");
        //		streetTypeMap.put("RTRN","RETURN");
        //		streetTypeMap.put("RTT","RETREAT");
        //		streetTypeMap.put("RTY","ROTARY");
        //		streetTypeMap.put("RUA","RUA");
        //		streetTypeMap.put("RUE","RUE");
        //		streetTypeMap.put("RUN","RUN");
        //		streetTypeMap.put("RVR","RIVER");
        //		streetTypeMap.put("RVRA","RIVIERA");
        //		streetTypeMap.put("RVWY","RIVERWAY");
        //		streetTypeMap.put("SBWY","SUBWAY");
        //		streetTypeMap.put("SCHL","SCHOOL");
        //		streetTypeMap.put("SDNG","SIDING");
        //		streetTypeMap.put("SECT","SECTION");
        //		streetTypeMap.put("SHL","SHOAL");
        //		streetTypeMap.put("SHR","SHORE");
        //		streetTypeMap.put("SHRS","SHORES");
        //		streetTypeMap.put("SHT","SHOOT");
        //		streetTypeMap.put("SHWY","STATE HIGHWAY");
        //		streetTypeMap.put("SLPE","SLOPE");
        //		streetTypeMap.put("SMT","SUMMIT");
        //		streetTypeMap.put("SND","SOUND");
        //		streetTypeMap.put("SPA","SPA");
        //		streetTypeMap.put("SPG","SPRING");
        //		streetTypeMap.put("SPGS","SPRINGS");
        //		streetTypeMap.put("SPUR","SPUR");
        //		streetTypeMap.put("SQ","SQUARE");
        //		streetTypeMap.put("SQN","SQUADRON");
        //		streetTypeMap.put("ST","STREET");
        //		streetTypeMap.put("STAA","STRAAT");
        //		streetTypeMap.put("STAT","STATION");
        //		streetTypeMap.put("STEE","STEEP");
        //		streetTypeMap.put("STEY","STEYNE");
        //		streetTypeMap.put("STGT","STRAIGHT");
        //		streetTypeMap.put("STP","STEP");
        //		streetTypeMap.put("STPS","STEPS");
        //		streetTypeMap.put("STRA","STRAND");
        //		streetTypeMap.put("STRM","STREAM");
        //		streetTypeMap.put("STRP","STRIP");
        //		streetTypeMap.put("STRS","STAIRS");
        //		streetTypeMap.put("STS","STREETS");
        //		streetTypeMap.put("STUD","STUD");
        //		streetTypeMap.put("SVLN","SERVICE LANE");
        //		streetTypeMap.put("SWMP","SWAMP");
        //		streetTypeMap.put("SWY","SERVICEWAY");
        //		streetTypeMap.put("TARN","TARN");
        //		streetTypeMap.put("TCE","TERRACE");
        //		streetTypeMap.put("TCES","TERRACES");
        //		streetTypeMap.put("THOR","THOROUGHFARE");
        //		streetTypeMap.put("THWY","THROUGHWAY");
        //		streetTypeMap.put("TKWY","TRUNKWAY");
        //		streetTypeMap.put("TLWY","TOLLWAY");
        //		streetTypeMap.put("TMWY","TRAMWAY");
        //		streetTypeMap.put("TOP","TOP");
        //		streetTypeMap.put("TOR","TOR");
        //		streetTypeMap.put("TOWR","TOWER");
        //		streetTypeMap.put("TRAM","TRAM");
        //		streetTypeMap.put("TRCT","TRACT");
        //		streetTypeMap.put("TRES","TREES");
        //		streetTypeMap.put("TRI","TRIANGLE");
        //		streetTypeMap.put("TRK","TRACK");
        //		streetTypeMap.put("TRL","TRAIL");
        //		streetTypeMap.put("TRLR","TRAILER");
        //		streetTypeMap.put("TUNL","TUNNEL");
        //		streetTypeMap.put("TURN","TURN");
        //		streetTypeMap.put("TWRS","TOWERS");
        //		streetTypeMap.put("UPAS","UNDERPASS");
        //		streetTypeMap.put("UPR","UPPER");
        //		streetTypeMap.put("VALE","VALE");
        //		streetTypeMap.put("VDCT","VIADUCT");
        //		streetTypeMap.put("VIEW","VIEW");
        //		streetTypeMap.put("VLLG","VILLAGE");
        //		streetTypeMap.put("VLLS","VILLAS");
        //		streetTypeMap.put("VLLY","VALLEY");
        //		streetTypeMap.put("VNUS","VENUS");
        //		streetTypeMap.put("VSTA","VISTA");
        //		streetTypeMap.put("VUE","VUE");
        //		streetTypeMap.put("VWS","VIEWS");
        //		streetTypeMap.put("WADE","WADE");
        //		streetTypeMap.put("WALK","WALK");
        //		streetTypeMap.put("WAY","WAY");
        //		streetTypeMap.put("WDS","WOODS");
        //		streetTypeMap.put("WHNA","WHENUA");
        //		streetTypeMap.put("WHRF","WHARF");
        //		streetTypeMap.put("WKWY","WALKWAY");
        //		streetTypeMap.put("WOOD","WOOD");
        //		streetTypeMap.put("WTRS","WATERS");
        //		streetTypeMap.put("WYND","WYND");
        //		streetTypeMap.put("YARD","YARD");

    }

    private void initializeIndicatorMap() {
        if (indicatorMap == null)
            indicatorMap = new HashMap<String, String>();
        indicatorMap.put("<", "DUPLEX");
        indicatorMap.put("(", "FLAT");
        indicatorMap.put("+", "HOUSE");
        indicatorMap.put("&", "MAISONETTE");
        indicatorMap.put("$", "PENTHOUSE");
        indicatorMap.put("*", "KIOSK");
        indicatorMap.put(")", "MARINE");
        indicatorMap.put(";", "PRIVATE");
        indicatorMap.put(">", "SHED");
        indicatorMap.put("@", "STALL");
        indicatorMap.put("~", "REAR");
        indicatorMap.put("{", "TOWNHOUSE");
        indicatorMap.put("A", "APARTMENT");
        indicatorMap.put("B", "BOX");
        indicatorMap.put("C", "BUILDING");
        indicatorMap.put("D", "BAY");
        indicatorMap.put("E", "HANGAR");
        indicatorMap.put("F", "FLOOR");
        indicatorMap.put("G", "LOT");
        indicatorMap.put("H", "CABIN");
        indicatorMap.put("I", "PIER");
        indicatorMap.put("}", "RD");
        indicatorMap.put("J", "ROOM");
        indicatorMap.put("K", "FACTORY");
        indicatorMap.put("L", "LEVEL");
        indicatorMap.put("M", "MAILBAG");
        indicatorMap.put("N", "LODGE");
        indicatorMap.put("O", "OFFICE");
        indicatorMap.put("P", "PO");
        indicatorMap.put("Q", "RSD");
        indicatorMap.put("R", "FARM");
        indicatorMap.put("S", "SUITE");
        indicatorMap.put("T", "MS");
        indicatorMap.put("U", "UNIT");
        indicatorMap.put("V", "PMB");
        indicatorMap.put("W", "PORTION");
        indicatorMap.put("X", "POST");
        indicatorMap.put("Y", "RMB");
        indicatorMap.put("Z", "SHOP");
        indicatorMap.put("0", "DIVISION");
        indicatorMap.put("1", "COTTAGE");
        indicatorMap.put("2", "SECTION");
        indicatorMap.put("3", "SITE");
        indicatorMap.put("4", "STUDIO");
        indicatorMap.put("5", "VILLA");
        indicatorMap.put("6", "BLOCK");
        indicatorMap.put("7", "WARD");
        indicatorMap.put("8", "CMB");
        indicatorMap.put("9", "RSM");

        streetDirectionMap.put("C", "Central");
        streetDirectionMap.put("E", "East");
        streetDirectionMap.put("EX", "Extension");
        streetDirectionMap.put("LR", "Lower");
        streetDirectionMap.put("N", "North");
        streetDirectionMap.put("NE", "North East");
        streetDirectionMap.put("NW", "North West");
        streetDirectionMap.put("S", "South");
        streetDirectionMap.put("SE", "South East");
        streetDirectionMap.put("SW", "South West");
        streetDirectionMap.put("UP", "Upper");
        streetDirectionMap.put("W", "West");
        streetDirectionMap.put("N1", "No1");
        streetDirectionMap.put("N2", "No2");

    }
}
