package au.com.iag.execution.claimupdateapi.model.business;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Claim {
    public String claimIdentifier;
    public Boolean collectExcess;
    public String repairerIdentifier;
}
