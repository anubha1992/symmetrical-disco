package au.com.iag.execution.correspondenceapi;

import au.com.iag.execution.correspondenceapi.builders.CorrespondenceHeaderBuilder;
import au.com.iag.execution.correspondenceapi.builders.CorrespondenceRequestBuilder;
import au.com.iag.execution.correspondenceapi.configuration.CorrespondenceConfiguration;
import au.com.iag.execution.correspondenceapi.configuration.PropertyOverrideContextInitializer;
import au.com.iag.execution.correspondenceapi.model.DigitalCorrespondenceArtifact;
import au.com.iag.execution.correspondenceapi.service.CorrespondenceService;
import au.com.iag.execution.correspondenceapi.verifiers.CorrespondenceVerifier;
import au.com.iag.execution.correspondenceapi.verifiers.SessionAffinityVerifier;
import au.com.iag.glados.common.GladosRunnerExtension;
import io.restassured.response.Response;
import org.apache.commons.lang3.SerializationUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.UUID;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static org.apache.http.HttpStatus.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { CorrespondenceConfiguration.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tags({@Tag("digital-correspondence"), @Tag("send-coc")})
public class DigitalCorrespondenceSendCoCOperationTest {

    @Autowired private CorrespondenceRequestBuilder correspondenceRequestBuilder;
    @Autowired private CorrespondenceService correspondenceService;
    @Autowired private CorrespondenceVerifier correspondenceVerifier;
    @Autowired private CorrespondenceHeaderBuilder correspondenceHeaderBuilder;
    @Autowired private SessionAffinityVerifier sessionAffinityVerifier;

    private DigitalCorrespondenceArtifact digitalCorrespondenceArtifactCopy;
    private DigitalCorrespondenceArtifact digitalCorrespondenceArtifact;

    private static final String OKTA_AWARE_MOTOR_POLICY = "MOTN0000001550";
    private static final String OKTA_AWARE_HOME_POLICY = "HOMN0000001953";

    @BeforeAll
    public void setupOnce() throws Exception{
        correspondenceService.getSwaggerSchema("/digital");
        digitalCorrespondenceArtifact = correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(PRODUCT_MOTOR_INSURANCE, OKTA_AWARE_MOTOR_POLICY);
        digitalCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(true));
    }

    @BeforeEach
    public void setup() throws IOException {
        digitalCorrespondenceArtifactCopy = SerializationUtils.clone(digitalCorrespondenceArtifact);
    }

    @Test
    public void successfulSendMotorCoCWithoutOkta() throws Exception{
        digitalCorrespondenceArtifactCopy.setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        correspondenceHeaderBuilder.updateHeadersWithAnonymousToken(getDigitalCorrespondenceArtifactCopy().getHeaders()
                , getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getPolicyNumber());
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyMotorDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
    }

    @Test
    public void sessionAffinityValidationWithBapiProvidingSessionIdInRequestHeader() throws Exception{
        digitalCorrespondenceArtifactCopy.setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        correspondenceHeaderBuilder.updateHeadersWithAnonymousToken(getDigitalCorrespondenceArtifactCopy().getHeaders()
                , getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getPolicyNumber());
        getDigitalCorrespondenceArtifactCopy().getHeaders().put(X_IAG_SESSION_ID, UUID.randomUUID().toString());
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyMotorDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
        sessionAffinityVerifier.verifySessionAffinity(response.getHeader(X_B3_TRACE_ID)
                , (String) getDigitalCorrespondenceArtifactCopy().getHeaders().get(X_IAG_SESSION_ID));
    }

    @Test
    public void sessionAffinityValidationWithoutBapiProvidingSessionIdInRequestHeader() throws Exception{
        digitalCorrespondenceArtifactCopy.setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        correspondenceHeaderBuilder.updateHeadersWithAnonymousToken(getDigitalCorrespondenceArtifactCopy().getHeaders()
                , getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getPolicyNumber());
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyMotorDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
        sessionAffinityVerifier.verifySessionAffinity(response.getHeader(X_B3_TRACE_ID));
    }

    @Test
    public void successfulSendMotorCoCWithOkta() throws Exception{
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyMotorDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
    }

    @Test
    public void successfulSendMotorCoCWithOktaViaPost() throws Exception{
        getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_POST);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyMotorDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
    }

    @Test
    public void verifyMandatoryHeaderMissingAuthUser() {
        getDigitalCorrespondenceArtifactCopy().getHeaders().remove(X_IAG_AUTH_USER);
        correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNAUTHORIZED);
    }

    @Test
    public void verifyMandatoryHeaderInvalidAuthUser() {
        getDigitalCorrespondenceArtifactCopy().getHeaders().put(X_IAG_AUTH_USER, getDigitalCorrespondenceArtifactCopy().getHeaders().get(X_IAG_AUTH_USER)+"INVALID");
        correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNAUTHORIZED);
    }

    @DisplayName("Digital Send Correspondence - Certificate of Currency, Independent Mandatory Field Validation Test")
    @ParameterizedTest(name = "{index} ==> Mandatory Property : ''{1}''=''null''")
    @CsvSource({
            "Individual,MOTOR_INSURANCE,$.correspondence.channel",
            "Individual,MOTOR_INSURANCE,$.policy_details.assets.vehicle_assets.asset_number",
            "Individual,HOME_INSURANCE,$.policy_details.assets.home_assets.asset_number"
    })
    public void sendCoCIndependentMandatoryFieldValidationTest(final String primaryRecipientType, String product, String jsonPath) throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(product, OKTA_AWARE_MOTOR_POLICY));
        correspondenceRequestBuilder.updateDigitalCorrespondenceRequest(primaryRecipientType, getDigitalCorrespondenceArtifactCopy(), jsonPath);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNPROCESSABLE_ENTITY);
        correspondenceVerifier.verifyDigitalCorrespondenceValidationErrors(jsonPath, "mandatory_value_missing", "validation_failed", "error", response);
    }

    @DisplayName("Digital Send Correspondence - Certificate of Currency, Independent Fields With Invalid RDM Data Validation Test")
    @ParameterizedTest(name = "{index} ==> Mandatory Property : ''{1}''=''null''")
    @CsvSource({
            "Individual,MOTOR_INSURANCE,$.correspondence.channel=xxx"
    })
    public void sendCoCIndependentFieldsWithInvalidRdmDataValidationTest(final String primaryRecipientType, String product, String jsonPath) throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(product, OKTA_AWARE_MOTOR_POLICY));
        correspondenceRequestBuilder.updateDigitalCorrespondenceRequest(primaryRecipientType, getDigitalCorrespondenceArtifactCopy(), jsonPath);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNPROCESSABLE_ENTITY);
        correspondenceVerifier.verifyDigitalCorrespondenceValidationErrors(jsonPath, "value_not_allowed", "validation_failed", "error", response);
    }

    @DisplayName("Digital Send Correspondence - Certificate of Currency, Dependant Mandatory Field Validation Test")
    @ParameterizedTest(name = "{index} ==> Mandatory Property : ''{1}''=''null''")
    @CsvSource({
            "Individual,MOTOR_INSURANCE,$.correspondence.channel=EMAIL|$.correspondence.primary_recipient.individual.email_contact"
    })
    public void sendCoCDependantMandatoryFieldValidationTest(final String primaryRecipientType, String product, String jsonPath) throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(product, OKTA_AWARE_MOTOR_POLICY));
        correspondenceRequestBuilder.updateDigitalCorrespondenceRequest(primaryRecipientType, getDigitalCorrespondenceArtifactCopy(), jsonPath);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNPROCESSABLE_ENTITY);
        correspondenceVerifier.verifyDigitalCorrespondenceValidationErrors(jsonPath, "mandatory_value_missing", "validation_failed", "error", response);
    }

    @Test
    public void validateBothHomeAndMotorAssetsCannotBeSupplied() throws Exception{
        getDigitalCorrespondenceArtifactCopy().setSendCertificateRequest(correspondenceRequestBuilder.getSendCertificateRequestFromConfig());
        getDigitalCorrespondenceArtifactCopy().setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNPROCESSABLE_ENTITY);
        correspondenceVerifier.verifyDigitalCorrespondenceValidationErrors("$.policy_details.assets.home_assets", "only_one_asset_should_be_provided"
                , "validation_failed", "error", response);
    }

    @Test
    public void validateEitherBuildingOrContentsFlagMustBeSupplied() throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(PRODUCT_HOME_INSURANCE, OKTA_AWARE_HOME_POLICY));
        getDigitalCorrespondenceArtifactCopy().setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getAssets().getHomeAssets().setBuildingAsset(null);
        getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getAssets().getHomeAssets().setContentsAsset(null);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNPROCESSABLE_ENTITY);
        correspondenceVerifier.verifyDigitalCorrespondenceValidationErrors("$.policy_details.assets.home_assets.contents_asset", "one_asset_should_be_provided"
                , "validation_failed", "error", response);
    }

    @Test
    public void validateBothBuildingAndContentsFlagCannotBeSupplied() throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(PRODUCT_HOME_INSURANCE, OKTA_AWARE_HOME_POLICY));
        getDigitalCorrespondenceArtifactCopy().setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_UNPROCESSABLE_ENTITY);
        correspondenceVerifier.verifyDigitalCorrespondenceValidationErrors("$.policy_details.assets.home_assets.contents_asset", "one_asset_should_be_provided"
                , "validation_failed", "error", response);
    }

    @Test
    public void successfulSendHomeCoCWithoutOkta() throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(PRODUCT_HOME_INSURANCE, OKTA_AWARE_HOME_POLICY));
        getDigitalCorrespondenceArtifactCopy().setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        correspondenceHeaderBuilder.updateHeadersWithAnonymousToken(getDigitalCorrespondenceArtifactCopy().getHeaders()
                , getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getPolicyNumber());
        getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getAssets().getHomeAssets().setContentsAsset(null);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyHomeDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
    }

    @Test
    public void successfulSendHomeCoCWithoutOktaViaPost() throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(PRODUCT_HOME_INSURANCE, OKTA_AWARE_HOME_POLICY));
        getDigitalCorrespondenceArtifactCopy().setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        correspondenceHeaderBuilder.updateHeadersWithAnonymousToken(getDigitalCorrespondenceArtifactCopy().getHeaders()
                , getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getPolicyNumber());
        getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getPolicyDetails().getAssets().getHomeAssets().setContentsAsset(null);
        getDigitalCorrespondenceArtifactCopy().getSendCertificateRequest().getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_POST);
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyHomeDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
    }

    @Disabled()
    @Test
    public void successfulSendHomeCoCWithOkta() throws Exception{
        setDigitalCorrespondenceArtifactCopy(correspondenceRequestBuilder.setupDigitalCoCIndividualSingleAsset(PRODUCT_HOME_INSURANCE, OKTA_AWARE_HOME_POLICY));
        getDigitalCorrespondenceArtifactCopy().setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        Response response = correspondenceService.executeDigitalSendCorrespondence(getDigitalCorrespondenceArtifactCopy(), SC_OK);
        correspondenceVerifier.verifyHomeDigitalCorrespondenceResponse(digitalCorrespondenceArtifactCopy, response);
    }

    public DigitalCorrespondenceArtifact getDigitalCorrespondenceArtifactCopy() {
        return this.digitalCorrespondenceArtifactCopy;
    }

    public void setDigitalCorrespondenceArtifactCopy(DigitalCorrespondenceArtifact digitalCorrespondenceArtifactCopy) {
        this.digitalCorrespondenceArtifactCopy = digitalCorrespondenceArtifactCopy;
    }
}