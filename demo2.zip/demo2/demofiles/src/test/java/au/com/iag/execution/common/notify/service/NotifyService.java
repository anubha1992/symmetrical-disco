package au.com.iag.execution.common.notify.service;

import static org.apache.http.HttpStatus.SC_ACCEPTED;
import static au.com.iag.glados.model.constants.GladosConstants.APPLICATION_JSON;
import static au.com.iag.glados.model.constants.GladosConstants.CONTENT_TYPE;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AGENT_ID;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_SALES_CHANNEL;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import au.com.iag.execution.common.builders.security.SecurityTokenBuilder;
import au.com.iag.execution.notifyapi.model.business.Policy;
import au.com.iag.glados.common.GladosEnrichmentService;
import io.restassured.response.Response;

@Service
public class NotifyService {

    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityTokenBuilder securityTokenBuilder;

    @Value("${test.security.consumer}") private String consumerSystem;

    public Response notifyPolicyUpdate(Policy policy) throws IOException {
        return gladosEnrichmentService.sendPostRequest(
            buildAPIHeaders(), "/services/v1/product/notify/policy-contract-update",
            policy, SC_ACCEPTED);
    }

    private Map<String, Object> buildAPIHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityTokenBuilder.getSystemSecurityToken(false));
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_SALES_CHANNEL, "ONLINE");
        requestHeaders.put(X_IAG_USER, "WEBCGU");
        requestHeaders.put(X_IAG_AGENT_ID, "IT");
        return requestHeaders;
    }
}
