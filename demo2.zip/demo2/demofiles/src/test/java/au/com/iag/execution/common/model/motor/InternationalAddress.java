package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class InternationalAddress implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("address_line1")
    private String addressLine1 ;
    @JsonProperty("address_line2")
    private String addressLine2 ;
    @JsonProperty("county_province_state")
    private String countyProvinceState ;

  
    @ApiModelProperty(
        value = "First line of the address",
        example = "181 William Street",
        required = false
    )
    public String getAddressLine1() {
       return addressLine1;
    }
 
    @ApiModelProperty(
        value = "Second line of the address",
        example = "Melbourne 3000",
        required = false
    )
    public String getAddressLine2() {
       return addressLine2;
    }
 
    @ApiModelProperty(
        value = "Depending on the particular country address format, this can be used to represent administration area.",
        example = "VIC Australia",
        required = false
    )
    public String getCountyProvinceState() {
       return countyProvinceState;
    }
 

}