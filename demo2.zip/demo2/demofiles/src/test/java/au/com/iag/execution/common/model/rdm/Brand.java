package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Brand implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("abn")
    private String abn ;
    @JsonProperty("afs_licence_number")
    private String afsLicenceNumber ;
    @JsonProperty("brand")
    private String brand ;
    @JsonProperty("brand_name")
    private String brandName ;
    @JsonProperty("claims_phone_number")
    private String claimsPhoneNumber ;
    @JsonProperty("distribution_channel")
    private String distributionChannel ;
    @JsonProperty("effective_date")
    private java.time.LocalDate effectiveDate ;
    @JsonProperty("enquiries_phone_number")
    private String enquiriesPhoneNumber ;
    @JsonProperty("facebook_url")
    private String facebookUrl ;
    @JsonProperty("filter_empty")
    private Boolean filterEmpty ;
    @JsonProperty("legal_entity_name")
    private String legalEntityName ;
    @JsonProperty("linkedin_url")
    private String linkedinUrl ;
    @JsonProperty("instagram_url")
    private String instagramUrl ;
    @JsonProperty("payments_phone_number")
    private String paymentsPhoneNumber ;
    @JsonProperty("payments_url")
    private String paymentsUrl ;
    @JsonProperty("pds_url")
    private String pdsUrl ;
    @JsonProperty("portfolio")
    private String portfolio ;
    @JsonProperty("privacy_phone_number")
    private String privacyPhoneNumber ;
    @JsonProperty("privacy_url")
    private String privacyUrl ;
    @JsonProperty("product")
    private String product ;
    @JsonProperty("return_address_country")
    private String returnAddressCountry ;
    @JsonProperty("return_address_line1")
    private String returnAddressLine1 ;
    @JsonProperty("return_address_postcode")
    private String returnAddressPostcode ;
    @JsonProperty("return_address_state")
    private String returnAddressState ;
    @JsonProperty("return_address_suburb")
    private String returnAddressSuburb ;
    @JsonProperty("twitter_url")
    private String twitterUrl ;
    @JsonProperty("web_url")
    private String webUrl ;
    @JsonProperty("weekday_close_hour")
    private String weekdayCloseHour ;
    @JsonProperty("weekday_open_hour")
    private String weekdayOpenHour ;
    @JsonProperty("weekend_close_hour")
    private String weekendCloseHour ;
    @JsonProperty("weekend_open_hour")
    private String weekendOpenHour ;
    @JsonProperty("youtube_url")
    private String youtubeUrl ;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getAbn() {
        return abn;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getAfsLicenceNumber() {
        return afsLicenceNumber;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getBrand() {
        return brand;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getBrandName() {
        return brandName;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getClaimsPhoneNumber() {
        return claimsPhoneNumber;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getDistributionChannel() {
        return distributionChannel;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public java.time.LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getEnquiriesPhoneNumber() {
        return enquiriesPhoneNumber;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getFacebookUrl() {
        return facebookUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Boolean getFilterEmpty() {
        return filterEmpty;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getLegalEntityName() {
        return legalEntityName;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getLinkedinUrl() {
        return linkedinUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getInstagramUrl() {
        return instagramUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPaymentsPhoneNumber() {
        return paymentsPhoneNumber;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPaymentsUrl() {
        return paymentsUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPdsUrl() {
        return pdsUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPortfolio() {
        return portfolio;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPrivacyPhoneNumber() {
        return privacyPhoneNumber;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getPrivacyUrl() {
        return privacyUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getProduct() {
        return product;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getReturnAddressCountry() {
        return returnAddressCountry;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getReturnAddressLine1() {
        return returnAddressLine1;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getReturnAddressPostcode() {
        return returnAddressPostcode;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getReturnAddressState() {
        return returnAddressState;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getReturnAddressSuburb() {
        return returnAddressSuburb;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getTwitterUrl() {
        return twitterUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getWebUrl() {
        return webUrl;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getWeekdayCloseHour() {
        return weekdayCloseHour;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getWeekdayOpenHour() {
        return weekdayOpenHour;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getWeekendCloseHour() {
        return weekendCloseHour;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getWeekendOpenHour() {
        return weekendOpenHour;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getYoutubeUrl() {
        return youtubeUrl;
    }


}