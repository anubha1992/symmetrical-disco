package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains payment related information for the policy")
public class PaymentDetailsResponse implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("billing_frequency")
    private String billingFrequency ;
    @JsonProperty("direct_debit")
    private Boolean directDebit ;
    @JsonProperty("payment_summary")
    private PaymentSummary paymentSummary = new PaymentSummary();

  
    @ApiModelProperty(
        value = "Billing plan. [Ref Data: billing_frequency]",
        example = "MONTHLY",
        required = false
    )
    public String getBillingFrequency() {
       return billingFrequency;
    }
 
    @ApiModelProperty(
        value = "Indicates if billing plan has instalments",
        example = "true",
        required = false
    )
    public Boolean getDirectDebit() {
       return directDebit;
    }
 
    @ApiModelProperty(
        value = "Payment summary details",
        required = false
    )
    public PaymentSummary getPaymentSummary() {
       return paymentSummary;
    }
 

}