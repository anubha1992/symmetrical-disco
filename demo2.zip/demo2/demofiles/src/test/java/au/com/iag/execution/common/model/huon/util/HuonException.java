package au.com.iag.execution.common.model.huon.util;

/**
 * This is an Exception class we define for HUON operation.
 */
public class HuonException extends Exception {
    private static final long serialVersionUID = 1L;

    public HuonException(String ex) {
        super(ex);
    }
}

