package au.com.iag.execution.common.model.huon;

import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * A class to write HUON policies/clients information to a report file or
 * somewhere else. It also has screenshot function
 */
public class HuonReporter {
    String absoluteFileName = "";
    String testcaseDir = "";

    /**
     * Create a report with a file name.
     *
     * @param
     */
    public HuonReporter(String testcaseDir) {
        if (testcaseDir == null)
            return;

        this.testcaseDir = testcaseDir;
        File dir = new File(testcaseDir);
        if (dir.isDirectory()) {
            if (testcaseDir.endsWith(File.separator)) {
                this.absoluteFileName = testcaseDir + "huon.txt";
            } else {
                this.absoluteFileName = testcaseDir + File.separator + "huon.txt";
            }

            //			if (testcaseDir.endsWith("\\")) {
            //				this.absoluteFileName = testcaseDir + "huon.txt";
            //			} else {
            //				this.absoluteFileName = testcaseDir + "\\" + "huon.txt";
            //			}
        } else {
            this.absoluteFileName = testcaseDir;
            this.testcaseDir = dir.getParent();
        }
    }

    /**
     * Write policy or client information to a txt file.
     *
     * @param information
     */
    public void writeTxt(String information) {
        if (this.absoluteFileName == null)
            return;
        if (this.absoluteFileName.isEmpty())
            return;

        File file = new File(this.absoluteFileName);
        BufferedWriter bf = null;
        try {
            if (file.exists()) {
                bf = new BufferedWriter(new FileWriter(file, true));
                bf.newLine();
                bf.newLine();
            } else {
                bf = new BufferedWriter(new FileWriter(file));
            }

            bf.write(information);

        } catch (IOException ioe) {
            //Don't stop the running when there is IOException
            //Just write something to log
            System.err.println(
                    "[ERROR] Failed to write HUON policy/client information to txt file -- " + this.absoluteFileName);
            ioe.printStackTrace();
        } finally {

        }

        if (bf != null) {
            try {
                bf.close();
            } catch (IOException ex2) {

            }
        }
    }

    public void writeError(String error) {
        writeTxt("[ERROR] " + error);
    }

    public void writeWarning(String warning) {
        writeTxt("[WARN] " + warning);
    }

    public void captureScreenshot(String source) {
        //		String fileName = testcaseDir;

        Calendar cal = Calendar.getInstance();
        Date now = cal.getTime();
        DateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String fileName = "Huon" + source + "_" + formatter.format(now) + ".png";

        if (testcaseDir.endsWith(File.separator)) {
            fileName = testcaseDir + fileName;
        } else {
            fileName = testcaseDir + File.separator + fileName;
        }

        //		if (testcaseDir.endsWith("\\")) {
        //			fileName = testcaseDir + fileName;
        //		} else {
        //			fileName = testcaseDir + "\\" + fileName;
        //		}
        try {
            Robot robot = new Robot();
            Rectangle rect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage screenshot = robot.createScreenCapture(rect);

            ImageIO.write(screenshot, "png", new File(fileName));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (AWTException awte) {
            awte.printStackTrace();
        }

        System.out.println("[" + source + "]Screenshot of HUON exception put to: " + fileName);
    }

    public void printScreenshot() throws AWTException {
        Robot robot = new Robot();
        Rectangle rect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage screenshot = robot.createScreenCapture(rect);

        System.out.println(screenshot);
    }

}
