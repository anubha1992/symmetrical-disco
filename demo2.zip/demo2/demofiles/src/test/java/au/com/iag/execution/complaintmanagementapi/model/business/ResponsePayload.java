package au.com.iag.execution.complaintmanagementapi.model.business;

import java.io.Serializable;
import lombok.Data;

@Data
public class ResponsePayload implements Serializable {
    private static final long serialVersionUID = 1L;
    private String response;
}
