package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PolicyDriver implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("age_licence_obtained")
    private Integer ageLicenceObtained ;
    @JsonProperty("licence_events")
    private java.util.List<LicenceEvent> licenceEvents = new java.util.ArrayList<LicenceEvent>();
    @JsonProperty("party_id")
    private String partyId ;
    @JsonProperty("prior_licence_events")
    private Boolean priorLicenceEvents ;
    @JsonProperty("prior_licence_events_effective_from")
    private String priorLicenceEventsEffectiveFrom ;
    @JsonProperty("prior_licence_events_number_of_years")
    private Integer priorLicenceEventsNumberOfYears ;

  
    @ApiModelProperty(
        value = "Driver age when licence obtained",
        example = "18",
        required = false
    )
    public Integer getAgeLicenceObtained() {
       return ageLicenceObtained;
    }
 
    @ApiModelProperty(
        value = "List of licence events",
        required = false
    )
    public java.util.List<LicenceEvent> getLicenceEvents() {
       return licenceEvents;
    }
 
    @ApiModelProperty(
        value = "Driver party id",
        example = "12345567890",
        required = false
    )
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Indicates if driver has had licence problems in the past three years.",
        required = false
    )
    public Boolean getPriorLicenceEvents() {
       return priorLicenceEvents;
    }
 
    @ApiModelProperty(
        value = "Driver had their licence disqualified, cancelled or suspended due to driving offences since this effective year month. Date format: yyyy-mm",
        example = "2019-12",
        required = false
    )
    public String getPriorLicenceEventsEffectiveFrom() {
       return priorLicenceEventsEffectiveFrom;
    }
 
    @ApiModelProperty(
        value = "Driver had their licence disqualified, cancelled or suspended due to driving offences since this number of years.",
        required = false
    )
    public Integer getPriorLicenceEventsNumberOfYears() {
       return priorLicenceEventsNumberOfYears;
    }
 

}