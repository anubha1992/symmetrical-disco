package au.com.iag.execution.claimupdateapi;

import au.com.iag.execution.claimupdateapi.builders.*;
import au.com.iag.execution.claimupdateapi.configurations.*;
import au.com.iag.execution.claimupdateapi.model.*;
import au.com.iag.execution.claimupdateapi.service.*;
import au.com.iag.execution.claimupdateapi.verifiers.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.io.*;
import java.util.*;

@SpringBootTest()
@ExtendWith({SpringExtension.class, GladosRunnerExtension.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = {ClaimUpdateConfiguration.class})
@Tags({@Tag("RecoveryJourney"), @Tag("ClaimsLodgement"), @Tag("MotorClaimsLodgement"), @Tag("ReallocateServiceRequest"), @Tag("claim-update-api")})
public class SendCorrespondenceTest {

    @Autowired
    private ClaimUpdateService claimUpdateService;
    @Autowired
    private ClaimUpdateRequestBuilder claimUpdateRequestBuilder;
    @Autowired
    private ClaimUpdateVerifier claimUpdateVerifier;

    @Value("${test.api.product.code}") private String productCode;

    private SendCorrespondenceArtifact sendCorrespondenceArtifact;
    private String claimId;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimUpdateService.getSwaggerSchema();
        claimId = claimUpdateRequestBuilder.getClaimId();
        if(productCode.equalsIgnoreCase("MOT")|| productCode.equalsIgnoreCase("COM")) {
            LodgeMotorServiceRequestArtifact lodgeMotorServiceRequestArtifact = claimUpdateRequestBuilder.buildMotorServiceReqArtifact(claimId);
            Response response = claimUpdateService.executeMotorLodgeServiceRequest(lodgeMotorServiceRequestArtifact, SC_CREATED);
            claimId = response.path("claim_identifier");
        }
    }

    @BeforeEach
    public void setup() throws Exception {

        sendCorrespondenceArtifact = claimUpdateRequestBuilder.buildSendCorrespondenceArtifact(claimId);
    }

    @Test
    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NRMA, loadContext = true)
    public void sendCorrespond() {
        Response response = claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_OK);
    }

    @Test
    public void sendCorrespondWithInvalidClaimId() {
        String invalidClaimId = "COMO99900000";
        sendCorrespondenceArtifact.getClaimCorrespondence().getClaim().setClaimIdentifier(invalidClaimId);
        Response response = claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_NOT_FOUND);
        claimUpdateVerifier.verifyErrorResponse(response, "Could not find Claim '"+invalidClaimId+"'");
    }

    @Test
    public void sendCorrespondMissingClaimId() throws IOException{
        sendCorrespondenceArtifact.getClaimCorrespondence().getClaim().setClaimIdentifier(null);
        Response response = claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyValidationErrorMessagesForMandatory(response, "claim.claim_identifier", "MANDATORY_FIELD_MISSING","Claim identifier is mandatory" );
    }

    @Test
    public void sendCorrespondWithMissingRepairerIdentifier() throws IOException {
        sendCorrespondenceArtifact.getClaimCorrespondence().getClaim().setRepairerIdentifier(null);
        Response response = claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyValidationErrorMessagesForMandatory(response, "claim.repairer_identifier", "MANDATORY_FIELD_MISSING", "Repairer identifier is mandatory");
    }

    @Test
    public void sendCorrespondWithMissingEventType() throws IOException {
        sendCorrespondenceArtifact.getClaimCorrespondence().getCoreCorrespondenceDetails().setEventType(null);
        Response response = claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyValidationErrorMessagesForMandatory(response, "core_correspondence_details.event_type", "MANDATORY_FIELD_MISSING", "EventType is mandatory");
    }

    @Test
    public void sendCorrespondWithMissingLineOfBusiness() throws IOException {
        sendCorrespondenceArtifact.getClaimCorrespondence().getCoreCorrespondenceDetails().setLineOfBusiness(null);
        Response response = claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyValidationErrorMessagesForMandatory(response, "core_correspondence_details.line_of_business", "MANDATORY_FIELD_MISSING", "LineOfBusiness is mandatory");
    }

    @Test
    public void sendCorrespondInValidConsumerSystem() {
        Map<String, Object> requestHeaders = sendCorrespondenceArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNAUTHORIZED);
    }

    @Test
    public void sendCorrespondNoConsumerSystem() {
        Map<String, Object> requestHeaders = sendCorrespondenceArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityTokensendCorrespond() {
        Map<String, Object> requestHeaders = sendCorrespondenceArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNAUTHORIZED);
    }

    @Test
    public void inValidSecurityTokensendCorrespond() {
        Map<String, Object> requestHeaders = sendCorrespondenceArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        claimUpdateService.executeSendCorrespondenceRequest(sendCorrespondenceArtifact, SC_UNAUTHORIZED);
    }

    @Test
    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NRMA, loadContext = true)
    public void sendCorrespondApiGeeExternal() throws IOException {
        sendCorrespondenceArtifact = claimUpdateRequestBuilder.buildSendCorrespondenceArtifactExternal(claimId);
        Response response = claimUpdateService.executeSendCorrespondenceRequestExternal(sendCorrespondenceArtifact, SC_OK);
    }
}
