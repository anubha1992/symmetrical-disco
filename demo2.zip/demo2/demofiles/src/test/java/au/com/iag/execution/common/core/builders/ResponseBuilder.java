package au.com.iag.execution.common.core.builders;

import au.com.iag.glados.service.JsonMapperService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class ResponseBuilder {

    @Autowired private JsonMapperService jsonMapperService;

    public <T> T buildResponse(Response response, Class<T> clazz) throws IOException {
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper
                .readValue(objectMapper.writeValueAsString(response.jsonPath().get()), clazz);
    }
}
