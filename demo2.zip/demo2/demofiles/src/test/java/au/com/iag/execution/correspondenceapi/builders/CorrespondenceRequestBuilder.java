package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.DigitalCorrespondenceArtifact;
import au.com.iag.execution.correspondenceapi.model.PolicySendCorrespondenceArtifact;
import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.execution.correspondenceapi.model.business.ResendDocument;
import au.com.iag.execution.correspondenceapi.model.business.ResendPolicy;
import au.com.iag.execution.correspondenceapi.model.business.digital.SendCertificateRequest;
import au.com.iag.execution.correspondenceapi.service.JsonPathService;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class CorrespondenceRequestBuilder {

    @Autowired private JsonPathService jsonPathService;
    @Autowired private MotorCorrespondenceRequestBuilder motorCorrespondenceRequestBuilder;
    @Autowired private HomeCorrespondenceRequestBuilder homeCorrespondenceRequestBuilder;
    @Autowired private LandlordCorrespondenceRequestBuilder landlordCorrespondenceRequestBuilder;
    @Autowired private LetterCorrespondenceRequestBuilder letterCorrespondenceRequestBuilder;
    @Autowired private PolicyRoleBuilder policyRoleBuilder;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private CorrespondenceHeaderBuilder correspondenceHeaderBuilder;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private SmsCorrespondenceRequestBuilder smsCorrespondenceRequestBuilder;

    @Value("${test.api.route}")
    private String route;
    @Value("${test.api.brand}")
    private String brand;

    public void setupResendPolicy(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact
            , String correspondenceId, String channel, String primaryRecipientType) throws IOException{
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/resend/resend"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        policySendCorrespondenceArtifact.setResendPolicyRequest(buildResendPolicyCorrespondenceRequest(correspondenceId, channel, primaryRecipientType));
    }

    public void setupResendOnFailurePolicy(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact, String correspondenceId) throws IOException{
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/resend/resend-on-failure"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        policySendCorrespondenceArtifact.setResendOnFailurePolicyRequest(buildResendOnFailurePolicyCorrespondenceRequest(correspondenceId));
    }

    public PolicySendCorrespondenceArtifact setupSmsRenewalReminderExpiry(String product, String correspondenceType) throws IOException{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/sms-delivery/send-sms"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(smsCorrespondenceRequestBuilder
                .getSmsCorrespondenceRequest(getSmsRenewalReminderExpiryRequest()
                        , correspondenceType
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL));
        return policySendCorrespondenceArtifact;
    }

    public PolicyCorrespondence getSmsRenewalReminderExpiryRequest() throws IOException{
        PolicyCorrespondence policyCorrespondence = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/smsRenewalReminderExpiry.json")
                        , PolicyCorrespondence.class);
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        return policyCorrespondence;
    }

    public PolicySendCorrespondenceArtifact setupSmsPolicyCancellation(String product, String correspondenceType) throws IOException{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/sms-delivery/send-sms"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(smsCorrespondenceRequestBuilder
                .getSmsCorrespondenceRequest(getSmsPolicyCancellationRequest()
                        , correspondenceType
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL));
        return policySendCorrespondenceArtifact;
    }

    public PolicyCorrespondence getSmsPolicyCancellationRequest() throws IOException{
        PolicyCorrespondence policyCorrespondence = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/smsPolicyCancellation.json")
                        , PolicyCorrespondence.class);
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        return policyCorrespondence;
    }

    public PolicySendCorrespondenceArtifact setupSmsCancelledRisk(String product, String correspondenceType) throws IOException{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/sms-delivery/send-sms"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(smsCorrespondenceRequestBuilder
                .getSmsCorrespondenceRequest(getSmsCancelledRiskRequest()
                        , correspondenceType
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL));
        return policySendCorrespondenceArtifact;
    }

    public PolicyCorrespondence getSmsCancelledRiskRequest() throws IOException{
        PolicyCorrespondence policyCorrespondence = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/smsCancelledRisk.json")
                        , PolicyCorrespondence.class);
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        return policyCorrespondence;
    }

    public PolicySendCorrespondenceArtifact setupSmsRenewalReminder(String product, String correspondenceType) throws IOException{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/sms-delivery/send-sms"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(smsCorrespondenceRequestBuilder
                .getSmsCorrespondenceRequest(getSmsRenewalReminderRequest()
                        , correspondenceType
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL));
        return policySendCorrespondenceArtifact;
    }

    public PolicyCorrespondence getSmsRenewalReminderRequest() throws IOException{
        PolicyCorrespondence policyCorrespondence = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/smsRenewalReminder.json")
                        , PolicyCorrespondence.class);
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        return policyCorrespondence;
    }

    public PolicySendCorrespondenceArtifact setupAnonymousQuoteIndividualSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(CORRESPONDENCE_TYPE_ANONYMOUS_QUOTE));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildAnonymousQuoteRequest(product
                , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                , policyRoleBuilder.getIndividualWithSingleAsset(product)));
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupPolicySendCorrespondenceIndividualSingleAsset(String product, String correspondenceType) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildPolicyCorrespondenceRequest(product
                , correspondenceType
                , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                , policyRoleBuilder.getIndividualWithSingleAsset(product)));
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupPolicySendCorrespondenceSingleAsset(String product, String correspondenceType, final String primaryRecipientType) throws IOException {
        switch (primaryRecipientType){
            case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                return setupPolicySendCorrespondenceIndividualSingleAsset(product, correspondenceType);
            case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                return setupPolicySendCorrespondenceOrganisationSingleAsset(product, correspondenceType);
            default:
                throw new IllegalArgumentException("Invalid primary recipient type "+primaryRecipientType);
        }
    }

    public PolicySendCorrespondenceArtifact setupHomeContentsOnlySendCorrespondenceIndividualSingleAsset(String correspondenceType) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(PRODUCT_HOME_INSURANCE));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildPolicyCorrespondenceRequest(PRODUCT_HOME_INSURANCE
                , correspondenceType
                , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                , policyRoleBuilder.getIndividualWithSingleHomeAssetNoOtherParty()));
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupPolicySendCorrespondenceIndividualMultiAsset(String product, String correspondenceType) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildPolicyCorrespondenceRequest(product
                , correspondenceType
                , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                , policyRoleBuilder.getIndividualWithMultipleAssets(product)));
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupPolicySendCorrespondenceOrganisationSingleAsset(String product, String correspondenceType) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildPolicyCorrespondenceRequest(product
                , correspondenceType
                , PRIMARY_RECIPIENT_TYPE_ORGANISATION
                , policyRoleBuilder.getOrganisationWithSingleAsset(product)));
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupPolicySendCorrespondenceOrganisationWithMultiAsset(String product, String correspondenceType) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders(correspondenceType));
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildPolicyCorrespondenceRequest(product
                , correspondenceType
                , PRIMARY_RECIPIENT_TYPE_ORGANISATION
                , policyRoleBuilder.getOrganisationWithMultipleAssets(product)));
        return policySendCorrespondenceArtifact;
    }

    //Policy Cancellation
    public PolicySendCorrespondenceArtifact setupLetterPolicyCancellationIndividualSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/letter/send-letter"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        PolicyCorrespondence policyCorrespondence = letterCorrespondenceRequestBuilder
                .buildLetterPolicyCancellationRequest(product
                        , CORRESPONDENCE_TYPE_POLICY_CANCELLATION
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , policyRoleBuilder.getIndividualWithSingleAsset(product));
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(policyCorrespondence);
        return policySendCorrespondenceArtifact;
    }

    //Dishonour Policy Cancellation
    public PolicySendCorrespondenceArtifact setupLetterDishonourPolicyCancellationIndividualSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/letter/send-letter"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        PolicyCorrespondence policyCorrespondence = letterCorrespondenceRequestBuilder
                .buildLetterDishonourPolicyCancellationRequest(product
                        , CORRESPONDENCE_TYPE_DISHONOUR_POLICY_CANCELLATION
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , policyRoleBuilder.getIndividualWithSingleAsset(product));
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(policyCorrespondence);
        return policySendCorrespondenceArtifact;
    }

    //Renewal Reminder Expiry
    public PolicySendCorrespondenceArtifact setupLetterRenewalReminderExpiryIndividualSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/letter/send-letter"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        PolicyCorrespondence policyCorrespondence = letterCorrespondenceRequestBuilder
                .buildLetterRenewalReminderExpiryRequest(product
                        , CORRESPONDENCE_TYPE_RENEWAL_REMINDER_EXPIRY
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , policyRoleBuilder.getIndividualWithSingleAsset(product));
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(policyCorrespondence);
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupLetterRenewalReminderExpiryOrganisationSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/letter/send-letter"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        PolicyCorrespondence policyCorrespondence = letterCorrespondenceRequestBuilder
                .buildLetterRenewalReminderExpiryRequest(product
                        , CORRESPONDENCE_TYPE_RENEWAL_REMINDER_EXPIRY
                        , PRIMARY_RECIPIENT_TYPE_ORGANISATION
                        , policyRoleBuilder.getOrganisationWithSingleAsset(product));
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(policyCorrespondence);
        return policySendCorrespondenceArtifact;
    }

    // Start Dishonour Notification
    public PolicySendCorrespondenceArtifact setupLetterDishonourNotificationIndividualSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/letter/send-letter"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        PolicyCorrespondence policyCorrespondence = letterCorrespondenceRequestBuilder
                .buildLetterDishonourNotificationRequest(product
                        , CORRESPONDENCE_TYPE_DISHONOUR_NOTIFICATION
                        , PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , policyRoleBuilder.getIndividualWithSingleAsset(product));
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(policyCorrespondence);
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupLetterDishonourNotificationOrganisationSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/letter/send-letter"));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        PolicyCorrespondence policyCorrespondence = letterCorrespondenceRequestBuilder
                .buildLetterDishonourNotificationRequest(product
                        , CORRESPONDENCE_TYPE_DISHONOUR_NOTIFICATION
                        , PRIMARY_RECIPIENT_TYPE_ORGANISATION
                        , policyRoleBuilder.getIndividualWithSingleAsset(product));
        policyCorrespondence.getPolicyDetails().setBrand(brand);
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(policyCorrespondence);
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupCoCIndividualSingleAsset(String product) throws IOException{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildCoCRequest(product, PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                , policyRoleBuilder.getIndividualWithSingleAsset(product)));
        return policySendCorrespondenceArtifact;
    }

    public PolicySendCorrespondenceArtifact setupCoCOrganisationSingleAsset(String product) throws IOException {
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = new PolicySendCorrespondenceArtifact();
        policySendCorrespondenceArtifact.setPath(getPolicyApiPath(product));
        policySendCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildCorrespondenceHeaders());
        policySendCorrespondenceArtifact.setPolicyCorrespondenceRequest(buildCoCRequest(product, PRIMARY_RECIPIENT_TYPE_ORGANISATION
                , policyRoleBuilder.getIndividualWithSingleAsset(product)));
        return policySendCorrespondenceArtifact;
    }

    public DigitalCorrespondenceArtifact setupDigitalCoCIndividualSingleAsset(String product, String policyNumber) throws IOException {
        DigitalCorrespondenceArtifact digitalCorrespondenceArtifact = new DigitalCorrespondenceArtifact();
        digitalCorrespondenceArtifact.setPath(route.replaceFirst("/motor", "/digital/send-certificate-of-currency"));
        SendCertificateRequest sendCertificateRequest = getSendCertificateRequestFromConfig();
        updateDigitalCorrespondenceArtifactByProduct(product, sendCertificateRequest);
        digitalCorrespondenceArtifact.setSendCertificateRequest(sendCertificateRequest);
        digitalCorrespondenceArtifact.getSendCertificateRequest().getPolicyDetails().setPolicyNumber(policyNumber);
        digitalCorrespondenceArtifact.setHeaders(correspondenceHeaderBuilder.buildDigitalCorrespondenceHeaders(false));
        return digitalCorrespondenceArtifact;
    }

    public SendCertificateRequest getSendCertificateRequestFromConfig() throws IOException{
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/digitalCorrespondenceSendCoC.json")
                        , SendCertificateRequest.class);
    }

    private void updateDigitalCorrespondenceArtifactByProduct(String product, SendCertificateRequest sendCertificateRequest){
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                sendCertificateRequest.getPolicyDetails().getAssets().setVehicleAssets(null);
                break;
            case PRODUCT_MOTOR_INSURANCE:
                sendCertificateRequest.getPolicyDetails().getAssets().setHomeAssets(null);
                break;
            default:
                throw new IllegalArgumentException("Invalid product - " + product);
        }
    }

    public void updatePolicyCorrespondenceRequest(final String primaryRecipientType, PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact, String jsonPaths) throws IOException {
        primaryRecipientBuilder.updatePrimaryRecipient(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest(), primaryRecipientType);
        updateSpecialAttributes(policySendCorrespondenceArtifact, jsonPaths);
        jsonPathService.updatePolicyCorrespondenceRequest(policySendCorrespondenceArtifact, jsonPaths);
    }

    public void updateDigitalCorrespondenceRequest(final String primaryRecipientType, DigitalCorrespondenceArtifact digitalCorrespondenceArtifact, String jsonPaths) throws IOException {
        primaryRecipientBuilder.updatePrimaryRecipient(digitalCorrespondenceArtifact.getSendCertificateRequest(), primaryRecipientType);
        jsonPathService.updateDigitalCorrespondenceRequest(digitalCorrespondenceArtifact, jsonPaths);
    }

    public void updatePolicyCorrespondenceRequest(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact, String jsonPaths) throws IOException {
        updateSpecialAttributes(policySendCorrespondenceArtifact, jsonPaths);
        jsonPathService.updatePolicyCorrespondenceRequest(policySendCorrespondenceArtifact, jsonPaths);
    }

    public void updateResendPolicyRequest(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact, String jsonPaths) throws IOException {
        updateSpecialAttributes(policySendCorrespondenceArtifact, jsonPaths);
        jsonPathService.updateResendPolicyRequest(policySendCorrespondenceArtifact, jsonPaths);
    }

    public void updateResendOnFailurePolicyRequest(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact, String jsonPaths) throws IOException {
        updateSpecialAttributes(policySendCorrespondenceArtifact, jsonPaths);
        jsonPathService.updateResendOnFailurePolicyRequest(policySendCorrespondenceArtifact, jsonPaths);
    }

    private void updateSpecialAttributes(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact, String jsonPaths){
        Map<String, Object> mapOfJsonPaths = jsonPathService.tokenizeJsonPaths(jsonPaths);
        if(mapOfJsonPaths.containsKey("$.correspondence.insert_effective_date"))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().setInsertEffectiveDate("");
        if(mapOfJsonPaths.containsKey("$.correspondence.inserts[0]"))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().setInserts(Collections.singletonList(""));
    }

    private PolicyCorrespondence buildPolicyCorrespondenceRequest(String product, String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                PolicyCorrespondence homeCorrespondence = homeCorrespondenceRequestBuilder
                        .getHomeCorrespondenceRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
                homeCorrespondence.getPolicyDetails().setBrand(brand);
                return homeCorrespondence;
            case PRODUCT_MOTOR_INSURANCE:
                PolicyCorrespondence motorCorrespondence = motorCorrespondenceRequestBuilder
                        .getMotorCorrespondenceRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
                motorCorrespondence.getPolicyDetails().setBrand(brand);
                return motorCorrespondence;
            case PRODUCT_LANDLORD_INSURANCE:
                PolicyCorrespondence landlordCorrespondence = landlordCorrespondenceRequestBuilder
                        .getLandlordCorrespondenceRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
                landlordCorrespondence.getPolicyDetails().setBrand(brand);
                return landlordCorrespondence;
            default:
                throw new IllegalArgumentException("Invalid product - " + product);
        }
    }

    private PolicyCorrespondence buildCoCRequest(String product, String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                PolicyCorrespondence homeCorrespondence = homeCorrespondenceRequestBuilder.getHomeCoCRequest(primaryRecipientType, listOfCoverableToPartyRoleSpec);
                homeCorrespondence.getPolicyDetails().setBrand(brand);
                return homeCorrespondence;
            case PRODUCT_MOTOR_INSURANCE:
                PolicyCorrespondence motorCorrespondence = motorCorrespondenceRequestBuilder.getMotorCoCRequest(primaryRecipientType, listOfCoverableToPartyRoleSpec);
                motorCorrespondence.getPolicyDetails().setBrand(brand);
                return motorCorrespondence;
            default:
                throw new IllegalArgumentException("Invalid product - " + product);
        }
    }

    private PolicyCorrespondence buildAnonymousQuoteRequest(String product, String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                PolicyCorrespondence homeCorrespondence = homeCorrespondenceRequestBuilder.getHomeAnonymousQuoteRequest(primaryRecipientType, listOfCoverableToPartyRoleSpec);
                homeCorrespondence.getPolicyDetails().setBrand(brand);
                return homeCorrespondence;
            case PRODUCT_MOTOR_INSURANCE:
                PolicyCorrespondence motorCorrespondence = motorCorrespondenceRequestBuilder.getMotorAnonymousQuoteRequest(primaryRecipientType, listOfCoverableToPartyRoleSpec);
                motorCorrespondence.getPolicyDetails().setBrand(brand);
                return motorCorrespondence;
            default:
                throw new IllegalArgumentException("Invalid product - " + product);
        }
    }

    private ResendPolicy buildResendPolicyCorrespondenceRequest(String correspondenceId, String channel, String primaryRecipientType) throws IOException{
        ResendPolicy resendPolicy = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/resendCorrespondence.json")
                        , ResendPolicy.class);
        resendPolicy.getCorrespondence().setCorrespondenceId(correspondenceId);
        resendPolicy.getCorrespondence().setChannel(channel);
        updateResendPrimaryRecipient(resendPolicy, primaryRecipientType);
        resendPolicy.getPolicyDetails().setBrand(brand);
        return resendPolicy;
    }

    private ResendDocument buildResendOnFailurePolicyCorrespondenceRequest(String correspondenceId) throws IOException{
        ResendDocument resendDocument = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/resendOnFailureCorrespondence.json")
                        , ResendDocument.class);
        resendDocument.getCorrespondence().setCorrespondenceId(correspondenceId);
        resendDocument.getPolicyDetails().setBrand(brand);
        return resendDocument;
    }

    private void updateResendPrimaryRecipient(ResendPolicy resendPolicy, String primaryRecipientType){
        switch (primaryRecipientType) {
            case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                resendPolicy.getCorrespondence().getPrimaryRecipient().setOrganisation(null);
                break;
            case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                resendPolicy.getCorrespondence().getPrimaryRecipient().setIndividual(null);
                break;
            default:
                throw new IllegalArgumentException("Invalid primary recipient type - " + primaryRecipientType);
        }
    }

    private String getPolicyApiPath(String product) {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return route.replaceFirst("/motor", "/home/policy-quote");
            case PRODUCT_MOTOR_INSURANCE:
                return route.replaceFirst("/motor", "/motor/policy-quote");
            case PRODUCT_LANDLORD_INSURANCE:
                return route.replaceFirst("/motor", "/landlord/policy-quote");
            default:
                throw new IllegalArgumentException("Invalid product - " + product);
        }
    }
}
