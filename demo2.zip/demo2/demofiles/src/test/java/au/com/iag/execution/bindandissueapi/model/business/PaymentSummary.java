package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PaymentSummary implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("payment_status")
    private String paymentStatus ;

  
    @ApiModelProperty(
        value = "Payment status. [Ref Data: payment_status]",
        required = false
    )
    public String getPaymentStatus() {
       return paymentStatus;
    }
 

}