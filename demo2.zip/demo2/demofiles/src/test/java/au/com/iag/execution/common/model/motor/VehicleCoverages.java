package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleCoverages implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("accidental_damage")
    private BasicCoverage accidentalDamage = new BasicCoverage();
    @JsonProperty("baby_capsules")
    private BasicCoverage babyCapsules = new BasicCoverage();
    @JsonProperty("choice_of_repairer")
    private BasicCoverage choiceOfRepairer = new BasicCoverage();
    @JsonProperty("collision")
    private BasicCoverage collision = new BasicCoverage();
    @JsonProperty("cyclone")
    private BasicCoverage cyclone = new BasicCoverage();
    @JsonProperty("earthquake")
    private BasicCoverage earthquake = new BasicCoverage();
    @JsonProperty("emergency_repairs")
    private BasicCoverage emergencyRepairs = new BasicCoverage();
    @JsonProperty("emergency_transport")
    private BasicCoverage emergencyTransport = new BasicCoverage();
    @JsonProperty("explosion")
    private BasicCoverage explosion = new BasicCoverage();
    @JsonProperty("fire")
    private BasicCoverage fire = new BasicCoverage();
    @JsonProperty("fire_extinguisher")
    private BasicCoverage fireExtinguisher = new BasicCoverage();
    @JsonProperty("flood")
    private BasicCoverage flood = new BasicCoverage();
    @JsonProperty("glass_excess_waiver")
    private BasicCoverage glassExcessWaiver = new BasicCoverage();
    @JsonProperty("hire_vehicle_after_incident")
    private BasicCoverage hireVehicleAfterIncident = new BasicCoverage();
    @JsonProperty("hire_vehicle_after_not_at_fault")
    private BasicCoverage hireVehicleAfterNotAtFault = new BasicCoverage();
    @JsonProperty("hire_vehicle_after_theft")
    private BasicCoverage hireVehicleAfterTheft = new BasicCoverage();
    @JsonProperty("incorrect_fuel")
    private BasicCoverage incorrectFuel = new BasicCoverage();
    @JsonProperty("legal_repair_costs")
    private BasicCoverage legalRepairCosts = new BasicCoverage();
    @JsonProperty("liability")
    private BasicCoverage liability = new BasicCoverage();
    @JsonProperty("lightning")
    private BasicCoverage lightning = new BasicCoverage();
    @JsonProperty("methamphetamine")
    private BasicCoverage methamphetamine = new BasicCoverage();
    @JsonProperty("new_replacement_vehicle")
    private BasicCoverage newReplacementVehicle = new BasicCoverage();
    @JsonProperty("personal_items")
    private BasicCoverage personalItems = new BasicCoverage();
    @JsonProperty("replacement_of_keys")
    private BasicCoverage replacementOfKeys = new BasicCoverage();
    @JsonProperty("standard_excess")
    private BasicCoverage standardExcess = new BasicCoverage();
    @JsonProperty("storage")
    private BasicCoverage storage = new BasicCoverage();
    @JsonProperty("storm")
    private BasicCoverage storm = new BasicCoverage();
    @JsonProperty("taxi_fare")
    private BasicCoverage taxiFare = new BasicCoverage();
    @JsonProperty("temporary_cover")
    private BasicCoverage temporaryCover = new BasicCoverage();
    @JsonProperty("theft")
    private BasicCoverage theft = new BasicCoverage();
    @JsonProperty("tools_of_trade")
    private BasicCoverage toolsOfTrade = new BasicCoverage();
    @JsonProperty("towing")
    private BasicCoverage towing = new BasicCoverage();
    @JsonProperty("trailer")
    private BasicCoverage trailer = new BasicCoverage();
    @JsonProperty("tsunami")
    private BasicCoverage tsunami = new BasicCoverage();
    @JsonProperty("uninsured_motorist_damage")
    private BasicCoverage uninsuredMotoristDamage = new BasicCoverage();
    @JsonProperty("vandalism")
    private BasicCoverage vandalism = new BasicCoverage();
    @JsonProperty("vehicle_pickup")
    private BasicCoverage vehiclePickup = new BasicCoverage();

  
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getAccidentalDamage() {
       return accidentalDamage;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getBabyCapsules() {
       return babyCapsules;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getChoiceOfRepairer() {
       return choiceOfRepairer;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getCollision() {
       return collision;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getCyclone() {
       return cyclone;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getEarthquake() {
       return earthquake;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getEmergencyRepairs() {
       return emergencyRepairs;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getEmergencyTransport() {
       return emergencyTransport;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getExplosion() {
       return explosion;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getFire() {
       return fire;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getFireExtinguisher() {
       return fireExtinguisher;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getFlood() {
       return flood;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getGlassExcessWaiver() {
       return glassExcessWaiver;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getHireVehicleAfterIncident() {
       return hireVehicleAfterIncident;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getHireVehicleAfterNotAtFault() {
       return hireVehicleAfterNotAtFault;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getHireVehicleAfterTheft() {
       return hireVehicleAfterTheft;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getIncorrectFuel() {
       return incorrectFuel;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getLegalRepairCosts() {
       return legalRepairCosts;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getLiability() {
       return liability;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getLightning() {
       return lightning;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getMethamphetamine() {
       return methamphetamine;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getNewReplacementVehicle() {
       return newReplacementVehicle;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getPersonalItems() {
       return personalItems;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getReplacementOfKeys() {
       return replacementOfKeys;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getStandardExcess() {
       return standardExcess;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getStorage() {
       return storage;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getStorm() {
       return storm;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getTaxiFare() {
       return taxiFare;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getTemporaryCover() {
       return temporaryCover;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getTheft() {
       return theft;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getToolsOfTrade() {
       return toolsOfTrade;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getTowing() {
       return towing;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getTrailer() {
       return trailer;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getTsunami() {
       return tsunami;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getUninsuredMotoristDamage() {
       return uninsuredMotoristDamage;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getVandalism() {
       return vandalism;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public BasicCoverage getVehiclePickup() {
       return vehiclePickup;
    }
 

}