package au.com.iag.execution.complaintmanagementapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValidationMessagesItem{

	@JsonProperty("severity")
	private String severity;

	@JsonProperty("code")
	private String code;

	@JsonProperty("field")
	private String field;

	@JsonProperty("description")
	private String description;

	@JsonProperty("category")
	private String category;

	public String getSeverity(){
		return severity;
	}

	public String getCode(){
		return code;
	}

	public String getField(){
		return field;
	}

	public String getDescription(){
		return description;
	}

	public String getCategory(){
		return category;
	}
}
