package au.com.iag.execution.claimupdateapi.model.business;

import au.com.iag.execution.claimupdateapi.model.business.qapter.*;
import lombok.Data;

@Data
public class UpdateAssessment {
    private AssessmentDetails assessmentDetails;
    private Damage damageDetails;
    private Repair repairDetails;
    private TotalLoss totalLossDetails;
    private Vehicle vehicleDetails;

}
