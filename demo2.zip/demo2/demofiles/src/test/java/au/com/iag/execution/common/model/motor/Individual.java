package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Individual implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("addresses")
    private java.util.List<MailingAddress> addresses = new java.util.ArrayList<MailingAddress>();
    @JsonProperty("date_of_birth")
    private java.time.LocalDate dateOfBirth ;
    @JsonProperty("email_contacts")
    private EmailContacts emailContacts = new EmailContacts();
    @JsonProperty("gender")
    private String gender ;
    @JsonProperty("names")
    private IndividualNames names = new IndividualNames();
    @JsonProperty("party_id")
    private String partyId ;
    @JsonProperty("phone_contacts")
    private PhoneContacts phoneContacts = new PhoneContacts();
    @JsonProperty("preferences")
    private PreferenceDetails preferences = new PreferenceDetails();
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("registered_numbers")
    private java.util.List<RegisteredNumber> registeredNumbers = new java.util.ArrayList<RegisteredNumber>();
    @JsonProperty("temp_id")
    private String tempId ;

  
    @ApiModelProperty(
        value = "List of addresses of the individual",
        required = false
    )
    public java.util.List<MailingAddress> getAddresses() {
       return addresses;
    }
 
    @ApiModelProperty(
        value = "Date Of Birth of the Individual. [Constraint: &#x60;individual_date_of_birth&#x60;]",
        example = "1990-01-30",
        required = false
    )
    public java.time.LocalDate getDateOfBirth() {
       return dateOfBirth;
    }
 
    @ApiModelProperty(
        value = "Email contact details of the individual",
        required = false
    )
    public EmailContacts getEmailContacts() {
       return emailContacts;
    }
 
    @ApiModelProperty(
        value = "Gender of the Individual [Ref Data: individual_genders]",
        example = "FEMALE",
        required = false
    )
    public String getGender() {
       return gender;
    }
 
    @ApiModelProperty(
        value = "Name details of the individual",
        required = false
    )
    public IndividualNames getNames() {
       return names;
    }
 
    @ApiModelProperty(
        value = "Party identifier of this individual party. Identified customer party id has IAG recognised MDM party identifier. Anonymous customer party id prefixed with either TEMP or ANON",
        example = "IAG0000000461981234",
        required = false
    )
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Phone contact details",
        required = false
    )
    public PhoneContacts getPhoneContacts() {
       return phoneContacts;
    }
 
    @ApiModelProperty(
        value = "Marketing related preferences of the individual",
        required = false
    )
    public PreferenceDetails getPreferences() {
       return preferences;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "pc:581933",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "List of registered numbers for this individual",
        required = false
    )
    public java.util.List<RegisteredNumber> getRegisteredNumbers() {
       return registeredNumbers;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000333",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 

}