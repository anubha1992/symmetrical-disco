package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel(description = "Name information")
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Name implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getName() {
        return name;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public String getType() {
        return type;
    }


}