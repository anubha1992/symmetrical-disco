package au.com.iag.execution.common.model.huon;

import au.com.iag.execution.common.exception.*;
import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.*;
import com.jagacy.util.*;
import java.text.*;
import java.util.*;

public class SearchHuonPolicyCapture extends HuonCapturer {
    private ArrayList<String> huonPolicies = new ArrayList<String>();

    public SearchHuonPolicyCapture(HuonSession huon, String testcaseDir) throws JagacyException {
        super(huon, testcaseDir);
    }

    public SearchHuonPolicyCapture(String env, String testcaseDir) throws JagacyException, HuonException {
        super(env, testcaseDir);
    }

    public ArrayList<String> capture(String env, String productCode)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        if (!(productCode.equalsIgnoreCase("HOM") || productCode.equalsIgnoreCase("MOT")
                || productCode.equalsIgnoreCase("CTP") || productCode.equalsIgnoreCase("CVT")
                || productCode.equalsIgnoreCase("BOT") || productCode.equalsIgnoreCase("VVC"))) {
            throw new HuonException("Not a valid product code: " + productCode);
        }
        huon.gotoScreen("PP731");
        System.out.println("dump HUON PP731 screen --------------------------------------------");
        huon.printScreenshot();
//        System.out.println(huon.readScreenText());
        // huon.waitForScreen("HB0530");
        huon.input(4, 9, productCode);
        huon.eraseField(4, 21);
        huon.input(6, 15, "01/01/2018");
        huon.input(6, 29, "01/12/2019");
        huon.enter();
        System.out.println("dump HUON PP731 screen --------------------------------------------");
        huon.printScreenshot();
//        System.out.println(huon.readScreenText());

        if ((huon.readFromField(9, 9, 12).trim().isEmpty()) || (huon.readFromField(9, 9, 12).trim().length() <= 0)) {
            throw new HuonException("No policy exists in HUON for product code " + productCode);

        } else {
            for (int row = 9; row <= 22; row++) {
                if (!(huon.readFromField(row, 15, 23).trim().isEmpty()) || (!(huon.readFromField(row, 15, 23).trim().length() <= 0))) {
                    huonPolicies.add(productCode + huon.readFromField(row, 15, 23).trim());
                }

            }
        }
        return huonPolicies;
    }

    public static ArrayList<String> capturePolicies(String env, String productCode, String brand)
            throws JagacyException, HuonException, ParseException, InvalidDataException {

        HuonSession huon = new HuonSession(env);
        try {
            huon.open();
            SearchHuonPolicyCapture capturer = new SearchHuonPolicyCapture(huon, null);
            return capturer.capture(env, productCode);
        } finally {
            /*
             * Close the session if finished
             */
            try {
                huon.close();
            } catch (JagacyException ex) {
                if (huon != null) {
                    huon.abort();
                }
            }
        }
    }

    public static ArrayList<String> capturePolicies(HuonSession huon, String env, String productCode, String brand)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        try {
            huon.open();
            SearchHuonPolicyCapture capturer = new SearchHuonPolicyCapture(huon, null);
            return capturer.capture(env, productCode);
        } finally {
            /*
             * Close the session if finished
             */
            try {
                huon.close();
            } catch (JagacyException ex) {
                if (huon != null) {
                    huon.abort();
                }
            }
        }
    }

    public static Policy capturePolicyDetails(String env, String policyNumber)
            throws JagacyException, HuonException, ParseException, InvalidDataException {

        HuonSession huon = new HuonSession(env);
        try {
            huon.open();
            huon.printScreenshot();
            SearchHuonPolicyCapture capturer = new SearchHuonPolicyCapture(huon, null);
            Policy huonPolicy = new Policy(policyNumber);
            return capturer.capture(policyNumber, huonPolicy);
        } finally {
            /*
             * Close the session if finished
             */
            try {
                huon.close();
            } catch (JagacyException ex) {
                if (huon != null) {
                    huon.abort();
                }
            }
        }
    }

    public static Policy capturePolicyDetails(HuonSession huon, String env, String policyNumber)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        try {
            huon.open();
            huon.printScreenshot();
            SearchHuonPolicyCapture capturer = new SearchHuonPolicyCapture(huon, null);
            Policy huonPolicy = new Policy(policyNumber);
            return capturer.capture(policyNumber, huonPolicy);
        } finally {
            /*
             * Close the session if finished
             */
            try {
                huon.close();
            } catch (JagacyException ex) {
                if (huon != null) {
                    huon.abort();
                }
            }
        }
    }

    public static Policy capturePolicyAndCustomerDetailsForPolicy(HuonSession huon, String policyNumber)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        try {
            huon.open();
            huon.printScreenshot();
            SearchHuonPolicyCapture capturer = new SearchHuonPolicyCapture(huon, null);
            Policy huonPolicy = new Policy(policyNumber);
            huonPolicy = capturer.capture(policyNumber, huonPolicy);
            return capturer.captureCustomerDetailsForPolicyNumber(policyNumber, huonPolicy);
        } finally {
            /*
             * Close the session if finished
             */
            try {
                huon.close();
            } catch (JagacyException ex) {
                if (huon != null) {
                    huon.abort();
                }
            }
        }
    }

    public static HuonSession changeUserProfile(String env, String brand)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        HuonSession huon = new HuonSession(env);
        try {
            huon.open();
            huon.printScreenshot();
            huon.gotoScreen("HU000");
            System.out.println("dump HUON HU000 screen --------------------------------------------");
            huon.printScreenshot();
//        System.out.println(huon.readScreenText());
            // huon.waitForScreen("HB0530");
            huon.input(4, 12, "3");
            huon.input(5, 12, huon.getHuonUser());
            huon.printScreenshot();
            huon.enter();
            huon.printScreenshot();
            String company = huon.readFromField(7, 36, 38).trim();
            if (brand.equalsIgnoreCase("RACV")) {
                if (!(company.equalsIgnoreCase("300"))) {
                    huon.input(7, 36, "300");
                    huon.input(7, 48, "03");
                    huon.input(7, 60, "3000");
                    huon.input(7, 77, "7000");
                    huon.input(9, 20, "RACV");
                    huon.input(9, 60, "RACV");
                    huon.input(10, 20, "RACV");
                    huon.input(10, 60, "RACV");
                    huon.input(11, 20, "RACV");
                    huon.printScreenshot();
                    huon = saveHuonTransaction(huon);
                }
            } else if (brand.equalsIgnoreCase("NRMA")) {
                if (!(company.equalsIgnoreCase("100"))) {
                    huon.input(7, 36, "100");
                    huon.input(7, 48, "02");
                    huon.input(7, 60, "2000");
                    huon.input(7, 77, "9000");
                    huon.input(9, 20, "NRMA");
                    huon.input(9, 60, "NRMA");
                    huon.input(10, 20, "NRMA");
                    huon.input(10, 60, "NRMA");
                    huon.input(11, 20, "NRMA");
                    huon.printScreenshot();
                    huon = saveHuonTransaction(huon);
                }
            } else if (brand.equalsIgnoreCase("NZL")) {
                if (!(company.equalsIgnoreCase("064"))) {
                    huon.input(7, 36, "064");
                    huon.input(7, 48, "64");
                    huon.input(7, 60, "0001");
                    huon.input(7, 77, "0064");
                    huon.input(9, 20, "NZL");
                    huon.pressKey(Key.DELETE);
                    huon.input(9, 60, "NZL");
                    huon.pressKey(Key.DELETE);
                    huon.input(10, 20, "NZL");
                    huon.pressKey(Key.DELETE);
                    huon.input(10, 60, "NZL");
                    huon.pressKey(Key.DELETE);
                    huon.input(11, 20, "NZL");
                    huon.pressKey(Key.DELETE);
                    huon.printScreenshot();
                    huon = saveHuonTransaction(huon);
                }
            }
            return huon;
        } finally {
            /*
             * Close the session if finished
             */
            try {
                huon.close();
            } catch (JagacyException ex) {
                if (huon != null) {
                    huon.abort();
                }
            }
        }
    }

    public static HuonSession saveHuonTransaction(HuonSession huon)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        huon.enter();
        huon.printScreenshot();
        huon.gotoScreen("HZ965");
        huon.printScreenshot();
        huon.enter();
        huon.printScreenshot();
        huon.pressKey(Key.CLEAR);
        huon.printScreenshot();
        huon.input(1, 1, "HUON");
        return huon;
    }
}
