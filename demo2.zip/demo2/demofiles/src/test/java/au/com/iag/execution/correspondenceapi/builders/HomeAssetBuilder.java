package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.*;
import au.com.iag.glados.service.RandomContentService;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

@Component
public class HomeAssetBuilder {

    @Autowired private BaseRequestBuilder baseRequestBuilder;
    @Autowired private RandomContentService randomContentService;
    @Autowired private MiscDataBuilder miscDataBuilder;

    public List<HomeAsset> buildHomeAssets(PolicyCorrespondence policyCorrespondence, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec){
        final int maxCoverables = baseRequestBuilder.getMax(listOfCoverableToPartyRoleSpec);
        List<HomeAsset> listOfHomeAssets = new ArrayList<>();
        IntStream.range(0, maxCoverables+1).forEachOrdered(assetIndex -> {
            HomeAsset homeAsset = getHomeAsset(policyCorrespondence);
            HomeAssetParty homeAssetParty = new HomeAssetParty();

            List<AssetPartyRole> listOfAssetPartyRoles = new ArrayList<>();
            listOfCoverableToPartyRoleSpec.forEach(coverableToPartyRoleSpec -> {
                Map<Integer, List<String>> mapOfAssetIndexToAssetLevelRoles = coverableToPartyRoleSpec.getMapOfAssetIndexToAssetLevelRoles();
                if(mapOfAssetIndexToAssetLevelRoles != null) {
                    List<String> listOfAssetRoles = mapOfAssetIndexToAssetLevelRoles.get(assetIndex);
                    if(listOfAssetRoles != null) {
                        listOfAssetRoles.forEach(assetRole -> {
                            AssetPartyRole assetPartyRole = new AssetPartyRole();
                            assetPartyRole.setPartyId(coverableToPartyRoleSpec.getPartyId());
                            assetPartyRole.setRole(assetRole);
                            listOfAssetPartyRoles.add(assetPartyRole);
                        });
                    }
                }
            });
            List<HomeAsset> listOfHomeAssetsFromConfig = policyCorrespondence.getPolicyDetails().getAssets().getHomeAssets();
            homeAssetParty.setPartyRoles((listOfHomeAssetsFromConfig !=null
                    && listOfHomeAssetsFromConfig.get(0).getParties() != null
                    && listOfHomeAssetsFromConfig.get(0).getParties().getPartyRoles() !=null )?listOfAssetPartyRoles:null);
            homeAsset.setParties((listOfHomeAssetsFromConfig !=null && listOfHomeAssetsFromConfig.get(0).getParties() !=null )?homeAssetParty:null);
            listOfHomeAssets.add(homeAsset);
        });
        return listOfHomeAssets;
    }

    public ExcessDetails getExcessDetails(List<String> listOfExcessTypes){
        return getExcessDetails(listOfExcessTypes, miscDataBuilder.getDouble(500, 1000));
    }

    public ExcessDetails getExcessDetails(List<String> listOfExcessTypes, Double excessAmount){
        ExcessDetails excessDetails = new ExcessDetails();
        List<Excess> listOfExcess = null;
        if(listOfExcessTypes != null) {
            listOfExcess = new ArrayList<>();
            for (String excessType : listOfExcessTypes) {
                Excess excess = new Excess();
                excess.setAmount(excessAmount);
                excess.setType(excessType);
                listOfExcess.add(excess);
            }
        }
        excessDetails.setExcesses(listOfExcess);
        excessDetails.setTotalExcess(listOfExcess==null?0.0:listOfExcess.stream().mapToDouble(Excess::getAmount).sum());
        return excessDetails;
    }

    private HomeAsset getHomeAsset(PolicyCorrespondence policyCorrespondence){
        HomeAsset homeAsset = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getAssets().getHomeAssets().get(0));
        homeAsset.setAssetNumber(homeAsset.getAssetNumber()!=null?randomContentService.getRandomNumber(11):null);
        return homeAsset;
    }
}
