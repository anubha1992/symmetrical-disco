package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class StatusHistoryItem implements Serializable {

	@JsonProperty("timeAddedDb")
	private String timeAddedDb;

	@JsonProperty("statusReasonCode")
	private String statusReasonCode;

	@JsonProperty("timeLastUpdated")
	private String timeLastUpdated;

	@JsonProperty("userId")
	private String userId;

	@JsonProperty("statusCode")
	private String statusCode;

	public void setTimeAddedDb(String timeAddedDb){
		this.timeAddedDb = timeAddedDb;
	}

	public String getTimeAddedDb(){
		return timeAddedDb;
	}

	public void setStatusReasonCode(String statusReasonCode){
		this.statusReasonCode = statusReasonCode;
	}

	public String getStatusReasonCode(){
		return statusReasonCode;
	}

	public void setTimeLastUpdated(String timeLastUpdated){
		this.timeLastUpdated = timeLastUpdated;
	}

	public String getTimeLastUpdated(){
		return timeLastUpdated;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return userId;
	}

	public void setStatusCode(String statusCode){
		this.statusCode = statusCode;
	}

	public String getStatusCode(){
		return statusCode;
	}

	@Override
 	public String toString(){
		return 
			"StatusHistoryItem{" + 
			"timeAddedDb = '" + timeAddedDb + '\'' + 
			",statusReasonCode = '" + statusReasonCode + '\'' + 
			",timeLastUpdated = '" + timeLastUpdated + '\'' + 
			",userId = '" + userId + '\'' + 
			",statusCode = '" + statusCode + '\'' + 
			"}";
		}
}