package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains details for the quote and policy")
public class PolicyDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("assets")
    private AssetGroup assets = new AssetGroup();
    @JsonProperty("brand")
    private String brand ;
    @JsonProperty("correspondence_preferences")
    private CorrespondencePreference correspondencePreferences = new CorrespondencePreference();
    @JsonProperty("currency")
    private String currency ;
    @JsonProperty("discounts")
    private PolicyDiscounts discounts = new PolicyDiscounts();
    @JsonProperty("distribution_channel")
    private String distributionChannel ;
    @JsonProperty("manufacturer")
    private Manufacturer manufacturer = new Manufacturer();
    @JsonProperty("parties")
    private Parties parties = new Parties();
    @JsonProperty("payments")
    private PaymentDetails payments = new PaymentDetails();
    @JsonProperty("policy_dates")
    private PolicyDates policyDates = new PolicyDates();
    @JsonProperty("policy_history")
    private PolicyHistory policyHistory = new PolicyHistory();
    @JsonProperty("policy_number")
    private String policyNumber ;
    @JsonProperty("portfolio")
    private String portfolio ;
    @JsonProperty("product")
    private String product ;
    @JsonProperty("status")
    private String status ;
    @JsonProperty("terms_condition_agreement")
    private Boolean termsConditionAgreement ;
    @JsonProperty("transaction_reason")
    private String transactionReason ;
    @JsonProperty("transaction_type")
    private String transactionType ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "List of assets for this policy",
        required = false
    )
    public AssetGroup getAssets() {
       return assets;
    }
 
    @ApiModelProperty(
        value = "The policy brand. [Ref Data: brands]",
        example = "CGU",
        required = false
    )
    public String getBrand() {
       return brand;
    }
 
    @ApiModelProperty(
        value = "Correspondence preference details",
        required = false
    )
    public CorrespondencePreference getCorrespondencePreferences() {
       return correspondencePreferences;
    }
 
    @ApiModelProperty(
        value = "The currency applicable for all amount values on the policy. [Ref Data: currency]",
        example = "AUD",
        required = false
    )
    public String getCurrency() {
       return currency;
    }
 
    @ApiModelProperty(
        value = "Loyalty discount details",
        required = false
    )
    public PolicyDiscounts getDiscounts() {
       return discounts;
    }
 
    @ApiModelProperty(
        value = "Policy distribution channel. [Ref Data: distribution_channel]",
        example = "DIRECT",
        required = false
    )
    public String getDistributionChannel() {
       return distributionChannel;
    }
 
    @ApiModelProperty(
        value = "Manufacturer details",
        required = false
    )
    public Manufacturer getManufacturer() {
       return manufacturer;
    }
 
    @ApiModelProperty(
        value = "List of parties for this policy",
        required = false
    )
    public Parties getParties() {
       return parties;
    }
 
    @ApiModelProperty(
        value = "Payment details of the policy",
        required = false
    )
    public PaymentDetails getPayments() {
       return payments;
    }
 
    @ApiModelProperty(
        value = "Policy dates",
        required = false
    )
    public PolicyDates getPolicyDates() {
       return policyDates;
    }
 
    @ApiModelProperty(
        value = "The policy history details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public PolicyHistory getPolicyHistory() {
       return policyHistory;
    }
 
    @ApiModelProperty(
        value = "Quote number or Policy number",
        example = "QTE1234567",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getPolicyNumber() {
       return policyNumber;
    }
 
    @ApiModelProperty(
        value = "The Portfolio this product is part of. [Ref Data: portfolio]",
        example = "CONSUMER",
        required = false
    )
    public String getPortfolio() {
       return portfolio;
    }
 
    @ApiModelProperty(
        value = "Product - MOTOR_INSURANCE, HOME_INSURANCE etc. [Ref Data: product]",
        example = "MOTOR_INSURANCE",
        required = false
    )
    public String getProduct() {
       return product;
    }
 
    @ApiModelProperty(
        value = "Status of the business entity. [Ref Data: quote_status, policy_status]",
        example = "DRAFT",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getStatus() {
       return status;
    }
 
    @ApiModelProperty(
        value = "Indicates the customer agreement to terms and conditions. True - customer agrees. False - customer disagrees",
        example = "true",
        required = false
    )
    public Boolean getTermsConditionAgreement() {
       return termsConditionAgreement;
    }
 
    @ApiModelProperty(
        value = "Transaction reason code or description",
        required = false
    )
    public String getTransactionReason() {
       return transactionReason;
    }
 
    @ApiModelProperty(
        value = "The transaction type of the business entity. [Ref Data: transaction_type]",
        example = "RENEWAL",
        required = false
    )
    public String getTransactionType() {
       return transactionType;
    }
 
    @ApiModelProperty(
        value = "The business entity type. [Ref Data: business_type]",
        example = "QUOTE",
        required = false
    )
    public String getType() {
       return type;
    }
 

}