package au.com.iag.execution.claimdetailsapi.model.business;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class DateRange implements Serializable {

    private static final long serialVersionUID = 1L;

    private String fromDate;
    private String toDate;

//    @NotNull
//    @JsonSerialize(using = CustomDateSerializer.class)
//    @JsonDeserialize(using = CustomDateDeserializer.class)
//    @ApiModelProperty(example = "2017-07-20T12:00:00", required = false)
//    @JsonFormat(pattern = DATE_TIME_FORMAT)
    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

//    @NotNull
//    @JsonSerialize(using = CustomDateSerializer.class)
//    @JsonDeserialize(using = CustomDateDeserializer.class)
//    @ApiModelProperty(example = "2017-07-20T12:00:00", required = false)
//    @JsonFormat(pattern = DATE_TIME_FORMAT)
    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
}
