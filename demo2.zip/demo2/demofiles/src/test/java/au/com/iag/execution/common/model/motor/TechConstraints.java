package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Field value technical validation")
public class TechConstraints implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("data_format")
    private String dataFormat ;
    @JsonProperty("data_type")
    private String dataType ;
    @JsonProperty("read_only")
    private Boolean readOnly ;

  
    @ApiModelProperty(
        value = "Optional. The syntax / format the field&#x27;s value must match. Expressed as a regular expression.",
        required = false
    )
    public String getDataFormat() {
       return dataFormat;
    }
 
    @ApiModelProperty(
        value = "The primitive field data type. E.g. integer, string, date-time, etc.",
        required = false
    )
    public String getDataType() {
       return dataType;
    }
 
    @ApiModelProperty(
        value = "Optional. Defines if the field is read only for the Consumer/User. Default&#x3D;false.",
        required = false
    )
    public Boolean getReadOnly() {
       return readOnly;
    }
 

}