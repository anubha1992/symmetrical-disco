package au.com.iag.execution.common.security.okta.token.teardown;

import au.com.iag.execution.common.listofbusiness.service.ListOfBusinessService;
import au.com.iag.execution.common.notify.builders.PolicyContractUpdateBuilder;
import au.com.iag.execution.common.notify.service.NotifyService;
import au.com.iag.execution.notifyapi.model.business.HomeAsset;
import au.com.iag.execution.notifyapi.model.business.Policy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;

import static au.com.iag.execution.common.security.okta.token.teardown.PolicyPurgeParams.*;

@Component
public class PolicyPurgeService {

    @Autowired private PolicyContractUpdateBuilder policyContractUpdateBuilder;

    @Autowired private ListOfBusinessService listOfBusinessService;
    @Autowired private NotifyService notifyService;

    public void purgeMotorPolicy(Map<String, String> policyPurgeParams) throws IOException {
        final String policyNumber = policyPurgeParams.get(POLICY_NUMBER.getValue());
        final String partyId = policyPurgeParams.get(PARTY_ID.getValue());
        final String brand = policyPurgeParams.get(BRAND.getValue());
        final String status = "EXPIRED";
        final String type = policyPurgeParams.get(TYPE.getValue());

        final String assetNumber = listOfBusinessService.getListOfBusiness(partyId).getPolicyDetails()
                .stream()
                .filter(policyDetails -> policyDetails.getPolicyNumber().equals(policyNumber))
                .map(policyDetails -> policyDetails.getAssets().getVehicleAssets().stream().findFirst().get().getAssetNumber())
                .findFirst()
                .get();

        Policy motor = policyContractUpdateBuilder.buildPurgePolicyRequest("motor");
        motor.getAssets().getVehicleAssets().stream().findFirst().get().setAssetNumber(assetNumber);
        motor.getAssets().getVehicleAssets().stream().findFirst().get()
                .getParties().getPartyRoles().stream().findFirst().get().setPartyId(partyId);

        motor.setBrand(brand);
        motor.setPolicyNumber(policyNumber);
        motor.setStatus(status);
        motor.setType(type);

        motor.getParties().getIndividuals().stream().findFirst().get().setPartyId(partyId);
        motor.getParties().getPartyRoles().stream().findFirst().get().setPartyId(partyId);

        notifyService.notifyPolicyUpdate(motor);
    }

    public void purgeHomePolicy(Map<String, String> policyPurgeParams) throws IOException {
        final String policyNumber = policyPurgeParams.get(POLICY_NUMBER.getValue());
        final String partyId = policyPurgeParams.get(PARTY_ID.getValue());
        final String brand = policyPurgeParams.get(BRAND.getValue());
        final String status = "EXPIRED";
        final String type = policyPurgeParams.get(TYPE.getValue());

        final String assetNumber = listOfBusinessService.getListOfBusiness(partyId).getPolicyDetails()
                .stream()
                .filter(policyDetails -> policyDetails.getPolicyNumber().equals(policyNumber))
                .map(policyDetails -> policyDetails.getAssets().getHomeAssets().stream().findFirst().get().getAssetNumber())
                .findFirst()
                .get();

        Policy home = policyContractUpdateBuilder.buildPurgePolicyRequest("home");
        home.getAssets().getHomeAssets().stream().findFirst().get().setAssetNumber(assetNumber);

        home.setBrand(brand);
        home.setPolicyNumber(policyNumber);
        home.setStatus(status);
        home.setType(type);

        home.getParties().getIndividuals().stream().findFirst().get().setPartyId(partyId);
        home.getParties().getPartyRoles().stream().findFirst().get().setPartyId(partyId);

        notifyService.notifyPolicyUpdate(home);
    }
}
