package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.CorrespondenceParties;
import au.com.iag.execution.correspondenceapi.model.business.Parties;
import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.RandomContentService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class MotorCorrespondenceRequestBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private PartyBuilder partyBuilder;
    @Autowired private MotorAssetBuilder motorAssetBuilder;
    @Autowired private PolicyDatesBuilder policyDatesBuilder;
    @Autowired private RandomContentService randomContentService;
    @Autowired private BaseRequestBuilder baseRequestBuilder;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private PolicyBuilder policyBuilder;

    public PolicyCorrespondence getMotorCorrespondenceRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = readMotorCorrespondenceFromConfig(correspondenceType);
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Vehicle Assets
        policyCorrespondence.getPolicyDetails().getAssets()
                .setVehicleAssets(motorAssetBuilder.buildVehicleAssets(policyCorrespondence, listOfCoverableToPartyRoleSpec));
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        //Build Policy dates
        policyCorrespondence.getPolicyDetails().setPolicyDates(policyDatesBuilder.getPolicyDates());
        //Update PartyId of history disclosures
        partyBuilder.updatePartyIdOnIncidentsOrClaims(policyCorrespondence);
        //Update policy type
        policyBuilder.updatePolicyCorrespondenceByType(correspondenceType, policyCorrespondence);
        return policyCorrespondence;
    }

    public PolicyCorrespondence getMotorCoCRequest(String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getMotorCoCRequestFromConfig();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Vehicle Assets
        policyCorrespondence.getPolicyDetails().getAssets()
                .setVehicleAssets(motorAssetBuilder.buildVehicleAssets(policyCorrespondence, listOfCoverableToPartyRoleSpec));
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    public PolicyCorrespondence getMotorCoCRequestFromConfig() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/cocMotor.json"), PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getMotorAnonymousQuoteRequest(String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getMotorAnonymousQuoteRequestFromConfig();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Vehicle Assets
        policyCorrespondence.getPolicyDetails().getAssets()
                .setVehicleAssets(motorAssetBuilder.buildVehicleAssets(policyCorrespondence, listOfCoverableToPartyRoleSpec));
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        return policyCorrespondence;
    }

    public PolicyCorrespondence getMotorAnonymousQuoteRequestFromConfig() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/policyCorrespondenceMotorAnonymousQuote.json"), PolicyCorrespondence.class);
    }

    private PolicyCorrespondence readMotorCorrespondenceFromConfig(final String correspondenceType) throws IOException{
        switch (correspondenceType){
            case CORRESPONDENCE_TYPE_NEW_BUSINESS:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceMotorNewBusiness.json")
                                , PolicyCorrespondence.class);
            case CORRESPONDENCE_TYPE_RENEWAL:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceMotorRenewal.json")
                                , PolicyCorrespondence.class);
            case CORRESPONDENCE_TYPE_AMENDMENT:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceMotorAmendment.json")
                                , PolicyCorrespondence.class);
            default:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceMotorQuotation.json")
                                , PolicyCorrespondence.class);
        }
    }
}
