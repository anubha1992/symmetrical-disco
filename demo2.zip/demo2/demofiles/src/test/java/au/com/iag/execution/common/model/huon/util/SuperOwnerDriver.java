package au.com.iag.execution.common.model.huon.util;

import java.lang.reflect.*;

public class SuperOwnerDriver {
    protected boolean existingCustomers = false;
    protected boolean anonymous = false;
    protected Customer customer = new Customer();
//	protected CustomerRole customerRole = new CustomerRole(); //throws InvalidDataException;

    /*
     * Only used by web for unmatched
     */
    protected int YOR = 0;
    protected int PC = 0;


    public SuperOwnerDriver(boolean existingCustomer, Customer customer) {
        this.existingCustomers = existingCustomer;
        this.customer = customer;
    }

    public SuperOwnerDriver(String state, String customerType) {
        this.customer = new Customer(state, customerType);
    }

    public boolean isExistingCustomers() {
        return existingCustomers;
    }

    public void setExistingCustomers(boolean existingCustomers) {
        this.existingCustomers = existingCustomers;
        if (existingCustomers)
            this.anonymous = false;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
        if (anonymous)
            this.existingCustomers = false;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public int getYOR() {
        return YOR;
    }

    public String getYORString() {
        return Integer.toString(YOR).trim();
    }

    public void setYOR(int yOR) {
        this.YOR = yOR;
    }

    public void setYOR(String yOR) {
        if (yOR.isEmpty())
            this.YOR = 0;
        else
            this.YOR = Integer.parseInt(yOR);
    }

    public int getPC() {
        return PC;
    }

    public String getPCString() {
        return Integer.toString(PC).trim();
    }

    public void setPC(int pC) {
        this.PC = pC;
    }

    public void setPC(String PC) {
        if (PC.isEmpty())
            this.PC = 0;
        else
            this.PC = Integer.parseInt(PC);
    }

    //Chetan added new line of code
    public Customer getRole() {
        return customer;
    }

    public void setRole(Customer customer) {
        this.customer = customer;
    }


    /**
     * Get the owner/driver matched information: Matched, Unmatched, Anonymous
     *
     * @return
     */
    public String getMatchedInfo() {
        String matched = "";

        if (this.anonymous)
            matched = "Anonymous";
        else if (this.existingCustomers)
            matched = "Matched";
        else
            matched = "Unmatched";

        return matched;
    }

    public void copy(SuperOwnerDriver ownerDriver) throws IllegalArgumentException, IllegalAccessException {
        Class<?> thisClass = this.getClass();
        String thisName = SuperOwnerDriver.class.getName();
        while (!thisClass.getName().equalsIgnoreCase(thisName)) {
            thisClass = thisClass.getSuperclass();
        }
        Class<?> thatClass = ownerDriver.getClass();
        while (!thatClass.getName().equalsIgnoreCase(thisName)) {
            thatClass = thatClass.getSuperclass();
        }
        Field[] thisFields = thisClass.getDeclaredFields();
        Field[] thatFields = thatClass.getDeclaredFields();
        for (int i = 0; i < thisFields.length; i++) {
            if (Modifier.isStatic(thisFields[i].getModifiers()))
                continue;
            if (thisFields[i].getType().getName().contains("Customer"))
                continue;
            thisFields[i].setAccessible(true);
            thatFields[i].setAccessible(true);
            thisFields[i].set(this, thatFields[i].get(ownerDriver));
        }

        customer.copy(ownerDriver.customer);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        Class<?> myClass = this.getClass();
        String thisName = SuperOwnerDriver.class.getName();
        while (!myClass.getName().equalsIgnoreCase(thisName)) {
            myClass = myClass.getSuperclass();
        }

        try {
            Field[] fields = myClass.getDeclaredFields();
            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers()))
                    continue;
                if (field.getName().startsWith("this"))
                    continue;
                if (field.getName().equalsIgnoreCase("customer"))
                    continue;
                sb.append(field.getName());
                sb.append("=");
                sb.append(field.get(this));
                sb.append("; ");
            }
        } catch (IllegalAccessException iae) {

        }

        sb.append(customer.toString());

        sb.replace(sb.length() - 1, sb.length(), "");
        return sb.toString();
    }


}
