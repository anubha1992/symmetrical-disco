package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class EmailContacts implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("emails")
    private java.util.List<Email> emails = new java.util.ArrayList<Email>();

  
    @ApiModelProperty(
        value = "List of emails",
        required = false
    )
    public java.util.List<Email> getEmails() {
       return emails;
    }
 

}