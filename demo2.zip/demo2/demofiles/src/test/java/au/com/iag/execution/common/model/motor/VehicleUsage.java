package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleUsage implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("activities")
    private java.util.List<String> activities = new java.util.ArrayList<String>();
    @JsonProperty("annual_kilometres_range")
    private String annualKilometresRange ;
    @JsonProperty("ride_share_and_food_delivery_hours_per_week")
    private Integer rideShareAndFoodDeliveryHoursPerWeek ;

  
    @ApiModelProperty(
        value = "Vehicle usage activity code. [Ref Data: vehicle_usage]",
        example = "[&quot;RIDE_SHARE&quot;,&quot;TAXI_OR_PEOPLE_TRANSPORTATION&quot;]",
        required = false
    )
    public java.util.List<String> getActivities() {
       return activities;
    }
 
    @ApiModelProperty(
        value = "Number of annual kilometres run by this vehicle. [Ref Data: annual_kilometres]",
        example = "GREATER_THAN_15K_LESS_THAN_20K",
        required = false
    )
    public String getAnnualKilometresRange() {
       return annualKilometresRange;
    }
 
    @ApiModelProperty(
        value = "Number of hours per week the vehicle is used for ride share.",
        example = "20",
        required = false
    )
    public Integer getRideShareAndFoodDeliveryHoursPerWeek() {
       return rideShareAndFoodDeliveryHoursPerWeek;
    }
 

}