package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleExternalReferences implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("reference_id")
    private String referenceId ;
    @JsonProperty("reference_type")
    private String referenceType ;

  
    @ApiModelProperty(
        value = "Reference Id from external data provider e.g. Glasses or Redbook",
        required = false
    )
    public String getReferenceId() {
       return referenceId;
    }
 
    @ApiModelProperty(
        value = "Reference type of external data provider e.g. Glasses or Redbook",
        required = false
    )
    public String getReferenceType() {
       return referenceType;
    }
 

}