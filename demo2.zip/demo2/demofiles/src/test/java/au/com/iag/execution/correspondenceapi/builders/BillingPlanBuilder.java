package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.*;
import au.com.iag.glados.service.RandomContentService;
import com.github.javafaker.Faker;
import org.apache.commons.lang3.SerializationUtils;
import org.junit.jupiter.params.provider.Arguments;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Stream;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class BillingPlanBuilder {

    @Autowired private MiscDataBuilder miscDataBuilder;
    @Autowired private RandomContentService randomContentService;
    private static final Random RANDOM = new Random();

    public PaymentDetails getPaymentDetails(PolicyCorrespondence policyCorrespondence, String correspondenceType, String billingPlan, String howToPay){
        double annualPremium = miscDataBuilder.formatDouble(1000 + RANDOM.nextDouble() * (2000 - 1000));
        double installment = getInstallment(billingPlan, annualPremium);
        double firstInstallment = miscDataBuilder.formatDouble(installment+installment*(0.0002));
        LocalDate firstPaymentDueOn = LocalDate.now();
        PaymentDetails paymentDetails = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getPayments());//new PaymentDetails();
        paymentDetails.setBillingFrequency(billingPlan);
        paymentDetails.getPaymentInstruments().setBpayDetails(getBpay());
        paymentDetails.getPaymentSummary().getFirstPaymentDetails().setAmount(firstInstallment);
        paymentDetails.getPaymentSummary().getFirstPaymentDetails().setDueDate(firstPaymentDueOn);
        paymentDetails.getPaymentSummary().setPremiumPaidDate(null);
        paymentDetails.getPaymentInstruments().setPostBillDetails(getPostBill());
        paymentDetails.setPaymentMethod(PAYMENT_METHOD_CREDIT_CARD);
        paymentDetails.setBillingPlanOptions(getBillingPlanOptions(correspondenceType, billingPlan, annualPremium));
        if(BILLING_PLAN_ANNUAL.equals(billingPlan) && PAYMENT_METHOD_PAY_NOW.equals(howToPay)){
            paymentDetails.setDirectDebit(false);
            paymentDetails.getPaymentSummary().setPaymentStatus(PAYMENT_STATUS_PAID);
            paymentDetails.getPaymentSummary().setPremiumPaidDate(LocalDate.now());
            paymentDetails.getPaymentSummary().getNextPaymentDetails().setAmount(null);
            paymentDetails.getPaymentSummary().getNextPaymentDetails().setDueDate(null);
            paymentDetails.getBillingPlanOptions().forEach(billingPlanOptions -> billingPlanOptions.setInstalments(null));
        }
        else {
            paymentDetails.setDirectDebit(true);
            paymentDetails.getPaymentSummary().setPaymentStatus(PAYMENT_STATUS_UNPAID);
            paymentDetails.getPaymentSummary().getNextPaymentDetails().setAmount(BILLING_PLAN_ANNUAL.equals(billingPlan)?0.0:installment);
            paymentDetails.getPaymentSummary().getNextPaymentDetails().setDueDate(getNextPaymentDueDate(billingPlan, firstPaymentDueOn));
        }
        return paymentDetails;
    }

    public PremiumDetails getPremiumDetails(double annualTotalPremium, String billingPlan) {
        return getPremiumDetails(annualTotalPremium, billingPlan, false);
    }

    public PremiumDetails getPremiumDetailsOnlyWithTotal(double annualTotalPremium, String billingPlan) {
        return getPremiumDetails(annualTotalPremium, billingPlan, true);
    }

    public List<InstalmentDetails> buildListOfInstalmentDetails(String billingPlan, PremiumDetails premiumDetails){
        List<InstalmentDetails> listOfInstalmentDetails;
        switch (billingPlan){
            case BILLING_PLAN_ANNUAL:
                listOfInstalmentDetails = getListOfInstallments(billingPlan, premiumDetails, 1);
                break;
            case BILLING_PLAN_QUARTERLY:
                listOfInstalmentDetails = getListOfInstallments(billingPlan, premiumDetails, 4);
                break;
            case BILLING_PLAN_MONTHLY:
                listOfInstalmentDetails = getListOfInstallments(billingPlan, premiumDetails, 12);
                break;
            case BILLING_PLAN_FORTNIGHTLY:
                listOfInstalmentDetails = getListOfInstallments(billingPlan, premiumDetails, 26);
                break;
            default:
                throw new IllegalArgumentException("Invalid Billing plan - "+billingPlan);
        }
        return listOfInstalmentDetails;
    }

    public Stream<Arguments> getSupportedBillingPlans() {
        List<String> listOfExpectedBillingPlanOptions = Arrays.asList(BILLING_PLAN_ANNUAL, BILLING_PLAN_FORTNIGHTLY, BILLING_PLAN_MONTHLY, BILLING_PLAN_QUARTERLY);
        return Stream.of(
                Arguments.of(listOfExpectedBillingPlanOptions.get(0), PAYMENT_METHOD_PAY_NOW, PAYMENT_METHOD_CREDIT_CARD),
                Arguments.of(listOfExpectedBillingPlanOptions.get(0), PAYMENT_METHOD_DIRECT_DEBIT, PAYMENT_METHOD_CREDIT_CARD),
                Arguments.of(listOfExpectedBillingPlanOptions.get(1), PAYMENT_METHOD_DIRECT_DEBIT, PAYMENT_METHOD_CREDIT_CARD),
                Arguments.of(listOfExpectedBillingPlanOptions.get(2), PAYMENT_METHOD_DIRECT_DEBIT, PAYMENT_METHOD_CREDIT_CARD),
                Arguments.of(listOfExpectedBillingPlanOptions.get(3), PAYMENT_METHOD_DIRECT_DEBIT, PAYMENT_METHOD_CREDIT_CARD)
        );
    }

    private Bpay getBpay(){
        Bpay bpay = new Bpay();
        bpay.setBillerCode(Integer.toString(randomContentService.getRandomNumber(20000, 90000)));
        bpay.setBillerReference(Long.toString(System.currentTimeMillis()));
        return bpay;
    }

    private PostBill getPostBill(){
        Faker fakerAusLocale = miscDataBuilder.getFakerWithAusLocale();
        PostBill postBill = new PostBill();
        postBill.setBarcode(fakerAusLocale.code().ean13());
        postBill.setPayCode(fakerAusLocale.code().gtin13());
        postBill.setProductNumber(fakerAusLocale.code().imei());
        return postBill;
    }

    private List<BillingPlanOptions> getBillingPlanOptions(String correspondenceType, String billingPlan, double annualPremium){
        if(CORRESPONDENCE_TYPE_QUOTATION.equals(correspondenceType)) {
            return Arrays.asList(getBillingPlanOptions(annualPremium, BILLING_PLAN_ANNUAL)
                    , getBillingPlanOptions(annualPremium, BILLING_PLAN_QUARTERLY)
                    , getBillingPlanOptions(annualPremium, BILLING_PLAN_MONTHLY)
                    , getBillingPlanOptions(annualPremium, BILLING_PLAN_FORTNIGHTLY)
            );
        }
        else {
            return Collections.singletonList(getBillingPlanOptions(annualPremium, billingPlan));
        }
    }

    private LocalDate getNextPaymentDueDate(String billingPlan, LocalDate firstPaymentDueOn){
        LocalDate nextPaymentDueOn;
        switch (billingPlan){
            case BILLING_PLAN_ANNUAL:
                nextPaymentDueOn = firstPaymentDueOn.plusYears(1);
                break;
            case BILLING_PLAN_QUARTERLY:
                nextPaymentDueOn = firstPaymentDueOn.plusMonths(3);
                break;
            case BILLING_PLAN_HALF_YEARLY:
                nextPaymentDueOn = firstPaymentDueOn.plusMonths(6);
                break;
            case BILLING_PLAN_MONTHLY:
                nextPaymentDueOn = firstPaymentDueOn.plusMonths(1);
                break;
            case BILLING_PLAN_FORTNIGHTLY:
                nextPaymentDueOn = firstPaymentDueOn.plusWeeks(2);
                break;
            case "NOT_APPLICABLE":
                nextPaymentDueOn = firstPaymentDueOn.plusWeeks(1);
                break;
            default:
                throw new IllegalArgumentException("Invalid Billing plan - "+billingPlan);
        }
        return nextPaymentDueOn;
    }

    private double getInstallment(String billingPlan, double annualPremium){
        double firstInstallment;
        switch (billingPlan){
            case BILLING_PLAN_ANNUAL:
                firstInstallment = annualPremium;
                break;
            case BILLING_PLAN_QUARTERLY:
                firstInstallment = annualPremium/4;
                break;
            case BILLING_PLAN_HALF_YEARLY:
                firstInstallment = annualPremium/2;
                break;
            case BILLING_PLAN_MONTHLY:
                firstInstallment = annualPremium/12;
                break;
            case BILLING_PLAN_FORTNIGHTLY:
                firstInstallment = annualPremium/26;
                break;
            case "NOT_APPLICABLE":
                //Weekly payments
                firstInstallment = annualPremium/52;
                break;
            default:
                throw new IllegalArgumentException("Invalid Billing plan - "+billingPlan);
        }
        return firstInstallment+(firstInstallment*0.1);
    }

    private BillingPlanOptions getBillingPlanOptions(double annualTotalPremium, String billingPlan){
        BillingPlanOptions billingPlanOptions = new BillingPlanOptions();
        billingPlanOptions.setBillingFrequency(billingPlan);
        PremiumDetails premiumDetails = getPremiumDetails(annualTotalPremium, billingPlan);
        billingPlanOptions.setAggregatePremiumDetails(premiumDetails);
        billingPlanOptions.setInstalments(buildListOfInstalmentDetails(billingPlan, premiumDetails));
        return billingPlanOptions;
    }

    private List<InstalmentDetails> getListOfInstallments(String billingPlan, PremiumDetails premiumDetails, int numberOfInstallments){
        List<InstalmentDetails> listOfInstalmentDetails = new ArrayList<>();
        for(int i=1; i<=numberOfInstallments; i++){
            InstalmentDetails instalmentDetails = getInstalmentDetails(billingPlan, premiumDetails, i);
            listOfInstalmentDetails.add(instalmentDetails);
        }
        return listOfInstalmentDetails;
    }

    private InstalmentDetails getInstalmentDetails(String billingPlan, PremiumDetails premiumDetails, int installmenetNumber) {
        InstalmentDetails instalmentDetails = new InstalmentDetails();
        instalmentDetails.setAmount(miscDataBuilder.formatDouble(premiumDetails.getBasePremium()));
        LocalDate localDate = LocalDate.now();
        switch (billingPlan){
            case BILLING_PLAN_ANNUAL:
                localDate = localDate.plusYears(installmenetNumber);
                break;
            case BILLING_PLAN_QUARTERLY:
                localDate = localDate.plusMonths(3 * installmenetNumber);
                break;
            case BILLING_PLAN_MONTHLY:
                localDate = localDate.plusMonths(installmenetNumber);
                break;
            case BILLING_PLAN_FORTNIGHTLY:
                localDate = localDate.plusWeeks(2 * installmenetNumber);
                break;
            default:
                throw new IllegalArgumentException("Invalid Billing plan - "+billingPlan);
        }
        instalmentDetails.setDueDate(localDate);
        instalmentDetails.setNumber(BILLING_PLAN_ANNUAL.equals(billingPlan)?"2":"1");
        instalmentDetails.setPremiumDetails(Collections.singletonList(premiumDetails));
        return instalmentDetails;
    }

    private PremiumDetails getPremiumDetails(double annualTotalPremium, String billingPlan, boolean onlyTotalPremium) {
        double premiumForBillingPlan = miscDataBuilder.formatDouble(getInstallment(billingPlan, annualTotalPremium));
        double esl = miscDataBuilder.formatDouble(premiumForBillingPlan*(5.5/100));
        double gst = miscDataBuilder.formatDouble(premiumForBillingPlan*(5.5/100));
        double stampDuty = miscDataBuilder.formatDouble(premiumForBillingPlan*(2.1/100));
        double netAmount = miscDataBuilder.formatDouble(premiumForBillingPlan-(esl+gst+stampDuty));
        PremiumDetails premiumDetails = new PremiumDetails();
        if(onlyTotalPremium){
            premiumDetails.setTotalPremium(netAmount);
        }
        else {
            premiumDetails.setBasePremium(premiumForBillingPlan - 2);
            premiumDetails.setEsl(esl);
            premiumDetails.setTotalPremium(premiumForBillingPlan);
            premiumDetails.setGst(gst);
            premiumDetails.setTotalPremium(netAmount);
            premiumDetails.setStampDuty(stampDuty);
        }
        return premiumDetails;
    }
}
