package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Policy implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("any_repairer_option")
    private Boolean anyRepairerOption;
    @JsonProperty("brand")
    private String brand;
    @JsonProperty("fleet")
    private Boolean fleet;
    @JsonProperty("insured")
    private Party insured;
    @JsonProperty("policy_identifier")
    private String policyIdentifier;
    @JsonProperty("sum_insured")
    private Amount sumInsured;
    @JsonProperty("term_expiry_date")
    private java.time.ZonedDateTime termExpiryDate;
    @JsonProperty("term_inception_date")
    private java.time.ZonedDateTime termInceptionDate;
    @JsonProperty("valuation_type")
    private String valuationType;


    @ApiModelProperty(
            value = "indicates if the policy has the Any Repairer option on it",
            example = "true",
            required = false
    )
    public Boolean getAnyRepairerOption() {
        return anyRepairerOption;
    }

    @ApiModelProperty(
            value = "distributor / brand . examples - NRMA, CGU, SGIO, WFI",
            example = "nrma",
            required = false
    )
    public String getBrand() {
        return brand;
    }

    @ApiModelProperty(
            value = "indicates if this vehicle is a fleet vehicle",
            example = "true",
            required = false
    )
    public Boolean getFleet() {
        return fleet;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Party getInsured() {
        return insured;
    }

    @ApiModelProperty(
            value = "unique policy identifier",
            example = "MOT123456789",
            required = false
    )
    public String getPolicyIdentifier() {
        return policyIdentifier;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Amount getSumInsured() {
        return sumInsured;
    }

    @ApiModelProperty(
            value = "date / time policy period ends",
            example = "2020-03-30T14:00:00.000+0000",
            required = false
    )
    public java.time.ZonedDateTime getTermExpiryDate() {
        return termExpiryDate;
    }

    @ApiModelProperty(
            value = "date / time policy period starts",
            example = "2021-03-30T14:00:00.000+0000",
            required = false
    )
    public java.time.ZonedDateTime getTermInceptionDate() {
        return termInceptionDate;
    }

    @ApiModelProperty(
            value = "indicates if the policy covers a vehicle insured for either market or agreed value",
            example = "market",
            required = false
    )
    public String getValuationType() {
        return valuationType;
    }


}