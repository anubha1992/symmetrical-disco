package au.com.iag.execution.claimnotesapi.builders;

import au.com.iag.execution.claimnotesapi.model.*;
import au.com.iag.execution.claimnotesapi.model.business.*;
import au.com.iag.execution.common.model.claims.motor.*;
import au.com.iag.execution.common.service.lodgeclaims.*;
import au.com.iag.glados.common.*;
import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.security.*;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.propertyvaluationapi.model.PropertyValuationsConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER_PROFILE;
import java.io.*;
import java.util.*;

@Component
public class ClaimNotesRequestBuilder {

    @Autowired private SecurityService securityService;
    @Autowired private ApigeeOauthClient apigeeOauthClient;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private LodgeMotorClaimService lodgeMotorClaimService;
    @Autowired private LodgePropertyClaimService lodgePropertyClaimService;
    @Autowired private GladosEnrichmentService gladosEnrichmentService;

    @Value("${test.api.route}")  private String route;
    @Value("${test.apigee.api.key}") private String apigeeKey;
    @Value("${test.apigee.route}") private String apigeeRoute;
    @Value("${test.api.source.system.brand}") private String brand;
    @Value("${test.apigee.api.secret}") private String apigeeSecret;
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;
    @Value("${test.api.source.system}") private String apiSourceSystem;

    @Value("${test.api.lodgemotorclaim.route}")
    private String lodgeMotorClaimPath;

    private String claimNotesRequestJsonPath = "requests/claimnotes-api/claimNotesRequest.json";
    private String lodgeMotorClaimsRequestJsonPath = "requests/motor-claim-lodgement-api/";

    private String getClaimNotesApiPath(String claimId){
        return route + "/" + claimId + "/notes";
    }

    public ClaimNotesArtifact setupClaimNote(String claimId) throws Exception {
        ClaimNotesArtifact claimNotesArtifact = new ClaimNotesArtifact();
        claimNotesArtifact.setHeaders(buildClaimsHeaders(claimId));
        claimNotesArtifact.setPath(getClaimNotesApiPath(claimId));
        claimNotesArtifact.setClaimNotesRequest(buildClaimNotesRequest());
        return claimNotesArtifact;
    }

    public ClaimNotesArtifact setupClaimNotesExternal(String claimId) throws Exception {

        ClaimNotesArtifact claimNotesArtifact = setupClaimNote(claimId);
        claimNotesArtifact.setPath(apigeeRoute + claimId +"/notes");
        Map<String, Object> requestHeaders = claimNotesArtifact.getHeaders();
        requestHeaders.put(AUTHORIZATION, apigeeOauthClient.getToken(apigeeKey, apigeeSecret));
        return claimNotesArtifact;
    }

    private Map<String, Object> buildClaimsHeaders(String claimId) {
        UserTokenRequestPayload userTokenRequestPayload = buildUserTokenRequestPayload(claimId);
        Map<String, Object> requestHeaders = getRequestHeaders();
        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        requestHeaders.put(X_IAG_USER, "LAA008C9705F@anonymous");
        return requestHeaders;
    }

    private ClaimNotesRequest buildClaimNotesRequest() throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(claimNotesRequestJsonPath), ClaimNotesRequest.class);

    }

    private UserTokenRequestPayload buildUserTokenRequestPayload(String claimId){
        UserTokenRequestPayload userTokenRequestPayload = new UserTokenRequestPayload();
        userTokenRequestPayload.setAudience("business-api-provider");
        userTokenRequestPayload.setAuthentication("business-api-provider");
        userTokenRequestPayload.setContext("");
        userTokenRequestPayload.setGrantType("NOTARY");
        userTokenRequestPayload.setIss("");
        userTokenRequestPayload.setName("");
        userTokenRequestPayload.setScope("r:claimId:"+claimId);
        userTokenRequestPayload.setSubject("LAA008C9705F@anonymous");

        return userTokenRequestPayload;

    }

    public String getClaimId(List<Map<String, Object>> claimIdDetails, String productCode) throws Exception {

        if (isNzBrand()) {

            Response response = null;
            if (productCode.equalsIgnoreCase("MOT")) {
                Map<String, Object> requestHeaders = getLodgeMotorClaimHeader();
                requestHeaders = updateNZHeadersToUseAHODCredentials(requestHeaders);
                response = gladosEnrichmentService.sendPostRequest(requestHeaders, lodgeMotorClaimPath,
                        lodgeMotorClaimService.buildClaim(buildLodgeMotorClaimRequest()), SC_OK);
            } else
            {
                response = lodgePropertyClaimService.lodgeClaim(SC_OK);
            }
            return response.path("claim_identifier");

        }
        return claimIdDetails.get(new Random().nextInt(claimIdDetails.size())).get(DB_CC_CLAIMNUMBER).toString();
    }

    private Claim buildLodgeMotorClaimRequest() throws Exception {
        String fileName = "lodgeMotorClaim.json";
        if (brand.equalsIgnoreCase("NZ STATE")) { //This is for NZ State lodgement in test2 environment
            fileName = "lodgeNZSTATEMotorClaim.json";
        } else if (brand.equalsIgnoreCase("AMI")) {  //AMI lodge in Test2 and UAT
            fileName = "lodgeNZAMIMotorClaim.json";
        }
        Claim claim = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(lodgeMotorClaimsRequestJsonPath + fileName), Claim.class);
        claim.getReportingChannel().setClaimReportedMethod("ALL_HANDS_ON_DECK_CLAIM");
        claim.getReportingChannel().setSourceId("ALL_HANDSON_DECK");
        return claim;
    }

    private boolean isNzBrand() {
        return brand.equalsIgnoreCase("NZ STATE")
            || brand.equalsIgnoreCase("AMI")
            || brand.equalsIgnoreCase("NZSTATE")
            || brand.equalsIgnoreCase("STATE");
    }

    // LodgeMotorClaims
    private Map<String, Object> getLodgeMotorClaimHeader(){
        Map<String, Object> requestHeaders = getRequestHeaders();

        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            requestHeaders.put(X_IAG_DISTRIBUTOR, brand);
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            if (brand.equalsIgnoreCase("NZ STATE")) {
                requestHeaders.put(X_IAG_USER, "WEBZIIP");
                requestHeaders.put(X_IAG_USER_PROFILE, "IAGNZ");
            } else {
                requestHeaders.put(X_IAG_USER, "WEBNIIP");
                requestHeaders.put(X_IAG_USER_PROFILE, "IAGSM");
                requestHeaders.put(X_IAG_USER_ALIASES, "HUON=MRJUSER");
            }
        }
        return requestHeaders;
    }

    private Map<String, Object> updateNZHeadersToUseAHODCredentials(Map<String, Object> requestHeaders){
        if (brand.equalsIgnoreCase("NZ STATE")) {
            requestHeaders.put(X_IAG_USER_ALIASES, "HUON=AHODNZST");
        } else {
            requestHeaders.put(X_IAG_USER_ALIASES, "HUON=AHODUSER");
        }
        return requestHeaders;
    }

    private Map<String, Object> getRequestHeaders(){
        Map<String, Object> requestHeaders = new HashMap<>();

        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(SOURCE_ID, "DC");

        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        return requestHeaders;
    }
}
