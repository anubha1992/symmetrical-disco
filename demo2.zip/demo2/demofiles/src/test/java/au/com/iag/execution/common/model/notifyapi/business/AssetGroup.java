package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class AssetGroup implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("boat_assets")
    private java.util.List<BoatAsset> boatAssets;
    @JsonProperty("caravan_assets")
    private java.util.List<CaravanAsset> caravanAssets;
    @JsonProperty("classic_vehicle_assets")
    private java.util.List<ClassicVehicleAsset> classicVehicleAssets;
    @JsonProperty("home_assets")
    private java.util.List<HomeAsset> homeAssets;
    @JsonProperty("landlord_assets")
    private java.util.List<LandlordAsset> landlordAssets;
    @JsonProperty("motorcycle_assets")
    private java.util.List<MotorcycleAsset> motorcycleAssets;
    @JsonProperty("strata_assets")
    private java.util.List<StrataAsset> strataAssets;
    @JsonProperty("trailer_assets")
    private java.util.List<TrailerAsset> trailerAssets;
    @JsonProperty("vehicle_assets")
    private java.util.List<MotorVehicleAsset> vehicleAssets;

  
    @ApiModelProperty(
        value = "List of Boat assets",
        required = false
    )
    public java.util.List<BoatAsset> getBoatAssets() {
       return boatAssets;
    }
 
    @ApiModelProperty(
        value = "List of Caravan assets",
        required = false
    )
    public java.util.List<CaravanAsset> getCaravanAssets() {
       return caravanAssets;
    }
 
    @ApiModelProperty(
        value = "List of Classic Vehicle assets",
        required = false
    )
    public java.util.List<ClassicVehicleAsset> getClassicVehicleAssets() {
       return classicVehicleAssets;
    }
 
    @ApiModelProperty(
        value = "List of home assets",
        required = false
    )
    public java.util.List<HomeAsset> getHomeAssets() {
       return homeAssets;
    }
 
    @ApiModelProperty(
        value = "List of Landlord assets",
        required = false
    )
    public java.util.List<LandlordAsset> getLandlordAssets() {
       return landlordAssets;
    }
 
    @ApiModelProperty(
        value = "List of Motor Cycle assets",
        required = false
    )
    public java.util.List<MotorcycleAsset> getMotorcycleAssets() {
       return motorcycleAssets;
    }
 
    @ApiModelProperty(
        value = "List of Strata assets",
        required = false
    )
    public java.util.List<StrataAsset> getStrataAssets() {
       return strataAssets;
    }
 
    @ApiModelProperty(
        value = "List of trailer assets",
        required = false
    )
    public java.util.List<TrailerAsset> getTrailerAssets() {
       return trailerAssets;
    }
 
    @ApiModelProperty(
        value = "List of vehicle assets",
        required = false
    )
    public java.util.List<MotorVehicleAsset> getVehicleAssets() {
       return vehicleAssets;
    }
 

}