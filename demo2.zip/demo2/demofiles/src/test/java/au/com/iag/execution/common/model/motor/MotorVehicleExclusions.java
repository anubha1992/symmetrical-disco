package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class MotorVehicleExclusions implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("person_under_25_vehicle_value_above_100k")
    private AbstractExclusion personUnder25VehicleValueAbove100k = new AbstractExclusion();
    @JsonProperty("person_under_30_vehicle_value_above_250k")
    private AbstractExclusion personUnder30VehicleValueAbove250k = new AbstractExclusion();
    @JsonProperty("pre_existing_damage")
    private AbstractExclusion preExistingDamage = new AbstractExclusion();

  
    @ApiModelProperty(
        value = "Exclusion details for person age and vehicle value",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public AbstractExclusion getPersonUnder25VehicleValueAbove100k() {
       return personUnder25VehicleValueAbove100k;
    }
 
    @ApiModelProperty(
        value = "Exclusion details for person age and vehicle value",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public AbstractExclusion getPersonUnder30VehicleValueAbove250k() {
       return personUnder30VehicleValueAbove250k;
    }
 
    @ApiModelProperty(
        value = "Exclusion details for pre existing hail damage",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public AbstractExclusion getPreExistingDamage() {
       return preExistingDamage;
    }
 

}