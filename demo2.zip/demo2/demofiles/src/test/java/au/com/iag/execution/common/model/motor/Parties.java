package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Parties implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("drivers")
    private java.util.List<PolicyDriver> drivers = new java.util.ArrayList<PolicyDriver>();
    @JsonProperty("individuals")
    private java.util.List<Individual> individuals = new java.util.ArrayList<Individual>();
    @JsonProperty("organisations")
    private java.util.List<Organisation> organisations = new java.util.ArrayList<Organisation>();
    @JsonProperty("party_history_disclosures")
    private PartyHistoryDisclosure partyHistoryDisclosures = new PartyHistoryDisclosure();
    @JsonProperty("party_roles")
    private java.util.List<PartyRole> partyRoles = new java.util.ArrayList<PartyRole>();

  
    @ApiModelProperty(
        value = "List of drivers",
        required = false
    )
    public java.util.List<PolicyDriver> getDrivers() {
       return drivers;
    }
 
    @ApiModelProperty(
        value = "List of individuals",
        required = false
    )
    public java.util.List<Individual> getIndividuals() {
       return individuals;
    }
 
    @ApiModelProperty(
        value = "List of organisations",
        required = false
    )
    public java.util.List<Organisation> getOrganisations() {
       return organisations;
    }
 
    @ApiModelProperty(
        value = "History Disclosure details for party",
        required = false
    )
    public PartyHistoryDisclosure getPartyHistoryDisclosures() {
       return partyHistoryDisclosures;
    }
 
    @ApiModelProperty(
        value = "List of party roles",
        required = false
    )
    public java.util.List<PartyRole> getPartyRoles() {
       return partyRoles;
    }
 

}