package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Range implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("dynamic_range_ref")
    private String dynamicRangeRef ;
    @JsonProperty("max_value")
    private RangeValue maxValue = new RangeValue();
    @JsonProperty("min_value")
    private RangeValue minValue = new RangeValue();

  
    @ApiModelProperty(
        value = "Name of the dynamic range to retrieve min and max from",
        required = false
    )
    public String getDynamicRangeRef() {
       return dynamicRangeRef;
    }
 
    @ApiModelProperty(
        value = "Optional. For type &#x3D; integer or decimal, the maximum value.",
        required = false
    )
    public RangeValue getMaxValue() {
       return maxValue;
    }
 
    @ApiModelProperty(
        value = "Optional. For type &#x3D; integer or decimal, the minimum value.",
        required = false
    )
    public RangeValue getMinValue() {
       return minValue;
    }
 

}