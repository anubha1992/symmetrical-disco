package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Individual{

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("name")
	private Name name;

	@JsonProperty("dateOfBirth")
	private String dateOfBirth;

	public void setGender(String gender){
		this.gender = gender;
	}

	public String getGender(){
		return gender;
	}

	public void setName(Name name){
		this.name = name;
	}

	public Name getName(){
		return name;
	}

	public void setDateOfBirth(String dateOfBirth){
		this.dateOfBirth = dateOfBirth;
	}

	public String getDateOfBirth(){
		return dateOfBirth;
	}

	@Override
 	public String toString(){
		return 
			"Individual{" + 
			"gender = '" + gender + '\'' + 
			",name = '" + name + '\'' + 
			",dateOfBirth = '" + dateOfBirth + '\'' + 
			"}";
		}
}