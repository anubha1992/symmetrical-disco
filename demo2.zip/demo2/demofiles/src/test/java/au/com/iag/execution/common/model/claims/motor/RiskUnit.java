package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class RiskUnit implements Serializable {

    private static final long serialVersionUID = -3962109157367171925L;
    private String riskType;
    private Vehicle riskItem;

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public Vehicle getRiskItem() {
        return riskItem;
    }

    public void setRiskItem(Vehicle riskItem) {
        this.riskItem = riskItem;
    }
}
