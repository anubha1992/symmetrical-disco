package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class StreetAddress implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("building_name")
    private String buildingName ;
    @JsonProperty("flat_unit_number")
    private String flatUnitNumber ;
    @JsonProperty("flat_unit_type")
    private String flatUnitType ;
    @JsonProperty("floor_level_number")
    private String floorLevelNumber ;
    @JsonProperty("floor_level_type")
    private String floorLevelType ;
    @JsonProperty("house_number")
    private String houseNumber ;
    @JsonProperty("lot_number")
    private String lotNumber ;
    @JsonProperty("street_direction")
    private String streetDirection ;
    @JsonProperty("street_name")
    private String streetName ;
    @JsonProperty("street_type")
    private String streetType ;

  
    @ApiModelProperty(
        value = "Optional name of the place associated with the address",
        example = "Batman Hill",
        required = false
    )
    public String getBuildingName() {
       return buildingName;
    }
 
    @ApiModelProperty(
        value = "Composite unit number including potential ranges, prefixes or suffixes",
        example = "209",
        required = false
    )
    public String getFlatUnitNumber() {
       return flatUnitNumber;
    }
 
    @ApiModelProperty(
        value = "see SUBDWELLING ref data",
        example = "DUPLEX",
        required = false
    )
    public String getFlatUnitType() {
       return flatUnitType;
    }
 
    @ApiModelProperty(
        value = "Composite floor number including potential ranges, prefixes or suffixes",
        example = "6",
        required = false
    )
    public String getFloorLevelNumber() {
       return floorLevelNumber;
    }
 
    @ApiModelProperty(
        value = "see SUBDWELLING ref data.",
        example = "L",
        required = false
    )
    public String getFloorLevelType() {
       return floorLevelType;
    }
 
    @ApiModelProperty(
        value = "Composite representation of the street number including potential ranges, prefixes or suffixes",
        example = "181",
        required = false
    )
    public String getHouseNumber() {
       return houseNumber;
    }
 
    @ApiModelProperty(
        value = "Lot number when the address represents a lot",
        example = "L0001",
        required = false
    )
    public String getLotNumber() {
       return lotNumber;
    }
 
    @ApiModelProperty(
        value = "see STREET_DIRECTION ref data",
        example = "NW",
        required = false
    )
    public String getStreetDirection() {
       return streetDirection;
    }
 
    @ApiModelProperty(
        value = "Name of the street excluding street type or street direction",
        example = "William St",
        required = false
    )
    public String getStreetName() {
       return streetName;
    }
 
    @ApiModelProperty(
        value = "see STREET_TYPE ref data",
        example = "AVE",
        required = false
    )
    public String getStreetType() {
       return streetType;
    }
 

}