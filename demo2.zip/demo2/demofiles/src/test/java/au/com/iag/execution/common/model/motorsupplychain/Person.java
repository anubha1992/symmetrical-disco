package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.time.*;

@Data
@ApiModel(description = "Person information")
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
@EqualsAndHashCode(callSuper = true)
public class Person extends Party {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(
            value = "Date of birth of individual",
            example = "2017-11-19",
            required = false
    )
    @JsonProperty("date_of_birth")
    private LocalDate dateOfBirth;

    @ApiModelProperty(
            value = "First name of individual",
            example = "Jane",
            required = false
    )
    @JsonProperty("first_name")
    private String firstName;

    @ApiModelProperty(
            value = "Last name of individual",
            example = "Doe",
            required = false
    )
    @JsonProperty("last_name")
    private String lastName;

    @ApiModelProperty(
            value = "Title of individual",
            example = "Ms",
            required = false
    )
    @JsonProperty("title")
    private String title;


}