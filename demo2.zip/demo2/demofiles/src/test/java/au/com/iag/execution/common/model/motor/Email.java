package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Email implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("effective_from")
    private String effectiveFrom ;
    @JsonProperty("effective_to")
    private String effectiveTo ;
    @JsonProperty("email_address")
    private String emailAddress ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Effective from date",
        example = "2019-12-01",
        required = false
    )
    public String getEffectiveFrom() {
       return effectiveFrom;
    }
 
    @ApiModelProperty(
        value = "Effective to date",
        example = "2020-12-01",
        required = false
    )
    public String getEffectiveTo() {
       return effectiveTo;
    }
 
    @ApiModelProperty(
        value = "Email address",
        example = "abc@xyz.com",
        required = false
    )
    public String getEmailAddress() {
       return emailAddress;
    }
 
    @ApiModelProperty(
        value = "The type of email address e.g. PRIMARY or SECONDARY",
        example = "PRIMARY",
        required = false
    )
    public String getType() {
       return type;
    }
 

}