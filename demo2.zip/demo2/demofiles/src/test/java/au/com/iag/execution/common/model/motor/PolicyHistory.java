package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PolicyHistory implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("quote")
    private QuoteHistory quote = new QuoteHistory();

  
    @ApiModelProperty(
        value = "Quote Details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public QuoteHistory getQuote() {
       return quote;
    }
 

}