package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class EnterpriseReferenceDataPayload implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("groups")
    private java.util.List<ReferenceDataGroup> groups;

  
    @ApiModelProperty(
        value = "",
        required = false
    )
    public java.util.List<ReferenceDataGroup> getGroups() {
       return groups;
    }
 

}