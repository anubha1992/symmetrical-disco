package au.com.iag.execution.complaintmanagementapi.builders;

import static au.com.iag.glados.model.constants.GladosConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.APPLICATION_JSON;
import static au.com.iag.glados.model.constants.GladosConstants.CONTENT_TYPE;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_USER;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_BRAND;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CHANNEL;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CONSUMER_SYSTEM;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import au.com.iag.execution.complaintmanagementapi.model.NotifyCaseArtifact;
import au.com.iag.execution.complaintmanagementapi.model.business.NotifyCaseRequest;
import au.com.iag.execution.pricingremediationapi.model.business.UpdateRemediationRequest;
import au.com.iag.execution.totallossapi.model.OutstandingItemsArtifact;
import au.com.iag.glados.model.security.UserTokenRequestPayload;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import au.com.iag.glados.service.SecurityService;

@Component
public class NotifyCaseRequestBuilder {

    @Autowired
    private SecurityService securityService;
    @Autowired
    private JsonMapperService jsonMapperService;
    @Autowired
    private ResourceReaderService resourceReaderService;

    @Value("${test.api.brand}")
    public String brand;
    @Value("${test.api.route}")
    private String route;
    @Value("${test.security.consumer}")
    private String consumerSystem;
    @Value("${test.security.provider}")
    private String providerSystem;

    public NotifyCaseArtifact setupNotifyCaseDefaults(String claimId, String caseId) throws IOException {

        NotifyCaseArtifact notifyCaseArtifact = new NotifyCaseArtifact();
        notifyCaseArtifact.setPath(route + "/notifyCase/");
        notifyCaseArtifact.setCaseId(caseId);
        notifyCaseArtifact.setHeaders(buildNotifyCaseHeaders("r:claimId:" + claimId));
        notifyCaseArtifact.setNotifyCaseRequest(buildNotifyCaseRequest(claimId, caseId));
        return notifyCaseArtifact;
    }

    private NotifyCaseRequest buildNotifyCaseRequest(String claimNumber, String caseId) throws IOException {
        NotifyCaseRequest notifyCaseRequest = jsonMapperService.getObjectMapper().readValue(
                resourceReaderService.generateStringFromResource("requests/complaint-management-api/NotifyCaseRequest.json"), NotifyCaseRequest.class);
        notifyCaseRequest.setCaseId(caseId);
        notifyCaseRequest.setClaimId(claimNumber);
        return notifyCaseRequest;
    }

    private Map<String, Object> buildNotifyCaseHeaders(String scope) {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(X_IAG_CHANNEL, "ASSISTED");
        requestHeaders.put("source_id", "DC");
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));

        UserTokenRequestPayload userTokenRequestPayload = getUserTokenRequestPayload(scope);

        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        return requestHeaders;
    }

    private UserTokenRequestPayload getUserTokenRequestPayload(String scope) {
        UserTokenRequestPayload userTokenRequestPayload = new UserTokenRequestPayload();
        userTokenRequestPayload.setScope(scope);
        userTokenRequestPayload.setSubject("test");
        userTokenRequestPayload.setAudience("business-api-provider");
        userTokenRequestPayload.setIss("business-api-provider");
        userTokenRequestPayload.setGrantType("NOTARY");
        return userTokenRequestPayload;
    }

}