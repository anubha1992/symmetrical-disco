package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class CorrespondenceType implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("correspondence_type")
    private String correspondenceType;
    @JsonProperty("event_code")
    private String eventCode;
    @JsonProperty("event_description")
    private String eventDescription;
    @JsonProperty("template_id")
    private String templateId;

  
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getCorrespondenceType() {
       return correspondenceType;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getEventCode() {
       return eventCode;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getEventDescription() {
       return eventDescription;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getTemplateId() {
       return templateId;
    }
 

}