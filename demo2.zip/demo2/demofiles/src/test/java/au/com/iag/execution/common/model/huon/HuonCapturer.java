package au.com.iag.execution.common.model.huon;

import au.com.iag.execution.common.exception.*;
import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.*;
import com.jagacy.util.*;
import java.text.*;
import java.util.*;

/**
 * The class is the super class to capture policy information from HUON.
 */
public class HuonCapturer extends HuonCreator {
    String policyNumber = "";
    boolean captureQuote = false;

    /**
     * Create a capture instance with existing HUON session.
     *
     * @param huon        //     * @param policyNumber
     * @param testcaseDir The directory for test case's snapshot.
     * @throws JagacyException
     */
    public HuonCapturer(HuonSession huon, String testcaseDir) throws JagacyException {
        super(huon, testcaseDir);

    }

    /**
     * Create a capture instance by creating new HUON session.
     *
     * @param env         //     * @param policyNumber
     * @param testcaseDir The directory for test case's snapshot.
     * @throws JagacyException
     * @throws HuonException
     */
    public HuonCapturer(String env, String testcaseDir) throws JagacyException, HuonException {
        super(env, testcaseDir);
    }

    /**
     * Get HUON session
     *
     * @return HUON session
     */
    public HuonSession getHuonSession() {
        return this.huon;
    }

    public Policy capture(String policyNumber, Policy policy) throws JagacyException, HuonException, InvalidDataException {
        this.policyNumber = policyNumber.replaceAll(" ", "");

        if (policyNumber.length() != 12) {
            if (reporter != null)
                reporter.writeError("Capture policy " + policyNumber + " failed because policy number length is not 12.");
            throw new HuonException(" Capture-The policy number is not a valid policy number -- " + policyNumber);
        }
        huon.printScreenshot();
        huon.gotoHH100();
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.input(4, 33, policyNumber);
        huon.enter();

        String error = huon.readErrorMessage();
        String errorCode = huon.extractErrorCode();
        if (errorCode.equalsIgnoreCase("6044")) {
            if (reporter != null)
                huon.printScreenshot();
            reporter.writeError("Capture policy " + policyNumber + " Policy is not in HUON.");
            throw new HuonException(" Capture-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
        }
        System.out.println("dump HUON screen --------------------------------------------");
        huon.printScreenshot();
//        System.out.println(huon.readScreenText());
        String screen = huon.waitForScreens(new String[]{"PP510", "PP618"});
        if (screen.equalsIgnoreCase("PP618"))
            captureQuote = true;

        String status = "";
        String distributor = "";
        String agent = "";
        String effectiveDate = "";
        String reason = "";
        String riskType = "";
        String state = "";
        String mailingAddressString = "";
        String mailingAddressCustname = "";
        String insuredName = "";

        status = huon.readFromField(4, 9, 16).trim();
        reason = huon.readFromField(4, 25, 28).trim();
        insuredName = huon.readFromField(5, 13, 79).trim();
        mailingAddressCustname = huon.readFromField(6, 13, 79).trim();
        mailingAddressString = huon.readFromField(7, 13, 79).trim();
        agent = huon.readFromField(8, 13, 15).trim();


        if (!captureQuote)
            effectiveDate = huon.readFromField(12, 18, 27).trim();
        else
            effectiveDate = huon.readFromField(13, 18, 27).trim();

        switch (agent) {
            case "CIT":
            case "CTP":
            case "TAT":
                distributor = Policy.NRMA;
                break;
            case "BNE":
                distributor = Policy.NRMAQLD;
                break;
            case "ADE":
                distributor = Policy.SGIC;
                break;
            case "PER":
                distributor = Policy.SGIO;
                break;
            case "RNP":
            case "PLR":
                distributor = Policy.RACV;
                break;
            case "PLI":
                //Temporarily set it as NRMA. Will change it based on state
                distributor = Policy.NRMA;
                break;
            case "INT": //updated based on the screen layout of quote and policy in huon
                if (!captureQuote) {
                    state = huon.readFromField(10, 42, 43).trim();
                } else {
                    state = huon.readFromField(11, 36, 37).trim();
                }

                if (state.equals("02") || state.equals("01") || state.equals("07"))
                    distributor = "NRMA";

                if (state.equals("04"))
                    distributor = "NRMAQLD";

                if (state.equals("05"))
                    distributor = "SGIC";

                if (state.equals("06"))
                    distributor = "SGIO";

                break;

            default:
                distributor = Policy.NRMA;
                break;
        }

//		policy = new Policy(distributor, riskType);
        try {
            policy.setEffectiveDate(effectiveDate.trim());
            policy.setDistributor(distributor.trim());
            policy.setRiskType(riskType.trim());
            policy.setMailingAddressString(mailingAddressString.trim());
            policy.setMailingAddressCustname(mailingAddressCustname.trim());
            policy.setInsuredName(insuredName.trim());
        } catch (ParseException pe) {

        }

        policy.setStatus(status.trim());
        policy.setReason(reason.trim());

        //Original quote number --extra in G
        if (!this.captureQuote) {
            policy.setQuoteNumber(huon.readFromField(18, 42, 53).trim());
        }

        //Go to
        if (!this.captureQuote) {
            huon.input(3, 13, "T");
            huon.input(3, 23, "1");
            huon.input(3, 37, "1");
        } else {
            huon.input(3, 13, "T");
            huon.input(3, 25, "1");
            huon.input(3, 39, "1");
        }
        huon.enter();
        String address = huon.readFromField(05, 2, 50).trim();
        String[] fullAddress = address.split(" ");
        String postcode = fullAddress[fullAddress.length - 1].trim();
        String mailingState = fullAddress[fullAddress.length - 2].trim();
        String[] suburbList = address.split(mailingState + " " + postcode );
        policy.setSuburb(suburbList[0].trim());
        policy.setPostcode(postcode.trim());

        if (policyNumber.toUpperCase().indexOf("MOT")>=0 || policyNumber.toUpperCase().indexOf("VVC")>=0){
            String vehicleRegistrationDetails = huon.readFromField(11, 2, 80).trim();
            String[] registrationDetails = vehicleRegistrationDetails.split("Reg No");
            registrationDetails = registrationDetails[registrationDetails.length-1].trim().split(" ");

            policy.setVehicleRegistrationNumber(registrationDetails[0].trim());
        }
        return policy;
    }


    public Policy captureCustomerDetailsForPolicyNumber(String policyNumber, Policy policy) throws JagacyException, HuonException, InvalidDataException {
        this.policyNumber = policyNumber.replaceAll(" ", "");

        if (policyNumber.length() != 12) {
            if (reporter != null)
                reporter.writeError("Capture policy " + policyNumber + " failed because policy number length is not 12.");
            throw new HuonException(" Capture-The policy number is not a valid policy number -- " + policyNumber);
        }
        huon.printScreenshot();
        huon.gotoHH100();
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.input(4, 33, policyNumber);
        huon.enter();

        String error = huon.readErrorMessage();
        String errorCode = huon.extractErrorCode();
        if (errorCode.equalsIgnoreCase("6044")) {
            if (reporter != null)
                huon.printScreenshot();
            reporter.writeError("Capture policy " + policyNumber + " Policy is not in HUON.");
            throw new HuonException(" Capture-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
        }
        System.out.println("dump HUON screen --------------------------------------------");
        String screen = huon.waitForScreens(new String[]{"PP510", "PP618"});
        huon.input(3, 13, "n");
        huon.enter();
        String customerNumber = huon.readFromField(9, 19, 26).trim();
        while (customerNumber.length() < 7) {
            customerNumber = "0" + customerNumber;
        }
        policy.setCustomerNumber(customerNumber);
        String address1 = huon.readFromField(05, 15, 79).trim();
        String[] insuredAddress1 = address1.split(" ");
        String streetName = insuredAddress1[insuredAddress1.length -2] + " " + insuredAddress1[insuredAddress1.length -1];
        String address2 = huon.readFromField(06, 15, 79).trim();
        String[] insuredAddress2 = address2.split(" ");
        String postcode = insuredAddress2[insuredAddress2.length - 1].trim();
        String mailingState = insuredAddress2[insuredAddress2.length - 2].trim();
        String[] suburbList = address2.split(mailingState + " " + postcode );
        policy.setSuburb(suburbList[0].trim());
        policy.setPostcode(postcode.trim());
        policy.setStreetName(streetName.trim());
        huon.input(9, 2, "v");
        huon.enter();
        String dateOfBirth = huon.readFromField(9, 12, 22).trim();
        policy.setCustomerDateOfBirth(dateOfBirth.trim());
        String phoneNumber = huon.readFromField(13, 6, 8).trim() + huon.readFromField(13, 28, 35).trim();
        policy.setCustomerPhoneNumber(phoneNumber.trim());

        return policy;
    }

    /**
     * Capture risk address from WPO582
     *
     * @throws JagacyException
     * @throws InvalidDataException
     */
//    public void captureRiskAddress(Policy policy) throws JagacyException, InvalidDataException {
//        String indicators = huon.readFromField(5, 17, 79).trim();
//        String fullStreet = huon.readFromField(6, 17, 79).trim();
//        String fullSuburb = huon.readFromField(7, 17, 79).trim();
//
//        if (fullSuburb.isEmpty()) {
//            fullSuburb = fullStreet;
//            fullStreet = indicators;
//            indicators = "";
//        }
//
//        String addressNumber = huon.readFromField(11, 31, 40).trim();
//
//        policy.getRiskAddress().extractIndicators(indicators);
//        policy.getRiskAddress().extractStreet(fullStreet);
//        policy.getRiskAddress().extractSuburb(fullSuburb);
//        policy.getRiskAddress().setSequenceNumber(addressNumber);
//
//
//    }
    public Address captureRiskAddress(Policy policy) throws JagacyException, InvalidDataException {
        String indicators = huon.readFromField(5, 17, 79).trim();
        String fullStreet = huon.readFromField(6, 17, 79).trim();
        String fullSuburb = huon.readFromField(7, 17, 79).trim();
        String addressNumber = huon.readFromField(11, 31, 40).trim();

        if (fullSuburb.isEmpty()) {
            fullSuburb = fullStreet;
            fullStreet = indicators;
            indicators = "";
        }

        if (fullStreet.split(" ").length <= 3) {

            policy.getRiskAddress().extractIndicators(indicators);
            policy.getRiskAddress().extractStreet(fullStreet);
        } else if (fullStreet.split(" ").length == 5) {
            String[] riskAddress = fullStreet.split(" ");

            policy.getRiskAddress().setStreetType(riskAddress[4], false);
            policy.getRiskAddress().setStreetName(riskAddress[3]);
            policy.getRiskAddress().setStreetNo(riskAddress[2]);
            policy.getRiskAddress().setUnitNo(riskAddress[1]);
            policy.getRiskAddress().setIndicator(EsbMapping.getHuonAddressIndicator(riskAddress[0]));
        } else if (fullStreet.split(" ").length == 4) {
            String[] riskAddress = fullStreet.split(" ");

            policy.getRiskAddress().setStreetType(riskAddress[3], false);
            policy.getRiskAddress().setStreetName(riskAddress[2]);
            policy.getRiskAddress().setStreetNo(riskAddress[1]);
            policy.getRiskAddress().setUnitNo(riskAddress[0]);
        }

        policy.getRiskAddress().extractSuburb(fullSuburb);
        policy.getRiskAddress().setSequenceNumber(addressNumber);

        return policy.getRiskAddress();

    }

    //WBO530

    protected void capturePolicyPremiumBreakdown(CapturedPolicy capturedPolicy) throws JagacyException, InvalidDataException {

        int col = 0;
        int colEnd = 0;

        if (huon.readFromField(06, 23, 26).trim().equalsIgnoreCase("PLIB")) {
            col = 12;
            colEnd = 27;
        } else {
            col = 52;
            colEnd = 67;
        }


        PremiumBreakdown premiumBreakdown = new PremiumBreakdown();

        premiumBreakdown.setBasicPremium(huon.readFromField(8, col, colEnd).trim());
        premiumBreakdown.setOtherCharges(huon.readFromField(9, col, colEnd).trim());

        //Actually, this is Stamp Duty
        premiumBreakdown.setStampDuty(huon.readFromField(10, col, colEnd).trim());
        premiumBreakdown.setGst(huon.readFromField(11, col, colEnd).trim());
        premiumBreakdown.setGross(huon.readFromField(12, col, colEnd).trim());
        premiumBreakdown.setCommission(huon.readFromField(13, col, colEnd).trim());
        premiumBreakdown.setNet(huon.readFromField(15, col, colEnd).trim());
        capturedPolicy.setPolicyPremiumBreakdown(premiumBreakdown);
    }

    //Monthly premium breakdown capture
    protected void capturemonthlyPolicyPremiumBreakdown(CapturedPolicy capturedPolicy) throws JagacyException, InvalidDataException {

        int col = 0;
        int colEnd = 0;


        if (huon.readFromField(06, 23, 26).trim().equalsIgnoreCase("PLIB")) {
            col = 52;
            colEnd = 67;
        } else {
            col = 12;
            colEnd = 27;
        }

        PremiumBreakdown premiumBreakdown = new PremiumBreakdown();

        premiumBreakdown.setmonthlyBasicPremium(huon.readFromField(8, col, colEnd).trim());
        premiumBreakdown.setmonthlyOtherCharges(huon.readFromField(9, col, colEnd).trim());
        premiumBreakdown.setmonthlyStampDuty(huon.readFromField(10, col, colEnd).trim());

        premiumBreakdown.setmonthlyGst(huon.readFromField(11, col, colEnd).trim());
        premiumBreakdown.setmonthlyGross(huon.readFromField(12, col, colEnd).trim());
        premiumBreakdown.setmonthlyCommission(huon.readFromField(13, col, colEnd).trim());
        premiumBreakdown.setmonthlyNet(huon.readFromField(15, col, colEnd).trim());
        capturedPolicy.setmonthlyPolicyPremiumBreakdown(premiumBreakdown);
    }

    public void capturePolicyPremiumBreakdownRenAmend(CapturedPolicy capturedPolicy) throws JagacyException, InvalidDataException {
        int col = 70;
        int colEnd = 77;


        huon.waitForScreen("PPO450");
        if (huon.readFromField(5, 70, 77).trim().isEmpty() || huon.readFromField(5, 70, 77).trim().equals("0.00") || huon.readFromField(5, 70, 77).trim().equals("0")) {
            col = 52;
            colEnd = 66;
        }
        PremiumBreakdown premiumBreakdown = new PremiumBreakdown();
        premiumBreakdown.setCoverage("");
        premiumBreakdown.setBasicPremium(huon.readFromField(5, col, colEnd).trim());
        premiumBreakdown.setOtherCharges(huon.readFromField(6, col, colEnd).trim());
        premiumBreakdown.setGst(huon.readFromField(7, col, colEnd).trim());
        //Actually, this is Stamp Duty
        premiumBreakdown.setStampDuty(huon.readFromField(8, col, colEnd).trim());
        premiumBreakdown.setGross(huon.readFromField(9, col, colEnd).trim());
        premiumBreakdown.setCommission(huon.readFromField(10, col, colEnd).trim());
        premiumBreakdown.setNet(huon.readFromField(11, col, colEnd).trim());
        capturedPolicy.setPolicyPremiumBreakdown(premiumBreakdown);
    }

    /*
     * Capture premium breakdown for all coverages
     */
    protected void capturePremiumBreakdown(CapturedPolicy capturedPolicy) throws JagacyException, InvalidDataException {
        //Start from TJO011
        int iPage = 1;

        int iRow = 6;

        while (iRow < 22) {
            String coverage = huon.readFromField(iRow, 6, 19).trim();
            String coveragesSumInsured = huon.readFromField(iRow, 21, 29).trim();
            if (coveragesSumInsured.isEmpty()) {
                coveragesSumInsured = "0";
            }

            if (coverage.isEmpty())
                break;

            huon.input(iRow, 2, "P");
            huon.enter();
            huon.waitForScreen("PPO628");
            int col = 12;
            int colEnd = 22;
            if (huon.readFromField(7, 12, 24).trim().isEmpty() || huon.readFromField(7, 12, 24).trim().equals("0.00") || huon.readFromField(7, 12, 24).trim().equals("0")) {
                col = 48;
                colEnd = 59;
            }

            PremiumBreakdown premiumBreakdown = new PremiumBreakdown();
            premiumBreakdown.setCoverage(coverage);
            premiumBreakdown.setCoveragesSumInsured(coveragesSumInsured);
            premiumBreakdown.setBasicPremium(huon.readFromField(7, col, colEnd).trim());
            premiumBreakdown.setOtherCharges(huon.readFromField(8, col, colEnd).trim());
            premiumBreakdown.setTax(huon.readFromField(9, col, colEnd).trim());
            premiumBreakdown.setGross(huon.readFromField(10, col, colEnd).trim());
            premiumBreakdown.setCommission(huon.readFromField(11, col, colEnd).trim());
            premiumBreakdown.setNet(huon.readFromField(12, col, colEnd).trim());

            //Difference
            premiumBreakdown.setPremiumDifference(huon.readFromField(14, 21, 34).trim());
            premiumBreakdown.setPremiumNew(huon.readFromField(15, 21, 34).trim());
            premiumBreakdown.setReason(huon.readFromField(14, 49, 80).trim());

            huon.input(5, 64, "Y");
            huon.enter();
            huon.waitForScreen("PPO635");
            premiumBreakdown.setStampDuty(huon.readFromField(8, col, colEnd + 12).trim());
            premiumBreakdown.setGst(huon.readFromField(9, col, colEnd + 12).trim());

            capturedPolicy.addPremiumBreakdown(premiumBreakdown);

            //Go back to TJO011
            huon.input(4, 13, "CO");
            huon.input(4, 24, "1");
            huon.input(4, 38, "1");
            huon.enter();
            huon.waitForScreen("TJO011");
            //Goto previous page
            int n = iPage - 1;
            for (int k = 0; k < n; k++) {
                huon.gotoNextPage();
            }

            iRow = iRow + 2;
            if (iRow >= 22) {
                if (huon.extractErrorCode().equals("108"))
                    break;
                else {
                    huon.gotoNextPage();
                    iPage++;
                    iRow = 6;
                }
            }
        }
    }

    /*
     * Capture adjustment points for all coverages
     */
    protected void captureAdjustmentPoints(CapturedPolicy capturedPolicy) throws JagacyException, InvalidDataException {
        //Start from TJO011
        int iPage = 1;

        int iRow = 6;

        while (iRow < 22) {
            String coverage = huon.readFromField(iRow, 6, 19).trim();
            if (coverage.isEmpty())
                break;

            huon.input(iRow, 2, "A");
            huon.enter();

            //WP62 - WPO629 COVERAGE ADJUSTMENT VIEW
            huon.waitForScreen("WPO629");
            int col = 14;
            int colEnd = 23;
//			if (huon.readFromField(7, 12, 24).trim().isEmpty() || huon.readFromField(7, 12, 24).trim().equals("0.00") || huon.readFromField(7, 12, 24).trim().equals("0")) {
//				col = 48;
//				colEnd = 59;
//			}

            AdjustmentPoints adjustmentPoints = new AdjustmentPoints();
            adjustmentPoints.setCoverage(coverage);
            adjustmentPoints.setInclusive(huon.readFromField(12, col, colEnd).trim());
            adjustmentPoints.setAdjustment(huon.readFromField(13, col, colEnd).trim());
            adjustmentPoints.setBasepoints(huon.readFromField(14, col, colEnd).trim());
            adjustmentPoints.setExcluded(huon.readFromField(15, col, colEnd).trim());
            capturedPolicy.addAdjustmentPoints(adjustmentPoints);

            //Go back to TJO011
            huon.pressKey(Key.PF3);
            huon.waitForScreen("TJO011");
            //Goto previous page
            int n = iPage - 1;
            for (int k = 0; k < n; k++) {
                huon.gotoNextPage();
            }

            iRow = iRow + 2;
            if (iRow >= 22) {
                if (huon.extractErrorCode().equals("108"))
                    break;
                else {
                    huon.gotoNextPage();
                    iPage++;
                    iRow = 6;
                }
            }
        }
    }

    /*
     * Capture Geo ID from:
     * WP5C - WPO582       GEOID DISPLAY
     */
    protected void captureGeo(Policy policy) throws JagacyException {
        policy.getRiskAddress().setGeoId(huon.readFromField(9, 31, 41).trim());
    }

    // Caravan Policy Notes capture
    protected void capturePolicyNotes(CapturedPolicy capturedPolicy, String policyNumber) throws JagacyException, InvalidDataException {
        String msgDesc = "";
        ArrayList msgDetails = new ArrayList();

        huon.gotoScreen("pp000");

        huon.input(04, 17, "10");
        huon.input(04, 33, policyNumber);
        huon.enter();

        int pagecount = Integer.parseInt(huon.readFromField(02, 13, 14));

        if (!huon.readFromField(8, 20, 33).trim().isEmpty()) {

            for (int i = 1; i <= pagecount; i++) {

                int l = 8;

                while (!huon.readFromField(l, 20, 33).trim().isEmpty()) {

                    huon.input(l, 03, "V");
                    huon.enter();

                    int j = 10;
                    int k = 1;
                    msgDesc = "";
                    while (!huon.readFromField(j, 10, 79).trim().isEmpty()) {


                        if (huon.readFromField(j - 1, 10, 79).replaceAll("\\s+$", "").length() == 70) {
                            msgDesc = msgDesc + huon.readFromField(j, 10, 79).replaceAll("\\s+$", "");
                        } else {
                            if (!msgDesc.isEmpty()) {
                                msgDesc = msgDesc + " " + huon.readFromField(j, 10, 79).trim();
                            } else {
                                msgDesc = msgDesc + huon.readFromField(j, 10, 79).trim();
                            }
                        }

                        j++;
                        k++;

                        if (k == 13) {
                            huon.gotoNextPage();
                            j = 10;
                            k = 1;
                        }

                    }

                    msgDetails.add(huon.readFromField(04, 16, 24).trim() + "|" + huon.readFromField(04, 47, 77).trim() + "|" + huon.readFromField(05, 16, 18).trim() + "|" + huon.readFromField(05, 47, 47).trim() + "|" + huon.readFromField(05, 78, 78).trim() + "|" + huon.readFromField(06, 16, 25).trim() + "|" + huon.readFromField(06, 47, 56).trim() + "|" + huon.readFromField(06, 74, 78).trim() + "|" + msgDesc);

                    huon.input(8, 14, "E");
                    huon.enter();

                    l++;

                }

                if (pagecount > 1) {
                    huon.gotoNextPage();
                }

            }
        }

        for (int i = 1; i <= (msgDetails.size()); i++) {
            System.out.println(((String) msgDetails.get(i - 1)).trim());
        }

        capturedPolicy.setpolicyMsgDetails(msgDetails);

        huon.input(05, 12, "E");
        huon.enter();

    }


    protected void captureDafMatch(CapturedPolicy capturedPolicy) throws JagacyException {
        //Go back to coverage
        huon.pressKey(Key.PF3);
        huon.input(3, 12, "DL");
        huon.enter();
        //WP62 - WPO629 COVERAGE ADJUSTMENT VIEW
        huon.waitForScreen("WPO580");
        capturedPolicy.setDafMatch(huon.readFromField(5, 21, 80).trim());
    }

    public String captureBillPlan(String policyNumber) throws JagacyException, HuonException {
        String billPlan = "";

        huon.gotoHH100();
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.input(4, 33, policyNumber);
        huon.enter();

        String error = huon.readErrorMessage();
        String errorCode = huon.extractErrorCode();
        if (errorCode.equalsIgnoreCase("6044")) {
            if (reporter != null)
                reporter.writeError("Capture policy " + policyNumber + " failed because the policy is not in HUON.");
            throw new HuonException(" Capture-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
        }

        huon.waitForScreens(new String[]{"PP510", "PP618"});
        huon.input(3, 13, "BC");
        huon.enter();
        huon.waitForScreen("WBO530");

        billPlan = huon.readFromField(6, 23, 26).trim();


        if (billPlan.endsWith("TH"))
            billPlan = Policy.MONTHLY;
        else
            billPlan = Policy.ANNUAL;
        return billPlan;
    }
}
