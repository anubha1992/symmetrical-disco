package au.com.iag.execution.common.listofbusiness.service;

import au.com.iag.execution.common.builders.security.SecurityTokenBuilder;

import au.com.iag.execution.common.core.builders.ResponseBuilder;

import au.com.iag.execution.listofbusinessapi.model.business.ListOfBusinessResponse;

import au.com.iag.glados.common.GladosEnrichmentService;

import io.restassured.response.Response;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.io.IOException;

import java.util.HashMap;
import java.util.Map;

import static au.com.iag.glados.model.constants.GladosConstants.*;

import static org.apache.http.HttpStatus.*;

@Service
public class ListOfBusinessService {

    @Autowired private SecurityTokenBuilder securityTokenBuilder;
    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private ResponseBuilder responseBuilder;

    public ListOfBusinessResponse getListOfBusiness(final String partyId) throws IOException {
        Response response = gladosEnrichmentService.sendGetRequest(
                getMandatoryHeaders(), "/internal/services/party-crods/list-of-business/" + partyId,"", SC_OK);
        return responseBuilder.buildResponse(response, ListOfBusinessResponse.class);
    }

    private Map<String, Object> getMandatoryHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityTokenBuilder.getSystemSecurityToken(false));
        requestHeaders.put(X_IAG_AGENT_ID, "INT");
        requestHeaders.put(X_IAG_SALES_CHANNEL, "ONLINE");
        requestHeaders.put(X_IAG_USER, "WEBCGU");
        return requestHeaders;
    }
}
