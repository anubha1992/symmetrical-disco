package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class TaxiBenefit implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("entitlement")
    private String entitlement;
    @JsonProperty("fare_limit")
    private String fareLimit;
    @JsonProperty("journey_limit")
    private String journeyLimit;


    @ApiModelProperty(
            value = "describes the taxi benefit. Ref data  https://confluence.iag.com.au/display/GICP/CC+Taxi+Benefit+Entitlement",
            example = "standard",
            required = false
    )
    public String getEntitlement() {
        return entitlement;
    }

    @ApiModelProperty(
            value = "$ limit for the taxi fare",
            required = false
    )
    public String getFareLimit() {
        return fareLimit;
    }

    @ApiModelProperty(
            value = "distance limit for taxi benefit (kms)",
            required = false
    )
    public String getJourneyLimit() {
        return journeyLimit;
    }


}