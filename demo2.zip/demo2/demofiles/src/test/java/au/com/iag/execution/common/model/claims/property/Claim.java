package au.com.iag.execution.common.model.claims.property;

import au.com.iag.glados.common.serializers.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.time.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Claim implements Serializable {
    private static final long serialVersionUID = 7026418328586378208L;
    @JsonDeserialize(using = CustomDateDeserializer.class)
    @JsonSerialize(using = CustomDateSerializer.class)
    private OffsetDateTime dateOfLoss;
    private ClaimReporter claimReporter = new ClaimReporter();
    private MainContact primaryContact = new MainContact();
    private List<Person> relatedContacts;
    private List<Official> officials;
    private String generalNatureOfLoss;
    private String descriptionOfLoss;
    private String fullDescriptionOfLoss;
    private String causeOfLoss;
    private String lodgementLineOfBusiness;
    private ReportingChannel reportingChannel;
    private Address locationOfLoss = new Address();
    private String atFaultParty;
    private String policyIdentifier;
    private Indicator claimIndicator;
    private List<Incident> incidents;
    private List<Note> notes = new ArrayList<>();
    private EventQuestions eventQuestions;
    private String declarationConfirmed;
    private List<InsuredPreviousLossDetails> insuredPreviousLossDetails = new ArrayList<>();
    private boolean werePoliceNotified;
    private String propertyHasDualInsurance;
    private String dualInsuranceNumber;
    private String dualInsuranceDetails;
    private String insuredHasPreviousLoss;

    private String riskType;

    public String getPropertyHasDualInsurance() {   return propertyHasDualInsurance;   }

    public void setPropertyHasDualInsurance(String propertyHasDualInsurance) { this.propertyHasDualInsurance = propertyHasDualInsurance;    }

    public String getDualInsuranceNumber() { return dualInsuranceNumber;    }

    public void setDualInsuranceNumber(String dualInsuranceNumber) { this.dualInsuranceNumber = dualInsuranceNumber;    }

    public String getDualInsuranceDetails() { return dualInsuranceDetails;  }

    public void setDualInsuranceDetails(String dualInsuranceDetails) { this.dualInsuranceDetails = dualInsuranceDetails;  }

    public String getInsuredHasPreviousLoss() { return insuredHasPreviousLoss; }

    public void setInsuredHasPreviousLoss(String insuredHasPreviousLoss) { this.insuredHasPreviousLoss = insuredHasPreviousLoss;   }

    public String getPoliceIncidentNumber() { return policeIncidentNumber; }

    public void setPoliceIncidentNumber(String policeIncidentNumber) { this.policeIncidentNumber = policeIncidentNumber;   }

    private String policeIncidentNumber;

    public boolean isWerePoliceNotified() {  return werePoliceNotified; }

    public void setWerePoliceNotified(boolean werePoliceNotified) { this.werePoliceNotified = werePoliceNotified;   }

    public String getDeclarationConfirmed() { return declarationConfirmed; }

    public void setDeclarationConfirmed(String declarationConfirmed) { this.declarationConfirmed = declarationConfirmed; }

    public String getFullDescriptionOfLoss() { return fullDescriptionOfLoss;  }

    public void setFullDescriptionOfLoss(String fullDescriptionOfLoss) { this.fullDescriptionOfLoss = fullDescriptionOfLoss;    }

    public OffsetDateTime getDateOfLoss() {
        return dateOfLoss;
    }

    public void setDateOfLoss(OffsetDateTime dateOfLoss) {
        this.dateOfLoss = dateOfLoss;
    }

    public ClaimReporter getClaimReporter() {
        return claimReporter;
    }

    public void setClaimReporter(ClaimReporter claimReporter) {
        this.claimReporter = claimReporter;
    }

    public MainContact getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(MainContact primaryContact) {
        this.primaryContact = primaryContact;
    }

    public List<Person> getRelatedContacts() {
        return relatedContacts;
    }

    public void setRelatedContacts(List<Person> relatedContacts) {
        this.relatedContacts = relatedContacts;
    }

    public String getGeneralNatureOfLoss() {
        return generalNatureOfLoss;
    }

    public void setGeneralNatureOfLoss(String generalNatureOfLoss) {
        this.generalNatureOfLoss = generalNatureOfLoss;
    }


    public String getCauseOfLoss() {
        return causeOfLoss;
    }

    public void setCauseOfLoss(String causeOfLoss) {
        this.causeOfLoss = causeOfLoss;
    }

    public String getDescriptionOfLoss() {
        return descriptionOfLoss;
    }

    public void setDescriptionOfLoss(String descriptionOfLoss) {
        this.descriptionOfLoss = descriptionOfLoss;
    }

    public Address getLocationOfLoss() {
        return locationOfLoss;
    }

    public void setLocationOfLoss(Address locationOfLoss) {
        this.locationOfLoss = locationOfLoss;
    }

    public String getPolicyIdentifier() {
        return policyIdentifier;
    }

    public void setPolicyIdentifier(String policyIdentifier) {
        this.policyIdentifier = policyIdentifier;
    }

    public List<Note> getNotes() {
        return notes;
    }

    public void setNotes(List<Note> notes) {
        this.notes = notes;
    }

    public String getLodgementLineOfBusiness() {
        return lodgementLineOfBusiness;
    }

    public void setLodgementLineOfBusiness(String lodgementLineOfBusiness) {
        this.lodgementLineOfBusiness = lodgementLineOfBusiness;
    }

    public ReportingChannel getReportingChannel() {
        return reportingChannel;
    }

    public void setReportingChannel(ReportingChannel reportingChannel) {
        this.reportingChannel = reportingChannel;
    }

    public Indicator getClaimIndicator() {
        return claimIndicator;
    }

    public void setClaimIndicator(Indicator claimIndicator) {
        this.claimIndicator = claimIndicator;
    }

    public String getAtFaultParty() {
        return atFaultParty;
    }

    public void setAtFaultParty(String atFaultParty) {
        this.atFaultParty = atFaultParty;
    }

    public List<Incident> getIncidents() {
        return incidents;
    }

    public void setIncidents(List<Incident> incidents) {
        this.incidents = incidents;
    }

    public EventQuestions getEventQuestions() {
        return eventQuestions;
    }

    public void setEventQuestions(EventQuestions eventQuestions) {
        this.eventQuestions = eventQuestions;
    }

    public List<InsuredPreviousLossDetails> getInsuredPreviousLossDetails() {
        return insuredPreviousLossDetails;
    }

    public void setInsuredPreviousLossDetails(List<InsuredPreviousLossDetails> insuredPreviousLossDetails) {
        this.insuredPreviousLossDetails = insuredPreviousLossDetails;
    }
    public List<Official> getOfficials() {
        return officials;
    }
    public void setOfficials(List<Official> officials) {
        this.officials = officials;
    }
    public String getRiskType() {        return riskType;    }
    public void setRiskType(String riskType) {        this.riskType = riskType;    }
}
