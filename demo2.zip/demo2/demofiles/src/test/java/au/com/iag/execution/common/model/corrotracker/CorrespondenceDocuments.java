package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class CorrespondenceDocuments {
    @JsonProperty("documents")
    private List<CorrespondenceDocument> documents;

    public void setDocuments(List<CorrespondenceDocument> documents){
        this.documents = documents;
    }

    public List<CorrespondenceDocument> getDocuments(){
        return documents;
    }

    @Override
    public String toString(){
        return
                "Documents{" +
                        "documents = '" + documents + '\'' +
                        "}";
    }
}
