package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class QuoteHistory implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("completing_channel")
    private String completingChannel ;
    @JsonProperty("originating_channel")
    private String originatingChannel ;
    @JsonProperty("quote_number")
    private String quoteNumber ;

  
    @ApiModelProperty(
        value = "Quote completing channel [Ref Data: sales_channel]",
        example = "CONTACT_CENTRE",
        required = false
    )
    public String getCompletingChannel() {
       return completingChannel;
    }
 
    @ApiModelProperty(
        value = "Quote originating channel [Ref Data: sales_channel]",
        example = "ONLINE",
        required = false
    )
    public String getOriginatingChannel() {
       return originatingChannel;
    }
 
    @ApiModelProperty(
        value = "Quote number",
        example = "QTE1234567",
        required = false
    )
    public String getQuoteNumber() {
       return quoteNumber;
    }
 

}