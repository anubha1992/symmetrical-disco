package au.com.iag.execution.common.model.huon.util;

import java.lang.reflect.*;
import java.text.*;
import java.util.*;


public class PremiumBreakdown {

    private String coverage = "";
    private String basicPremium = "";
    private String otherCharges = "";
    private String gst = "";
    private String stampDuty = "";
    private String tax = "";        //tax = gst + stampDuty
    private String gross = "";
    private String commission = "";
    private String net = "";

    private String monthlybasicPremium = "";
    private String monthlyotherCharges = "";
    private String monthlygst = "";
    private String monthlystampDuty = "";
    private String monthlytax = "";
    private String monthlygross = "";
    private String monthlycommission = "";
    private String monthlynet = "";

    private String premiumDifference = "";
    private String premiumNew = "";
    private String reason = "";
    private String coveragesSumInsured = "";

    // Chetan Added (Date 22-Feb-2018) - 8 variables for Renewal
    private String basicRenewalPremium = "";
    private String otherChargesRenewal = "";
    private String gstRenewal = "";
    private String stampDutyRenewal = "";
    private String taxRenewal = "";        //tax = gst + stampDuty
    private String grossRenewal = "";
    private String commissionRenewal = "";
    private String netRenewal = "";


    public String getCoveragesSumInsured() {
        return coveragesSumInsured;
    }

    public void setCoveragesSumInsured(String coveragesSumInsured) {
        this.coveragesSumInsured = coveragesSumInsured;
    }

    public String getCoverage() {
        return coverage;
    }

    public void setCoverage(String coverage) {
        this.coverage = coverage;
    }

    public String getBasicPremium() {
        return basicPremium;
    }

    public void setBasicPremium(String basicPremium) {
        this.basicPremium = basicPremium.trim().replaceAll(",", "");
        ;
    }

    public String getOtherCharges() {
        return otherCharges;
    }

    public void setOtherCharges(String otherCharges) {
        this.otherCharges = otherCharges.trim().replaceAll(",", "");
        ;
    }

    public String getGst() {
        return gst;
    }

    public void setGst(String gst) {
        this.gst = gst.trim().replaceAll(",", "");
        ;
    }

    public String getStampDuty() {
        return stampDuty;
    }

    public void setStampDuty(String stampDuty) {
        this.stampDuty = stampDuty.trim().replaceAll(",", "");
        ;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax.trim().replaceAll(",", "");
        ;
    }

    public String getGross() {
        return gross;
    }

    public void setGross(String gross) {
        this.gross = gross.trim().replaceAll(",", "");
        ;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission.trim().replaceAll(",", "");
        ;
    }

    public String getNet() {
        return net;
    }

    public void setNet(String net) {
        this.net = net.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyBasicPremium() {
        return monthlybasicPremium;
    }

    public void setmonthlyBasicPremium(String monthlybasicPremium) {
        this.monthlybasicPremium = monthlybasicPremium.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyOtherCharges() {
        return monthlyotherCharges;
    }

    public void setmonthlyOtherCharges(String monthlyotherCharges) {
        this.monthlyotherCharges = monthlyotherCharges.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyGst() {
        return monthlygst;
    }

    public void setmonthlyGst(String monthlygst) {
        this.monthlygst = monthlygst.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyStampDuty() {
        return monthlystampDuty;
    }

    public void setmonthlyStampDuty(String monthlystampDuty) {
        this.monthlystampDuty = monthlystampDuty.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyTax() {
        return monthlytax;
    }

    public void setmonthlyTax(String monthlytax) {
        this.monthlytax = monthlytax.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyGross() {
        return monthlygross;
    }

    public void setmonthlyGross(String monthlygross) {
        this.monthlygross = monthlygross.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyCommission() {
        return monthlycommission;
    }

    public void setmonthlyCommission(String monthlycommission) {
        this.monthlycommission = monthlycommission.trim().replaceAll(",", "");
        ;
    }

    public String getmonthlyNet() {
        return monthlynet;
    }

    public void setmonthlyNet(String monthlynet) {
        this.monthlynet = monthlynet.trim().replaceAll(",", "");
        ;
    }

    // Chetan Added (Date 22-Feb-2018) - 16 Get and Set properties for  for Renewal

    public String getBasicRenewalPremium() {
        return basicRenewalPremium;
    }

    public void setBasicRenewalPremium(String basicRenewalPremium) {
        this.basicRenewalPremium = basicRenewalPremium.trim().replaceAll(",", "");
        ;
    }

    public String getOtherChargesRenewal() {
        return otherChargesRenewal;
    }

    public void setOtherChargesRenewal(String otherChargesRenewal) {
        this.otherChargesRenewal = otherChargesRenewal.trim().replaceAll(",", "");
        ;
    }

    public String getGstRenewal() {
        return gstRenewal;
    }

    public void setGstRenewal(String gstRenewal) {
        this.gstRenewal = gstRenewal.trim().replaceAll(",", "");
        ;
    }

    public String getStampDutyRenewal() {
        return stampDutyRenewal;
    }

    public void setStampDutyRenewal(String stampDutyRenewal) {
        this.stampDutyRenewal = stampDutyRenewal.trim().replaceAll(",", "");
        ;
    }

    public String getTaxRenewal() {
        return taxRenewal;
    }

    public void setTaxRenewal(String taxRenewal) {
        this.taxRenewal = taxRenewal.trim().replaceAll(",", "");
        ;
    }

    public String getGrossRenewal() {
        return grossRenewal;
    }

    public void setGrossRenewal(String grossRenewal) {
        this.grossRenewal = grossRenewal.trim().replaceAll(",", "");
        ;
    }

    public String getCommissionRenewal() {
        return commissionRenewal;
    }

    public void setCommissionRenewal(String commissionRenewal) {
        this.commissionRenewal = commissionRenewal.trim().replaceAll(",", "");
        ;
    }

    public String getNetRenewal() {
        return netRenewal;
    }

    public void setNetRenewal(String netRenewal) {
        this.netRenewal = netRenewal.trim().replaceAll(",", "");
        ;
    }

    //  End -- (Date 22-Feb-2018) - 16 Get and Set properties for  for Renewal

    public String getPremiumDifference() {
        return premiumDifference;
    }

    public void setPremiumDifference(String premiumDifference) {
        this.premiumDifference = premiumDifference;
    }

    public String getPremiumNew() {
        return premiumNew;
    }

    public void setPremiumNew(String premiumNew) {
        this.premiumNew = premiumNew;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public boolean equals(PremiumBreakdown otherPremiumBreakDown, HashMap<String, String> assertMessage) throws IllegalArgumentException, IllegalAccessException {
        boolean totalResult = true;

        Class<?> thisClass = this.getClass();
//		Class<?> thatClass = otherPremiumBreakDown.getClass();
        Field[] thisFields = thisClass.getDeclaredFields();
//		Field[] thatFields = thatClass.getDeclaredFields();
        for (int i = 0; i < thisFields.length; i++) {
            if (Modifier.isStatic(thisFields[i].getModifiers()))
                continue;

            if (thisFields[i].getName().equals("coverage"))
                continue;

            if (thisFields[i].getName().equals("tax"))
                continue;

            thisFields[i].setAccessible(true);
//			thatFields[i].setAccessible(true);

            //
            String thisStr = (String) thisFields[i].get(this);
            String thatStr = (String) thisFields[i].get(otherPremiumBreakDown);
            thisStr = thisStr.trim().replaceAll(",", "");
            thatStr = thatStr.trim().replaceAll(",", "");

            boolean isSame = false;

            if (thisStr.isEmpty() || thatStr.isEmpty()) {
                if (thisStr.equalsIgnoreCase(thatStr)) {
                    isSame = true;
                }
            } else {
                float thisFloat = Float.parseFloat(thisStr);
                float thatFloat = Float.parseFloat(thatStr);

                if (thisFloat == thatFloat) {
                    isSame = true;
                }
            }
//			double thisFloat = -999.0;
//			double thatFloat = -888.0;
//			boolean isFloat = false;
//			try {
//				thisFloat = Double.parseDouble(thisStr);
//				thatFloat = Double.parseDouble(thatStr);
//				isFloat = true;
//			} catch (NumberFormatException ex) {
//				isFloat = false;
//			}
//			
//			boolean isSame = false;
//			if (isFloat) {
//				if (thisFloat == thatFloat) {
//					isSame = true;
//				}
//			} else {
//				if (thisStr.equalsIgnoreCase(thatStr)) {
//					isSame = true;
//				}
//			}


            if (!isSame) {
                totalResult = false;
                if (!this.coverage.isEmpty())
                    assertMessage.put(this.coverage + "_" + thisFields[i].getName(), thisFields[i].get(this) + ";" + thisFields[i].get(otherPremiumBreakDown));
                else
                    assertMessage.put("Policy" + "_" + thisFields[i].getName(), thisFields[i].get(this) + ";" + thisFields[i].get(otherPremiumBreakDown));
            }

        }

        return totalResult;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        sb.append(super.toString());

        Class<?> myClass = this.getClass();
        String thisName = PremiumBreakdown.class.getName();
        while (!myClass.getName().equalsIgnoreCase(thisName)) {
            myClass = myClass.getSuperclass();
        }

        try {
            Field[] fields = myClass.getDeclaredFields();

            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers()))
                    continue;
                field.setAccessible(true);
                sb.append(field.getName());
                sb.append("=");
                if (field.getType().getName().endsWith("Date")) {
                    Date date = (Date) field.get(this);
                    if (date != null) {
                        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                        sb.append(formatter.format(date));
                    } else {
                        sb.append("");
                    }
                } else {
                    sb.append(field.get(this));
                }
                sb.append(";");
            }
        } catch (IllegalAccessException iae) {

        }


        sb.append("]");
        return sb.toString();
    }

}
