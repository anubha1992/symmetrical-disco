package au.com.iag.execution.bindandissueapi.verifiers;

import au.com.iag.glados.service.SplunkService;
import org.assertj.core.api.SoftAssertions;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class SessionAffinityVerifier {

    @Autowired private SplunkService splunkService;

    public void verifySessionAffinity(final String traceId) {
        final Map<String, String> cookieDetails = getCookieDetails(traceId);
        final SoftAssertions softly = new SoftAssertions();

        softly.assertThat(cookieDetails.keySet())
                .as("")
                .containsExactlyInAnyOrderElementsOf(List.of("policycenter-ingress"));

        softly.assertThat(cookieDetails.values().size())
                .as("")
                .isEqualTo(1);

        softly.assertThat(cookieDetails.keySet().size())
                .as("Assert -> SessionAffinity:cookie:size")
                .isEqualTo(1);

        softly.assertThat(cookieDetails.get("policycenter-ingress"))
                .as("Assert -> SessionAffinity:cookie:value")
                .isNotEmpty();

        softly.assertThat(cookieDetails.get("policycenter-ingress").length())
                .as("Assert -> SessionAffinity:cookie:value:length")
                .isLessThanOrEqualTo(32);

        softly.assertAll();
    }

    public void verifySessionAffinity(final String traceId, final String sessionId) {
        final Map<String, String> cookieDetails = getCookieDetails(traceId);
        final SoftAssertions softly = new SoftAssertions();

        softly.assertThat(cookieDetails.keySet().size())
                .as("Assert -> SessionAffinity:cookie:size")
                .isEqualTo(1);

        softly.assertThat(cookieDetails.get("policycenter-ingress"))
                .as("Assert -> SessionAffinity:cookie:value")
                .isEqualTo(sessionId);
        softly.assertAll();
    }

    private Map<String, String> getCookieDetails(final String traceId) {
        final String requestHeaders = splunkService
                .fetchRequestHeaders(traceId, "policy.iagcloud.net/master/pc/rest/iag/v1/policy-interceptor/policies");
        final JSONObject requestHeadersJson = new JSONObject(requestHeaders);
        final String cookie = requestHeadersJson.getJSONArray("Cookie").getString(0);
        return Arrays.stream(cookie.split("; "))
                .map(entry -> Map.entry(entry.split("=")[0], entry.split("=")[1]))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }
}
