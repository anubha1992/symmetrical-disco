package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Exposure implements Serializable {

    private static final long serialVersionUID = 1L;

    private String exposureId;
    private Coverage coverage;
    private String lossPartyType;
    private String exposureType;

    public String getExposureType() { return exposureType;  }

    public void setExposureType(String exposureType) { this.exposureType = exposureType;    }

    public String getExposureId() {
        return exposureId;
    }

    public void setExposureId(String exposureId) {
        this.exposureId = exposureId;
    }

    public Coverage getCoverage() {
        return coverage;
    }

    public void setCoverage(Coverage coverage) {
        this.coverage = coverage;
    }

    public String getLossPartyType() {
        return lossPartyType;
    }

    public void setLossPartyType(String lossPartyType) {
        this.lossPartyType = lossPartyType;
    }

}
