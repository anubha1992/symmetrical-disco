package au.com.iag.execution.common.constants;

import org.springframework.stereotype.*;

@Component
public class RepxConstants {

    //Repx database
    public static final String DB_REPX_SUPPLIER_ID = "orm_supplier_id";
    public static final String DB_REPX_BOOKING_DATE = "booking_day";
    public static final String DB_REPX_POLICY_REGO = "policy_rego";
    public static final String DB_REPX_CLAIM_NO = "claim_no";
    public static final String DB_REPX_VENDOR_CODE = "vendor_code";
    public static final String DB_REPX_REPAIRER_TOKEN = "repairer_token";
}
