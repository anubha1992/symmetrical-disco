package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "Contains payment related information for the policy")
public class PaymentInfo implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("billing_plan")
    private String billingPlan;
    @JsonProperty("next_payment_due_date")
    private java.time.LocalDate nextPaymentDueDate;

  
    @ApiModelProperty(
        value = "Billing plan. [Ref Data: billing_plan]",
        example = "Annual",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getBillingPlan() {
       return billingPlan;
    }
 
    @ApiModelProperty(
        value = "The date the next payment is due.",
        example = "2019-12-20T00:00:00.000Z",
        required = false
    )
    public java.time.LocalDate getNextPaymentDueDate() {
       return nextPaymentDueDate;
    }
 

}