package au.com.iag.execution.complaintmanagementapi.service;

import static org.apache.http.HttpStatus.SC_OK;
import static org.apache.http.HttpStatus.SC_CREATED;
import static org.junit.Assert.assertEquals;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import au.com.iag.execution.complaintmanagementapi.model.NotifyCaseArtifact;
import au.com.iag.glados.common.GladosEnrichmentService;
import au.com.iag.glados.service.SchemaValidationService;
import io.restassured.response.Response;

@Service
public class NotifyCaseService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired
    private SchemaValidationService schemaValidationService;

    @Value("${test.schema.file.path}")
    private String schemaFilePath;

    public String getApiUrl() {
        return gladosEnrichmentService.getUrl();
    }

    public Response executeNotifycase(NotifyCaseArtifact notifyCaseArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequest(
                notifyCaseArtifact.getHeaders(),
                notifyCaseArtifact.getPath(),
                notifyCaseArtifact.getNotifyCaseRequest(),
                expectStatusCode);
        validateSchema(expectStatusCode, response, "/definitions/ResponsePayload");
        return checkResponseStatus(expectStatusCode, response);
    }
    public Response executeUpdateCase(NotifyCaseArtifact notifyCaseArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPutRequest(
                notifyCaseArtifact.getHeaders(),
                notifyCaseArtifact.getPath() + notifyCaseArtifact.getCaseId(),
                notifyCaseArtifact.getNotifyCaseRequest(),
                expectStatusCode);
        validateSchema(expectStatusCode, response, "/definitions/ResponsePayload");
        return checkResponseStatus(expectStatusCode, response);
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }

    private void validateSchema(int statusCode, Response response, String url) {
        if (statusCode == SC_OK || statusCode == SC_CREATED) {
            schemaValidationService.validate(response, schemaFilePath, url);
        }
    }

    public void getSwaggerSchema() {
        schemaValidationService.getSwaggerSchema(getApiUrl(), schemaFilePath);
    }

}
