package au.com.iag.execution.bindandissueapi.verifiers;

import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueRequest;
import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueResponse;

import au.com.iag.glados.service.JsonMapperService;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;

import org.assertj.core.api.SoftAssertions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;

@Component
public class BindAndIssueVerifier {

    @Autowired private JsonMapperService jsonMapperService;

    public BindAndIssueResponse buildBindAndIssueResponse(Response response) throws IOException {
        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(
                objectMapper.writeValueAsString(response.jsonPath().get()),
                BindAndIssueResponse.class);
    }

    public void verifyBindAndIssue(final Response response, final String quoteNumber) throws IOException {
        final BindAndIssueResponse bindAndIssue = buildBindAndIssueResponse(response);
        final SoftAssertions softly = new SoftAssertions();

        softly.assertThat(bindAndIssue.getPolicyDetails().getStatus())
                .as("Assert -> BindAndIssue::status")
                .isEqualTo("BOUND");

        softly.assertThat(bindAndIssue.getPolicyDetails().getPolicyNumber())
                .as("Assert -> BindAndIssue::policyNumber")
                .isNotBlank()
                .isNotEqualTo(quoteNumber);

        softly.assertThat(bindAndIssue.getPolicyDetails().getPolicyNumber())
                .as("Assert -> BindAndIssue::quoteNumber")
                .isNotBlank()
                .isEqualTo(quoteNumber);
    }
}
