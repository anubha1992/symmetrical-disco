package au.com.iag.execution.common.service.notifyapi;

import static org.apache.http.HttpStatus.SC_CREATED;
import static org.apache.http.HttpStatus.SC_OK;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.com.iag.core.model.exception.ErrorResponse;
import au.com.iag.execution.notifyapi.model.PartyRequestArtifact;
import au.com.iag.execution.notifyapi.model.PartyResponseArtifact;
import au.com.iag.execution.partyapi.model.business.Individual;
import au.com.iag.execution.partyapi.model.business.Organisation;
import au.com.iag.execution.partyapi.model.business.SaveIndividualResponse;
import au.com.iag.execution.partyapi.model.business.SaveOrganisationResponse;
import au.com.iag.glados.common.GladosEnrichmentService;
import io.restassured.response.Response;

//import au.com.iag.execution.notifyapi.model.party.*;

/// sends the request

@Component
public class CreatePartyForNotifyService {
    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private PartyResponseArtifact partyResponseArtifact;


    public PartyResponseArtifact<Individual> executeCreateIndividual(PartyRequestArtifact<Individual> partyRequestArtifact, int expectStatusCode) {
        Response response = sendIndividualPost(partyRequestArtifact, expectStatusCode);
        partyResponseArtifact.setResponse(response);
        if (expectStatusCode != SC_OK && expectStatusCode != SC_CREATED && expectStatusCode != SC_UNPROCESSABLE_ENTITY) {
            partyResponseArtifact.setErrorResponse(response.as(ErrorResponse.class));
        } else if (expectStatusCode == SC_UNPROCESSABLE_ENTITY) {
            partyResponseArtifact.setValidationErrors(response.as(SaveIndividualResponse.class).getErrors());
            assertTrue(!partyResponseArtifact.getValidationErrors().isEmpty(), "expected validation errors, but there was none");
        } else {
                partyResponseArtifact.setIndividual(response.as(SaveIndividualResponse.class).getIndividual());
                partyResponseArtifact.setParty(response.as(SaveIndividualResponse.class).getIndividual());
        }
        return partyResponseArtifact;
    }

    public PartyResponseArtifact<Organisation> executeCreateOrganisation(PartyRequestArtifact<Organisation> partyRequestArtifact, int expectStatusCode) {
        Response response = sendOrganisationPost(partyRequestArtifact, expectStatusCode);
        partyResponseArtifact.setResponse(response);
        if (expectStatusCode != SC_OK && expectStatusCode != SC_CREATED && expectStatusCode != SC_UNPROCESSABLE_ENTITY) {
            partyResponseArtifact.setErrorResponse(response.as(ErrorResponse.class));
        } else if (expectStatusCode == SC_UNPROCESSABLE_ENTITY) {
            partyResponseArtifact.setValidationErrors(response.as(SaveOrganisationResponse.class).getErrors());
            assertTrue(!partyResponseArtifact.getValidationErrors().isEmpty(), "expected validation errors, but there was none");
        } else {
            partyResponseArtifact.setOrganisation(response.as(SaveOrganisationResponse.class).getOrganisation());
            partyResponseArtifact.setParty(response.as(SaveOrganisationResponse.class).getOrganisation());
        }
        return partyResponseArtifact;
    }

    public Response sendIndividualPost(PartyRequestArtifact<Individual> partyRequestArtifact, int expectStatusCode){
        Response response = gladosEnrichmentService.sendPostRequest(
                partyRequestArtifact.getHeaders(),
                partyRequestArtifact.getPath(),
                partyRequestArtifact.getRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response sendOrganisationPost(PartyRequestArtifact<Organisation> partyRequestArtifact, int expectStatusCode){
        Response response = gladosEnrichmentService.sendPostRequest(
                partyRequestArtifact.getHeaders(),
                partyRequestArtifact.getPath(),
                partyRequestArtifact.getRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }


}
