package au.com.iag.execution.common.model.huon.util;

import java.text.*;
import java.util.*;

/**
 * It is a common data handler class to provide some common data functions, e.g. get different dates, get random string, convert from motor driver experience to age got license.
 */
public class DataHandler {

    /**
     * All the methods in this class should be static methods, so we don't need
     * to call constructor to create an object in order to use the methods
     */
    public DataHandler() {

    }

    /**
     * Get today as a string
     *
     * @return format is "dd/MM/yyyy", like "01/07/2013"
     */
    public static String todayString() {
        Calendar cal = Calendar.getInstance(); // get today
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String today = formatter.format(cal.getTime());

        return today;
    }

    /**
     * Get today as a Date
     *
     * @return today
     */
    public static Date today() {
        Calendar cal = Calendar.getInstance(); // get today
        return cal.getTime();
    }

    /**
     * Get today of last year
     *
     * @return Date
     */
    public static Date todayLastYear() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.YEAR, -1);
        return cal.getTime();
    }

    /**
     * Get today of last year as a string
     *
     * @return string like "01/07/2013"
     */
    public static String todayLastYearString() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.YEAR, -1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(cal.getTime());
    }

    /**
     * Get today of next year
     *
     * @return Date
     */
    public static Date todayNextYear() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.YEAR, 1);
        return cal.getTime();
    }

    /**
     * Get today of next year as a string
     *
     * @return string like "01/07/2013"
     */
    public static String todayNextYearString() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.YEAR, 1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(cal.getTime());
    }

    /**
     * Get tomorrow as a Date
     *
     * @return
     */
    public static Date tomorrow() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    public static Date lastQuarter() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.DAY_OF_MONTH, -95);
        return cal.getTime();
    }

    public static Date lastHalfYear() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.DAY_OF_MONTH, -195);
        return cal.getTime();
    }

    /**
     * Get tomorrow as a string
     *
     * @return format is "dd/MM/yyyy", like "01/07/2013"
     */
    public static String tomorrowString() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.DAY_OF_MONTH, 1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String tomorrow = formatter.format(cal.getTime());

        return tomorrow;
    }

    /**
     * Get tomorrow of last year
     *
     * @return Date
     */
    public static Date tomorrowLastYear() {
        Calendar cal = Calendar.getInstance(); // get tomorrow
        cal.add(Calendar.DAY_OF_MONTH, 1);
        cal.add(Calendar.YEAR, -1);
        return cal.getTime();
    }

    /**
     * Get tomorrow of last year as a string
     *
     * @return string like "01/07/2013"
     */
    public static String tomorrowLastYearString() {
        Calendar cal = Calendar.getInstance(); // get tomorrow
        cal.add(Calendar.DAY_OF_MONTH, 1);
        cal.add(Calendar.YEAR, -1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(cal.getTime());
    }

    /**
     * Get tomorrow of next year
     *
     * @return Date
     */
    public static Date tomorrowNextYear() {
        Calendar cal = Calendar.getInstance(); // get tomorrow
        cal.add(Calendar.DAY_OF_MONTH, 1);
        cal.add(Calendar.YEAR, 1);
        return cal.getTime();
    }

    /**
     * Get tomorrow of next year as a string
     *
     * @return string like "01/07/2013"
     */
    public static String tomorrowNextYearString() {
        Calendar cal = Calendar.getInstance(); // get tomorrow
        cal.add(Calendar.DAY_OF_MONTH, 1);
        cal.add(Calendar.YEAR, 1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(cal.getTime());
    }

    /**
     * Get specified date's tomorrow
     *
     * @param date the specified date "dd/MM/yyyy"
     * @return format is "dd/MM/yyyy", like "01/07/2013"
     */
    public static String tomorrow(String date) throws ParseException {
        Calendar cal = Calendar.getInstance(); // get today
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date d = formatter.parse(date);
        cal.setTime(d);
        cal.add(Calendar.DAY_OF_MONTH, 1);

        String tomorrow = formatter.format(cal.getTime());

        return tomorrow;
    }

    /**
     * Get yesterday as a Date
     *
     * @return
     */
    public static Date yesterday() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.DAY_OF_MONTH, -1);

        return cal.getTime();
    }

    /**
     * Get yesterday
     *
     * @return format is "dd/MM/yyyy", like "01/07/2013"
     */
    public static String yesterdayString() {
        Calendar cal = Calendar.getInstance(); // get today
        cal.add(Calendar.DAY_OF_MONTH, -1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String yesterday = formatter.format(cal.getTime());

        return yesterday;
    }

    /**
     * Get yesterday of last year
     *
     * @return Date
     */
    public static Date yesterdayLastYear() {
        Calendar cal = Calendar.getInstance(); // get yesterday
        cal.add(Calendar.DAY_OF_MONTH, -1);
        cal.add(Calendar.YEAR, -1);
        return cal.getTime();
    }

    /**
     * Get yesterday of last year as a string
     *
     * @return string like "01/07/2013"
     */
    public static String yesterdayLastYearString() {
        Calendar cal = Calendar.getInstance(); // get yesterday
        cal.add(Calendar.DAY_OF_MONTH, -1);
        cal.add(Calendar.YEAR, -1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(cal.getTime());
    }

    /**
     * Get yesterday of next year
     *
     * @return Date
     */
    public static Date yesterdayNextYear() {
        Calendar cal = Calendar.getInstance(); // get yesterday
        cal.add(Calendar.DAY_OF_MONTH, -1);
        cal.add(Calendar.YEAR, 1);
        return cal.getTime();
    }

    /**
     * Get yesterday of next year as a string
     *
     * @return string like "01/07/2013"
     */
    public static String yesterdayNextYearString() {
        Calendar cal = Calendar.getInstance(); // get yesterday
        cal.add(Calendar.DAY_OF_MONTH, -1);
        cal.add(Calendar.YEAR, 1);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(cal.getTime());
    }

    /**
     * Get specified date's yesterday
     *
     * @param date the specified date "dd/MM/yyyy"
     * @return format is "dd/MM/yyyy", like "01/07/2013"
     */
    public static String yesterday(String date) throws ParseException {
        Calendar cal = Calendar.getInstance(); // get today
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date d = formatter.parse(date);
        cal.setTime(d);
        cal.add(Calendar.DAY_OF_MONTH, -1);

        String tomorrow = formatter.format(cal.getTime());

        return tomorrow;
    }

    /**
     * Offset date from today.
     *
     * @param offset format is "+n" ("n" = "+n",  or "-n": n is a number
     * @return
     */
    public static Date dateOffset(String offset) throws ParseException {
        int n = Integer.parseInt(offset);

        Calendar cal = Calendar.getInstance();

        cal.add(Calendar.DAY_OF_MONTH, n);
        return cal.getTime();
    }

    /**
     * Get a date by string
     * Format is "", or "dd/MM/yyyy", or "today", or "tomorrow", or "Dn+"
     * //	 * @param effectiveDate acceptable input are (case insensitive):
     * - "" or "today"
     * - "dd/MM/yyyy": a specific date
     * - "tomorrow"
     * - "yesterday"
     * - "today-last-year"
     * - "today-next-year"
     * - "tomorrow-last-year"
     * - "tomorrow-next-year"
     * - "yesterday-last-year"
     * - "yesterday-next-year"
     * - "n" or "+n": n days after today
     * - "-n": n days before today
     */
    public static Date getDate(String strDate) throws ParseException {
        Date date = null;
        switch (strDate.toLowerCase()) {
            case "":
            case "today":
                date = DataHandler.today();
                break;
            case "tomorrow":
                date = DataHandler.tomorrow();
                break;
            case "yesterday":
                date = DataHandler.yesterday();
                break;
            case "today-last-year":
                date = DataHandler.todayLastYear();
                break;
            case "today-next-year":
                date = DataHandler.todayNextYear();
                break;
            case "tomorrow-last-year":
                date = DataHandler.tomorrowLastYear();
                break;
            case "tomorrow-next-year":
                date = DataHandler.tomorrowNextYear();
                break;
            case "yesterday-last-year":
                date = DataHandler.yesterdayLastYear();
                break;
            case "yesterday-next-year":
                date = DataHandler.yesterdayNextYear();
                break;
            default:
                //check whether it is an integer
                boolean isInt = false;
                int n;
                try {
                    n = Integer.parseInt(strDate);
                    isInt = true;
                } catch (NumberFormatException nfe) {
                    n = 0;
                    isInt = false;
                }

                if (isInt) {
                    if (n > 3650 || n < -3650) {
                        throw new ParseException("The offeset date for policy effective date is more than 10 years", 0);
                    }
                }

                if (isInt) {
                    date = DataHandler.dateOffset(strDate);
                } else {
                    // assume it is "dd/MM/yyyy" or "yyyy-MM-dd"
                    if (strDate.contains("-")) {
                        DateFormat formatter;
                        if (strDate.length() <= 8)
                            formatter = new SimpleDateFormat("yy-MM-dd");
                        else
                            formatter = new SimpleDateFormat("yyyy-MM-dd");
                        date = formatter.parse(strDate);
                    } else {
                        DateFormat formatter;
                        if (strDate.length() <= 8)
                            formatter = new SimpleDateFormat("dd/MM/yy");
                        else
                            formatter = new SimpleDateFormat("dd/MM/yyyy");
                        date = formatter.parse(strDate);
                    }
                }
                break;
        }

        return date;
    }

    /**
     * Standard formatter to return a date as string "dd/MM/yyyy"
     *
     * @param date
     * @return
     */
    public static String formatDate(Date date) {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(date);
    }

    /**
     * Parse date from a string
     *
     * @param sDate support 2 formats:
     *              - dd/MM/yyyy
     *              - ddMMyyy
     * @return
     *
     * @throws ParseException
     */
    public static Date parseDate(String sDate) throws ParseException {
        Date date = null;

        sDate = sDate.trim();
        int len = sDate.length();

        switch (len) {
            case 9:
            case 7:
                sDate = "0" + sDate;
                break;
            case 10:
            case 8:
                //do nothing
                break;
            default:
                throw new ParseException("Date string format is not a valid format (dd/MM/yyyy or ddMMyyyy):" + sDate, 0);
        }

        len = sDate.length();
        DateFormat formatter = null;
        if (len == 10)
            formatter = new SimpleDateFormat("dd/MM/yyyy");
        else
            formatter = new SimpleDateFormat("ddMMyyyy");

        date = formatter.parse(sDate);

        return date;
    }

    /**
     * In addition to input age got driver license directly, we can also input
     * the field with drive experience years as "exp:5" meaning driver
     * experience is 5 years. If so, this function is called to calculate age
     * got driver license based on date of birth, driver experience years and
     * effective date (very important).
     *
     * @param birthDate
     * @param experienceYears
     * @param effectiveDate
     * @return age got driver license
     * @throws ParseException
     */
    public static int getAgeGotLicenseByExperience(Date birthDate,
                                                   int experienceYears, Date effectiveDate) throws ParseException {
        int age = 0;

        Calendar calBirth = Calendar.getInstance();
        Calendar calEffective = Calendar.getInstance();
        calBirth.setTime(birthDate);
        calEffective.setTime(effectiveDate);
        int yearBirth = calBirth.get(Calendar.YEAR);
        int yearEffective = calEffective.get(Calendar.YEAR);
        int monthBirth = calBirth.get(Calendar.MONTH);
        int monthEffective = calEffective.get(Calendar.MONTH);

        age = yearEffective - yearBirth;
        if (monthBirth > monthEffective) {
            age--;
        } else if (monthBirth == monthEffective) {
            int dayBirth = calBirth.get(Calendar.DAY_OF_MONTH);
            int dayEffective = calEffective.get(Calendar.DAY_OF_MONTH);
            if (dayBirth > dayEffective) {
                age--;
            }
        }

        age = age - experienceYears;

        return age;
    }

    /**
     * Get drive experience years by age got license
     *
     * @param birthDate
     * @param ageGotLicense
     * @param effectiveDate
     * @return
     * @throws ParseException
     */
    public static int getDriveExperienceByAgeGotLicense(Date birthDate,
                                                        int ageGotLicense, Date effectiveDate) throws ParseException {
        int years = 0;

        Calendar calBirth = Calendar.getInstance();
        Calendar calEffective = Calendar.getInstance();
        calBirth.setTime(birthDate);
        calEffective.setTime(effectiveDate);
        int yearBirth = calBirth.get(Calendar.YEAR);
        int yearEffective = calEffective.get(Calendar.YEAR);
        int monthBirth = calBirth.get(Calendar.MONTH);
        int monthEffective = calEffective.get(Calendar.MONTH);

        int age = yearEffective - yearBirth;
        if (monthBirth > monthEffective) {
            age--;
        } else if (monthBirth == monthEffective) {
            int dayBirth = calBirth.get(Calendar.DAY_OF_MONTH);
            int dayEffective = calEffective.get(Calendar.DAY_OF_MONTH);
            if (dayBirth > dayEffective) {
                age--;
            }
        }

        years = age - ageGotLicense;

        return years;
    }

    /**
     * Get a client's age by TODAY based on his/her date fo birth
     *
     * @param dateOfBirth
     * @return age by today (The transaction date)
     */
    public static int getAgeByToday(Date dateOfBirth) {
        int age = 0;

        Calendar dob = Calendar.getInstance();
        dob.setTime(dateOfBirth);
        Calendar today = Calendar.getInstance();
        age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
            age--;
        } else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH)
                && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
            age--;
        }

        return age;
    }

    /**
     * Get age by some day
     *
     * @param dateOfBirth
     * @param someday
     * @return
     */
    public static int getAgeBySomeday(Date dateOfBirth, Date someday) {
        int age = 0;

        Calendar dob = Calendar.getInstance();
        dob.setTime(dateOfBirth);
        Calendar somedayCal = Calendar.getInstance();
        somedayCal.setTime(someday);
        age = somedayCal.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        if (somedayCal.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
            age--;
        } else if (somedayCal.get(Calendar.MONTH) == dob.get(Calendar.MONTH)
                && somedayCal.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
            age--;
        }

        return age;
    }

    /**
     * Get a random string
     *
     * @param length
     * @return
     */
    public static String randomWord(int length) {

        StringBuilder sb = new StringBuilder(length);

        char[] characters = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

//		Random randomGenerator = new Random(System.currentTimeMillis());
        Random randomGenerator = new Random(System.nanoTime());
        for (int i = 0; i < length; i++) {
            int randomInt = randomGenerator.nextInt(52);
            sb.append(characters[randomInt]);
        }

        return sb.toString();
    }

    public static String randomAlphanumeric(int length) {

        StringBuilder sb = new StringBuilder(length);

        char[] characters = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

//		Random randomGenerator = new Random(System.currentTimeMillis());
        Random randomGenerator = new Random(System.nanoTime());
        for (int i = 0; i < length; i++) {
            int randomInt = randomGenerator.nextInt(characters.length);
            sb.append(characters[randomInt]);
        }

        return sb.toString();
    }

    public static String randomNumeric(int length) {

        StringBuilder sb = new StringBuilder(length);

        char[] characters = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

        Random randomGenerator = new Random(System.nanoTime());
        for (int i = 0; i < length; i++) {
            int randomInt = randomGenerator.nextInt(characters.length);
            sb.append(characters[randomInt]);
        }

        return sb.toString();
    }

    public static String generate_random_string() {

        Calendar calendarStart = Calendar.getInstance();
        Long Start_Time_In_Millis = calendarStart.getTimeInMillis();

        // converts Long to String
        String str = Long.toString(Start_Time_In_Millis);

        int ascii_offset = 65;
        int final_integer_value = 0;
        String surname_suffix = "";
        char oneByte;
        char FinalAsciiCharacter;
        int n = 0;
        for (int i = 0; i < str.length(); i++) {
            // fetches a char in the string indexed by i
            oneByte = str.charAt(i);

            // converts this char to an integer
            n = Character.digit(oneByte, 10);

            // adds the integer offset of 65 to this char
            final_integer_value = ascii_offset + n;

            // convert this integer back to an ascii character
            FinalAsciiCharacter = (char) final_integer_value;

            // append the character to the surname string
            surname_suffix = surname_suffix + FinalAsciiCharacter;
        }

        return surname_suffix;
    }


    public static String getDefaultStateByDistributor(String distributor) {
        String defaultState = "NSW";
        switch (distributor) {
            case Policy.NRMA:
                defaultState = "NSW";
                break;
            case Policy.NRMAQLD:
                defaultState = "QLD";
                break;
            case Policy.SGIC:
                defaultState = "SA";
                break;
            case Policy.SGIO:
                defaultState = "WA";
                break;
        }

        return defaultState;
    }

    public static String formateWebString(String str) {
        if (str.trim().isEmpty())
            return "";
        String formatted = "";

        String[] arrayStr = str.trim().split(" ");
        for (int i = 0; i < arrayStr.length; i++) {
            String temp = arrayStr[i].substring(0, 1).toUpperCase();
            if (arrayStr[i].length() > 1)
                temp = temp + arrayStr[i].substring(1).toLowerCase();
            if (i > 0)
                formatted = formatted + " ";
            formatted = formatted + temp;
        }

        return formatted;
    }

}
