package au.com.iag.execution.claimnotesapi.configurations;

import org.springframework.context.*;
import static org.springframework.test.context.support.TestPropertySourceUtils.*;

public class PropertyOverrideContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        addPropertiesFilesToEnvironment(
                configurableApplicationContext,
                "classpath:config/application-test.properties",
                "classpath:config/claimnotes-api/application-test.properties",
                "classpath:config/claimnotes-api/${env}/application-test.properties");
    }
}