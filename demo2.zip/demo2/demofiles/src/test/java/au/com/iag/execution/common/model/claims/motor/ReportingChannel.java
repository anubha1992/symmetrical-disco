package au.com.iag.execution.common.model.claims.motor;

import au.com.iag.glados.common.serializers.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.io.*;
import java.time.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class ReportingChannel implements Serializable {

    private static final long serialVersionUID = 1L;

    private String claimReportedMethod;
    private String sourceId;
    private Organisation sourcePartyDetails;
    private String sourceEventId;
    private String sourceEventName;
    @JsonSerialize(using = CustomDateSerializer.class)
    @JsonDeserialize(using = CustomDateDeserializer.class)
    private OffsetDateTime sourceReportedDate;
    private String reasonForDelayInReporting;
}
