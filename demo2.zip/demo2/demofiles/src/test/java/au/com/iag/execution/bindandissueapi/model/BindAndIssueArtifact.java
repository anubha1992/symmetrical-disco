package au.com.iag.execution.bindandissueapi.model;

import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueRequest;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class BindAndIssueArtifact implements Serializable {

    private String path;
    private Map<String, Object> headers;
    private BindAndIssueRequest bindAndIssueRequest;

}
