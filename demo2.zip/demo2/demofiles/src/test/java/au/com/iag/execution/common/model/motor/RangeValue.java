package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class RangeValue implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("field")
    private String field ;
    @JsonProperty("field_reference")
    private FieldReference fieldReference = new FieldReference();
    @JsonProperty("type")
    private String type ;
    @JsonProperty("value")
    private Integer value ;

  
    @ApiModelProperty(
        value = "The name of the data field to compare against. Appears in the data structure.",
        required = false
    )
    public String getField() {
       return field;
    }
 
    @ApiModelProperty(
        value = "Optional. Reference to the field path and context to get that data field to compare against.",
        required = false
    )
    public FieldReference getFieldReference() {
       return fieldReference;
    }
 
    @ApiModelProperty(
        value = "Range data type i.e PERCENTAGE, ABSOLUTE_YEAR, ABSOLUTE_MONTH, ABSOLUTE.",
        required = false
    )
    public String getType() {
       return type;
    }
 
    @ApiModelProperty(
        value = "Value",
        required = false
    )
    public Integer getValue() {
       return value;
    }
 

}