package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class BillingPlanComparison implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("billing_frequency")
    private String billingFrequency ;
    @JsonProperty("difference_amount")
    private Double differenceAmount ;

  
    @ApiModelProperty(
        value = "The billing frequency that is being compared with. [Ref Data: billing_frequency]",
        example = "FORTNIGHTLY",
        required = false
    )
    public String getBillingFrequency() {
       return billingFrequency;
    }
 
    @ApiModelProperty(
        value = "Difference amount between compared plans - customer selected plan vs plan that is being compared with",
        example = "-14.71",
        required = false
    )
    public Double getDifferenceAmount() {
       return differenceAmount;
    }
 

}