package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.common.service.lodgeclaims.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static org.junit.jupiter.api.Assertions.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tags({@Tag("ClaimDetails")})
public class GetClaimDetailsTest {

    @Autowired
    LodgeMotorClaimService lodgeMotorClaimService;

    @Autowired
    RetrieveClaimDetailsService retrieveClaimDetailsService;


    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM, loadContext = true)
    @Test
    public void testGetClaimDetails() throws Exception {
        Response response = lodgeMotorClaimService.lodgeClaim(SC_OK);
        String claimId = response.path("claim_identifier");

        response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithStatusInProgressAndRepxEnableTrue(){
        String claimId = "C3002438";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("true", response.path("claim.can_book_inspection").toString());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithStatusInProgressAndSafeToDriveFalse(){
        String claimId = "C3002388";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("false", response.path("claim.can_book_inspection").toString());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithStatusInProgressAndLossOfCauseWindscreen(){
        String claimId = "C3002491";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("false", response.path("claim.can_book_inspection").toString());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithStatusInProgressAndRepxEnabledFalse(){
        String claimId = "C3002498";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("false", response.path("claim.can_book_inspection").toString());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithStatusInProgressAndRepxEnabledTrueAndRepairStatusBooked(){
        String claimId = "C3002439";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("false", response.path("claim.can_book_inspection").toString());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithServiceRequestStatusComplete(){
        String claimId = "C3002512";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("true", response.path("claim.can_book_inspection").toString());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void testNZGetClaimDetailsWithServiceRequestStatusCancelledAndRepxEnabledFalse(){
        String claimId = "C3002513";
        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        assertEquals("true", response.path("claim.can_book_inspection").toString());
    }

}
