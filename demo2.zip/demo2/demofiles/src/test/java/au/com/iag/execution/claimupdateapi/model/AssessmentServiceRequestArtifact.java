package au.com.iag.execution.claimupdateapi.model;

import au.com.iag.execution.claimupdateapi.model.business.*;
import lombok.Data;
import java.util.*;

@Data
public class AssessmentServiceRequestArtifact {
    private Map<String, Object> headers;
    private String path;
    private UpdateAssessment updateAssessment;
}
