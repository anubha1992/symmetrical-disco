package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.*;
import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.model.business.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.execution.common.service.crods.*;
import au.com.iag.execution.common.service.lodgeclaims.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.SYSTEM_SECURITY_TOKEN_MISSING;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.common.constants.ApiConstants.INVALID_SYSTEM_TOKEN;
import static au.com.iag.execution.common.constants.ApiConstants.SYSTEM_SECURITY_VALIDATION_FAILURE;
import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@Tags({@Tag("RecoveryJourney"), @Tag("SearchClaimTest"), @Tag("ClaimDetails"),@Tag("NZClaimDetails")})
public class SearchClaimTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    ClaimDetailService claimDetailService;


    @Autowired
    ClaimsDbService claimsDbService;
    @Autowired
    WimpDbService wimpDbService;
    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;
    @Autowired
    CrodsDbService crodsDbService;
    @Autowired
    LodgeMotorClaimService lodgeMotorClaimService;

    @Autowired
    LodgePropertyClaimService lodgePropertyClaimService;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;

    @Value("${test.api.source.system}")
    private String apiSourceSystem;

    static List<Map<String, Object>> claimIdDetails;
    private ClaimDetailsArtifact claimDetailsArtifact;
    private ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimsHavingLossItems(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        setClaimDetailsArtifact(claimDetailsRequestBuilder.setUpSearchClaimDetails());
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ, loadContext = true)
    @Test
    public void searchClaimDetailsWithNoPolicies() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        claimSearchRequest.setPolicies(null);
        claimDetailsArtifact.setClaimSearchRequest(claimSearchRequest);
        String errorMessage = "Policies: must not be null";
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_BAD_REQUEST);
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);

    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ, loadContext = true)
    @Test
    public void searchClaimDetailsWithNullPolicyId() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        List<Policy> policies = new ArrayList<>();
        claimSearchRequest.setPolicies(policies);
        claimDetailsArtifact.setClaimSearchRequest(claimSearchRequest);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_BAD_REQUEST);
        String errorMessage = "Policies: At least one policy identifier must be provided";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    @Test
    public void inValidSecuritySystemSearchClaimDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchRequest);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_VALIDATION_FAILURE);
    }

    @Test
    public void noSecurityConsumerSystemSearchClaimDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchRequest);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response,INVALID_SYSTEM);
    }

    @Test
    public void noSecurityTokenSearchClaim() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchRequest);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_TOKEN_MISSING);
    }

    @Test
    public void inValidSecurityTokenSearchClaim() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchRequest);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_SYSTEM_TOKEN);
    }

    @Test
    public void searchClaimDetailsForInValidDateRange() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        ClaimSearchRequest claimSearchReq = setUpDataWithCheckOnWimp();
        claimSearchReq.setRangeStartDate("2018-01-01");
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact,SC_BAD_REQUEST);
        String errorMessage = "Invalid date range provided";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ, loadContext = true)
    @Test
    public void searchClaimDetailsForValidPolicyId() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        ClaimSearchRequest claimSearchReq = setUpDataWithCheckOnWimp();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact, SC_OK);
        claimDetailsVerifier.verifyPolicyNumber(response, claimSearchReq.getPolicies().get(0).getPolicyIdentifier());
        claimDetailsVerifier.verifyClaimDetailsSearch(response);
    }

    @Test
    public void searchClaimDetailsForValidPolicyIdAndBrand() throws Exception {

        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        ClaimSearchRequest claimSearchReq = setUpData();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact, SC_OK);
        claimDetailsVerifier.verifyPolicyNumber(response, claimSearchReq.getPolicies().get(0).getPolicyIdentifier());
        claimDetailsVerifier.verifyClaimDetailsSearch(response);
    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ, loadContext = true)
    @Test
    public void searchClaimDetailsForValidPolicyIdAndProduct() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        ClaimSearchRequest claimSearchReq = setUpDataWithCheckOnWimp();
        claimSearchReq.getPolicies().get(0).setProduct(productCode);
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact, SC_OK);
        claimDetailsVerifier.verifyPolicyNumber(response, claimSearchReq.getPolicies().get(0).getPolicyIdentifier());
        claimDetailsVerifier.verifyClaimDetailsSearch(response);

    }

    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ, loadContext = true)
    @Test
    public void searchClaimDetailsForValidPolicyBrandAndProduct() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        ClaimSearchRequest claimSearchReq = setUpDataWithCheckOnWimp();
        claimSearchReq.getPolicies().get(0).setBrand(brand);
        claimSearchReq.getPolicies().get(0).setProduct(productCode);
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact, SC_OK);
        claimDetailsVerifier.verifyPolicyNumber(response, claimSearchReq.getPolicies().get(0).getPolicyIdentifier());
        claimDetailsVerifier.verifyClaimDetailsSearch(response);
    }

    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @EnabledIf(expression = API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ, loadContext = true)
    @Test
    public void searchClaimDetailsForValidDateRange() throws Exception {

        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        ClaimSearchRequest claimSearchReq = setUpDataWithCheckOnWimp();
        claimSearchReq.setRangeStartDate("2018-01-01");
        claimSearchReq.setRangeEndDate("2020-01-01");
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearch(claimDetailsArtifact, SC_OK);
        claimDetailsVerifier.verifyPolicyNumber(response, claimSearchReq.getPolicies().get(0).getPolicyIdentifier());
        claimDetailsVerifier.verifyClaimDetailsSearch(response);
    }

    @Test
    public void searchClaimDetailsForValidPolicyIdAndBrandExternal() throws Exception {

        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.buildClaimDetailsExternal(getClaimDetailsArtifact());
        ClaimSearchRequest claimSearchReq = setUpData();
        claimDetailsArtifact.setClaimSearchRequest(claimSearchReq);
        Response response = claimDetailService.executeClaimDetailsSearchExternal(claimDetailsArtifact, SC_OK);
        claimDetailsVerifier.verifyPolicyNumber(response, claimSearchReq.getPolicies().get(0).getPolicyIdentifier());
        claimDetailsVerifier.verifyClaimDetailsSearch(response);
    }

    private ClaimSearchRequest setUpData() throws Exception {
        ClaimSearchRequest claimSearchRequest;

        if ((brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("NZSTATE") || brand.equalsIgnoreCase("STATE") || brand.equalsIgnoreCase("AMI"))) {
            claimSearchRequest = setUpNZData();
        }
        else {
            claimSearchRequest = setUpDataWithCheckOnWimp();
        }

        claimSearchRequest.getPolicies().get(0).setBrand(brand);
        return claimSearchRequest;
    }

    private ClaimSearchRequest setUpDataWithCheckOnWimp() throws Exception {
        ClaimSearchRequest claimSearchReq = new ClaimSearchRequest();
        List<Policy> policies = new ArrayList<>();
        String policyId = wimpDbService.ensurePolicyIsInWimpAndReturnPolicyId(claimIdDetails, brand);

        Policy policy = new Policy();

        if ((brand.equalsIgnoreCase("NRMA") || brand.equalsIgnoreCase("SGIO") || brand.equalsIgnoreCase("SGIC") || brand.equalsIgnoreCase("RACV"))) {
            policy.setBrand(brand);
        }

        policy.setPolicyIdentifier(policyId);
        policies.add(policy);
        claimSearchReq.setPolicies(policies);

        return claimSearchReq;
    }

    private ClaimSearchRequest setUpNZData() throws Exception {
        ClaimSearchRequest claimSearchReq = new ClaimSearchRequest();
        List<Policy> policies = new ArrayList<>();
        String policyId = null;
        Policy policy = new Policy();

        if (brand.equalsIgnoreCase("AMI")) {
            if(productCode.equalsIgnoreCase("MOT")) {
                policyId = "M0010162288";
            }
            else {
                policyId = "C0010171627";
            }
        } else {
            Response response = null;
            if(productCode.equalsIgnoreCase("MOT")) {
                response = lodgeMotorClaimService.lodgeClaim(SC_OK);
            }
            else {
                response = lodgePropertyClaimService.lodgeClaim(SC_OK);
            }
            policyId = response.path("policy_identifier");
        }
        policy.setPolicyIdentifier(policyId);
        policies.add(policy);
        claimSearchReq.setPolicies(policies);
        return claimSearchReq;
    }

    public ClaimDetailsArtifact getClaimDetailsArtifact() {
        return claimDetailsArtifact;
    }

    public void setClaimDetailsArtifact(ClaimDetailsArtifact claimDetailsArtifact) {
        this.claimDetailsArtifact = claimDetailsArtifact;
    }
}
