package au.com.iag.execution.common.service.corrotracker;

import au.com.iag.execution.common.model.corrotracker.Correspondence;
import au.com.iag.execution.common.model.corrotracker.CorrespondenceDocuments;
import au.com.iag.glados.common.RestAssuredRequestSender;
import au.com.iag.glados.integration.SplunkClient;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import au.com.iag.glados.service.SecurityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.config.ObjectMapperConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.swagger.models.HttpMethod;
import org.junit.jupiter.api.Assertions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.USER_SC_APP_ADMIN;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static java.lang.String.format;

@Service
public class CorrespondenceTrackerService {

    @Autowired private SecurityService securityService;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private RestAssuredRequestSender restAssuredRequestSender;
    @Autowired private SplunkClient splunkIntegrationService;

    @Value("${test.security.consumer}")
    private String consumerSystem;
    @Value("${test.security.provider}")
    private String providerSystem;
    @Value("${test.api.brand}")
    private String brand;
    @Value("${correspondence.tracker.url}")
    private String correspondenceTrackerUrl;

    private static final String CORRESPONDENCE_SEARCH_PATH = "/customer-correspondence/correspondence/";

    public Correspondence searchCorrespondence(String correspondenceId, int statusCode) throws IOException {
        String url = correspondenceTrackerUrl+CORRESPONDENCE_SEARCH_PATH+correspondenceId;
        Response response = sendRequestToCustomHost(buildHeaders(), url
                , null, new HashMap<>(), "", statusCode, HttpMethod.GET.name());
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), Correspondence.class);
    }

    public Correspondence createCorrespondence(String partyId, String policyNumber, int statusCode) throws IOException {
        String url = correspondenceTrackerUrl+CORRESPONDENCE_SEARCH_PATH;
        Correspondence correspondenceRequest = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/policy-documents-api/createCorrespondenceRequest.json")
                        , Correspondence.class);
        correspondenceRequest.getCustomerIdentifier().setCustomerId(partyId);
        correspondenceRequest.getCorrespondenceBusiness().setReferenceId(policyNumber);
        Response response = sendRequestToCustomHost(buildHeaders(), url
                , null, new HashMap<>(), correspondenceRequest, statusCode, HttpMethod.POST.name());
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), Correspondence.class);
    }

    public Correspondence createCorrespondence(String partyId, String policyNumber, String corroTrackerStatus, int statusCode) throws IOException {
        String url = correspondenceTrackerUrl+CORRESPONDENCE_SEARCH_PATH;
        Correspondence correspondenceRequest = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/policy-documents-api/createCorrespondenceRequest.json")
                        , Correspondence.class);
        correspondenceRequest.getCustomerIdentifier().setCustomerId(partyId);
        correspondenceRequest.getCorrespondenceBusiness().setReferenceId(policyNumber);
        correspondenceRequest.setStatus(corroTrackerStatus);
        Response response = sendRequestToCustomHost(buildHeaders(), url
                , null, new HashMap<>(), correspondenceRequest, statusCode, HttpMethod.POST.name());
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), Correspondence.class);
    }

    public void addCorrespondenceDocuments(String correspondenceId, CorrespondenceDocuments correspondenceDocuments, int statusCode){
        String url = correspondenceTrackerUrl+CORRESPONDENCE_SEARCH_PATH+correspondenceId+"/documents";
        Response response = sendRequestToCustomHost(buildHeaders(), url
                , null, new HashMap<>(), correspondenceDocuments, statusCode, HttpMethod.PUT.name());
        System.out.println(response.prettyPrint());
    }

    private Map<String, Object> buildHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_USER, USER_SC_APP_ADMIN);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM,
                securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        return requestHeaders;
    }

    public Response sendRequestToCustomHost(Map<String, Object> requestHeaders, String url, String queryString, Map<String, String> params,
                                            Object requestBody, int statusCode, String method) {
        setRestAssuredConfig();
        String queryUrl = format("%s", url, queryString);
        Response response = restAssuredRequestSender.internalRequest(requestHeaders, method, queryUrl, params, requestBody);
        return verifyResults(statusCode, response);
    }

    private void setRestAssuredConfig() {
        RestAssured.config = RestAssuredConfig.config()
                .objectMapperConfig(new ObjectMapperConfig().jackson2ObjectMapperFactory((type, s) -> jsonMapperService.getObjectMapper()));
    }

    private Response verifyResults(int statusCode, Response response) {
        System.out.println("Splunk log: " + splunkIntegrationService.printSplunkUrl(response.getHeader(X_B3_TRACE_ID)));
        Assertions.assertEquals(statusCode, response.statusCode());
        return response;
    }
}
