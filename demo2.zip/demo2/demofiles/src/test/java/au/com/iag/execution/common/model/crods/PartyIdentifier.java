package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PartyIdentifier{

	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@JsonProperty("partyId")
	private String partyId;

	public void setSourceSystem(String sourceSystem){
		this.sourceSystem = sourceSystem;
	}

	public String getSourceSystem(){
		return sourceSystem;
	}

	public void setPartyId(String partyId){
		this.partyId = partyId;
	}

	public String getPartyId(){
		return partyId;
	}

	@Override
 	public String toString(){
		return 
			"PartyIdentifier{" + 
			"sourceSystem = '" + sourceSystem + '\'' + 
			",partyId = '" + partyId + '\'' + 
			"}";
		}
}