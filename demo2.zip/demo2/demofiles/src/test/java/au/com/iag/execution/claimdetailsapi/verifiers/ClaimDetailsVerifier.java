package au.com.iag.execution.claimdetailsapi.verifiers;

import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Map;

import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_USER;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Component
public class ClaimDetailsVerifier {

    public void verifyClaimDetailsResponse(Response response) {
        Assert.assertNotNull(response.path("claim_status"));
        Assert.assertNotNull(response.path("policy_details.status"));
        Assert.assertNotNull(response.path("policy_details.policy_identifier"));
        Assert.assertNotNull(response.path("policy_details.policy_system"));
        Assert.assertNotNull(response.path("parties.party_type"));
        if (response.path("parties.party_type").toString().contains("Person")) {
            Assert.assertNotNull(response.path("parties.first_name"));
            Assert.assertNotNull(response.path("parties.last_name"));
        }
    }

    public void verifyClaimDetailsRetrieveBrandResponse(Response response) {
        Assert.assertNotNull(response.path("policy_details.brand"));
    }

    public void verifyPolicyNumber(Response response, String policyId) {
        String policyNumber = response.path("policy_identifier").toString();
        policyNumber = policyNumber.replace("-", "").toString(); //Response has policy number formatted with hyphen between
        policyNumber = policyNumber.replace("[", "").toString();
        policyNumber = policyNumber.replace("]", "").toString();
        try {
            assertThat(policyNumber, Matchers.equalToIgnoringCase(policyId));
        } catch (AssertionError ex) {
            System.out.println("*** [INFO] *** - Policy id not matched in response \n. Expected: " + policyNumber + " || Actual: " + policyId);
        }
    }

    public void verifyClaimDetailsSearch(Response response) {

        Assert.assertNotNull(response.path("policy_identifier"));
        Assert.assertNotNull(response.path("claims.claim_identifier"));
        Assert.assertNotNull(response.path("claims.claim_status"));
        Assert.assertNotNull(response.path("claims.cause_of_loss"));
        Assert.assertNotNull(response.path("claims.loss_date"));
        Assert.assertNotNull(response.path("claims.general_nature_of_loss"));
        Assert.assertNotNull(response.path("claims.incidents.incident_code"));
        if (response.path("claims.incidents.incident_code").toString().contains("VEHICLE")) {
            Assert.assertNotNull(response.path("claims.incidents.registration"));
        } else {
            Assert.assertNotNull(response.path("claims.incidents.risk_address"));
        }

    }

    public void verifyClaimDetailsRetrieveClaimDetailsResponse(Response response) {
        Assert.assertNotNull(response.getHeaders().getValue("X-Iag-Auth-User"));
        Assert.assertNotNull(response.path("policy_details.risk_type"));
        String riskType =response.path("policy_details.risk_type");
        if(!(riskType.equalsIgnoreCase("per_strata"))) {
            Assert.assertNotNull(response.path("date_of_loss"));
            Assert.assertNotNull(response.path("claim_status"));
            //Assert.assertNotNull(response.path("allocation_status"));
            Assert.assertNotNull(response.path("applicable_excess.amount_owing.amount"));
            Assert.assertNotNull(response.path("applicable_excess.amount_paid.amount"));
            Assert.assertNotNull(response.path("applicable_excess.total_payable_excess.amount"));
            Assert.assertNotNull(response.path("applicable_excess.waived"));
            Assert.assertNotNull(response.path("applicable_excess.payment_status"));
            Assert.assertNotNull(response.path("applicable_excess.excess_items.additional_details"));
            Assert.assertNotNull(response.path("applicable_excess.excess_items.description"));
            Assert.assertNotNull(response.path("applicable_excess.excess_items.item_total.amount"));
            Assert.assertNotNull(response.path("applicable_excess.excess_items.type"));
            Assert.assertNotNull(response.path("applicable_excess.excess_items.type"));
            // email id is not returned always for the claim retrieve
            //Assert.assertNotNull(response.path("main_contact.contact_details.email"));
            //Assert.assertNotNull(response.path("insured.contact_details.email"));

            Assert.assertNotNull(response.path("policy_details.brand"));
            float totalPayableExcess = 0;
            try {
                totalPayableExcess = response.path("applicable_excess.total_payable_excess.amount");
            } catch (Exception e) {
            }
            Boolean waived = response.path("applicable_excess.waived");
            if (waived) {
                if (!(totalPayableExcess == 0)) {
                    Assert.fail("Excess is waived for this claim. But Amount Owing in response is: " + totalPayableExcess + ". Expected amount owing is: 0");
                }
            }
        }
    }

    public void verifyViewLoss(Response response, String claimId) {
        Assert.assertNotNull(response.path("claim_identifier"));
        Assert.assertNotNull(response.path("incidents.incident_id"));
        Assert.assertThat(response.jsonPath().getList("incidents").size(), greaterThan(0));
        Assert.assertThat(response.jsonPath().getList("incidents.exposures.coverage.loss_items").size(), greaterThan(0));
        Assert.assertNotNull(response.path("incidents.exposures.coverage.loss_items.status"));
        Assert.assertNotNull(response.path("incidents.exposures.coverage.loss_items.type"));
        Assert.assertNotNull(response.path("incidents.exposures.coverage.loss_items.loss_item_id"));
        String responseClaimId = response.path("claim_identifier");
        try {
            assertThat(responseClaimId, Matchers.containsString(claimId));
        } catch (AssertionError ex) {
            ex.printStackTrace();
            Assert.fail("Claim  number not matched in response \n. Expected: " + claimId + " || Actual: " + responseClaimId);
        }
    }

    public void verifyClaimIdentifier(Response response, String claimId){
        String claimNumber = response.path("claim_identifier").toString();
        assertThat(claimNumber, Matchers.equalToIgnoringCase(claimId));
    }

    public void verifyErrorResponse(Response response, String errorMessage) {
        Assert.assertEquals(errorMessage, response.path("message"));
    }

    public void verifyRetrieveClaim(Response response, String claimId, String productCode) {
        String claimNumber = response.path("claim.claim_identifier").toString();
        assertThat(claimNumber, Matchers.equalToIgnoringCase(claimId));

        assertNotNull(response.path("claim.claim_status"));
        assertNotNull(response.path("claim.claim_lodgement_date"));
        assertNotNull(response.path("claim.date_of_loss"));
        assertNotNull(response.path("claim.allocation_exists")); //JAPI-403
        verifyOnlyOneIncidentCodePerIncident(response); //JAPI-968
        if (productCode.equalsIgnoreCase("MOT")||productCode.equalsIgnoreCase("COM")) {
            assertNotNull(response.path("claim.incidents.risk_unit.risk_item.registration"));
            assertNotNull(response.path("claim.incidents.risk_unit.risk_item.make"));
            assertNotNull(response.path("claim.can_book_inspection")); //JAPI-61
            assertNotNull(response.path("claim.allocation_allowed")); //JAPI-60
            assertNotNull(response.path("claim.applicable_excess.excess_items.type")); //JAPI-449
        }

        //Validation introduced from HOT fix 0.2-103 JIRA-391
        float totalPayableExcess = 0;
        try {
            totalPayableExcess = response.path("claim.applicable_excess.total_payable_excess.amount");
        } catch (Exception e) {
            //Do nothing. In some wierd cases, exposure api will come back with amount owing field as null. This try catch is to avoid test failing from null pointer exception
        }
        if (response.path("claim.applicable_excess.waived")) {
            if (!(totalPayableExcess == 0)) {
                fail("Excess is waived for this claim. But Amount Owing in response is: " + totalPayableExcess + ". Expected amount owing is: 0");
            }
        }
        verifyPossibleTotalLoss(response); //JAPI-919
    }

    public void verifyRetrieveClaimNZ(Response response, String claimId, String productCode) {
        String claimNumber = response.path("claim.claim_identifier").toString();
        assertThat(claimNumber, Matchers.equalToIgnoringCase(claimId));

        assertTrue(isRefData(response.path("claim.claim_status")));
        assertNotNull(response.path("claim.claim_lodgement_date"));

        assertNotNull(response.path("claim.claim_manager"));
        assertTrue(isRefData(response.path("claim.claim_manager.party_type")));
        assertTrue(isRefData(response.path("claim.incidents[0].incident_code")));
        assertNotNull(response.path("claim.incidents[0].incident_id"));
        assertTrue(isRefData(response.path("claim.incidents[0].loss_party_type")));

        assertTrue(isRefData(response.path("claim.incidents[0].risk_unit.risk_type")));
        assertNotNull(response.path("claim.date_of_loss"));
        assertNotNull(response.path("claim.applicable_excess"));
        assertNotNull(response.path("claim.insured"));
        assertNotNull(isRefData(response.path("claim.insured.indicators.insured_previous_loss")));
        assertNotNull(response.path("claim.loss_type"));

        assertNotNull(response.path("claim.description_of_loss"));
        assertTrue(isRefData(response.path("claim.claim_stage")));
        assertTrue(isRefData(response.path("claim.claim_decision_status")));
        assertTrue(isRefData(response.path("claim.at_fault_party")));
        assertTrue(isRefData(response.path("claim.cause_of_loss")));
        assertNotNull(response.path("claim.location_of_loss"));
        assertNotNull(response.path("claim.policy_details"));
        assertTrue(isRefData(response.path("claim.policy_details.policy_risk_type")));
        assertTrue(response.path("claim.policy_details.premium_paid"));
        assertNotNull(response.path("claim.policy_details.inception_date"));
        assertTrue(isRefData(response.path("claim.claim_segment")));
        verifyOnlyOneIncidentCodePerIncident(response); //JAPI-968
        if (productCode.equalsIgnoreCase("MOT")) {
            assertNotNull(response.path("claim.incidents[0].risk_unit.risk_item.registration"));
            assertNotNull(response.path("claim.incidents[0].risk_unit.risk_item.make"));
            assertFalse(response.path("claim.allocation_exists"));
            assertFalse(response.path("claim.can_book_inspection"));
            assertFalse(response.path("claim.allocation_allowed"));
            assertTrue(response.path("claim.can_choose_own_repairer"));
            assertNotNull(response.path("claim.incidents[0].risk_unit.risk_item.registration"));
            assertNotNull(response.path("claim.incidents[0].risk_unit.risk_item.make"));
            assertNotNull(response.path("claim.incidents[0].no_damage"));
            // assertNotNull(response.path("claim.incidents[0].safe_to_drive"));
            assertNotNull(response.path("claim.incidents[0].vehicle_parked"));
//            assertNotNull(response.path("claim.incidents[0].vehicle_towed"));
            assertNotNull(response.path("claim.incidents[0].wind_screen_only"));
            //           assertNotNull(response.path("claim.incidents[0].driver"));
        }else
        {
            assertNotNull(response.path("claim.incidents[0].risk_unit.risk_address"));
        }

    }

    private static boolean isRefData(String s) {
        for(char c : s.toCharArray()) {
            if(!(Character.isUpperCase(c) || Character.isDigit(c) || (c == '_'))) {
                return false;
            }
        }
        return true;
    }

    private void verifyPossibleTotalLoss(Response response) {
        String ptlFlag = null;
        ArrayList<Map<String, Object>> indicators = response.path("claim.incidents[0].incident_indicators");

        for (int i = 0; i < indicators.size(); i++) {
            Map<String, Object> incident = indicators.get(i);
            if(incident.get("name").toString().equals("total_loss_predicted")) {
                if (incident.get("value") != null) {
                    ptlFlag = incident.get("value").toString();
                }
            }
        }

        if(ptlFlag != null) {
            assertEquals(ptlFlag, response.path("claim.incidents[0].possible_total_loss").toString());
        } else {
            assertNull(response.path("claim.incidents[0].possible_total_loss"));
        }
    }
    private void verifyOnlyOneIncidentCodePerIncident(Response response) {
        int numberIncidents = response.jsonPath().getList("claim.incidents").size();
        String responseBody = response.body().asString();
        assertThat(StringUtils.countMatches(responseBody, "\"incident_code\""), is(numberIncidents));
    }

    public void verifyClaimUserResponse(String expectedContactId, Response response) {
        String actualContactId = response.path("contact_id");
        assertEquals(expectedContactId, actualContactId);
        assertNotNull(response.getHeader(X_IAG_AUTH_USER));

        String tokenBody = getTokenBodyAsString(response.getHeader(X_IAG_AUTH_USER));
        assertTrue(tokenBody.contains("w:claim.contactId:" + actualContactId));
    }

    public String getTokenBodyAsString(String jwtToken) {
        String[] split_string = jwtToken.split("\\.");
        String base64EncodedBody = split_string[1];

        org.apache.commons.codec.binary.Base64 base64Url = new org.apache.commons.codec.binary.Base64(true);
        String body = new String(base64Url.decode(base64EncodedBody));
        System.out.println("JWT Body is : " + body);

        return body;
    }
}
