package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.util.*;

@Data
public class Notification {

    @ApiModelProperty(
            value = "Notification type.\n"
            + "Reference data values : https://confluence.iag.com.au/display/GICP/CC+SR+10+NotifyItem+Type",
            example = "Assessment_Details")
    private String type;

    @ApiModelProperty(
            value = "Status",
            example = "Quote Received")
    private String externalStatus;

    private List<NotificationItem> notificationItems;
}
