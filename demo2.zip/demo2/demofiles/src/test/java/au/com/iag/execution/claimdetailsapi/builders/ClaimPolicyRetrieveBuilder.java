package au.com.iag.execution.claimdetailsapi.builders;

import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.glados.model.constants.*;
import au.com.iag.glados.service.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.util.*;

@Service
public class ClaimPolicyRetrieveBuilder {


    @Value("${test.api.claimspolicyretrieve.route}") private String path;
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;
    @Value("${test.api.claimPolicyRetrieveService.authorization}") private String authorizationDetails;
    @Value("${test.api.source.system}") private String apiSourceSystem;
    @Value("${test.api.product.code}") private String productCode;
    @Value("${test.api.source.system.brand}") private String brand;

    @Autowired
    private SecurityService securityService;

    public ClaimPolicyRetrieveArtifact setUpClaimPolicyRetrieve(){
        ClaimPolicyRetrieveArtifact claimPolicyRetrieveArtifact = new ClaimPolicyRetrieveArtifact();
        claimPolicyRetrieveArtifact.setHeaders(getClaimsPolicyRetrieveHeader());
        claimPolicyRetrieveArtifact.setPath(path);
        return claimPolicyRetrieveArtifact;
    }

    private Map<String, Object> getClaimsPolicyRetrieveHeader(){
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(GladosConstants.ACCEPT, APPLICATION_JSON);
        requestHeaders.put(AUTHORIZATION, authorizationDetails);
        requestHeaders.put("policy_system", apiSourceSystem.toLowerCase());
        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            requestHeaders = getBasicHuonHeaders(requestHeaders, brand.toUpperCase());
            if (productCode.equalsIgnoreCase("CTP")) {
                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
                requestHeaders.put("X-Iag-Operation", "retrieveCTPPolicy");

            } else {
                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
                requestHeaders.put("X-Iag-Operation", "retrievePolicy");
                requestHeaders.put("policy_system", "huon_" + productCode.toLowerCase());
                if (brand.equalsIgnoreCase("NZ STATE")) {
                    requestHeaders = getBasicHuonNzStateHeaders(requestHeaders, brand.toUpperCase());
                    requestHeaders.put("X-Iag-Operation", "retrievePolicy");
                    requestHeaders.put("policy_system", "huon_" + productCode.toLowerCase());
                }
            }
        }
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        return requestHeaders;
    }

    private Map<String, Object> getAdditionalHuonHeaders(Map<String, Object> requestHeaders) {
        requestHeaders.put("X-Iag-User", "WEBNIIP");
        requestHeaders.put("X-Iag-Consumer-System", "BAPI");
        requestHeaders.put("X-Iag-User-Profile", "IAGSM");
        requestHeaders.put("X-Iag-User-Aliases", "MRJUSER");
        return requestHeaders;
    }

    private Map<String, Object> getBasicHuonHeaders(Map<String, Object> requestHeaders, String brand) {
        requestHeaders.put("Content-Type", "text/xml");
        requestHeaders.put("X-Iag-Brand", brand);
        requestHeaders.put("X-Iag-Agent-Id", "INT");
        requestHeaders.put("X-Iag-Distributor", brand);
        requestHeaders.put("X-Iag-Channel", "Digital");
        return requestHeaders;
    }

    private Map<String, Object> getBasicHuonNzStateHeaders(Map<String, Object> requestHeaders, String brand) {
        requestHeaders = getBasicHuonHeaders(requestHeaders, brand.toUpperCase());
        requestHeaders.put("X-Iag-User", "WEBZIIP");
        requestHeaders.put("X-Iag-Consumer-System", "BAPI");
        requestHeaders.put("X-Iag-User-Profile", "IAGNZ");
        requestHeaders.put("X-Iag-User-Aliases", "HUON=WEBZIIP");
        return requestHeaders;
    }

}
