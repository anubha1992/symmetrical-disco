package au.com.iag.execution.common.model.notifyapi;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.iag.core.model.exception.ErrorResponse;
import au.com.iag.execution.common.model.notifyapi.business.ValidationError;
import au.com.iag.execution.partyapi.model.business.Individual;
import au.com.iag.execution.partyapi.model.business.Organisation;
import io.restassured.response.Response;
import lombok.Data;

@Component
@Data
public class PartyResponseArtifact<T> {
    private Response response;
    private T party;
    private List<ValidationError> validationErrors = new ArrayList();
    private ErrorResponse errorResponse;
    private Individual individual;
    private Organisation organisation;
}
