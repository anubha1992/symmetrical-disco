package au.com.iag.execution.correspondenceapi;

import au.com.iag.execution.correspondenceapi.builders.CorrespondenceRequestBuilder;
import au.com.iag.execution.correspondenceapi.configuration.CorrespondenceConfiguration;
import au.com.iag.execution.correspondenceapi.configuration.PropertyOverrideContextInitializer;
import au.com.iag.execution.correspondenceapi.model.PolicySendCorrespondenceArtifact;
import au.com.iag.execution.correspondenceapi.service.CorrespondenceService;
import au.com.iag.execution.correspondenceapi.verifiers.CorrespondenceTrackerVerifier;
import au.com.iag.execution.correspondenceapi.verifiers.CorrespondenceVerifier;
import au.com.iag.glados.common.GladosRunnerExtension;
import io.restassured.response.Response;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;
import static org.apache.http.HttpStatus.SC_OK;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { CorrespondenceConfiguration.class})
@Tags({@Tag("send-correspondence"), @Tag("corro-tracker-mapping-test")})
public class CorroTrackerMappingTest {

    @Autowired private CorrespondenceRequestBuilder correspondenceRequestBuilder;
    @Autowired private CorrespondenceService correspondenceService;
    @Autowired private CorrespondenceVerifier correspondenceVerifier;
    @Autowired private CorrespondenceTrackerVerifier correspondenceTrackerVerifier;

    private PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact;

    @DisplayName("Validate Corro Tracker mapping with different Correspondence Types for an Individual, Motor policies")
    @ParameterizedTest(name = "{index}  ==> Correspondence Type = ''{0}''")
    @CsvSource({
            CORRESPONDENCE_TYPE_QUOTATION,
            CORRESPONDENCE_TYPE_NEW_BUSINESS,
            CORRESPONDENCE_TYPE_AMENDMENT,
            CORRESPONDENCE_TYPE_RENEWAL
    })
    public void successfulMotorSendCorrespondence(String correspondenceType) throws Exception{
        policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualSingleAsset(PRODUCT_MOTOR_INSURANCE, correspondenceType);
        setPolicySendCorrespondenceArtifact(policySendCorrespondenceArtifact);
        Response response = correspondenceService.executeSendCorrespondence(getPolicySendCorrespondenceArtifact(), SC_OK);
        correspondenceVerifier.verifyCorrespondenceResponseIsNotNull(getPolicySendCorrespondenceArtifact(), response);
        correspondenceTrackerVerifier.verifyCorroTrackerMappings(getPolicySendCorrespondenceArtifact(), response.path(CORRESPONDENCE_ID));
    }

    @DisplayName("Validate Corro Tracker mapping with different Correspondence Types for an Individual, Home policies")
    @ParameterizedTest(name = "{index}  ==> Correspondence Type = ''{0}''")
    @CsvSource({
            CORRESPONDENCE_TYPE_QUOTATION,
            CORRESPONDENCE_TYPE_NEW_BUSINESS,
            CORRESPONDENCE_TYPE_AMENDMENT,
            CORRESPONDENCE_TYPE_RENEWAL
    })
    public void successfulHomeSendCorrespondence(String correspondenceType) throws Exception{
        policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualSingleAsset(PRODUCT_HOME_INSURANCE, correspondenceType);
        setPolicySendCorrespondenceArtifact(policySendCorrespondenceArtifact);
        Response response = correspondenceService.executeSendCorrespondence(getPolicySendCorrespondenceArtifact(), SC_OK);
        correspondenceVerifier.verifyCorrespondenceResponseIsNotNull(getPolicySendCorrespondenceArtifact(), response);
        correspondenceTrackerVerifier.verifyCorroTrackerMappings(getPolicySendCorrespondenceArtifact(), response.path(CORRESPONDENCE_ID));
    }

    @Test
    public void successfulLetterRenewalReminderExpiry() throws Exception{
        policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupLetterRenewalReminderExpiryIndividualSingleAsset(PRODUCT_MOTOR_INSURANCE);
        setPolicySendCorrespondenceArtifact(policySendCorrespondenceArtifact);
        Response response = correspondenceService.executeSendCorrespondence(getPolicySendCorrespondenceArtifact(), SC_OK);
        correspondenceVerifier.verifyCorrespondenceResponseIsNotNull(getPolicySendCorrespondenceArtifact(), response);
        correspondenceTrackerVerifier.verifyCorroTrackerMappings(getPolicySendCorrespondenceArtifact(), response.path(CORRESPONDENCE_ID));
    }

    @Test
    public void successfulSendSmsPolicyCancellation() throws Exception{
        policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupSmsPolicyCancellation(PRODUCT_MOTOR_INSURANCE, CORRESPONDENCE_TYPE_POLICY_CANCELLATION_SMS);
        setPolicySendCorrespondenceArtifact(policySendCorrespondenceArtifact);
        Response response = correspondenceService.executeSendCorrespondence(getPolicySendCorrespondenceArtifact(), SC_OK);
        correspondenceVerifier.verifyCorrespondenceResponseIsNotNull(getPolicySendCorrespondenceArtifact(), response);
        correspondenceTrackerVerifier.verifyCorroTrackerMappings(getPolicySendCorrespondenceArtifact(), response.path(CORRESPONDENCE_ID));
    }

    private PolicySendCorrespondenceArtifact getPolicySendCorrespondenceArtifact() {
        return policySendCorrespondenceArtifact;
    }

    private void setPolicySendCorrespondenceArtifact(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact) {
        this.policySendCorrespondenceArtifact = policySendCorrespondenceArtifact;
    }
}
