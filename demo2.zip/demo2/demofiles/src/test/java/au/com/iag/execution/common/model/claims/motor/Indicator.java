package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class Indicator implements Serializable {
    private static final long serialVersionUID = -223287988050039386L;
    private Boolean customerAcknowledgement;
    private String securityType;
}
