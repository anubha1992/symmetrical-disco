package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class LandlordContentsDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("asset_type")
    private String assetType;
    @JsonProperty("cover_type")
    private String coverType;

  
    @ApiModelProperty(
        value = "Asset type [Ref Data: asset_type]",
        example = "CONTENTS",
        required = false
    )
    public String getAssetType() {
       return assetType;
    }
 
    @ApiModelProperty(
        value = "Indicates the cover type. [Ref Data: cover_type]",
        example = "SILVER",
        required = false
    )
    public String getCoverType() {
       return coverType;
    }
 

}