package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Comparison implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("cover_type")
    private String coverType ;
    @JsonProperty("difference")
    private Double difference ;
    @JsonProperty("total_premium")
    private Double totalPremium ;

  
    @ApiModelProperty(
        value = "Cover Type",
        example = "COMPREHENSIVE_SILVER",
        required = false
    )
    public String getCoverType() {
       return coverType;
    }
 
    @ApiModelProperty(
        value = "Price difference",
        example = "300.0",
        required = false
    )
    public Double getDifference() {
       return difference;
    }
 
    @ApiModelProperty(
        value = "Total premium",
        example = "400.0",
        required = false
    )
    public Double getTotalPremium() {
       return totalPremium;
    }
 

}