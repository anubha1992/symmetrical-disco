package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class BankAccountDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("bsb")
    private String bsb ;
    @JsonProperty("name")
    private String name ;
    @JsonProperty("number")
    private String number ;

  
    @ApiModelProperty(
        value = "Bank State Branch Number",
        required = false
    )
    public String getBsb() {
       return bsb;
    }
 
    @ApiModelProperty(
        value = "Customer Account Name",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "Bank account number",
        required = false
    )
    public String getNumber() {
       return number;
    }
 

}