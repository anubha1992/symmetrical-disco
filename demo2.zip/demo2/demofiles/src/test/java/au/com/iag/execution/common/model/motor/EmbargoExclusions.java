package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class EmbargoExclusions implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("fire")
    private EmbargoExclusionDetails fire = new EmbargoExclusionDetails();
    @JsonProperty("flood")
    private EmbargoExclusionDetails flood = new EmbargoExclusionDetails();
    @JsonProperty("policy_refusal")
    private EmbargoExclusionDetails policyRefusal = new EmbargoExclusionDetails();
    @JsonProperty("rain_water_run_off")
    private EmbargoExclusionDetails rainWaterRunOff = new EmbargoExclusionDetails();
    @JsonProperty("storm")
    private EmbargoExclusionDetails storm = new EmbargoExclusionDetails();
    @JsonProperty("storm_surge")
    private EmbargoExclusionDetails stormSurge = new EmbargoExclusionDetails();

  
    @ApiModelProperty(
        value = "Fire embargo details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusionDetails getFire() {
       return fire;
    }
 
    @ApiModelProperty(
        value = "Flood embargo details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusionDetails getFlood() {
       return flood;
    }
 
    @ApiModelProperty(
        value = "Policy refusal embargo details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusionDetails getPolicyRefusal() {
       return policyRefusal;
    }
 
    @ApiModelProperty(
        value = "Rain water run off embargo details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusionDetails getRainWaterRunOff() {
       return rainWaterRunOff;
    }
 
    @ApiModelProperty(
        value = "Storm embargo details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusionDetails getStorm() {
       return storm;
    }
 
    @ApiModelProperty(
        value = "Storm surge embargo details",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public EmbargoExclusionDetails getStormSurge() {
       return stormSurge;
    }
 

}