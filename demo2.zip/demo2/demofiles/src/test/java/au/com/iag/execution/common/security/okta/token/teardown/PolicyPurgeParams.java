package au.com.iag.execution.common.security.okta.token.teardown;


public enum PolicyPurgeParams {

    POLICY_NUMBER("policyNumber"),
    PARTY_ID("partyId"),
    BRAND("brand"),
    TYPE("type");


    private final String value;

    PolicyPurgeParams(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
