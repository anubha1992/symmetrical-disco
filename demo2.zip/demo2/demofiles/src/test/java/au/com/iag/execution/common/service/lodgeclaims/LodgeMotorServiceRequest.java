package au.com.iag.execution.common.service.lodgeclaims;

import au.com.iag.execution.common.model.claims.motor.*;
import au.com.iag.glados.common.*;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.junit.Assert.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.propertyvaluationapi.model.PropertyValuationsConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.io.*;
import java.util.*;

@Service
public class LodgeMotorServiceRequest {

    @Value("${test.api.source.system.brand}")
    private String brand;

    @Value("${test.api.lodgemotorservice.route}")
    private String lodgeMotorClaimPath;

    @Autowired
    private SecurityService securityService;
    @Autowired
    private JsonMapperService jsonMapperService;
    @Autowired
    private ResourceReaderService resourceReaderService;

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    private String lodgeClaimsRequestPath = "requests/motor-claim-lodgement-api/";

    public MotorServiceRequest buildMotorServiceRequest(String incidentId) throws IOException {
        return getMotorServiceRequest(incidentId);
    }

    public Response lodgeMotorServiceRequest(String incidentId, int expectStatusCode, String claimId) throws IOException {

        return executeLodgeMotorServiceRequest(getMotorServiceRequest(incidentId), expectStatusCode, claimId);
    }

    private MotorServiceRequest getMotorServiceRequest(String incidentId) throws com.fasterxml.jackson.core.JsonProcessingException {
        MotorServiceRequest serviceRequest = null;
        String fileName = "motorServiceRequest.json";
        if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI")) {
            fileName = "motorServiceRequestNZ.json";
        }
        serviceRequest = jsonMapperService.getObjectMapper().readValue(resourceReaderService.generateStringFromResource(lodgeClaimsRequestPath + fileName), MotorServiceRequest.class);
        if (null != serviceRequest) {
            serviceRequest.getServiceRequests().get(0).getIncidents().get(0).setIncidentId(incidentId);
        }

        return serviceRequest;
    }

    private Response executeLodgeMotorServiceRequest(MotorServiceRequest serviceRequest, int expectStatusCode, String claimId){

        Response response = gladosEnrichmentService.sendPostRequest(
                getRequestHeaders(),
                lodgeMotorClaimPath + "/service-request/"+claimId,
                serviceRequest,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Map<String, Object> getRequestHeaders(){
        Map<String, Object> requestHeaders = new HashMap<>();

        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, BAPI);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(SOURCE_ID, "DC");

        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken("BAPI", "business-api-provider"));
        return requestHeaders;
    }


    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }

}
