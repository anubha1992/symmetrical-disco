package au.com.iag.execution.common.model.huon.util;

import au.com.iag.execution.common.exception.*;
import java.util.*;


/**
 * Home class for broker request
 * <p>
 * <p>
 * included makeDescMap for caravan validation
 * <p>
 * <p>
 * included various mappings for Boat validation
 */
public class EsbMapping {

    /*
     * These are some mapping tables to map between HUON and ESB
     */
    protected static HashMap<String, String> componentNameMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> addressIndicatorMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> streetTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> streetDirectionMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> usageMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> registerTaxMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> businessTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> occupanyMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> constructionTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> roofTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> dwellingTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> alarmTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> lockedWindowMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> previousInsurerMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> ncbProtectionMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> coverageMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> staffFlagMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> embargoMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> excessTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> makeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> trailerMakeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> boatTrailerTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> boatSailMaterialDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> boatPrimaryWatersDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> boatHullMakerDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> boatBusinessTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> financeTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> hullBoatTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> hullKeptDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> hullMaterialDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> hullPurchaseFromDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> NCBOverrideReasonDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> motorTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> motorFuelTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> motorMakeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> otherPartyClientTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> caravanBodyTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> caravanParkingPlaceDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> caravanMaterialDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> trailerBodyTypeDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> trailerbusinessTypeMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> premiumOverrideReasonDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> caravanPurchaseFromDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> policyCancelReasonDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> basicPremiumOverrideReasonDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> commissionOverrideReasonDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> ctpVehicleUseDescMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> NSWaddressMap = new LinkedHashMap<String, String>();
    protected static HashMap<String, String> riskStateMap = new LinkedHashMap<String, String>();

    /**
     * Get ESB component name
     *
     * @param riskType
     * @return //	 * @throws InvalidDataException
     */
    public static String getEsbComponentName(String riskType) throws InvalidDataException {
        //no mapping
//		return riskType;

        String str = componentNameMap.get(riskType);
        if (str == null)
            throw new InvalidDataException("Risk type - " + riskType + " - is not in componentNameMap");

        return str;
    }

    public static String getHuonRiskType(String componentName) {
        if (componentName.isEmpty())
            return "";

        if (componentName.contains("&"))
            componentName = componentName.replace("&", "&amp;");

        String riskType = "";
        for (Map.Entry<String, String> entry : componentNameMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(componentName)) {
                riskType = entry.getKey();
                break;
            }
        }
        return riskType;
    }

    /**
     * Get ESB address indicator (floor or building type)
     *
     * @param indicator
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbAddressIndicator(String indicator) throws InvalidDataException {
        if (indicator.trim().isEmpty())
            return "";
        String str = addressIndicatorMap.get(indicator);
        if (str == null)
            throw new InvalidDataException("Indicator - " + indicator + " - is not in addressIndicatorMap");

        return str;
    }

    public static String getHuonAddressIndicator(String indicator) {
        if (indicator.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : addressIndicatorMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(indicator)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB usage
     *
     * @param usage
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbUsage(String usage) throws InvalidDataException {
        //No mapping
//		return usage;

        String str = usageMap.get(usage);
        if (str == null)
            throw new InvalidDataException("usage - " + usage + " - is not in usageMap");

        return str;
    }

    public static String getHuonUsage(String usage) {
        if (usage.isEmpty())
            return "";

        String huonUsage = "";
        for (Map.Entry<String, String> entry : usageMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(usage)) {
                huonUsage = entry.getKey();
                break;
            }
        }
        return huonUsage;
    }

    /**
     * Get ESB register tax
     *
     * @param registerTax
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbRegisterTax(String registerTax) throws InvalidDataException {
        //No mapping
//		return registerTax;

        if (registerTax.trim().isEmpty())
            return "";
        String str = registerTaxMap.get(registerTax);
        if (str == null)
            throw new InvalidDataException("registerTaxMap - " + registerTax + " - is not in registerTaxMap");

        return str;
    }

    public static String getHuonRegisterTax(String registerTax) {
        if (registerTax.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : registerTaxMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(registerTax)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB business type
     *
     * @param businessType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBusinessType(String businessType) throws InvalidDataException {
        //No mapping
//		return businessType;

        if (businessType.trim().isEmpty())
            return "";
        String str = businessTypeMap.get(businessType);
        if (str == null)
            throw new InvalidDataException("businessType - " + businessType + " - is not in businessTypeMap");

        return str;
    }

    public static String getHuonBusinessType(String businessType) {
        if (businessType.isEmpty())
            return "";

        if (businessType.contains("&"))
            businessType = businessType.replace("&", "&amp;");

        String huonValue = "";
        for (Map.Entry<String, String> entry : businessTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(businessType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB Trailer business type
     *
     * @param trailerbusinessType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbTrailerBusinessType(String trailerbusinessType) throws InvalidDataException {
        //No mapping
//		return businessType;

        if (trailerbusinessType.trim().isEmpty())
            return "";
        String str = trailerbusinessTypeMap.get(trailerbusinessType);
        if (str == null)
            throw new InvalidDataException("Trailer Business Type - " + trailerbusinessType + " - is not in trailerbusinessTypeMap");

        return str;
    }

    public static String getHuonTrailerBusinessType(String trailerbusinessType) {
        if (trailerbusinessType.isEmpty())
            return "";

        if (trailerbusinessType.contains("&"))
            trailerbusinessType = trailerbusinessType.replace("&", "&amp;");

        String huonValue = "";
        for (Map.Entry<String, String> entry : trailerbusinessTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(trailerbusinessType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB occupany
     *
     * @param occupany
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbOccupany(String occupany) throws InvalidDataException {
        if (occupany.isEmpty())
            return "";

        //No mapping
//		return occupany;

        String str = occupanyMap.get(occupany);
        if (str == null)
            throw new InvalidDataException("Occupany - " + occupany + " - is not in occupanyMap");

        return str;
    }

    public static String getHuonOccupany(String occupany) {
        if (occupany.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : occupanyMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(occupany)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB construction type
     *
     * @param constructionType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbConstructionType(String constructionType) throws InvalidDataException {
        if (constructionType.isEmpty())
            return "";

//		return constructionType;


        String str = constructionTypeMap.get(constructionType);
        if (str == null)
            throw new InvalidDataException("constructionType - " + constructionType + " - is not in constructionTypeMap");

        return str;
    }

    public static String getHuonConstructionType(String constructionType) {
        if (constructionType.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : constructionTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(constructionType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB roof type
     *
     * @param roofType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbRoofType(String roofType) throws InvalidDataException {
        if (roofType.isEmpty())
            return "";

//		return roofType;

        String str = roofTypeMap.get(roofType);
        if (str == null)
            throw new InvalidDataException("roofTypeMap - " + roofType + " - is not in roofTypeMap");

        return str;
    }

    public static String getHuonRoofType(String roofType) {
        if (roofType.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : roofTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(roofType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB dwelling type
     *
     * @param dwellingType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbDwellingType(String dwellingType) throws InvalidDataException {
        if (dwellingType.isEmpty())
            return "";
        //No mapping
//		return dwellingType;

        String str = dwellingTypeMap.get(dwellingType);
        if (str == null)
            throw new InvalidDataException("dwellingType - " + dwellingType + " - is not in dwellingTypeMap");

        return str;
    }

    public static String getHuonDwellingType(String dwellingType) {
        if (dwellingType.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : dwellingTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(dwellingType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB alarm type
     *
     * @param alarmType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbAlarmType(String alarmType) throws InvalidDataException {
        if (alarmType.isEmpty())
            return "";
        //No mapping
//		return alarmType;

        String str = alarmTypeMap.get(alarmType);
        if (str == null)
            throw new InvalidDataException("AlarmType - " + alarmType + " - is not in alarmTypeMap");

        return str;
    }

    public static String getHuonAlarmType(String alarmType) {
        if (alarmType.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : alarmTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(alarmType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB locked window
     *
     * @param lockedWindow
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbLockedWindow(String lockedWindow) throws InvalidDataException {
        if (lockedWindow.isEmpty())
            return "";
//		return lockedWindow;

        String str = lockedWindowMap.get(lockedWindow);
        if (str == null)
            throw new InvalidDataException("LockedWindow - " + lockedWindow + " - is not in lockedWindowMap");

        return str;
    }

    public static String getHuonLockedWindow(String lockedWindow) {
        if (lockedWindow.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : lockedWindowMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(lockedWindow)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }


    /**
     * Get ESB previous insurer
     *
     * @param previousInsurer
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbPreviousInsurer(String previousInsurer) throws InvalidDataException {
        if (previousInsurer.isEmpty())
            return "";
        //No mapping
//		return previousInsurer;

        String str = previousInsurerMap.get(previousInsurer);
        if (str == null)
            throw new InvalidDataException("PreviousInsurer - " + previousInsurer + " - is not in previousInsurerMap");

        return str;
    }

    public static String getHuonPreviousInsurer(String previousInsurer) {
        if (previousInsurer.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : previousInsurerMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(previousInsurer)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }


    /**
     * Get ESB ncb protection
     *
     * @param ncbProtection
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbNcbProtection(String ncbProtection) throws InvalidDataException {
        if (ncbProtection.isEmpty())
            ncbProtection = "N";

        //No mapping
//		return ncbProtection;

        String str = ncbProtectionMap.get(ncbProtection);
        if (str == null)
            throw new InvalidDataException("ncbProtection - " + ncbProtection + " - is not in ncbProtectionMap");

        return str;
    }

    public static String getHuonNcbProtection(String ncbProtection) {
        if (ncbProtection.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : ncbProtectionMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(ncbProtection)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB PV coverage name
     * //	 * @param pvCoveragename
     *
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCoverageName(String coveragename) throws InvalidDataException {
        if (coveragename.isEmpty())
            return "";

        String str = coverageMap.get(coveragename);
        if (str == null)
            throw new InvalidDataException("coveragename - " + coveragename + " - is not in coverageMap");

        return str;
    }

    public static String getHuonCoverageName(String coveragename) {
        if (coveragename.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : coverageMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(coveragename)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB street type
     *
     * @param streetType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbStreetType(String streetType) throws InvalidDataException {
        if (streetType.isEmpty())
            return "";

        String str = streetTypeMap.get(streetType);
        if (str == null)
            throw new InvalidDataException("streetType - " + streetType + " - is not in streetTypeMap");

        return str;
    }

    public static String getHuonStreetType(String streetType) {
        if (streetType.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : streetTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(streetType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB street direction
     * !!!!!!!!!!!!! Actually ESB use HUON value directly
     *
     * @param streetDirection
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbStreetDirection(String streetDirection) throws InvalidDataException {
        if (streetDirection.isEmpty())
            return "";

        String str = streetDirectionMap.get(streetDirection);
        if (str == null)
            throw new InvalidDataException("streetDirection - " + streetDirection + " - is not in streetDirectionMap");

        return str;
    }

    public static String getHuonStreetDirection(String streetDirection) {
        if (streetDirection.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : streetDirectionMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(streetDirection)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB staff flag
     *
     * @param staffFlag
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbStaffFlag(String staffFlag) throws InvalidDataException {
        if (staffFlag.isEmpty())
            return "";

        String str = staffFlagMap.get(staffFlag);
        if (str == null)
            throw new InvalidDataException("staffFlag - " + staffFlag + " - is not in staffFlagMap");

        return str;
    }

    public static String getHuonStaffFlag(String staffFlag) {
        if (staffFlag.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : staffFlagMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(staffFlag)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }


    /**
     * Get ESB embargo code
     *
     * @param embargo
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbEmbargo(String embargo) throws InvalidDataException {
        if (embargo.isEmpty())
            return "";

        String str = embargoMap.get(embargo);
        if (str == null)
            throw new InvalidDataException("embargo - " + embargo + " - is not in embargoMap");

        return str;
    }

    public static String getHuonEmbargo(String embargo) {
        if (embargo.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : embargoMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(embargo)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB excess type. Actually, broker uses HUON value so this method just return the input value for now
     *
     * @param excessType
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbExcessType(String excessType) throws InvalidDataException {
//		return excessType;
        if (excessType.isEmpty())
            return "";

        String str = excessTypeMap.get(excessType);
        if (str == null)
            throw new InvalidDataException("excessType - " + excessType + " - is not in excessTypeMap");

        return str;
    }

    public static String getHuonExcessType(String excessType) {
        if (excessType.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : excessTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(excessType)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    public static String getHuonBasicExcessType(String esbExcessType) {
        if (esbExcessType.isEmpty())
            return "";

        String excessType = "";
        for (Map.Entry<String, String> entry : excessTypeMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(esbExcessType)) {
                excessType = entry.getKey();
                break;
            }
        }
        return excessType;
    }

    /**
     * Get ESB make description
     *
     * @param makeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbMakeDesc(String makeDesc) throws InvalidDataException {
        if (makeDesc.isEmpty())
            return "";

        String str = makeDescMap.get(makeDesc);
        if (str == null)
            throw new InvalidDataException("makeDesc - " + makeDesc + " - is not in makeDescMap");

        return str;
    }

    public static String getHuonMakeDesc(String makeDesc) {
        if (makeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : makeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(makeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }
        return huonValue;
    }

    /**
     * Get ESB Boat Trailer Make description
     *
     * @param boatTrailerMakeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBoatTrailerMakeDesc(String boatTrailerMakeDesc) throws InvalidDataException {
        if (boatTrailerMakeDesc.isEmpty())
            return "";

        String str = trailerMakeDescMap.get(boatTrailerMakeDesc);
        if (str == null)
            throw new InvalidDataException("Boat Trailer Make Description - " + boatTrailerMakeDesc + " - is not in trailerMakeDescMap");

        return str;
    }

    public static String getHuonBoatTrailerMakeDesc(String boatTrailerMakeDesc) {
        if (boatTrailerMakeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : trailerMakeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatTrailerMakeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Trailer Type description
     *
     * @param boatTrailerMakeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBoatTrailerTypeDesc(String boatTrailerTypeDesc) throws InvalidDataException {
        if (boatTrailerTypeDesc.isEmpty())
            return "";

        String str = boatTrailerTypeDescMap.get(boatTrailerTypeDesc);
        if (str == null)
            throw new InvalidDataException("Boat Trailer Type Description - " + boatTrailerTypeDesc + " - is not in boatTrailerTypeDescMap");

        return str;
    }

    public static String getHuonBoatTrailerTypeDesc(String boatTrailerTypeDesc) {
        if (boatTrailerTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : boatTrailerTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatTrailerTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Sail Material description
     *
     * @param boatSailMaterialDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBoatSailMaterialDesc(String boatSailMaterialDesc) throws InvalidDataException {
        if (boatSailMaterialDesc.isEmpty())
            return "";

        String str = boatSailMaterialDescMap.get(boatSailMaterialDesc);
        if (str == null)
            throw new InvalidDataException("Boat Sail Material Description - " + boatSailMaterialDesc + " - is not in boatSailMaterialDescMap");

        return str;
    }

    public static String getHuonBoatSailMaterialDesc(String boatSailMaterialDesc) {
        if (boatSailMaterialDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : boatSailMaterialDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatSailMaterialDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Primary Waters description
     *
     * @param boatPrimaryWatersDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBoatPrimaryWatersDesc(String boatPrimaryWatersDesc) throws InvalidDataException {
        if (boatPrimaryWatersDesc.isEmpty())
            return "";

        String str = boatPrimaryWatersDescMap.get(boatPrimaryWatersDesc);
        if (str == null)
            throw new InvalidDataException("Boat Primary Waters Description - " + boatPrimaryWatersDesc + " - is not in boatPrimaryWatersDescMap");

        return str;
    }

    public static String getHuonBoatPrimaryWatersDesc(String boatPrimaryWatersDesc) {
        if (boatPrimaryWatersDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : boatPrimaryWatersDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatPrimaryWatersDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Hull Maker description
     *
     * @param boatHullMakerDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBoatHullMakerDesc(String boatHullMakerDesc) throws InvalidDataException {
        if (boatHullMakerDesc.isEmpty())
            return "";

        String str = boatHullMakerDescMap.get(boatHullMakerDesc);
        if (str == null)
            throw new InvalidDataException("Boat Hull Maker Description - " + boatHullMakerDesc + " - is not in boatHullMakerDescMap");

        return str;
    }

    public static String getHuonBoatHullMakerDesc(String boatHullMakerDesc) {
        if (boatHullMakerDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : boatHullMakerDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatHullMakerDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Business Type description
     *
     * @param boatBusinessTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBoatBusinessTypeDesc(String boatBusinessTypeDesc) throws InvalidDataException {
        if (boatBusinessTypeDesc.isEmpty())
            return "";

        String str = boatBusinessTypeDescMap.get(boatBusinessTypeDesc);
        if (str == null)
            throw new InvalidDataException("Boat Business Type Description - " + boatBusinessTypeDesc + " - is not in boatBusinessTypeDescMap");

        return str;
    }

    public static String getHuonBoatBusinessTypeDesc(String boatBusinessTypeDesc) {
        if (boatBusinessTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : boatBusinessTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatBusinessTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Finance Type description
     * //	 * @param boatFinanceTypeDesc
     *
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbFinanceTypeDesc(String FinanceTypeDesc) throws InvalidDataException {
        if (FinanceTypeDesc.isEmpty())
            return "";

        String str = financeTypeDescMap.get(FinanceTypeDesc);
        if (str == null)
            throw new InvalidDataException("Boat Finance Type Description - " + FinanceTypeDesc + " - is not in boatFinanceTypeDescMap");

        return str;
    }

    public static String getHuonFinanceTypeDesc(String FinanceTypeDesc) {
        if (FinanceTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : financeTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(FinanceTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Type description
     *
     * @param boatHullBoatTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbHullBoatTypeDesc(String boatHullBoatTypeDesc) throws InvalidDataException {
        if (boatHullBoatTypeDesc.isEmpty())
            return "";

        String str = hullBoatTypeDescMap.get(boatHullBoatTypeDesc);
        if (str == null)
            throw new InvalidDataException("Boat Type Description - " + boatHullBoatTypeDesc + " - is not in hullBoatTypeDescMap");

        return str;
    }

    public static String getHuonHullBoatTypeDesc(String boatHullBoatTypeDesc) {
        if (boatHullBoatTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : hullBoatTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatHullBoatTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Kept description
     *
     * @param boatHullKeptDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbHullKeptDesc(String boatHullKeptDesc) throws InvalidDataException {
        if (boatHullKeptDesc.isEmpty())
            return "";

        String str = hullKeptDescMap.get(boatHullKeptDesc);
        if (str == null)
            throw new InvalidDataException("Boat Kept Description - " + boatHullKeptDesc + " - is not in hullKeptDescMap");

        return str;
    }

    public static String getHuonHullKeptDesc(String boatHullKeptDesc) {
        if (boatHullKeptDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : hullKeptDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatHullKeptDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Hull Material description
     *
     * @param boatHullMaterialDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbHullMaterialDesc(String boatHullMaterialDesc) throws InvalidDataException {
        if (boatHullMaterialDesc.isEmpty())
            return "";

        String str = hullMaterialDescMap.get(boatHullMaterialDesc);
        if (str == null)
            throw new InvalidDataException("Boat Hull Material Description - " + boatHullMaterialDesc + " - is not in hullMaterialDescMap");

        return str;
    }

    public static String getHuonHullMaterialDesc(String boatHullMaterialDesc) {
        if (boatHullMaterialDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : hullMaterialDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatHullMaterialDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Caravan Material description
     *
     * @param caravanMaterialDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCaravanMaterialDesc(String caravanMaterialDesc) throws InvalidDataException {
        if (caravanMaterialDesc.isEmpty())
            return "";

        String str = caravanMaterialDescMap.get(caravanMaterialDesc);
        if (str == null)
            throw new InvalidDataException("Caravan Material Description - " + caravanMaterialDesc + " - is not in caravanMaterialDescMap");

        return str;
    }

    public static String getHuonCaravanMaterialDesc(String caravanMaterialDesc) {
        if (caravanMaterialDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : caravanMaterialDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(caravanMaterialDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Boat Hull Purchase From description
     *
     * @param boatHullPurchaseFromDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbHullPurchaseFromDesc(String boatHullPurchaseFromDesc) throws InvalidDataException {
        if (boatHullPurchaseFromDesc.isEmpty())
            return "";

        String str = hullPurchaseFromDescMap.get(boatHullPurchaseFromDesc);
        if (str == null)
            throw new InvalidDataException("Boat Hull Purchase From Description - " + boatHullPurchaseFromDesc + " - is not in hullPurchaseFromDescMap");

        return str;
    }

    public static String getHuonHullPurchaseFromDesc(String boatHullPurchaseFromDesc) {
        if (boatHullPurchaseFromDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : hullPurchaseFromDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(boatHullPurchaseFromDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Caravan Purchase From description
     *
     * @param caravanPurchaseFromDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCaravanPurchaseFromDesc(String caravanPurchaseFromDesc) throws InvalidDataException {
        if (caravanPurchaseFromDesc.isEmpty())
            return "";

        String str = caravanPurchaseFromDescMap.get(caravanPurchaseFromDesc);
        if (str == null)
            throw new InvalidDataException("Caravan Purchase From Description - " + caravanPurchaseFromDesc + " - is not in caravanPurchaseFromDescMap");

        return str;
    }

    public static String getHuonCaravanPurchaseFromDesc(String caravanPurchaseFromDesc) {
        if (caravanPurchaseFromDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : caravanPurchaseFromDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(caravanPurchaseFromDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB NCB Override Reason description
     *
     * @param NCBOverrideReasonDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbNCBOverrideReasonDesc(String NCBOverrideReasonDesc) throws InvalidDataException {
        if (NCBOverrideReasonDesc.isEmpty())
            return "";

        String str = NCBOverrideReasonDescMap.get(NCBOverrideReasonDesc);
        if (str == null)
            throw new InvalidDataException("NCB Override Reason Description - " + NCBOverrideReasonDesc + " - is not in NCBOverrideReasonDescMap");

        return str;
    }

    public static String getHuonNCBOverrideReasonDesc(String NCBOverrideReasonDesc) {
        if (NCBOverrideReasonDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : NCBOverrideReasonDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(NCBOverrideReasonDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Motor Type description
     *
     * @param motorTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbMotorTypeDesc(String motorTypeDesc) throws InvalidDataException {
        if (motorTypeDesc.isEmpty())
            return "";

        String str = motorTypeDescMap.get(motorTypeDesc);
        if (str == null)
            throw new InvalidDataException("Motor Type Description - " + motorTypeDesc + " - is not in motorTypeDescMap");

        return str;
    }

    public static String getHuonMotorTypeDesc(String motorTypeDesc) {
        if (motorTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : motorTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(motorTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Motor Fuel Type description
     *
     * @param motorFuelTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbMotorFuelTypeDesc(String motorFuelTypeDesc) throws InvalidDataException {
        if (motorFuelTypeDesc.isEmpty())
            return "";

        String str = motorFuelTypeDescMap.get(motorFuelTypeDesc);
        if (str == null)
            throw new InvalidDataException("Motor Fuel Type Description - " + motorFuelTypeDesc + " - is not in motorFuelTypeDescMap");

        return str;
    }

    public static String getHuonMotorFuelTypeDesc(String motorFuelTypeDesc) {
        if (motorFuelTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : motorFuelTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(motorFuelTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Motor Make description
     *
     * @param motorMakeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbMotorMakeDesc(String motorMakeDesc) throws InvalidDataException {
        if (motorMakeDesc.isEmpty())
            return "";

        String str = motorMakeDescMap.get(motorMakeDesc);
        if (str == null)
            throw new InvalidDataException("Motor Make Description - " + motorMakeDesc + " - is not in motorMakeDescMap");

        return str;
    }

    public static String getHuonMotorMakeDesc(String motorMakeDesc) {
        if (motorMakeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : motorMakeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(motorMakeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Other Party Client Type description
     *
     * @param otherPartyClientTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbOtherPartyClientTypeDesc(String otherPartyClientTypeDesc) throws InvalidDataException {
        if (otherPartyClientTypeDesc.isEmpty())
            return "";

        String str = otherPartyClientTypeDescMap.get(otherPartyClientTypeDesc);
        if (str == null)
            throw new InvalidDataException("Other Party Client Type Description - " + otherPartyClientTypeDesc + " - is not in otherPartyClientTypeDescMap");

        return str;
    }

    public static String getHuonOtherPartyClientTypeDesc(String otherPartyClientTypeDesc) {
        if (otherPartyClientTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : otherPartyClientTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(otherPartyClientTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Caravan Body Type description
     *
     * @param caravanBodyTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCaravanBodyTypeDesc(String caravanBodyTypeDesc) throws InvalidDataException {
        if (caravanBodyTypeDesc.isEmpty())
            return "";

        String str = caravanBodyTypeDescMap.get(caravanBodyTypeDesc);
        if (str == null)
            throw new InvalidDataException("Caravan Body Type Description - " + caravanBodyTypeDesc + " - is not in caravanBodyTypeDescMap");

        return str;
    }

    public static String getHuonCaravanBodyTypeDesc(String caravanBodyTypeDesc) {
        if (caravanBodyTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : caravanBodyTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(caravanBodyTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Trailer Body Type description
     *
     * @param trailerBodyTypeDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbTrailerBodyTypeDesc(String trailerBodyTypeDesc) throws InvalidDataException {
        if (trailerBodyTypeDesc.isEmpty())
            return "";

        String str = trailerBodyTypeDescMap.get(trailerBodyTypeDesc);
        if (str == null)
            throw new InvalidDataException("Trailer Body Type Description - " + trailerBodyTypeDesc + " - is not in trailerBodyTypeDescMap");

        return str;
    }

    public static String getHuonTrailerBodyTypeDesc(String trailerBodyTypeDesc) {
        if (trailerBodyTypeDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : trailerBodyTypeDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(trailerBodyTypeDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Caravan Parking Place description
     *
     * @param caravanParkingPlaceDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCaravanParkingPlaceDesc(String caravanParkingPlaceDesc) throws InvalidDataException {
        if (caravanParkingPlaceDesc.isEmpty())
            return "";

        String str = caravanParkingPlaceDescMap.get(caravanParkingPlaceDesc);
        if (str == null)
            throw new InvalidDataException("Caravan Parking Place Description - " + caravanParkingPlaceDesc + " - is not in caravanParkingPlaceDescMap");

        return str;
    }

    public static String getHuonCaravanParkingPlaceDesc(String caravanParkingPlaceDesc) {
        if (caravanParkingPlaceDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : caravanParkingPlaceDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(caravanParkingPlaceDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Premium Override Reason description
     *
     * @param premiumOverrideReasonDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbpremiumOverrideReasonDesc(String premiumOverrideReasonDesc) throws InvalidDataException {
        if (premiumOverrideReasonDesc.isEmpty())
            return "";

        String str = premiumOverrideReasonDescMap.get(premiumOverrideReasonDesc);
        if (str == null)
            throw new InvalidDataException("Premium Override Reason Description - " + premiumOverrideReasonDesc + " - is not in premiumOverrideReasonDescMap");

        return str;
    }

    public static String getHuonpremiumOverrideReasonDesc(String premiumOverrideReasonDesc) {
        if (premiumOverrideReasonDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : premiumOverrideReasonDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(premiumOverrideReasonDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Policy Cancel Reason Type description
     *
     * @param policyCancelReasonDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbPolicyCancelReasonDesc(String policyCancelReasonDesc) throws InvalidDataException {
        if (policyCancelReasonDesc.isEmpty())
            return "";

        String str = policyCancelReasonDescMap.get(policyCancelReasonDesc);
        if (str == null)
            throw new InvalidDataException("Policy Cancel Reason Description - " + policyCancelReasonDesc + " - is not in policyCancelReasonDescMap");

        return str;
    }

    public static String getHuonPolicyCancelReasonDesc(String policyCancelReasonDesc) {
        if (policyCancelReasonDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : policyCancelReasonDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(policyCancelReasonDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Basic Premium Override Reason Type description
     *
     * @param basicPremiumOverrideReasonDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbBasicPremiumOverrideReasonDesc(String basicPremiumOverrideReasonDesc) throws InvalidDataException {
        if (basicPremiumOverrideReasonDesc.isEmpty())
            return "";

        String str = basicPremiumOverrideReasonDescMap.get(basicPremiumOverrideReasonDesc);
        if (str == null)
            throw new InvalidDataException("Basic Premium Override Reason Description - " + basicPremiumOverrideReasonDesc + " - is not in basicPremiumOverrideReasonDescMap");

        return str;
    }

    public static String getHuonBasicPremiumOverrideReasonDesc(String basicPremiumOverrideReasonDesc) {
        if (basicPremiumOverrideReasonDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : basicPremiumOverrideReasonDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(basicPremiumOverrideReasonDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB Commission Override Reason Type description
     *
     * @param commissionOverrideReasonDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCommissionOverrideReasonDesc(String commissionOverrideReasonDesc) throws InvalidDataException {
        if (commissionOverrideReasonDesc.isEmpty())
            return "";

        String str = commissionOverrideReasonDescMap.get(commissionOverrideReasonDesc);
        if (str == null)
            throw new InvalidDataException("Commission Override Reason Description - " + commissionOverrideReasonDesc + " - is not in commissionOverrideReasonDescMap");

        return str;
    }

    public static String getHuonCommissionOverrideReasonDesc(String commissionOverrideReasonDesc) {
        if (commissionOverrideReasonDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : commissionOverrideReasonDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(commissionOverrideReasonDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get ESB CTP Vehicle Use description
     *
     * @param ctpVehicleUseDesc
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbCTPVehicleUseDesc(String ctpVehicleUseDesc) throws InvalidDataException {
        if (ctpVehicleUseDesc.isEmpty())
            return "";

        String str = ctpVehicleUseDescMap.get(ctpVehicleUseDesc);
        if (str == null)
            throw new InvalidDataException("CTP Vehicle Use Description - " + ctpVehicleUseDesc + " - is not in ctpVehicleUseDescMap");

        return str;
    }

    public static String getHuonCTPVehicleUseDesc(String ctpVehicleUseDesc) {
        if (ctpVehicleUseDesc.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : ctpVehicleUseDescMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(ctpVehicleUseDesc)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get NSW Address
     *
     * @param nswAddress
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbNSWAddress(String nswAddress) throws InvalidDataException {
        if (nswAddress.isEmpty())
            return "";

        String str = NSWaddressMap.get(nswAddress);
        if (str == null)
            throw new InvalidDataException("NSW Address - " + nswAddress + " - is not in nswAddressMap");

        return str;
    }

    public static String getHuonNSWAddress(String nswAddress) {
        if (nswAddress.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : NSWaddressMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(nswAddress)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    /**
     * Get State Codes
     *
     * @param riskState
     * @return
     * @throws InvalidDataException
     */
    public static String getEsbRiskState(String riskState) throws InvalidDataException {
        if (riskState.isEmpty())
            return "";

        String str = riskStateMap.get(riskState);
        if (str == null)
            throw new InvalidDataException("Risk State - " + riskState + " - is not in riskStateMap");

        return str;
    }

    public static String getHuonRiskState(String riskState) {
        if (riskState.isEmpty())
            return "";

        String huonValue = "";
        for (Map.Entry<String, String> entry : riskStateMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(riskState)) {
                huonValue = entry.getKey();
                break;
            }
        }

        return huonValue;
    }

    static {
        componentNameMap.put("BKCP", "Bike Comprehensive");
        componentNameMap.put("BKTP", "Bike Third Party Property Damage");
        componentNameMap.put("BLDG", "Home Buildings");
        componentNameMap.put("BLDG+", "Home Plus Buildings");
        componentNameMap.put("BOT", "Boat");
        componentNameMap.put("BUSINSUR", "Business Insurance");
        componentNameMap.put("CONT", "Home Contents");
        componentNameMap.put("CONT+", "Home Plus Contents");
        componentNameMap.put("CRCP", "Car Comprehensive");
        componentNameMap.put("CRCP+", "Car Comprehensive Plus");
        componentNameMap.put("CRFT", "Car Third Party Fire &amp; Theft");
        componentNameMap.put("CRTP", "Car Third Party Property Damage");
        componentNameMap.put("CTA", "CTPACT");
        componentNameMap.put("CTP", "CTPNSW");
        componentNameMap.put("CTQ", "CTPQLD");
        componentNameMap.put("CVT", "Caravan");
        componentNameMap.put("ERA", "ERA");
        componentNameMap.put("FUNERAL", "Funeral");
        componentNameMap.put("HEALTH", "Health");
        componentNameMap.put("HPAC", "Home Combined");
        componentNameMap.put("HPAC+", "Home Plus Combined");
        componentNameMap.put("HSE", "Home Security");
        componentNameMap.put("INCOME", "Income");
        componentNameMap.put("LAND", "Landlords");
        componentNameMap.put("LIFE", "Life Insurance");
        componentNameMap.put("MEMBER", "Membership");
        componentNameMap.put("ONS", "Onsite Caravan");
        componentNameMap.put("PERSONAL", "Personal");
        componentNameMap.put("PSEF", "Personal Effect");
        componentNameMap.put("STRA", "Strata");
        componentNameMap.put("TAI", "Transport and Accident");
        componentNameMap.put("TOU", "Touring Caravan");
        componentNameMap.put("TPFT", "Third Party Fire &amp; Theft");
        componentNameMap.put("TRL", "Trailer");
        componentNameMap.put("TVL", "Travel");
        componentNameMap.put("HP.EXTRA", "Hp.Extra");
        componentNameMap.put("HP.SURE", "Hp.Sure");
        componentNameMap.put("C.EXTRA", "C.Extra");
        componentNameMap.put("C.SURE", "C.Sure");
        componentNameMap.put("BC", "Billing");
        componentNameMap.put("B.EXTRA", "B.Extra");
        componentNameMap.put("B.SURE", "B.Sure");

        addressIndicatorMap.put("A", "Apartment");
        addressIndicatorMap.put("D", "Bay");
        addressIndicatorMap.put("6", "Block");
        addressIndicatorMap.put("B", "General Post Office Box");
        addressIndicatorMap.put("C", "Building");
        addressIndicatorMap.put("H", "Cabin");
        addressIndicatorMap.put("8", "Community Mail Bag");
        addressIndicatorMap.put("1", "Cottage");
        addressIndicatorMap.put("0", "Division");
        addressIndicatorMap.put("<�", "Duplex");
        addressIndicatorMap.put("K", "Factory");
        addressIndicatorMap.put("R", "Farm");
        addressIndicatorMap.put("(", "Flat");
        addressIndicatorMap.put("F", "Floor");
        addressIndicatorMap.put("E", "Hangar");
        addressIndicatorMap.put("+", "House");
        addressIndicatorMap.put("*", "Kiosk");
        addressIndicatorMap.put("L", "Level");
        addressIndicatorMap.put("N", "Lodge");
        addressIndicatorMap.put("G", "Lot");
        addressIndicatorMap.put("&", "Maisonette");
        addressIndicatorMap.put(")", "Marine Berth");
        addressIndicatorMap.put("O", "Office");
        addressIndicatorMap.put("$", "Penthouse");
        addressIndicatorMap.put("I", "Pier");
        addressIndicatorMap.put("P", "PO Box");
        addressIndicatorMap.put("W", "Portion");
        addressIndicatorMap.put("X", "Post Office");
        addressIndicatorMap.put(";", "Private Mail Bag");
        addressIndicatorMap.put("V", "Private Mail Bag");
        addressIndicatorMap.put("~", "Rear");
        addressIndicatorMap.put("Q", "Roadside Delivery");
        addressIndicatorMap.put("Y", "Roadside Mail Bag");
        addressIndicatorMap.put("J", "Room");
        addressIndicatorMap.put("9", "Roadside Mail Service");
        addressIndicatorMap.put("}", "Rural Delivery");
        addressIndicatorMap.put("2", "Section");
        addressIndicatorMap.put(">�", "Shed");
        addressIndicatorMap.put("Z", "Shop");
        addressIndicatorMap.put("3", "Site");
        addressIndicatorMap.put("@", "Stall");
        addressIndicatorMap.put("4", "Studio");
        addressIndicatorMap.put("S", "Suite");
        addressIndicatorMap.put("{", "Townhouse");
        addressIndicatorMap.put("U", "Unit");
        addressIndicatorMap.put("5", "Villa");
        addressIndicatorMap.put("7", "Ward");
        addressIndicatorMap.put("M", "Mailbag");
        addressIndicatorMap.put("T", "MS Box");


        usageMap.put("B", "Business");
        usageMap.put("C", "Residential and Business");
        usageMap.put("R", "Residential");
        usageMap.put("", "Unknown");


        registerTaxMap.put("N", "Not Registered");
        registerTaxMap.put("U", "Unknown");
        registerTaxMap.put("Y", "Registered");

        businessTypeMap.put("BEDB", "Bed &amp; Breakfast");
        businessTypeMap.put("COMP", "Computing / Graphics");
        businessTypeMap.put("FILM", "Video / Photography / Film / Audio");
        businessTypeMap.put("FMDC", "Family Daycare");
        businessTypeMap.put("HAIR", "Beautician / Hairdresser / Grooming");
        businessTypeMap.put("MEDI", "Medical");
        businessTypeMap.put("TMAN", "Handyman / Tradesman / Cleaner");
        businessTypeMap.put("UNAC", "Unacceptable");
        businessTypeMap.put("CONS", "Consulting / Home Office");
        businessTypeMap.put("FOOD", "Food Catering");

        trailerbusinessTypeMap.put("BH", "BUSINESS HIRE");
        trailerbusinessTypeMap.put("CO", "COURIER");
        trailerbusinessTypeMap.put("PR", "PRIVATE");
        trailerbusinessTypeMap.put("RT", "RETAIL - VENDOR");

        occupanyMap.put("OWHOL", "owner's holiday home / weekender");
        occupanyMap.put("OWTEN", "Combination of owners and tenants");
        occupanyMap.put("OWNER", "owner who lives in the house");
        occupanyMap.put("HOLET", "Tenants - holiday letting");
        occupanyMap.put("LANDL", "Tenants via landlords");
        occupanyMap.put("�SPACE", "Unknown");
        occupanyMap.put("UNOCC", "Unoccupied");
        occupanyMap.put("RENTR", "Tenant");


        constructionTypeMap.put("BV", "Brick Veneer");
        constructionTypeMap.put("CE", "Cement");
        constructionTypeMap.put("CL", "Cladding");
        constructionTypeMap.put("CB", "Concrete Block (Besser)");
        constructionTypeMap.put("DB", "Double Brick");
        constructionTypeMap.put("FC", "Fibre Cement (Fibro)");
        constructionTypeMap.put("MT", "Metal");
        constructionTypeMap.put("MB", "Mud Brick");
        constructionTypeMap.put("SA", "Rock / Stone");
        constructionTypeMap.put("RO", "Rockcote EPS (Expand Polystyrene)");
        constructionTypeMap.put("TW", "Timber / Weatherboard");
        constructionTypeMap.put("", "Unknown");

        roofTypeMap.put("FI", "Fibro");
        roofTypeMap.put("SL", "Slate");
        roofTypeMap.put("TI", "Tin / Colourbond");
        roofTypeMap.put("CO", "Concrete");
        roofTypeMap.put("CT", "Tile Roof - Cement");
        roofTypeMap.put("TT", "Tile Roof - Terracotta / Clay");
        roofTypeMap.put("SH", "Shingles");
        roofTypeMap.put("", "Unknown");


        dwellingTypeMap.put("HOUS", "Free Standing Dwelling");
        dwellingTypeMap.put("SEMI", "Semi Detached House");
        dwellingTypeMap.put("VILA", "Villa");
        dwellingTypeMap.put("UNIT", "Unit");

        alarmTypeMap.put("AA", "Alarm Not Monitored");
        alarmTypeMap.put("MA", "24 Hour Back to Base Monitoring");
        alarmTypeMap.put("NO", "No Alarm Fitted");

        lockedWindowMap.put("D", "Not Applicable");
        lockedWindowMap.put("N", "No");
        lockedWindowMap.put("Y", "Yes");

        previousInsurerMap.put("AAMI", "AAMI Insurance");
        previousInsurerMap.put("AANT", "AANT (Northern Territory)");
        previousInsurerMap.put("AGI", "Accident General Insurance");
        previousInsurerMap.put("AIMH", "AIM Holdings");
        previousInsurerMap.put("ALLI", "Allianz Insurance");
        previousInsurerMap.put("AIG", "American International Group");
        previousInsurerMap.put("AMEV", "AMEV");
        previousInsurerMap.put("AMP", "AMP General");
        previousInsurerMap.put("ANSV", "Ansvar");
        previousInsurerMap.put("ANYO", "Any Other Insurer");
        previousInsurerMap.put("ANZ", "Anz");
        previousInsurerMap.put("API", "API Insurance Group");
        previousInsurerMap.put("ARB", "ARB 4X4");
        previousInsurerMap.put("ATUM", "Atia Underwriting Managers Pty Ltd");
        previousInsurerMap.put("AUHL", "Aussie Home Loans");
        previousInsurerMap.put("AUSI", "Australia Insurance Ltd");
        previousInsurerMap.put("AA", "Australian Alliance");
        previousInsurerMap.put("ABCU", "Australian Bus And Coach Underwriting");
        previousInsurerMap.put("AEI", "Australian Eagle Insurance");
        previousInsurerMap.put("APIA", "Australian Pensioners Insurance Agency");
        previousInsurerMap.put("ATIA", "Australian Transport Insurance Agency");
        previousInsurerMap.put("AUSU", "Australian Unity");
        previousInsurerMap.put("AVCO", "AVCO");
        previousInsurerMap.put("AVSR", "Avsure");
        previousInsurerMap.put("AXA", "AXA Insurance");
        previousInsurerMap.put("BCFS", "Baileys Court Financial Services - Motor Vehicle Division");
        previousInsurerMap.put("BIS", "Bellbird Insurance Services Pty Ltd");
        previousInsurerMap.put("BCI", "Best Cover Insurance Pty Ltd");
        previousInsurerMap.put("BUDI", "Budget Direct");
        previousInsurerMap.put("CCI", "Catholic Church Insurance Ltd.");
        previousInsurerMap.put("CGU", "Cgu Insurance");
        previousInsurerMap.put("CIC", "Cic Insurance");
        previousInsurerMap.put("CIA", "Cigna Insurance Australia Ltd");
        previousInsurerMap.put("CIT", "Citibank");
        previousInsurerMap.put("CLB", "Colonial Bank");
        previousInsurerMap.put("CONL", "Colonial Limited");
        previousInsurerMap.put("CMI", "Colonial Mutual Insurance");
        previousInsurerMap.put("CICA", "Combined Insurance Company Of Australia");
        previousInsurerMap.put("CU", "Commercial Union");
        previousInsurerMap.put("CBA", "Commonwealth Bank");
        previousInsurerMap.put("CMOI", "Cota Mature Outlook Insurance");
        previousInsurerMap.put("CIS", "Cover-More Insurance Services Pty Ltd");
        previousInsurerMap.put("DMUG", "Dawes Motor Underwriting Group");
        previousInsurerMap.put("DCTD", "Direcdial Insurance");
        previousInsurerMap.put("DIB", "Donnelly Insurance Brokers");
        previousInsurerMap.put("ELD", "Elders");
        previousInsurerMap.put("FAI", "FAI Insurance");
        previousInsurerMap.put("GECI", "GE Capital Insurance Australia Pty Ltd");
        previousInsurerMap.put("GIO", "GIO Insurance");
        previousInsurerMap.put("GUID", "Guild Insurance");
        previousInsurerMap.put("HALL", "Hallmark Insurance");
        previousInsurerMap.put("HHC", "Hanan Home And Car");
        previousInsurerMap.put("HBAC", "HBA Car Insurance");
        previousInsurerMap.put("HBF", "Health Benefit Fund");
        previousInsurerMap.put("HIHW", "HIH Winterthur Insurance");
        previousInsurerMap.put("IBIB", "Ian Berry Insurance Brokers Pty Ltd");
        previousInsurerMap.put("ING", "ING Australia");
        previousInsurerMap.put("ILU", "Institute Of London Underwriters");
        previousInsurerMap.put("IEAG", "Insurance Exchange Of Australia Group Pty Ltd");
        previousInsurerMap.put("UNKN", "Insurer Unknown");
        previousInsurerMap.put("ICC", "Integrity Care Car Pty Ltd");
        previousInsurerMap.put("JUA", "Jardine Underwriting Agency Pty Limited");
        previousInsurerMap.put("JM", "JMFor Insurance");
        previousInsurerMap.put("JCIA", "Just Car Insurance Agency Pty Ltd");
        previousInsurerMap.put("KKCP", "Kings Cross Car Park");
        previousInsurerMap.put("LDS", "Lloyds Australia");
        previousInsurerMap.put("LUML", "Lumley General Insurance");
        previousInsurerMap.put("MAN", "Mansions Australia");
        previousInsurerMap.put("MM", "Mercantile Mutual");
        previousInsurerMap.put("MLC", "MLC Insurance");
        previousInsurerMap.put("MMI", "MMI Insurance Group");
        previousInsurerMap.put("MCP", "Mutual Community Pty Ltd");
        previousInsurerMap.put("NAB", "National Australia Bank");
        previousInsurerMap.put("NT", "National Transport");
        previousInsurerMap.put("NRMF", "NRMA Fleet");
        previousInsurerMap.put("NRMA", "NRMA� Insurance Limited");
        previousInsurerMap.put("NRMO", "NRMA� Other");
        previousInsurerMap.put("NZI", "NZI Insurance");
        previousInsurerMap.put("INST", "Other Interstate Insurer");
        previousInsurerMap.put("O5IP", "Over 50'S Insurance Plan Wise - Motor Insurance");
        previousInsurerMap.put("OSIN", "Overseas Insurer");
        previousInsurerMap.put("PNSR", "Pensioners Insurance");
        previousInsurerMap.put("QBE", "QBE Insurance");
        previousInsurerMap.put("RASA", "RAASA (South Australia)");
        previousInsurerMap.put("RACQ", "RACQ Insurance");
        previousInsurerMap.put("RACT", "RACT (Tasmania)");
        previousInsurerMap.put("RACV", "RACV Insurance");
        previousInsurerMap.put("RAWA", "RACWA (Western Australia)");
        previousInsurerMap.put("RAM", "RAMS");
        previousInsurerMap.put("RP", "Ready Plan");
        previousInsurerMap.put("REIN", "Real Insurance");
        previousInsurerMap.put("RSAI", "Royal And Sun Alliance Insurance Australia Limited");
        previousInsurerMap.put("RGI", "Rural And General Insurance Ltd");
        previousInsurerMap.put("SGIC", "SGIC Insurance");
        previousInsurerMap.put("SGIO", "SGIO Insurance");
        previousInsurerMap.put("SC", "Shannons Corporation Pty Ltd");
        previousInsurerMap.put("SIRI", "Sirius Insurance");
        previousInsurerMap.put("STG", "St George Bank");
        previousInsurerMap.put("SI", "Strategic Insurance");
        previousInsurerMap.put("SALL", "Sun Alliance Insurance");
        previousInsurerMap.put("SUNC", "Suncorp Insurance");
        previousInsurerMap.put("SWAN", "Swann Insurance Pty Ltd");
        previousInsurerMap.put("TORU", "Torque Underwriting");
        previousInsurerMap.put("TII", "Transport Industries Insurance");
        previousInsurerMap.put("UAP", "UAP");
        previousInsurerMap.put("UDAD", "Union Des Assurances De Paris");
        previousInsurerMap.put("UCI", "Unique Car Insurance");
        previousInsurerMap.put("VACC", "VACC");
        previousInsurerMap.put("VVC", "Veteran Vintage And Classic Insurance");
        previousInsurerMap.put("WEST", "Western QBE Insurance");
        previousInsurerMap.put("WFI", "Westfarmers Federation Insurance");
        previousInsurerMap.put("WPC", "Westpac");
        previousInsurerMap.put("WMGI", "World Marine And General Insurance");
        previousInsurerMap.put("YFM", "Yasuda Fire And Marine");
        previousInsurerMap.put("YOUI", "YOUI");
        previousInsurerMap.put("ZUR", "Zurich");
        previousInsurerMap.put("WPC", "WESTPAC");
        previousInsurerMap.put("YFM", "YASUDA FIRE AND MARINE");
        previousInsurerMap.put("YOUI", "YOUI");
        previousInsurerMap.put("ZUR", "ZURICH");

        ncbProtectionMap.put("F", "Free");
        ncbProtectionMap.put("N", "Not Selected");
        ncbProtectionMap.put("P", "Selected");
        ncbProtectionMap.put("Y", "Selected");
        ncbProtectionMap.put("X", "Not Available");

        coverageMap.put("ACDB", "Accidental Damage Building");
        coverageMap.put("ACDC", "Accidental Damage Contents");
        coverageMap.put("BLDG", "Building");
        coverageMap.put("VCOL", "Valuable Collections");
        coverageMap.put("FLOD", "Flood");
        coverageMap.put("FUSN", "Fusion");
        coverageMap.put("GNCT", "General Contents");
        coverageMap.put("PLSB", "Home Plus Building");
        coverageMap.put("PLSC", "Home Plus Contents");
        coverageMap.put("VJAW", "Valuable Jewellery And Watches");
        coverageMap.put("LAND", "Landlord");
        coverageMap.put("VMGM", "Valuable Music Games Movies");
        coverageMap.put("PETC", "Pet Coverage");
        coverageMap.put("PLUG", "Portable Clothing And Luggage");
        coverageMap.put("PPED", "Portable Electronic Devices");
        coverageMap.put("PMED", "Portable Glasses And Medical Items");
        coverageMap.put("PJAW", "Portable Jewellery And Watches");
        coverageMap.put("PMOB", "Portable Mobility Scooters");
        coverageMap.put("PSRI", "Portable Sporting And Recreational Items");
        coverageMap.put("VWOA", "Valuable Works Of Art");

        streetTypeMap.put("ACCS", "Access");
        streetTypeMap.put("ACWY", "Accessway");
        streetTypeMap.put("ALLY", "Alley");
        streetTypeMap.put("ALWY", "Alleyway");
        streetTypeMap.put("ALYS", "Allies");
        streetTypeMap.put("AMBL", "Amble");
        streetTypeMap.put("ANCG", "Anchorage");
        streetTypeMap.put("ANNX", "Annexe");
        streetTypeMap.put("APP", "Approach");
        streetTypeMap.put("ARC", "Arcade");
        streetTypeMap.put("ARCH", "Arch");
        streetTypeMap.put("ARM", "Arm");
        streetTypeMap.put("ART", "Artery");
        streetTypeMap.put("ATHL", "Athol");
        streetTypeMap.put("AVE", "Avenue");
        streetTypeMap.put("BANK", "Bank");
        streetTypeMap.put("BRRK", "Barracks");
        streetTypeMap.put("BASE", "Base");
        streetTypeMap.put("BASN", "Basin");
        streetTypeMap.put("BAY", "Bay");
        streetTypeMap.put("BCH", "Beach");
        streetTypeMap.put("BELT", "Belt");
        streetTypeMap.put("BEND", "Bend");
        streetTypeMap.put("BLK", "Block");
        streetTypeMap.put("BLFF", "Bluff");
        streetTypeMap.put("BOG", "Bog");
        streetTypeMap.put("BTM", "Bottom");
        streetTypeMap.put("BVD", "Boulevard");
        streetTypeMap.put("BRCE", "Brace");
        streetTypeMap.put("BRAE", "Brae");
        streetTypeMap.put("BRCH", "Branch");
        streetTypeMap.put("BRK", "Break");
        streetTypeMap.put("BRET", "Brett");
        streetTypeMap.put("BRRS", "Briars");
        streetTypeMap.put("BDGE", "Bridge");
        streetTypeMap.put("BDWY", "Broadway");
        streetTypeMap.put("BROK", "Brook");
        streetTypeMap.put("BROW", "Brow");
        streetTypeMap.put("BLDG", "Building");
        streetTypeMap.put("BYPA", "Bypass");
        streetTypeMap.put("BYWY", "Byway");
        streetTypeMap.put("CAMP", "Campus");
        streetTypeMap.put("CPE", "Cape");
        streetTypeMap.put("CAUS", "Causeway");
        streetTypeMap.put("CTR", "Centre");
        streetTypeMap.put("CNWY", "Centreway");
        streetTypeMap.put("CH", "Chase");
        streetTypeMap.put("CIR", "Circle");
        streetTypeMap.put("CLT", "Circlet");
        streetTypeMap.put("CCT", "Circuit");
        streetTypeMap.put("CRCS", "Circus");
        streetTypeMap.put("CLM", "Claim");
        streetTypeMap.put("CLR", "Clear");
        streetTypeMap.put("CLWY", "Clearway");
        streetTypeMap.put("CLFS", "Cliffs");
        streetTypeMap.put("CL", "Close");
        streetTypeMap.put("COLL", "College");
        streetTypeMap.put("CLDE", "Collonade");
        streetTypeMap.put("CMMN", "Common");
        streetTypeMap.put("CON", "Concourse");
        streetTypeMap.put("CTN", "Connection");
        streetTypeMap.put("CPS", "Copse");
        streetTypeMap.put("CNR", "Corner");
        streetTypeMap.put("CNRS", "Corners");
        streetTypeMap.put("CORP", "Corp");
        streetTypeMap.put("CRPS", "Corps");
        streetTypeMap.put("CSO", "Corso");
        streetTypeMap.put("CTGE", "Cottage");
        streetTypeMap.put("COUR", "Course");
        streetTypeMap.put("CT", "Court");
        streetTypeMap.put("CRTS", "Courts");
        streetTypeMap.put("CTYD", "Courtyard");
        streetTypeMap.put("COVE", "Cove");
        streetTypeMap.put("CRK", "Creek");
        streetTypeMap.put("CRES", "Crescent");
        streetTypeMap.put("CRST", "Crest");
        streetTypeMap.put("CRSS", "Cross");
        streetTypeMap.put("CRSG", "Crossing");
        streetTypeMap.put("CRD", "Crossroad");
        streetTypeMap.put("COWY", "Crossway");
        streetTypeMap.put("CUWY", "Cruiseway");
        streetTypeMap.put("CUL", "Cul");
        streetTypeMap.put("CDS", "Cul De Sac");
        streetTypeMap.put("CTTG", "Cutting");
        streetTypeMap.put("DALE", "Dale");
        streetTypeMap.put("DAM", "Dam");
        streetTypeMap.put("DELL", "Dell");
        streetTypeMap.put("DEVN", "Deviation");
        streetTypeMap.put("DIP", "Dip");
        streetTypeMap.put("DSTR", "Distributor");
        streetTypeMap.put("DV", "Divide");
        streetTypeMap.put("DOCK", "Dock");
        streetTypeMap.put("DWNS", "Downs");
        streetTypeMap.put("DR", "Drive");
        streetTypeMap.put("DRWY", "Driveway");
        streetTypeMap.put("DUNE", "Dune");
        streetTypeMap.put("EASE", "Easement");
        streetTypeMap.put("EDGE", "Edge");
        streetTypeMap.put("ELB", "Elbow");
        streetTypeMap.put("ELM", "Elm");
        streetTypeMap.put("END", "End");
        streetTypeMap.put("ENT", "Entrance");
        streetTypeMap.put("ESP", "Esplanade");
        streetTypeMap.put("EST", "Estate");
        streetTypeMap.put("ESTS", "Estates");
        streetTypeMap.put("EXP", "Expressway");
        streetTypeMap.put("EXTN", "Extension");
        streetTypeMap.put("FAWY", "Fairway");
        streetTypeMap.put("FALL", "Fall");
        streetTypeMap.put("FLS", "Falls");
        streetTypeMap.put("FARE", "Fare");
        streetTypeMap.put("FARM", "Farm");
        streetTypeMap.put("FRMS", "Farms");
        streetTypeMap.put("FEN", "Fen");
        streetTypeMap.put("FERN", "Fern");
        streetTypeMap.put("FRY", "Ferry");
        streetTypeMap.put("FLD", "Field");
        streetTypeMap.put("FLDS", "Fields");
        streetTypeMap.put("FTRK", "Fire Track");
        streetTypeMap.put("FITR", "Firetrail");
        streetTypeMap.put("FLAT", "Flat");
        streetTypeMap.put("FLTS", "Flats");
        streetTypeMap.put("FOLW", "Follow");
        streetTypeMap.put("FTWY", "Footway");
        streetTypeMap.put("FRD", "Ford");
        streetTypeMap.put("FSHR", "Foreshore");
        streetTypeMap.put("FRST", "Forest");
        streetTypeMap.put("FRKS", "Forks");
        streetTypeMap.put("FORM", "Formation");
        streetTypeMap.put("FT", "Fort");
        streetTypeMap.put("FWY", "Freeway");
        streetTypeMap.put("FRNT", "Front");
        streetTypeMap.put("FRTG", "Frontage");
        streetTypeMap.put("GAP", "Gap");
        streetTypeMap.put("GDN", "Garden");
        streetTypeMap.put("GDNS", "Gardens");
        streetTypeMap.put("GTE", "Gate");
        streetTypeMap.put("GTES", "Gates");
        streetTypeMap.put("GTWY", "Gateway");
        streetTypeMap.put("GLD", "Glade");
        streetTypeMap.put("GLEN", "Glen");
        streetTypeMap.put("GRA", "Grange");
        streetTypeMap.put("GRN", "Green");
        streetTypeMap.put("GRND", "Ground");
        streetTypeMap.put("GR", "Grove");
        streetTypeMap.put("GLY", "Gully");
        streetTypeMap.put("HARB", "Harbour");
        streetTypeMap.put("HVEN", "Haven");
        streetTypeMap.put("HEAD", "Head");
        streetTypeMap.put("HDLD", "Headland");
        streetTypeMap.put("HETH", "Heath");
        streetTypeMap.put("HTS", "Heights");
        streetTypeMap.put("HRD", "Highroad");
        streetTypeMap.put("HWY", "Highway");
        streetTypeMap.put("HILL", "Hill");
        streetTypeMap.put("HLS", "Hills");
        streetTypeMap.put("HOSP", "Hospital");
        streetTypeMap.put("HSTL", "Hostel");
        streetTypeMap.put("HOTL", "Hotel");
        streetTypeMap.put("HSE", "House");
        streetTypeMap.put("HUB", "Hub");
        streetTypeMap.put("INTG", "Interchange");
        streetTypeMap.put("INTN", "Intersection");
        streetTypeMap.put("IS", "Island");
        streetTypeMap.put("JNC", "Junction");
        streetTypeMap.put("KEY", "Key");
        streetTypeMap.put("KNOB", "Knob");
        streetTypeMap.put("KNLL", "Knoll");
        streetTypeMap.put("LADR", "Ladder");
        streetTypeMap.put("LDG", "Landing");
        streetTypeMap.put("LANE", "Lane");
        streetTypeMap.put("LNWY", "Laneway");
        streetTypeMap.put("LEA", "Lea");
        streetTypeMap.put("LEDR", "Leader");
        streetTypeMap.put("LEES", "Lees");
        streetTypeMap.put("LGH", "Leigh");
        streetTypeMap.put("LGTS", "Lights");
        streetTypeMap.put("LINE", "Line");
        streetTypeMap.put("LNES", "Lines");
        streetTypeMap.put("LINK", "Link");
        streetTypeMap.put("LT", "Little");
        streetTypeMap.put("LDGE", "Lodge");
        streetTypeMap.put("LKT", "Lookout");
        streetTypeMap.put("LOOP", "Loop");
        streetTypeMap.put("LWR", "Lower");
        streetTypeMap.put("MAIL", "Mail");
        streetTypeMap.put("MALL", "Mall");
        streetTypeMap.put("MEAD", "Mead");
        streetTypeMap.put("MDWS", "Meadows");
        streetTypeMap.put("MNDR", "Meander");
        streetTypeMap.put("MESS", "Mess");
        streetTypeMap.put("MEW", "Mew");
        streetTypeMap.put("MEWS", "Mews");
        streetTypeMap.put("MILE", "Mile");
        streetTypeMap.put("ML", "Mill");
        streetTypeMap.put("MLS", "Mills");
        streetTypeMap.put("MSN", "Mission");
        streetTypeMap.put("MTL", "Motel");
        streetTypeMap.put("MWY", "Motorway");
        streetTypeMap.put("MOTU", "Motu");
        streetTypeMap.put("MT", "Mount");
        streetTypeMap.put("MTN", "Mountain");
        streetTypeMap.put("NVS", "Neaves");
        streetTypeMap.put("NOOK", "Nook");
        streetTypeMap.put("NRMA", "Nrma");
        streetTypeMap.put("OAKS", "Oaks");
        streetTypeMap.put("ORCH", "Orchard");
        streetTypeMap.put("OTLK", "Outlook");
        streetTypeMap.put("OVAL", "Oval");
        streetTypeMap.put("OVRB", "Overbridge");
        streetTypeMap.put("PADK", "Paddock");
        streetTypeMap.put("PAKU", "Paku");
        streetTypeMap.put("PLMS", "Palms");
        streetTypeMap.put("PDE", "Parade");
        streetTypeMap.put("PRDE", "Paradise");
        streetTypeMap.put("PARK", "Park");
        streetTypeMap.put("PKLD", "Parklands");
        streetTypeMap.put("PKWY", "Parkway");
        streetTypeMap.put("PART", "Part");
        streetTypeMap.put("PASS", "Pass");
        streetTypeMap.put("PSGE", "Passage");
        streetTypeMap.put("PATH", "Path");
        streetTypeMap.put("PHWY", "Pathway");
        streetTypeMap.put("PNNE", "Peninsula");
        streetTypeMap.put("PIAZ", "Piazza");
        streetTypeMap.put("PIER", "Pier");
        streetTypeMap.put("PL", "Place");
        streetTypeMap.put("PLN", "Plain");
        streetTypeMap.put("PLNS", "Plains");
        streetTypeMap.put("PLAT", "Plateau");
        streetTypeMap.put("PLZA", "Plaza");
        streetTypeMap.put("PKT", "Pocket");
        streetTypeMap.put("PNT", "Point");
        streetTypeMap.put("PORT", "Port");
        streetTypeMap.put("PRRS", "Priors");
        streetTypeMap.put("PROM", "Promenade");
        streetTypeMap.put("PURS", "Pursuit");
        streetTypeMap.put("QUAD", "Quad");
        streetTypeMap.put("QDGL", "Quadrangle");
        streetTypeMap.put("QDRT", "Quadrant");
        streetTypeMap.put("QTRS", "Quarters");
        streetTypeMap.put("QY", "Quay");
        streetTypeMap.put("QYS", "Quays");
        streetTypeMap.put("RMBL", "Ramble");
        streetTypeMap.put("RAMP", "Ramp");
        streetTypeMap.put("RAN", "Ranae");
        streetTypeMap.put("RNGE", "Range");
        streetTypeMap.put("RPDS", "Rapids");
        streetTypeMap.put("RCH", "Reach");
        streetTypeMap.put("REEF", "Reef");
        streetTypeMap.put("RES", "Reserve");
        streetTypeMap.put("RSDN", "Residence");
        streetTypeMap.put("REST", "Rest");
        streetTypeMap.put("RTT", "Retreat");
        streetTypeMap.put("RTRN", "Return");
        streetTypeMap.put("RIDE", "Ride");
        streetTypeMap.put("RDGE", "Ridge");
        streetTypeMap.put("RGWY", "Ridgeway");
        streetTypeMap.put("ROWY", "Right Of Way");
        streetTypeMap.put("RING", "Ring");
        streetTypeMap.put("RISE", "Rise");
        streetTypeMap.put("RVR", "River");
        streetTypeMap.put("RVWY", "Riverway");
        streetTypeMap.put("RVRA", "Riviera");
        streetTypeMap.put("RD", "Road");
        streetTypeMap.put("RDS", "Roads");
        streetTypeMap.put("RDSD", "Roadside");
        streetTypeMap.put("RDWY", "Roadway");
        streetTypeMap.put("RNDE", "Ronde");
        streetTypeMap.put("RSBL", "Rosebowl");
        streetTypeMap.put("RTY", "Rotary");
        streetTypeMap.put("RND", "Round");
        streetTypeMap.put("RTE", "Route");
        streetTypeMap.put("ROW", "Row");
        streetTypeMap.put("ROWE", "Rowe");
        streetTypeMap.put("RUA", "Rua");
        streetTypeMap.put("RUE", "Rue");
        streetTypeMap.put("RUN", "Run");
        streetTypeMap.put("SCHL", "School");
        streetTypeMap.put("SECT", "Section");
        streetTypeMap.put("SVLN", "Service Lane");
        streetTypeMap.put("SWY", "Serviceway");
        streetTypeMap.put("SHL", "Shoal");
        streetTypeMap.put("SHT", "Shoot");
        streetTypeMap.put("SHR", "Shore");
        streetTypeMap.put("SHRS", "Shores");
        streetTypeMap.put("SDNG", "Siding");
        streetTypeMap.put("SLPE", "Slope");
        streetTypeMap.put("SND", "Sound");
        streetTypeMap.put("SPA", "Spa");
        streetTypeMap.put("SPG", "Spring");
        streetTypeMap.put("SPGS", "Springs");
        streetTypeMap.put("SPUR", "Spur");
        streetTypeMap.put("SQN", "Squadron");
        streetTypeMap.put("SQ", "Square");
        streetTypeMap.put("STRS", "Stairs");
        streetTypeMap.put("SHWY", "State Highway");
        streetTypeMap.put("STAT", "Station");
        streetTypeMap.put("STEE", "Steep");
        streetTypeMap.put("STP", "Step");
        streetTypeMap.put("STPS", "Steps");
        streetTypeMap.put("STEY", "Steyne");
        streetTypeMap.put("STAA", "Straat");
        streetTypeMap.put("STGT", "Straight");
        streetTypeMap.put("STRA", "Strand");
        streetTypeMap.put("STRM", "Stream");
        streetTypeMap.put("ST", "Street");
        streetTypeMap.put("STS", "Streets");
        streetTypeMap.put("STRP", "Strip");
        streetTypeMap.put("STUD", "Stud");
        streetTypeMap.put("SBWY", "Subway");
        streetTypeMap.put("SMT", "Summit");
        streetTypeMap.put("SWMP", "Swamp");
        streetTypeMap.put("TARN", "Tarn");
        streetTypeMap.put("TCE", "Terrace");
        streetTypeMap.put("TCES", "Terraces");
        streetTypeMap.put("THOR", "Thoroughfare");
        streetTypeMap.put("THWY", "Throughway");
        streetTypeMap.put("TLWY", "Tollway");
        streetTypeMap.put("TOP", "Top");
        streetTypeMap.put("TOP", "Tor");
        streetTypeMap.put("TOWR", "Tower");
        streetTypeMap.put("TWRS", "Towers");
        streetTypeMap.put("TRK", "Track");
        streetTypeMap.put("TRCT", "Tract");
        streetTypeMap.put("TRL", "Trail");
        streetTypeMap.put("TRLR", "Trailer");
        streetTypeMap.put("TRAM", "Tram");
        streetTypeMap.put("TMWY", "Tramway");
        streetTypeMap.put("TRES", "Trees");
        streetTypeMap.put("TRI", "Triangle");
        streetTypeMap.put("TKWY", "Trunkway");
        streetTypeMap.put("TUNL", "Tunnel");
        streetTypeMap.put("TURN", "Turn");
        streetTypeMap.put("UPAS", "Underpass");
        streetTypeMap.put("UPR", "Upper");
        streetTypeMap.put("VALE", "Vale");
        streetTypeMap.put("VLLY", "Valley");
        streetTypeMap.put("VNUS", "Venus");
        streetTypeMap.put("VDCT", "Viaduct");
        streetTypeMap.put("VIEW", "View");
        streetTypeMap.put("VWS", "Views");
        streetTypeMap.put("VLLG", "Village");
        streetTypeMap.put("VLLS", "Villas");
        streetTypeMap.put("VSTA", "Vista");
        streetTypeMap.put("VUE", "Vue");
        streetTypeMap.put("WADE", "Wade");
        streetTypeMap.put("WALK", "Walk");
        streetTypeMap.put("WKWY", "Walkway");
        streetTypeMap.put("WTRS", "Waters");
        streetTypeMap.put("WAY", "Way");
        streetTypeMap.put("WHRF", "Wharf");
        streetTypeMap.put("WHNA", "Whenua");
        streetTypeMap.put("WOOD", "Wood");
        streetTypeMap.put("WDS", "Woods");
        streetTypeMap.put("WYND", "Wynd");
        streetTypeMap.put("YARD", "Yard");

        streetDirectionMap.put("C", "Central");
        streetDirectionMap.put("E", "East");
        streetDirectionMap.put("EX", "Extension");
        streetDirectionMap.put("LR", "Lower");
        streetDirectionMap.put("N", "North");
        streetDirectionMap.put("NE", "North East");
        streetDirectionMap.put("NW", "North West");
        streetDirectionMap.put("S", "South");
        streetDirectionMap.put("SE", "South East");
        streetDirectionMap.put("SW", "South West");
        streetDirectionMap.put("UP", "Upper");
        streetDirectionMap.put("W", "West");
        streetDirectionMap.put("N1", "No1");
        streetDirectionMap.put("N2", "No2");

        staffFlagMap.put("A", "IAG staff with over 25 year service");
        staffFlagMap.put("B", "Total or Permanent Disability");
        staffFlagMap.put("H", "HSBC Staff");
        staffFlagMap.put("L", "SGIO/SGIC Long Term staff");
        staffFlagMap.put("M", "NRMA Motoring and Services staff");
        staffFlagMap.put("N", "Non Staff");
        staffFlagMap.put("R", "RACV Staff");
        staffFlagMap.put("T", "Leave IAG due to total disability");
        staffFlagMap.put("V", "IAG Staff Victoria");
        staffFlagMap.put("Y", "IAG Staff");
        staffFlagMap.put("Z", "IAG NZ Staff");

        embargoMap.put("FIRE00001", "Fire");
        embargoMap.put("FLOOD0001", "Flood");
        embargoMap.put("HAIL00001", "Hail");

        excessTypeMap.put("D", "Deleted Excess");
        excessTypeMap.put("H", "High Sum Insured Excess");
        excessTypeMap.put("I", "Imposed Excess");
        excessTypeMap.put("L", "Loyalty Excess");
        excessTypeMap.put("S", "Standard Excess");
        excessTypeMap.put("U", "User Imposed Excess");
        excessTypeMap.put("T", "Voluntary Excess");
        excessTypeMap.put("P", "Policy Excess");

        //included the make description for caravan validation
        makeDescMap.put("ACT", "Act Lane");
        makeDescMap.put("ADV", "Advance");
        makeDescMap.put("ARG", "Argonaut");
        makeDescMap.put("AST", "Astrek");
        makeDescMap.put("ATL", "Atlantic");
        makeDescMap.put("AUS", "Aussie Swag");
        makeDescMap.put("AVA", "A'Van Campers");
        makeDescMap.put("AVO", "Avondale");
        makeDescMap.put("BED", "Bedford");
        makeDescMap.put("BLU", "Blue Horizon");
        makeDescMap.put("BLT", "Builtwell");
        makeDescMap.put("BUS", "Bushmate");
        makeDescMap.put("CAB", "Cabana");
        makeDescMap.put("CAO", "Camp/O/Matic");
        makeDescMap.put("CAM", "Camper-Craft");
        makeDescMap.put("CMH", "Campervan & Motor Home Conversions");
        makeDescMap.put("CAI", "Capri");
        makeDescMap.put("CAP", "Capricorn");
        makeDescMap.put("CVL", "Caravelle");
        makeDescMap.put("CAR", "Carinya");
        makeDescMap.put("CAS", "Casavilla");
        makeDescMap.put("CAV", "Cavalier");
        makeDescMap.put("CHE", "Chesney");
        makeDescMap.put("CHI", "Chinook Campervans");
        makeDescMap.put("CLA", "Classic");
        makeDescMap.put("COA", "Coachman");
        makeDescMap.put("COB", "Cobb & Co");
        makeDescMap.put("COL", "Coleman");
        makeDescMap.put("COM", "Commodore");
        makeDescMap.put("CPC", "Compass Campers");
        makeDescMap.put("CPM", "Compass Caravans");
        makeDescMap.put("CON", "Continental");
        makeDescMap.put("COR", "Coromal");
        makeDescMap.put("CNT", "Coronet");
        makeDescMap.put("COY", "Country Air");
        makeDescMap.put("COU", "Countrywide");
        makeDescMap.put("CRU", "Crusader");
        makeDescMap.put("CUB", "Cub");
        makeDescMap.put("DAR", "Dario");
        makeDescMap.put("DAT", "Dart");
        makeDescMap.put("DIN", "Dingo Camper Trailer");
        makeDescMap.put("DRI", "Driftaway");
        makeDescMap.put("ELI", "Elite Motorcampers");
        makeDescMap.put("ELR", "Elross");
        makeDescMap.put("EMP", "Empire");
        makeDescMap.put("EVE", "Evernew");
        makeDescMap.put("EZY", "Ezytow");
        makeDescMap.put("FOL", "Foldavan");
        makeDescMap.put("FOR", "Ford");
        makeDescMap.put("FRA", "Franklin");
        makeDescMap.put("FRW", "Freeway Motor Home Conversions");
        makeDescMap.put("FCC", "Frontline Camper Conversions");
        makeDescMap.put("FUT", "Futura");
        makeDescMap.put("FUU", "Future System");
        makeDescMap.put("GAZ", "Gazal");
        makeDescMap.put("GLE", "Glendale");
        makeDescMap.put("GOS", "Goldstream");
        makeDescMap.put("GOL", "Golf");
        makeDescMap.put("GYP", "Gypsy");
        makeDescMap.put("HAC", "Hacienda");
        makeDescMap.put("HAL", "Hallmark");
        makeDescMap.put("HAR", "Harding");
        makeDescMap.put("HOB", "Hobo");
        makeDescMap.put("HDN", "Holden");
        makeDescMap.put("HOL", "Holiday Equipment");
        makeDescMap.put("ISL", "Island Star");
        makeDescMap.put("JAR", "Jayar");
        makeDescMap.put("JAY", "Jayco");
        makeDescMap.put("KAR", "Kara-Kar");
        makeDescMap.put("KCB", "Kcb");
        makeDescMap.put("KIM", "Kimberley Kampers");
        makeDescMap.put("KON", "Konfort Industries");
        makeDescMap.put("LEA", "Leader");
        makeDescMap.put("LIT", "Litecraft");
        makeDescMap.put("MAJ", "Majestic");
        makeDescMap.put("MAZ", "Mazda");
        makeDescMap.put("MER", "Merimbula");
        makeDescMap.put("MIL", "Millard");
        makeDescMap.put("MOW", "Modern (Wa)");
        makeDescMap.put("MON", "Monarch");
        makeDescMap.put("NAY", "Naylor");
        makeDescMap.put("NEW", "New Home");
        makeDescMap.put("NLD", "Newlands");
        makeDescMap.put("NIS", "Nissan");
        makeDescMap.put("OLY", "Olympic");
        makeDescMap.put("OPA", "Opal");
        makeDescMap.put("OVE", "Overlander");
        makeDescMap.put("PAC", "Pacesetter");
        makeDescMap.put("PED", "Pedigree");
        makeDescMap.put("PLP", "Peter'S Leisure Products");
        makeDescMap.put("PHI", "Phillips");
        makeDescMap.put("PHO", "Phoenix");
        makeDescMap.put("PRA", "Prattline");
        makeDescMap.put("QUE", "Quest");
        makeDescMap.put("RAP", "Rapido");
        makeDescMap.put("RAY", "Ray'S");
        makeDescMap.put("REG", "Regal");
        makeDescMap.put("RGT", "Regent");
        makeDescMap.put("RMS", "Roadmaster");
        makeDescMap.put("ROA", "Roadstar");
        makeDescMap.put("ROM", "Roma");
        makeDescMap.put("ROY", "Royal Flair");
        makeDescMap.put("SAF", "Safari Camper Conversions");
        makeDescMap.put("SCA", "Scandica");
        makeDescMap.put("SCE", "Scenic");
        makeDescMap.put("SHI", "Shiralee Conversions");
        makeDescMap.put("SIL", "Silvan");
        makeDescMap.put("SKY", "Skyline");
        makeDescMap.put("SPA", "Spaceline");
        makeDescMap.put("STA", "Statesman");
        makeDescMap.put("SUL", "Sunliner");
        makeDescMap.put("SUN", "Sunwagon");
        makeDescMap.put("SUP", "Supreme");
        makeDescMap.put("TEL", "Telstar");
        makeDescMap.put("TOP", "Topagee");
        makeDescMap.put("TOY", "Toyota");
        makeDescMap.put("TRS", "Trail Easy");
        makeDescMap.put("TMT", "Trailmate");
        makeDescMap.put("TRA", "Trakka Conversions");
        makeDescMap.put("TRM", "Trakmaster");
        makeDescMap.put("TRH", "Travelhome");
        makeDescMap.put("TRV", "Traveller");
        makeDescMap.put("TRE", "Trek");
        makeDescMap.put("TRU", "Trustar (By Windsor)");
        makeDescMap.put("ULT", "Ultimate 4Wd");
        makeDescMap.put("VEN", "Venture");
        makeDescMap.put("VIS", "Viscount");
        makeDescMap.put("VOL", "Volkswagon");
        makeDescMap.put("WAN", "Wanderer");
        makeDescMap.put("WAS", "Wasp");
        makeDescMap.put("WAY", "Wayfarer");
        makeDescMap.put("WIN", "Windsor");
        makeDescMap.put("WIB", "Winnebago Conversions");
        makeDescMap.put("YOR", "York");

        trailerMakeDescMap.put("BEE", "Bee Jay");
        trailerMakeDescMap.put("BIN", "Binks");
        trailerMakeDescMap.put("BLT", "Builtwell");
        trailerMakeDescMap.put("BOE", "Boeing");
        trailerMakeDescMap.put("BRK", "Brooker");
        trailerMakeDescMap.put("CAD", "Caddie");
        trailerMakeDescMap.put("CLA", "Clark");
        trailerMakeDescMap.put("COA", "Coaster");
        trailerMakeDescMap.put("CUB", "Cub");
        trailerMakeDescMap.put("CUS", "Custom Made");
        trailerMakeDescMap.put("DAL", "Dale");
        trailerMakeDescMap.put("DUN", "Dunbier");
        trailerMakeDescMap.put("EAY", "Easytow");
        trailerMakeDescMap.put("FEL", "Felk");
        trailerMakeDescMap.put("FER", "Ferris");
        trailerMakeDescMap.put("GIR", "Girlock");
        trailerMakeDescMap.put("GOL", "Goldco");
        trailerMakeDescMap.put("GRA", "Grant");
        trailerMakeDescMap.put("HOB", "Hobie");
        trailerMakeDescMap.put("HOL", "Holiday Equipment");
        trailerMakeDescMap.put("JAW", "Jawar");
        trailerMakeDescMap.put("JAX", "Jax");
        trailerMakeDescMap.put("JON", "Jones");
        trailerMakeDescMap.put("KAR", "Kara-Kar");
        trailerMakeDescMap.put("KCB", "KCB");
        trailerMakeDescMap.put("LEE", "Leeda");
        trailerMakeDescMap.put("MAG", "Maggs");
        trailerMakeDescMap.put("MAN", "Manta");
        trailerMakeDescMap.put("MES", "Messenger");
        trailerMakeDescMap.put("MKY", "Mackay");
        trailerMakeDescMap.put("MLC", "Molco");
        trailerMakeDescMap.put("MLY", "Molloy");
        trailerMakeDescMap.put("MON", "Monark");
        trailerMakeDescMap.put("MRL", "Marlin");
        trailerMakeDescMap.put("MSN", "Messent");
        trailerMakeDescMap.put("NAU", "Nautisport");
        trailerMakeDescMap.put("NAY", "Naylor");
        trailerMakeDescMap.put("NOB", "Noble");
        trailerMakeDescMap.put("NOL", "Nolex");
        trailerMakeDescMap.put("NUM", "Numa");
        trailerMakeDescMap.put("OLY", "Olympic");
        trailerMakeDescMap.put("OVE", "Overlander");
        trailerMakeDescMap.put("PAN", "Panton Hill");
        trailerMakeDescMap.put("PRE", "Prestige");
        trailerMakeDescMap.put("RAN", "Ranch");
        trailerMakeDescMap.put("RED", "Redco");
        trailerMakeDescMap.put("RGR", "Ranger");
        trailerMakeDescMap.put("ROY", "Royale");
        trailerMakeDescMap.put("SCA", "Scarf");
        trailerMakeDescMap.put("TAN", "Tandem");
        trailerMakeDescMap.put("TER", "Teri");
        trailerMakeDescMap.put("TIN", "Tinka");
        trailerMakeDescMap.put("TRA", "Tracer");
        trailerMakeDescMap.put("TRE", "Trek");
        trailerMakeDescMap.put("TRS", "Trail Easy");
        trailerMakeDescMap.put("TUZ", "Tuza");
        trailerMakeDescMap.put("UNI", "Universal");
        trailerMakeDescMap.put("VEN", "Venture");
        trailerMakeDescMap.put("VIC", "Vickers Xatal");
        trailerMakeDescMap.put("VIL", "Villager");
        trailerMakeDescMap.put("VIS", "Viscount");
        trailerMakeDescMap.put("VTA", "Victor");
        trailerMakeDescMap.put("WAS", "Wasp");
        trailerMakeDescMap.put("WES", "Wesco");
        trailerMakeDescMap.put("WHI", "Whilley");
        trailerMakeDescMap.put("YAN", "Yantha");

        boatTrailerTypeDescMap.put("MA", "MULTI AXLE");
        boatTrailerTypeDescMap.put("MM", "MULTI AXLE MULTI ROLLER");
        boatTrailerTypeDescMap.put("SA", "SINGLE AXLE");
        boatTrailerTypeDescMap.put("SM", "SINGLE AXLE MULTI ROLLER");

        boatSailMaterialDescMap.put("CN", "COTTON");
        boatSailMaterialDescMap.put("CS", "CUSTOM");
        boatSailMaterialDescMap.put("CV", "CANVAS");
        boatSailMaterialDescMap.put("DC", "DACRON");
        boatSailMaterialDescMap.put("DL", "3DL");
        boatSailMaterialDescMap.put("KV", "KEVLAR");
        boatSailMaterialDescMap.put("MF", "MONOFILM");
        boatSailMaterialDescMap.put("MY", "MYLAR");
        boatSailMaterialDescMap.put("SC", "SPINNAKER CLOTH");
        boatSailMaterialDescMap.put("SP", "SPECTRA");
        boatSailMaterialDescMap.put("TC", "TECHNORA");

        boatPrimaryWatersDescMap.put("H", "HARBOURS/BAYS");
        boatPrimaryWatersDescMap.put("L", "LAKES/DAMS");
        boatPrimaryWatersDescMap.put("O", "OPEN SEAS");
        boatPrimaryWatersDescMap.put("R", "RIVERS");

        boatHullMakerDescMap.put("ABM", "ABM");
        boatHullMakerDescMap.put("ACA", "ACADEMY");
        boatHullMakerDescMap.put("ACC", "A CLASS CAT");
        boatHullMakerDescMap.put("ACH", "ACHILLES");
        boatHullMakerDescMap.put("ACT", "ACTIONCAT");
        boatHullMakerDescMap.put("ADD", "ADDICTOR");
        boatHullMakerDescMap.put("ADV", "ADVENTURE CRAFT");
        boatHullMakerDescMap.put("ALG", "ALGLAS");
        boatHullMakerDescMap.put("ALL", "ALLISON");
        boatHullMakerDescMap.put("ALO", "ALLOYCAT");
        boatHullMakerDescMap.put("ALU", "ALUFARM");
        boatHullMakerDescMap.put("ALY", "ALLY CRAFT");
        boatHullMakerDescMap.put("APO", "APOLLO");
        boatHullMakerDescMap.put("AQP", "AQUAPRO");
        boatHullMakerDescMap.put("AQR", "AQUARIS");
        boatHullMakerDescMap.put("ARR", "ARRIVA");
        boatHullMakerDescMap.put("AUW", "AUSSIE WHALER");
        boatHullMakerDescMap.put("AVO", "AVON");
        boatHullMakerDescMap.put("AZI", "AZIECRAFT");
        boatHullMakerDescMap.put("BAC", "BAYCRAFT");
        boatHullMakerDescMap.put("BAR", "BARON");
        boatHullMakerDescMap.put("BAT", "BARRETT");
        boatHullMakerDescMap.put("BAY", "BAYLINER");
        boatHullMakerDescMap.put("BEA", "BEAUFORT");
        boatHullMakerDescMap.put("BEC", "BELLCAT");
        boatHullMakerDescMap.put("BEL", "BELLBOY");
        boatHullMakerDescMap.put("BEN", "BENETEAU");
        boatHullMakerDescMap.put("BER", "BERTRAM");
        boatHullMakerDescMap.put("BFG", "BFG");
        boatHullMakerDescMap.put("BHM", "BOB HORTON MARINE");
        boatHullMakerDescMap.put("BLA", "BLAXELL SURFRIDER");
        boatHullMakerDescMap.put("BLI", "B-LINE");
        boatHullMakerDescMap.put("BLU", "BLUEBIRD");
        boatHullMakerDescMap.put("BMA", "BERMUDA SPORTSBOATS");
        boatHullMakerDescMap.put("BOM", "BOMAROO");
        boatHullMakerDescMap.put("BON", "BONITO CRAFT");
        boatHullMakerDescMap.put("BOS", "BOSTON WHALER");
        boatHullMakerDescMap.put("BOT", "BOTRIL");
        boatHullMakerDescMap.put("BOU", "BOUNTY CRAFT");
        boatHullMakerDescMap.put("BRO", "BROOKER");
        boatHullMakerDescMap.put("BRR", "BRUCE ROBERTS");
        boatHullMakerDescMap.put("BRW", "BROWNING");
        boatHullMakerDescMap.put("BUL", "BULLET");
        boatHullMakerDescMap.put("BUR", "BURWOOD");
        boatHullMakerDescMap.put("BWF", "BOB WALL FABRICATIONS");
        boatHullMakerDescMap.put("CAA", "CATALINA");
        boatHullMakerDescMap.put("CAC", "CAMCRAFT");
        boatHullMakerDescMap.put("CAD", "CADDIE");
        boatHullMakerDescMap.put("CAE", "CARRERA");
        boatHullMakerDescMap.put("CAF", "CAVE & FERGUSON");
        boatHullMakerDescMap.put("CAI", "CAIRNS CUSTOM CRAFT");
        boatHullMakerDescMap.put("CAL", "CALLEGARI");
        boatHullMakerDescMap.put("CAM", "CAMPER-CRAFT");
        boatHullMakerDescMap.put("CAN", "CARIBBEAN");
        boatHullMakerDescMap.put("CAP", "CAPER CAT");
        boatHullMakerDescMap.put("CAR", "CAMERO");
        boatHullMakerDescMap.put("CAT", "CARIBBEAN BERTRAM");
        boatHullMakerDescMap.put("CAV", "CARVER");
        boatHullMakerDescMap.put("CCR", "C-CRAFT");
        boatHullMakerDescMap.put("CHA", "CHALLENGE");
        boatHullMakerDescMap.put("CHB", "CHERUB");
        boatHullMakerDescMap.put("CHI", "CHILDSPLAY");
        boatHullMakerDescMap.put("CHM", "CHIVAS MARINE");
        boatHullMakerDescMap.put("CLA", "CLARK");
        boatHullMakerDescMap.put("CLE", "CLEVELAND");
        boatHullMakerDescMap.put("CLS", "CLASSIQUE");
        boatHullMakerDescMap.put("CLY", "CLAYTON");
        boatHullMakerDescMap.put("COA", "COASTER");
        boatHullMakerDescMap.put("COB", "COBRA CAT");
        boatHullMakerDescMap.put("COC", "CONCEPT");
        boatHullMakerDescMap.put("COM", "COMPASS");
        boatHullMakerDescMap.put("CON", "CONNELLY CRAFT");
        boatHullMakerDescMap.put("COO", "COOPERBUILT");
        boatHullMakerDescMap.put("COR", "CORRECT CRAFT");
        boatHullMakerDescMap.put("COU", "COUGAR");
        boatHullMakerDescMap.put("COX", "COX CRAFT");
        boatHullMakerDescMap.put("CPR", "CAPRICE");
        boatHullMakerDescMap.put("CRD", "CRUSADER");
        boatHullMakerDescMap.put("CRE", "CREELCRAFT");
        boatHullMakerDescMap.put("CRS", "CRESTRIDA");
        boatHullMakerDescMap.put("CRT", "CRESTCRAFT");
        boatHullMakerDescMap.put("CRU", "CRUISE CRAFT");
        boatHullMakerDescMap.put("CRW", "CROWNCRAFT");
        boatHullMakerDescMap.put("CRY", "CRUISERS YACHTS");
        boatHullMakerDescMap.put("CSR", "CORSAIR");
        boatHullMakerDescMap.put("CTD", "CONTENDER");
        boatHullMakerDescMap.put("CUM", "CUMMINS");
        boatHullMakerDescMap.put("CUS", "CUSTOMCRAFT");
        boatHullMakerDescMap.put("CVR", "CAVALIER");
        boatHullMakerDescMap.put("DAN", "DANCER");
        boatHullMakerDescMap.put("DAV", "DAVID ROSE YACHTS");
        boatHullMakerDescMap.put("DEA", "DE HAVILLAND");
        boatHullMakerDescMap.put("DEL", "DELTACRAFT");
        boatHullMakerDescMap.put("DEV", "DEVIL CAT");
        boatHullMakerDescMap.put("DIA", "DIAVOLO");
        boatHullMakerDescMap.put("DOG", "DOGGETT");
        boatHullMakerDescMap.put("DOL", "DOLPHIN");
        boatHullMakerDescMap.put("DOM", "DOMINATOR");
        boatHullMakerDescMap.put("DRA", "DRAGON");
        boatHullMakerDescMap.put("DUN", "DUNLOP C-CRAFT");
        boatHullMakerDescMap.put("DUY", "DUNCANSON YACHTS");
        boatHullMakerDescMap.put("EAC", "EAST COAST");
        boatHullMakerDescMap.put("EAS", "EASY RIDER");
        boatHullMakerDescMap.put("EDV", "ENDEAVOUR");
        boatHullMakerDescMap.put("ELB", "ELIMINATOR BOATS");
        boatHullMakerDescMap.put("ENS", "ENSIGN");
        boatHullMakerDescMap.put("ENT", "ENTERPRISE");
        boatHullMakerDescMap.put("ESC", "ESCAPE CAT");
        boatHullMakerDescMap.put("ETC", "ETCHELL");
        boatHullMakerDescMap.put("EVE", "EVERINGHAM");
        boatHullMakerDescMap.put("EXA", "EXPRESS");
        boatHullMakerDescMap.put("FAI", "FAIRLITE");
        boatHullMakerDescMap.put("FAR", "FARR");
        boatHullMakerDescMap.put("FAS", "FASTLANE");
        boatHullMakerDescMap.put("FDU", "FLYING DUTCHMAN");
        boatHullMakerDescMap.put("FEL", "FLYING ELEVEN");
        boatHullMakerDescMap.put("FFI", "FLYING FIFTEEN");
        boatHullMakerDescMap.put("FGI", "FIBREGLASS INDUSTRIES (FGI)");
        boatHullMakerDescMap.put("FIN", "FINN");
        boatHullMakerDescMap.put("FLA", "FLATCRAFT");
        boatHullMakerDescMap.put("FLI", "FLIGHTCRAFT");
        boatHullMakerDescMap.put("FLT", "FLEETWOOD");
        boatHullMakerDescMap.put("FNT", "FLYING ANT");
        boatHullMakerDescMap.put("FOA", "FORCE");
        boatHullMakerDescMap.put("FOR", "FORMULA FREEDOM");
        boatHullMakerDescMap.put("FOU", "FOUR WINNS");
        boatHullMakerDescMap.put("FRA", "FRASER");
        boatHullMakerDescMap.put("FRB", "FIREBALL");
        boatHullMakerDescMap.put("FRE", "FREELINE");
        boatHullMakerDescMap.put("FRI", "FREIGHTER INDUSTRIES");
        boatHullMakerDescMap.put("FRM", "FREEMAN");
        boatHullMakerDescMap.put("FRS", "FRISCO");
        boatHullMakerDescMap.put("GEE", "GEECRAFT");
        boatHullMakerDescMap.put("GFL", "GFLGIN");
        boatHullMakerDescMap.put("GIL", "GILFLITE");
        boatHullMakerDescMap.put("GLA", "GLASTRON-USA");
        boatHullMakerDescMap.put("GLC", "GLASTRON CARLSON");
        boatHullMakerDescMap.put("GOL", "GOLDSBOROUGH");
        boatHullMakerDescMap.put("GRG", "GREGFORD");
        boatHullMakerDescMap.put("GRI", "GRIFFIN");
        boatHullMakerDescMap.put("GSC", "GLASCRAFT");
        boatHullMakerDescMap.put("HAA", "HAINES HUNTER");
        boatHullMakerDescMap.put("HAL", "HALLETT");
        boatHullMakerDescMap.put("HAM", "HAMILTON");
        boatHullMakerDescMap.put("HAN", "HAMMOND");
        boatHullMakerDescMap.put("HAS", "HAINES SIGNATURE");
        boatHullMakerDescMap.put("HAT", "HARTLEY");
        boatHullMakerDescMap.put("HAV", "HALVORSEN");
        boatHullMakerDescMap.put("HER", "HERON");
        boatHullMakerDescMap.put("HIN", "HINTON");
        boatHullMakerDescMap.put("HIR", "HIRONDELLE");
        boatHullMakerDescMap.put("HOB", "HOBIE CAT");
        boatHullMakerDescMap.put("HOR", "HORNET");
        boatHullMakerDescMap.put("HOY", "HOYLE MARINE");
        boatHullMakerDescMap.put("HOZ", "HORIZON");
        boatHullMakerDescMap.put("HUM", "HUMBER");
        boatHullMakerDescMap.put("HUN", "HUNTSMAN-NOVA");
        boatHullMakerDescMap.put("HYC", "HYDRA CAT");
        boatHullMakerDescMap.put("HYD", "HYDROFIELD");
        boatHullMakerDescMap.put("IDE", "IDEAL");
        boatHullMakerDescMap.put("INT", "INTRUDER");
        boatHullMakerDescMap.put("INV", "INVESTIGATOR");
        boatHullMakerDescMap.put("ISL", "ISLANDER");
        boatHullMakerDescMap.put("JAV", "JAVLIN");
        boatHullMakerDescMap.put("JOY", "JOYCE");
        boatHullMakerDescMap.put("JUD", "JUDDCRAFT");
        boatHullMakerDescMap.put("KAF", "KAYFA INDUSTRIES");
        boatHullMakerDescMap.put("KAT", "KATCHA");
        boatHullMakerDescMap.put("KAW", "KAWASAKI JET-SKI");
        boatHullMakerDescMap.put("KAY", "KAYSER");
        boatHullMakerDescMap.put("KEL", "KELLERCRAFT");
        boatHullMakerDescMap.put("KEV", "KEVLACAT");
        boatHullMakerDescMap.put("KIF", "KING FISHER");
        boatHullMakerDescMap.put("KIS", "KINGSTON");
        boatHullMakerDescMap.put("LAS", "LASER");
        boatHullMakerDescMap.put("LEE", "LEEDER");
        boatHullMakerDescMap.put("LEW", "LEWIS");
        boatHullMakerDescMap.put("LUH", "LUHRS");
        boatHullMakerDescMap.put("LUN", "LUNNCRAFT");
        boatHullMakerDescMap.put("LYO", "LYONS");
        boatHullMakerDescMap.put("MAA", "MANICAT");
        boatHullMakerDescMap.put("MAC", "MACHO BOATS");
        boatHullMakerDescMap.put("MAG", "MANLY GRADUATE (MG)");
        boatHullMakerDescMap.put("MAI", "MARINER");
        boatHullMakerDescMap.put("MAJ", "MANLY JUNIOR");
        boatHullMakerDescMap.put("MAK", "MARKHAM");
        boatHullMakerDescMap.put("MAL", "MARLIN BROADBILL");
        boatHullMakerDescMap.put("MAN", "MANTA CRAFT");
        boatHullMakerDescMap.put("MAR", "MARKLINE");
        boatHullMakerDescMap.put("MAS", "MASTERS");
        boatHullMakerDescMap.put("MAV", "MAVERICK");
        boatHullMakerDescMap.put("MAW", "MARKHAM WHALER");
        boatHullMakerDescMap.put("MAX", "MAXUM");
        boatHullMakerDescMap.put("MCT", "MARICAT");
        boatHullMakerDescMap.put("MCW", "MCWILLIAMS");
        boatHullMakerDescMap.put("MEL", "MERLIN");
        boatHullMakerDescMap.put("MER", "MERCUB");
        boatHullMakerDescMap.put("MET", "METZLER");
        boatHullMakerDescMap.put("MFG", "MFG");
        boatHullMakerDescMap.put("MGM", "MAGNUM BOATS");
        boatHullMakerDescMap.put("MIA", "MIAMI");
        boatHullMakerDescMap.put("MIS", "MISSILE");
        boatHullMakerDescMap.put("MON", "MONARK");
        boatHullMakerDescMap.put("MOS", "MOSQUITO CAT");
        boatHullMakerDescMap.put("MOT", "MOTH");
        boatHullMakerDescMap.put("MRN", "MIRANDA CRAFT");
        boatHullMakerDescMap.put("MRR", "MIRROR");
        boatHullMakerDescMap.put("MST", "MISTRAL");
        boatHullMakerDescMap.put("MTA", "MTACFT");
        boatHullMakerDescMap.put("MUL", "MUTIMER HULLS");
        boatHullMakerDescMap.put("MUS", "MUSTANG");
        boatHullMakerDescMap.put("NAC", "NAUTICUS");
        boatHullMakerDescMap.put("NAM", "NAMCO");
        boatHullMakerDescMap.put("NAN", "NANKERVIS");
        boatHullMakerDescMap.put("NAU", "NAUTIGLASS");
        boatHullMakerDescMap.put("NAV", "NAVIGATOR");
        boatHullMakerDescMap.put("NCC", "NACRA CAT");
        boatHullMakerDescMap.put("NES", "NESSCRAFT");
        boatHullMakerDescMap.put("NIC", "NICHOLS BROS");
        boatHullMakerDescMap.put("NOV", "NOVA");
        boatHullMakerDescMap.put("NSR", "NORTHBRIDGE SENIOR (NS14)");
        boatHullMakerDescMap.put("ORC", "ORCA");
        boatHullMakerDescMap.put("PAC", "PACEMAKER");
        boatHullMakerDescMap.put("PAF", "PACIFIC");
        boatHullMakerDescMap.put("PAM", "PAMCRAFT");
        boatHullMakerDescMap.put("PEN", "PENGUIN");
        boatHullMakerDescMap.put("PER", "PERFORMANCE CRAFT");
        boatHullMakerDescMap.put("PIL", "PILOT (JARKAN)");
        boatHullMakerDescMap.put("PIO", "PIONEER");
        boatHullMakerDescMap.put("PIT", "PITMANS MARINE");
        boatHullMakerDescMap.put("POF", "POWERCAT");
        boatHullMakerDescMap.put("POM", "POMPELL");
        boatHullMakerDescMap.put("PON", "PONGRASS");
        boatHullMakerDescMap.put("POR", "PORTA-BOTE");
        boatHullMakerDescMap.put("PRE", "PREMIER");
        boatHullMakerDescMap.put("PRI", "PRIDE");
        boatHullMakerDescMap.put("PRO", "PROJECT");
        boatHullMakerDescMap.put("PRS", "PERSUADER");
        boatHullMakerDescMap.put("PRT", "PROJECTILE");
        boatHullMakerDescMap.put("PTC", "PAPER TIGER CAT");
        boatHullMakerDescMap.put("QSR", "QUICKSILVER");
        boatHullMakerDescMap.put("QUI", "QUINTREX");
        boatHullMakerDescMap.put("RAC", "RAMCO");
        boatHullMakerDescMap.put("RAD", "RANDELL");
        boatHullMakerDescMap.put("RAM", "RAMSAY");
        boatHullMakerDescMap.put("RAN", "RANGER");
        boatHullMakerDescMap.put("RAY", "RAYSONS CRAFT");
        boatHullMakerDescMap.put("REC", "REGCRAFT");
        boatHullMakerDescMap.put("REG", "REGAL");
        boatHullMakerDescMap.put("REN", "RENEGADE BOATS");
        boatHullMakerDescMap.put("RGC", "ROGERSCRAFT");
        boatHullMakerDescMap.put("RIV", "RIVIERA");
        boatHullMakerDescMap.put("ROB", "ROBALO");
        boatHullMakerDescMap.put("ROV", "ROVER");
        boatHullMakerDescMap.put("RUS", "RUSTON-HORNSBY");
        boatHullMakerDescMap.put("SAB", "SABOT");
        boatHullMakerDescMap.put("SAI", "SAILFISH");
        boatHullMakerDescMap.put("SAV", "SAVAGE");
        boatHullMakerDescMap.put("SEA", "SEA-AL");
        boatHullMakerDescMap.put("SEB", "SEABREEZE");
        boatHullMakerDescMap.put("SED", "SEA DOO");
        boatHullMakerDescMap.put("SEF", "SEAFARER");
        boatHullMakerDescMap.put("SEH", "SEA HUNTER");
        boatHullMakerDescMap.put("SEL", "SEALINE");
        boatHullMakerDescMap.put("SEM", "SEAMASTER");
        boatHullMakerDescMap.put("SEN", "SEASHINE");
        boatHullMakerDescMap.put("SES", "SEARANGER");
        boatHullMakerDescMap.put("SEW", "SEASWIRL");
        boatHullMakerDescMap.put("SEY", "SEAFLY");
        boatHullMakerDescMap.put("SHA", "SHARK CAT");
        boatHullMakerDescMap.put("SHE", "SHEPIROCRAFT");
        boatHullMakerDescMap.put("SID", "SIDEWINDER");
        boatHullMakerDescMap.put("SIG", "SIGNATURE");
        boatHullMakerDescMap.put("SIL", "SILVERLINE");
        boatHullMakerDescMap.put("SKA", "SKATE");
        boatHullMakerDescMap.put("SKB", "SKIBIRD");
        boatHullMakerDescMap.put("SKI", "SKICRAFT");
        boatHullMakerDescMap.put("SKL", "SKILINE");
        boatHullMakerDescMap.put("SLA", "SALEM");
        boatHullMakerDescMap.put("SLE", "SLEEKLINE");
        boatHullMakerDescMap.put("SMT", "SEAMETRE");
        boatHullMakerDescMap.put("SNT", "SONATA");
        boatHullMakerDescMap.put("SOL", "SOLING");
        boatHullMakerDescMap.put("SOP", "SOUTHERN PACIFIC");
        boatHullMakerDescMap.put("SOU", "SOUTHWIND");
        boatHullMakerDescMap.put("SPACES", "SPACES ARE VALID");
        boatHullMakerDescMap.put("SPC", "SPORTSCRAFT");
        boatHullMakerDescMap.put("SPF", "SPORTSFISH");
        boatHullMakerDescMap.put("SPM", "SPORTSMAN CRAFT");
        boatHullMakerDescMap.put("SPS", "SPORTSHULL");
        boatHullMakerDescMap.put("SRA", "SEA RAY");
        boatHullMakerDescMap.put("SRC", "STARCRAFT");
        boatHullMakerDescMap.put("STA", "STACER");
        boatHullMakerDescMap.put("STB", "STEBER");
        boatHullMakerDescMap.put("STC", "STEJCRAFT");
        boatHullMakerDescMap.put("STF", "STABI-CRAFT");
        boatHullMakerDescMap.put("STG", "STINGRAY CAT");
        boatHullMakerDescMap.put("STH", "STEPHENS");
        boatHullMakerDescMap.put("STP", "STEPHENSON");
        boatHullMakerDescMap.put("STR", "STERLING");
        boatHullMakerDescMap.put("STS", "STESSL");
        boatHullMakerDescMap.put("STT", "STREAKER");
        boatHullMakerDescMap.put("STY", "STYLECRAFT");
        boatHullMakerDescMap.put("SUC", "SUCCESS CRAFT");
        boatHullMakerDescMap.put("SUD", "SUNDANCE PLASTICS");
        boatHullMakerDescMap.put("SUN", "SUNCHASER");
        boatHullMakerDescMap.put("SUP", "SUPER TRAC");
        boatHullMakerDescMap.put("SUR", "SURFRIDER");
        boatHullMakerDescMap.put("SWA", "SWANSON");
        boatHullMakerDescMap.put("SWD", "SEAWIND");
        boatHullMakerDescMap.put("SWG", "SWINGER");
        boatHullMakerDescMap.put("SWI", "SWIFT CRAFT");
        boatHullMakerDescMap.put("TAS", "TASAR");
        boatHullMakerDescMap.put("TEN", "TENNESSEE");
        boatHullMakerDescMap.put("TIG", "TIGER CRAFT");
        boatHullMakerDescMap.put("TOP", "TOPCAT 11");
        boatHullMakerDescMap.put("TOR", "TORNADO");
        boatHullMakerDescMap.put("TRI", "TRITON");
        boatHullMakerDescMap.put("TRO", "TROJAN YACHTS");
        boatHullMakerDescMap.put("TRR", "TRIMCRAFT");
        boatHullMakerDescMap.put("TUF", "TUF");
        boatHullMakerDescMap.put("ULT", "ULTIMATE");
        boatHullMakerDescMap.put("VIC", "VICKERS");
        boatHullMakerDescMap.put("VIT", "VICTOR");
        boatHullMakerDescMap.put("VJR", "VAUCLUSE JUNIOR");
        boatHullMakerDescMap.put("VOL", "VOLERO");
        boatHullMakerDescMap.put("VSR", "VAUCLUSE SENIOR");
        boatHullMakerDescMap.put("WAH", "WAHOO BOATS");
        boatHullMakerDescMap.put("WEB", "WEBSTER'S");
        boatHullMakerDescMap.put("WEL", "WELLCRAFT");
        boatHullMakerDescMap.put("WES", "WESTERBERG");
        boatHullMakerDescMap.put("WET", "WESTONCRAFT");
        boatHullMakerDescMap.put("WHA", "WHALER");
        boatHullMakerDescMap.put("WHI", "WHITTLEY");
        boatHullMakerDescMap.put("WHT", "WHITELINE");
        boatHullMakerDescMap.put("WIL", "WILDCAT");
        boatHullMakerDescMap.put("WIM", "WILLIAMS");
        boatHullMakerDescMap.put("WIN", "WINDRIDER");
        boatHullMakerDescMap.put("WRS", "WINDRUSH CAT");
        boatHullMakerDescMap.put("YAL", "YALTA");
        boatHullMakerDescMap.put("YNG", "YINGLING");
        boatHullMakerDescMap.put("ZOD", "ZODIAC");
        boatHullMakerDescMap.put("12S", "12 FT SKIFF");
        boatHullMakerDescMap.put("14S", "14 FT SKIFF");
        boatHullMakerDescMap.put("16S", "16 FT SKIFF");
        boatHullMakerDescMap.put("18S", "18 FT SKIFF");
        boatHullMakerDescMap.put("49R", "49ER");

        boatBusinessTypeDescMap.put("CO", "COURTESY");
        boatBusinessTypeDescMap.put("DE", "DRIVER EDUCATION");
        boatBusinessTypeDescMap.put("HI", "HIRE");
        boatBusinessTypeDescMap.put("OF", "OFFICE");
        boatBusinessTypeDescMap.put("RM", "REMOVALIST");
        boatBusinessTypeDescMap.put("RP", "REPAIR");
        boatBusinessTypeDescMap.put("RT", "RETAIL - VENDOR");
        boatBusinessTypeDescMap.put("SF", "SEAFOOD INDUSTRY");
        boatBusinessTypeDescMap.put("TA", "TAXI");

        financeTypeDescMap.put("BS", "SECURED BUILDING SOCIETY");
        financeTypeDescMap.put("CU", "SECURED CREDIT UNION");
        financeTypeDescMap.put("FC", "SECURED FINANCE COMPANY");
        financeTypeDescMap.put("HP", "HIRE PURCHASE");
        financeTypeDescMap.put("LS", "LEASE");
        financeTypeDescMap.put("NF", "NO FINANCE APPLICABLE");
        financeTypeDescMap.put("NR", "NRMA");
        financeTypeDescMap.put("SB", "SECURED BANK");

        hullBoatTypeDescMap.put("CC", "HALF CABIN CRUISER");
        hullBoatTypeDescMap.put("CO", "CANOE");
        hullBoatTypeDescMap.put("CR", "CRUISER");
        hullBoatTypeDescMap.put("DG", "DINGHY");
        hullBoatTypeDescMap.put("HB", "HOUSE BOAT");
        hullBoatTypeDescMap.put("KK", "KAYAK");
        hullBoatTypeDescMap.put("RB", "RUNABOUT");
        hullBoatTypeDescMap.put("SB", "SAILBOARD");
        hullBoatTypeDescMap.put("SK", "SKI BOAT");
        hullBoatTypeDescMap.put("SM", "SAILBOAT - MULTI HULL");
        hullBoatTypeDescMap.put("SS", "SAILBOAT - SINGLE HULL");

        hullKeptDescMap.put("D", "DRY STORAGE");
        hullKeptDescMap.put("M", "MOORED/MARINA/PRIVATE JETTY");
        hullKeptDescMap.put("T", "TRAILED");

        hullMaterialDescMap.put("A", "ALUMINIUM");
        hullMaterialDescMap.put("C", "FERRO CEMENT");
        hullMaterialDescMap.put("F", "FIBREGLASS");
        hullMaterialDescMap.put("P", "PLASTIC");
        hullMaterialDescMap.put("R", "RUBBER");
        hullMaterialDescMap.put("S", "STEEL");
        hullMaterialDescMap.put("T", "TIMBER");

        caravanMaterialDescMap.put("A", "ALUMINIUM");
        caravanMaterialDescMap.put("C", "CANVAS");
        caravanMaterialDescMap.put("F", "FIBRO");
        caravanMaterialDescMap.put("O", "OTHER MATERIAL/S");
        caravanMaterialDescMap.put("V", "VINYL");

        hullPurchaseFromDescMap.put("A", "AUCTION");
        hullPurchaseFromDescMap.put("B", "BUILT");
        hullPurchaseFromDescMap.put("D", "DEALER");
        hullPurchaseFromDescMap.put("G", "GIFT/PRIZE");
        hullPurchaseFromDescMap.put("P", "PRIVATE");
        hullPurchaseFromDescMap.put("S", "SALVAGE");
        hullPurchaseFromDescMap.put("X", "CONVERSION DEFAULT VALUE");

        caravanPurchaseFromDescMap.put("A", "AUCTION");
        caravanPurchaseFromDescMap.put("B", "BUILT");
        caravanPurchaseFromDescMap.put("D", "DEALER");
        caravanPurchaseFromDescMap.put("G", "GIFT/PRIZE");
        caravanPurchaseFromDescMap.put("O", "OTHER");
        caravanPurchaseFromDescMap.put("P", "PRIVATE");

        NCBOverrideReasonDescMap.put("A", "CHANGE OF POLICY TYPE");
        NCBOverrideReasonDescMap.put("C", "CUSTOMER DECEASED");
        NCBOverrideReasonDescMap.put("I", "60 DAY GAP");
        NCBOverrideReasonDescMap.put("M", "TM DECISION");
        NCBOverrideReasonDescMap.put("N", "MEDICAL/DISABILITY/NON-DRIVER");
        NCBOverrideReasonDescMap.put("T", "TOTAL LOSS");
        NCBOverrideReasonDescMap.put("U", "UNDERWRITING DECISION");

        motorTypeDescMap.put("I", "INBOARD");
        motorTypeDescMap.put("O", "OUTBOARD");
        motorTypeDescMap.put("S", "STERN DRIVE");

        motorFuelTypeDescMap.put("D", "DIESEL");
        motorFuelTypeDescMap.put("E", "ELECTRIC");
        motorFuelTypeDescMap.put("P", "PETROL");

        motorMakeDescMap.put("AIL", "AILSA CRAIG");
        motorMakeDescMap.put("ALB", "ALBIN");
        motorMakeDescMap.put("ALL", "ALLIS CHALMERS");
        motorMakeDescMap.put("AME", "AMEC");
        motorMakeDescMap.put("ARC", "ARCHIMEDES PENTA");
        motorMakeDescMap.put("ARO", "ARONA");
        motorMakeDescMap.put("ARR", "ARROW");
        motorMakeDescMap.put("AUS", "AUSTIN MARINE");
        motorMakeDescMap.put("BEA", "BEADOUIN");
        motorMakeDescMap.put("BED", "BEDFORD");
        motorMakeDescMap.put("BER", "BERKLEY JETS");
        motorMakeDescMap.put("BET", "BETA");
        motorMakeDescMap.put("BLA", "BLACKSTONE");
        motorMakeDescMap.put("BLX", "BLAXLAND CHAP");
        motorMakeDescMap.put("BMC", "BMC");
        motorMakeDescMap.put("BMW", "BMW");
        motorMakeDescMap.put("BOM", "BOMBARDIER");
        motorMakeDescMap.put("BRA", "BRITISH ANZANI");
        motorMakeDescMap.put("BRG", "BRIGGS & STRATTON");
        motorMakeDescMap.put("BRS", "BRITISH SEAGULL");
        motorMakeDescMap.put("BUI", "BUICK");
        motorMakeDescMap.put("BUK", "BUKHO");
        motorMakeDescMap.put("CAR", "CARNITI");
        motorMakeDescMap.put("CAT", "CATERPILLAR");
        motorMakeDescMap.put("CHA", "CHAPMAN ENG P/L");
        motorMakeDescMap.put("CHR", "CHRYSLER");
        motorMakeDescMap.put("CHV", "CHEVROLET");
        motorMakeDescMap.put("CLA", "CLAE");
        motorMakeDescMap.put("CLI", "CLINTON");
        motorMakeDescMap.put("CMC", "C.M.C.");
        motorMakeDescMap.put("CNC", "CRUISE N CARRY");
        motorMakeDescMap.put("COB", "COBRA");
        motorMakeDescMap.put("COL", "COLE");
        motorMakeDescMap.put("COM", "COMMER");
        motorMakeDescMap.put("CON", "CONVENTRY VICT");
        motorMakeDescMap.put("CRC", "CRUISE CRAFT");
        motorMakeDescMap.put("CRS", "CHRISTOFORDES");
        motorMakeDescMap.put("CRU", "CRUSADERS");
        motorMakeDescMap.put("CUM", "CUMMINS");
        motorMakeDescMap.put("DAI", "DAIHATSU");
        motorMakeDescMap.put("DAT", "DATSUN");
        motorMakeDescMap.put("DAV", "DAVIS");
        motorMakeDescMap.put("DET", "DETROIT");
        motorMakeDescMap.put("DEU", "DEUTZ");
        motorMakeDescMap.put("DOD", "DODGE");
        motorMakeDescMap.put("DOL", "DOLPHIN");
        motorMakeDescMap.put("DOR", "DORMAN");
        motorMakeDescMap.put("DRO", "DROFIN");
        motorMakeDescMap.put("DUC", "DUCATI");
        motorMakeDescMap.put("DUN", "DUNG FONG CHANG CHOW");
        motorMakeDescMap.put("EAT", "EATON");
        motorMakeDescMap.put("ENF", "ENFIELD");
        motorMakeDescMap.put("EVI", "EVINRUDE");
        motorMakeDescMap.put("FAR", "FARYMANN");
        motorMakeDescMap.put("FIA", "FIAT");
        motorMakeDescMap.put("FOD", "FORD");
        motorMakeDescMap.put("FOR", "FORCE");
        motorMakeDescMap.put("FOS", "FORDSON");
        motorMakeDescMap.put("FRE", "FREEWAY");
        motorMakeDescMap.put("GAL", "GALE");
        motorMakeDescMap.put("GAR", "GARDINER");
        motorMakeDescMap.put("GEI", "GEMINI");
        motorMakeDescMap.put("GEM", "G.M.");
        motorMakeDescMap.put("GRA", "GRAY");
        motorMakeDescMap.put("HAL", "HALL");
        motorMakeDescMap.put("HAM", "HAMILTON JETS");
        motorMakeDescMap.put("HAN", "HANIMEX");
        motorMakeDescMap.put("HAR", "HARDMAN");
        motorMakeDescMap.put("HAT", "HATZ");
        motorMakeDescMap.put("HAZ", "HANGZHAU");
        motorMakeDescMap.put("HEN", "HENSCHELL");
        motorMakeDescMap.put("HER", "HERCULES");
        motorMakeDescMap.put("HIN", "HINO");
        motorMakeDescMap.put("HOL", "HOLDEN");
        motorMakeDescMap.put("HOM", "HOMELITE");
        motorMakeDescMap.put("HON", "HONDA");
        motorMakeDescMap.put("HUM", "HUMBER");
        motorMakeDescMap.put("HUP", "HUPEH");
        motorMakeDescMap.put("HUR", "HURRICAN");
        motorMakeDescMap.put("HYD", "HYDRO");
        motorMakeDescMap.put("IND", "INDMAR");
        motorMakeDescMap.put("INT", "INTERNATIONAL");
        motorMakeDescMap.put("ISU", "ISUZU");
        motorMakeDescMap.put("JAG", "JAGUAR");
        motorMakeDescMap.put("JAP", "JAP");
        motorMakeDescMap.put("JAV", "JAVELIN");
        motorMakeDescMap.put("JCZ", "JACUZZ");
        motorMakeDescMap.put("JEE", "JEEP MARINE");
        motorMakeDescMap.put("JND", "JOHN DEER");
        motorMakeDescMap.put("JOH", "JOHNSON");
        motorMakeDescMap.put("KAW", "KAWASAKI");
        motorMakeDescMap.put("KEL", "KELLERCRAFT");
        motorMakeDescMap.put("KEM", "KEMPEST");
        motorMakeDescMap.put("KEV", "KELVIN");
        motorMakeDescMap.put("KIR", "KIRBY");
        motorMakeDescMap.put("KNG", "KINGFISH");
        motorMakeDescMap.put("KRL", "KIRLOSKAR");
        motorMakeDescMap.put("KUB", "KUBOTA");
        motorMakeDescMap.put("LAN", "LANDROVER");
        motorMakeDescMap.put("LAZ", "LAZI TROLL ELECTRIC");
        motorMakeDescMap.put("LEE", "LEES MARINE");
        motorMakeDescMap.put("LEH", "LEHMAN");
        motorMakeDescMap.put("LEY", "LEYLAND");
        motorMakeDescMap.put("LIS", "LISTER");
        motorMakeDescMap.put("LLO", "LLOYD");
        motorMakeDescMap.put("LOM", "LOMANDINI");
        motorMakeDescMap.put("LYC", "LYCOMG");
        motorMakeDescMap.put("MAC", "MARCK CRUISSE");
        motorMakeDescMap.put("MAL", "MALARD");
        motorMakeDescMap.put("MAR", "MARINER");
        motorMakeDescMap.put("MAZ", "MAZDA");
        motorMakeDescMap.put("MCC", "MCCULLOUGH SCOT");
        motorMakeDescMap.put("MCD", "MERCEDES BENZ");
        motorMakeDescMap.put("MCR", "MERCRUISER");
        motorMakeDescMap.put("MCY", "MERCURY");
        motorMakeDescMap.put("MNK", "MINN KOTA");
        motorMakeDescMap.put("MOR", "MORRIS");
        motorMakeDescMap.put("MWM", "M.W.M.");
        motorMakeDescMap.put("NAN", "NANNI");
        motorMakeDescMap.put("NAT", "NATIONAL");
        motorMakeDescMap.put("NEP", "NEPTUNE");
        motorMakeDescMap.put("NIS", "NISSAN");
        motorMakeDescMap.put("OLD", "OLDSMOBILE");
        motorMakeDescMap.put("OMC", "O.M.C.");
        motorMakeDescMap.put("PER", "PERKINS");
        motorMakeDescMap.put("PET", "PETTER");
        motorMakeDescMap.put("PEU", "PEUGOT");
        motorMakeDescMap.put("PIM", "PIMEC");
        motorMakeDescMap.put("PIN", "PINOCK");
        motorMakeDescMap.put("PON", "PONTIAC");
        motorMakeDescMap.put("POR", "PORPOISE");
        motorMakeDescMap.put("REN", "RENAULT");
        motorMakeDescMap.put("REP", "REPCO LTD");
        motorMakeDescMap.put("RIP", "RIPTIDE");
        motorMakeDescMap.put("RIV", "RIVA");
        motorMakeDescMap.put("ROL", "ROLLS ROYCE");
        motorMakeDescMap.put("ROT", "ROTA");
        motorMakeDescMap.put("ROV", "ROVER");
        motorMakeDescMap.put("RTX", "ROTAX");
        motorMakeDescMap.put("RUG", "RUGBY");
        motorMakeDescMap.put("RUS", "RUSTON");
        motorMakeDescMap.put("SAA", "SAAB");
        motorMakeDescMap.put("SAB", "SABB");
        motorMakeDescMap.put("SAC", "SACHS");
        motorMakeDescMap.put("SCA", "SCANIA");
        motorMakeDescMap.put("SEP", "SEA PANTHER");
        motorMakeDescMap.put("SHA", "SHAKESPEARE");
        motorMakeDescMap.put("SHU", "SHUBIRA");
        motorMakeDescMap.put("SIG", "SIGMA");
        motorMakeDescMap.put("SIM", "SIMPLEX");
        motorMakeDescMap.put("SOE", "SOLE");
        motorMakeDescMap.put("SOL", "SOLO");
        motorMakeDescMap.put("STR", "STRATH");
        motorMakeDescMap.put("STT", "STUART TURNER");
        motorMakeDescMap.put("STU", "STUBEBAKER");
        motorMakeDescMap.put("SUZ", "SUZUKI");
        motorMakeDescMap.put("SVA", "SELVA");
        motorMakeDescMap.put("SWI", "SWIFT");
        motorMakeDescMap.put("TAN", "TANAKA");
        motorMakeDescMap.put("TAS", "TAS");
        motorMakeDescMap.put("TAY", "TAYLOR & WATSON");
        motorMakeDescMap.put("TED", "TED WILLIAMS");
        motorMakeDescMap.put("TEM", "TEMPEST");
        motorMakeDescMap.put("TER", "TERHI");
        motorMakeDescMap.put("THI", "THIESS");
        motorMakeDescMap.put("THM", "THOMPSON MARINE");
        motorMakeDescMap.put("THO", "THORNTON");
        motorMakeDescMap.put("THR", "THRUSTER");
        motorMakeDescMap.put("THY", "THORNYCROFT");
        motorMakeDescMap.put("TMB", "TOMBA");
        motorMakeDescMap.put("TOH", "TOHATSU");
        motorMakeDescMap.put("TOM", "TOMOS");
        motorMakeDescMap.put("TOY", "TOYOTA");
        motorMakeDescMap.put("TRI", "TRITON");
        motorMakeDescMap.put("UDE", "U.D.");
        motorMakeDescMap.put("UNI", "UNIVERSAL");
        motorMakeDescMap.put("VAL", "VALIANT");
        motorMakeDescMap.put("VAM", "VALMET");
        motorMakeDescMap.put("VAN", "VANGUARD");
        motorMakeDescMap.put("VAR", "VARIANT");
        motorMakeDescMap.put("VEM", "V.M.");
        motorMakeDescMap.put("VET", "VETUS");
        motorMakeDescMap.put("VIC", "VICTA");
        motorMakeDescMap.put("VIG", "VILGER");
        motorMakeDescMap.put("VIL", "VILLIERS");
        motorMakeDescMap.put("VIN", "VINCO");
        motorMakeDescMap.put("VIR", "VIRE");
        motorMakeDescMap.put("VKW", "VOLKSWAGEN WERK");
        motorMakeDescMap.put("VOL", "VOLVO");
        motorMakeDescMap.put("VOP", "VOLVO PENTA");
        motorMakeDescMap.put("VOX", "VAUXHALL VICTOR");
        motorMakeDescMap.put("WAN", "WANKEL");
        motorMakeDescMap.put("WAR", "WARREN JET");
        motorMakeDescMap.put("WAT", "WATERBOY");
        motorMakeDescMap.put("WBK", "WESTERBEKE");
        motorMakeDescMap.put("WHI", "WHITFIELD");
        motorMakeDescMap.put("WIL", "WILLYS");
        motorMakeDescMap.put("WIN", "WINDSOR");
        motorMakeDescMap.put("WOR", "WORTHAM BLAKE");
        motorMakeDescMap.put("WTB", "WESTBAND");
        motorMakeDescMap.put("WUX", "WUXI");
        motorMakeDescMap.put("XEN", "XENOAH");
        motorMakeDescMap.put("YAM", "YAMAHA");
        motorMakeDescMap.put("YAN", "YANMAR");

        otherPartyClientTypeDescMap.put("A", "NRMA FINANCE");
        otherPartyClientTypeDescMap.put("B", "SECURED CREDIT UNION/BANK LOAN");
        otherPartyClientTypeDescMap.put("C", "SECURED FINANCE COMPANY");
        otherPartyClientTypeDescMap.put("H", "HIRE PURCHASE");
        otherPartyClientTypeDescMap.put("L", "LEASE");
        otherPartyClientTypeDescMap.put("Y", "NRMA BUILDING SOCIETY PERSONAL LOANS");

        caravanBodyTypeDescMap.put("C", "CARAVAN");
        caravanBodyTypeDescMap.put("D", "DEMOUNTABLE");
        caravanBodyTypeDescMap.put("F", "FOLDING/CAMPER TRA");
        caravanBodyTypeDescMap.put("M", "MOBILE HOME");
        caravanBodyTypeDescMap.put("S", "SLIDE ON CAMPER");

        trailerBodyTypeDescMap.put("BK", "BIKE TRAILER");
        trailerBodyTypeDescMap.put("BT", "BOAT TRAILER");
        trailerBodyTypeDescMap.put("BX", "BOX TRAILER");
        trailerBodyTypeDescMap.put("CA", "CAR TRAILER");
        trailerBodyTypeDescMap.put("DG", "DOG TRAILER");
        trailerBodyTypeDescMap.put("GL", "GLIDER TRAILER");
        trailerBodyTypeDescMap.put("HF", "HORSEFLOAT");
        trailerBodyTypeDescMap.put("OT", "OTHER");

        caravanParkingPlaceDescMap.put("C", "CARPORT OR UNDERCOVER");
        caravanParkingPlaceDescMap.put("D", "DRIVEWAY OR ON THE PROPERTY");
        caravanParkingPlaceDescMap.put("G", "GARAGE");
        caravanParkingPlaceDescMap.put("S", "ON THE STREET");
        caravanParkingPlaceDescMap.put("T", "STORAGE CONTAINER");

        premiumOverrideReasonDescMap.put("A", "CHANGE OF POLICY TYPE");
        premiumOverrideReasonDescMap.put("C", "CUSTOMER DECEASED");
        premiumOverrideReasonDescMap.put("I", "60 DAY GAP");
        premiumOverrideReasonDescMap.put("M", "TM DECISION");
        premiumOverrideReasonDescMap.put("N", "MEDICAL/DISABILITY/NON-DRIVER");
        premiumOverrideReasonDescMap.put("T", "TOTAL LOSS");
        premiumOverrideReasonDescMap.put("U", "UNDERWRITING DECISION");

        policyCancelReasonDescMap.put("RC", "UPGRADE DOWNGRADE RISKTYPE CANCEL");
        policyCancelReasonDescMap.put("VC", "CONSULTANT USE: INTERSTATE MOVE TO RACV");
        policyCancelReasonDescMap.put("1", "KEYING ERROR");
        policyCancelReasonDescMap.put("2", "MOVED TO COMPETITOR - PRICE/PRODUCT");
        policyCancelReasonDescMap.put("3", "CONSULTANT USE: SOLD");
        policyCancelReasonDescMap.put("4", "COOLING OFF");
        policyCancelReasonDescMap.put("5", "POLICY RENEWED IN ERROR (CUSTOMER ERROR)");
        policyCancelReasonDescMap.put("6", "TOTAL LOSS");
        policyCancelReasonDescMap.put("7", "BUSINESS USE");
        policyCancelReasonDescMap.put("8", "CONSULTANT USE: PRICE OBJECTION");
        policyCancelReasonDescMap.put("9", "EARLY RETURN HOME");
        policyCancelReasonDescMap.put("10", "CONSULTANT USE: NOT REQUIRED");
        policyCancelReasonDescMap.put("11", "PRE-EXISTING MEDICAL COVER DENIED");
        policyCancelReasonDescMap.put("12", "MOVED TO COMPETITOR");
        policyCancelReasonDescMap.put("13", "NO REPLY TO CORRESPONDENCE");
        policyCancelReasonDescMap.put("14", "DETERIORATED CONDITION");
        policyCancelReasonDescMap.put("15", "REFUND (NO FEE)");
        policyCancelReasonDescMap.put("16", "REPOSSESSED");
        policyCancelReasonDescMap.put("17", "FAILURE TO MEET SECURITY REQUIREMENTS");
        policyCancelReasonDescMap.put("18", "UNACCEPTABLE MODIFICATIONS");
        policyCancelReasonDescMap.put("19", "AVOIDED");
        policyCancelReasonDescMap.put("20", "CONSULTANT USE: POLICY OBJECTION");
        policyCancelReasonDescMap.put("21", "SUBJECT OF COVER NOT ACCEPTABLE - UW CRITERIA");
        policyCancelReasonDescMap.put("22", "CONSULTANT USE: INTERSTATE MOVE");
        policyCancelReasonDescMap.put("23", "CHANGE SUM INSURED");
        policyCancelReasonDescMap.put("24", "UNSIGNED DOCUMENT");
        policyCancelReasonDescMap.put("25", "CTP-CANCELLED BY CLIENT-INSURANCE NOT REQUIRED (UNVALIDATED)");
        policyCancelReasonDescMap.put("26", "CTP-CANCELLED BY CLIENT-REGISTRATION CANCELLED (UNVALIDATED)");
        policyCancelReasonDescMap.put("27", "CTP-CANCELLED BY CLIENT-REGISTRATION REFUSED (UNVALIDATED)");
        policyCancelReasonDescMap.put("28", "CTP-CANCELLED BY CLIENT-VEHICLE NOT REGISTERED (UNVALIDATED)");
        policyCancelReasonDescMap.put("29", "CTP-CANCELLED BY CLIENT-CHANGE OF INSURER (UNVALIDATED)");
        policyCancelReasonDescMap.put("30", "CTP-CANCD BY NRMA-NO REPLY TO CORRESPONDENCE (UNVALIDATED)");
        policyCancelReasonDescMap.put("31", "CTP-CANCELLED BY NRMA-USER KEYING ERROR (UNVALIDATED)");
        policyCancelReasonDescMap.put("32", "CTP-CANCELLED BY NRMA-VEHICLE NOT REGISTERED (UNVALIDATED)");
        policyCancelReasonDescMap.put("33", "CTP-CANCELLED BY NRMA-DISHONOURED CHEQUE (UNVALIDATED)");
        policyCancelReasonDescMap.put("34", "CTP-CANCELLED BY RTA-REGISTRATION CANCELLED (UNVALIDATED)");
        policyCancelReasonDescMap.put("35", "CTP-CANCELLED BY RTA-REGISTRATION REFUSED (UNVALIDATED)");
        policyCancelReasonDescMap.put("36", "CTP-CANCELLED BY RTA-CHANGE OF INSURER (UNVALIDATED)");
        policyCancelReasonDescMap.put("37", "REFUSED DUE TO IDENTITY");
        policyCancelReasonDescMap.put("38", "REFUSED DUE TO SOC");
        policyCancelReasonDescMap.put("39", "OFFENCE/INCIDENT HISTORY");
        policyCancelReasonDescMap.put("40", "CTP-CANCELLED BY CLIENT-INSURANCE NOT REQUIRED (VALIDATED)");
        policyCancelReasonDescMap.put("41", "CTP-CANCELLED BY CLIENT-REGISTRATION CANCELLED (VALIDATED)");
        policyCancelReasonDescMap.put("42", "CTP-CANCELLED BY CLIENT-REGISTRATION REFUSED (VALIDATED)");
        policyCancelReasonDescMap.put("43", "CTP-CANCELLED BY CLIENT-VEHICLE NOT REGISTERED (VALIDATED)");
        policyCancelReasonDescMap.put("44", "CTP-CANCELLED BY CLIENT-CHANGE OF INSURER (VALIDATED)");
        policyCancelReasonDescMap.put("45", "CTP-CANCELLED BY NRMA-NO REPLY TO CORRESPONDENCE (VALIDATED)");
        policyCancelReasonDescMap.put("46", "CTP-CANCELLED BY NRMA-USER KEYING ERROR");
        policyCancelReasonDescMap.put("47", "CTP-CANCELLED BY NRMA-VEHICLE NOT REGISTERED (VALIDATED)");
        policyCancelReasonDescMap.put("48", "CTP-CANCELLED BY NRMA-DISHONOURED CHEQUE (VALIDATED)");
        policyCancelReasonDescMap.put("49", "CTP-CANCELLED BY RTA-REGISTRATION CANCELLED (VALIDATED)");
        policyCancelReasonDescMap.put("50", "CTP-CANCELLED BY WOVR-CTP PRODUCT USE ONLY (VALIDATED)");
        policyCancelReasonDescMap.put("51", "CTP-CANCELLED BY RTA-CHANGE OF INSURER (VALIDATED)");
        policyCancelReasonDescMap.put("52", "BREACH OF POLICY CONDITIONS");
        policyCancelReasonDescMap.put("53", "ADD/DELETE INSURED");
        policyCancelReasonDescMap.put("54", "HOM INSURING ELSEWHERE");
        policyCancelReasonDescMap.put("55", "HOM INSUFFICIENT SECURITY");
        policyCancelReasonDescMap.put("56", "HOM SPREAD OF RISK/SUM INSURED");
        policyCancelReasonDescMap.put("57", "HOM HOME NOT ACCEPTABLE");
        policyCancelReasonDescMap.put("58", "HOM UNACCEPTABLE BUSINESS USE");
        policyCancelReasonDescMap.put("59", "HOM OWNER/INSURED DISCLOSURE");
        policyCancelReasonDescMap.put("60", "HOM BUILDING WORK UNACCEPTABLE");
        policyCancelReasonDescMap.put("61", "HOM INS CLAIMS HISTORY");
        policyCancelReasonDescMap.put("62", "HOM SITUATION ADDRESS CHANGE");
        policyCancelReasonDescMap.put("63", "KEYING ERROR - COPY TO A NEW POLICY");
        policyCancelReasonDescMap.put("64", "CHANGE OF POLICY TYPE");
        policyCancelReasonDescMap.put("65", "CONSULTANT USE: POOR EXPERIENCE");
        policyCancelReasonDescMap.put("66", "CONSULTANT USE: UNPAID NEW BUSINESS/RENEWAL");
        policyCancelReasonDescMap.put("67", "CHANGE OF POLICY TYPE (RACV)");
        policyCancelReasonDescMap.put("68", "COOLING OFF (RACV)");
        policyCancelReasonDescMap.put("69", "KEYING ERROR (RACV)");
        policyCancelReasonDescMap.put("70", "VEHICLE REPLACED");
        policyCancelReasonDescMap.put("71", "HOME SECURITY - COST");
        policyCancelReasonDescMap.put("72", "HOME SECURITY MONITORING  - KEY ERROR- COPY TO A NEW POLICY");
        policyCancelReasonDescMap.put("73", "MOVED INTERSTATE (RACV)");
        policyCancelReasonDescMap.put("74", "NCD FOR LIFE ISSUE");
        policyCancelReasonDescMap.put("75", "COVER TRANSFERRED TO RURAL INSURANCE");
        policyCancelReasonDescMap.put("76", "TERMS AND CONDITIONS/PRIVACY/DOD NOT AGREED");
        policyCancelReasonDescMap.put("77", "TERMS AND CONDITIONS/DUTY OF DISCLOSURE NOT AGREED");
        policyCancelReasonDescMap.put("78", "MOVED TO COMPETITOR - PRICE/PRODUCT (RACV)");
        policyCancelReasonDescMap.put("79", "MOVED TO COMPETITOR - SERVICE (RACV)");
        policyCancelReasonDescMap.put("80", "TEMPORARY AMENDMENT");
        policyCancelReasonDescMap.put("81", "HOME SECURITY - INSTALLATION CANCELLATION");
        policyCancelReasonDescMap.put("82", "HOME SECURITY - CLIENT MOVED");
        policyCancelReasonDescMap.put("83", "HOME SECURITY - CLIENT NOT HAPPY");
        policyCancelReasonDescMap.put("84", "HOME SECURITY - NO REASON PROVIDED");
        policyCancelReasonDescMap.put("85", "HOME SECURITY - NON PAYMENT");
        policyCancelReasonDescMap.put("86", "HOME SECURITY - END OF CONTRACT");
        policyCancelReasonDescMap.put("87", "HOME SECURITY - CLIENT DECEASED");
        policyCancelReasonDescMap.put("88", "HOME SECURITY - RENOVATIONS OR REPAIRS");
        policyCancelReasonDescMap.put("89", "NO LONGER INSURING (RACV)");
        policyCancelReasonDescMap.put("90", "NO REPLY TO CORRESPONDENCE (RACV)");
        policyCancelReasonDescMap.put("91", "PROPERTY/VEHICLE SOLD (RACV)");
        policyCancelReasonDescMap.put("92", "TERMS & CONDTNS/PRIVACY/DOD NOT AGREED (RACV)");
        policyCancelReasonDescMap.put("93", "CONSULTANT USE: EX GRATIA");
        policyCancelReasonDescMap.put("94", "PERSONAL EFFECTS POLICIES NO LONGER ADDED");
        policyCancelReasonDescMap.put("95", "CONSULTANT USE: DECEASED ESTATE");
        policyCancelReasonDescMap.put("96", "CONSULTANT USE: INSURED NAME CHANGE RE-KEY");
        policyCancelReasonDescMap.put("97", "PAY BY THE MONTH INSTALMENT ARREARS");
        policyCancelReasonDescMap.put("98", "AUTO LAPSE - NEW BUSINESS");
        policyCancelReasonDescMap.put("99", "AUTO LAPSE");

        basicPremiumOverrideReasonDescMap.put("AA", "AGREED PREMIUM");
        basicPremiumOverrideReasonDescMap.put("AV", "RISK ADDRESS VERIFICATION");
        basicPremiumOverrideReasonDescMap.put("BB", "{BEAT BY 10 PERCENT (RENEWAL)}");
        basicPremiumOverrideReasonDescMap.put("BH", "BUY 1 GET 1 HALF PRICE");
        basicPremiumOverrideReasonDescMap.put("BR", "BUY 1 GET 1 HALF PRICE (RENEWAL)");
        basicPremiumOverrideReasonDescMap.put("B3", "SPECIAL PREMIUM AGREED THIS TRANSACTION");
        basicPremiumOverrideReasonDescMap.put("CA", "CAMPAIGN 1");
        basicPremiumOverrideReasonDescMap.put("CC", "CLAIMS COUNTER");
        basicPremiumOverrideReasonDescMap.put("CF", "COOLING OFF");
        basicPremiumOverrideReasonDescMap.put("CM", "CAMPAIGN 2");
        basicPremiumOverrideReasonDescMap.put("CO", "CONVERSION");
        basicPremiumOverrideReasonDescMap.put("CP", "CAMPAIGN 3");
        basicPremiumOverrideReasonDescMap.put("CS", "CONFLICTING STATEMENTS");
        basicPremiumOverrideReasonDescMap.put("C4", "UNDERWRITING CONSIDERATIONS OUTSIDE USUAL GUIDELINES");
        basicPremiumOverrideReasonDescMap.put("DC", "DISCRETIONARY CUSTOMER SOLUTIONS DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("DD", "DISCRETIONARY SPEND & MULTI POLICY DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("DE", "DISCRETIONARY VOLUNTARY EXCESS DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("DS", "DISCRETIONARY SPEND");
        basicPremiumOverrideReasonDescMap.put("DW", "DEALER WRITE OFF - NICHE ONLY");
        basicPremiumOverrideReasonDescMap.put("DX", "DISCRETIONARY CUST AND VOL XS DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("D1", "SPONSORSHIP PARTNER DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("D2", "SPONSORSHIP PARTNER DISCOUNT R");
        basicPremiumOverrideReasonDescMap.put("EQ", "OVER THE EQC CAP DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("GO", "GROWTH STRATEGY 2");
        basicPremiumOverrideReasonDescMap.put("GP", "SOVEREIGN STAFF DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("GR", "GROWTH STRATEGY 1");
        basicPremiumOverrideReasonDescMap.put("GS", "GROWTH STRATEGY");
        basicPremiumOverrideReasonDescMap.put("GW", "GROWTH STRATEGY 3");
        basicPremiumOverrideReasonDescMap.put("HL", "NRMA HOME LOAN");
        basicPremiumOverrideReasonDescMap.put("KM", "KILOMETRE DRIVEN (DI ONLY)");
        basicPremiumOverrideReasonDescMap.put("LD", "LOYALTY DISCOUNT EVP");
        basicPremiumOverrideReasonDescMap.put("LF", "LIMITS/FEATURES");
        basicPremiumOverrideReasonDescMap.put("LR", "LOYALTY DISCOUNT EVP (RENEWAL)");
        basicPremiumOverrideReasonDescMap.put("NC", "NEW CAR CAMPAIGN");
        basicPremiumOverrideReasonDescMap.put("NF", "NON FINANCIAL CHANGE");
        basicPremiumOverrideReasonDescMap.put("NR", "NO REPLY");
        basicPremiumOverrideReasonDescMap.put("OC", "OUTBOUND ESTIMATE CAMPAIGN - (OUTBOUND ONLY)");
        basicPremiumOverrideReasonDescMap.put("OD", "ONLINE DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("PC", "PRICE CERTAINTY");
        basicPremiumOverrideReasonDescMap.put("PD", "PROMOTIONAL / SHOW DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("PG", "PRICE GUARANTEE");
        basicPremiumOverrideReasonDescMap.put("PR", "PRICE CERTAINTY AT RENEWAL");
        basicPremiumOverrideReasonDescMap.put("PS", "PRICE SERVICE");
        basicPremiumOverrideReasonDescMap.put("QC", "QLD CTP/CAR OFFER");
        basicPremiumOverrideReasonDescMap.put("RA", "RACV ONLY - UNDER 25");
        basicPremiumOverrideReasonDescMap.put("RC", "RECEIPT ALLOCATION");
        basicPremiumOverrideReasonDescMap.put("RO", "RENEWAL PREMIUM OVERRIDE");
        basicPremiumOverrideReasonDescMap.put("SC", "STANDARD COVER POLICY");
        basicPremiumOverrideReasonDescMap.put("SD", "STAFF DISCOUNT");
        basicPremiumOverrideReasonDescMap.put("SI", "SCHEDULED ITEMS");
        basicPremiumOverrideReasonDescMap.put("SP", "STATE PROMOTION 1");
        basicPremiumOverrideReasonDescMap.put("SPACES", "SPACES ARE VALID WHEN AUTO FLAG = 'Y'");
        basicPremiumOverrideReasonDescMap.put("SQ", "STATE PROMOTION 2");
        basicPremiumOverrideReasonDescMap.put("SR", "STATE PROMOTION 3");
        basicPremiumOverrideReasonDescMap.put("SS", "SWITCH & SAVE (NEW BUSINESS)");
        basicPremiumOverrideReasonDescMap.put("SV", "SAVE CAMPAIGN");
        basicPremiumOverrideReasonDescMap.put("TA", "TEST AND LEARN RENEWAL");
        basicPremiumOverrideReasonDescMap.put("TL", "TEST AND LEARN NB");
        basicPremiumOverrideReasonDescMap.put("TN", "NZ GST RATE CHANGE (1 OCT 2010)");
        basicPremiumOverrideReasonDescMap.put("TR", "NZ GST RATE CHANGE (1 OCT 2010) RENEWAL");
        basicPremiumOverrideReasonDescMap.put("UL", "UNDERWRITING LOADING");
        basicPremiumOverrideReasonDescMap.put("UN", "UNECONOMIC");
        basicPremiumOverrideReasonDescMap.put("VC", "RVC ADJUSTMENT");
        basicPremiumOverrideReasonDescMap.put("VR", "RVC ADJUSTMENT - RENEWAL");

        commissionOverrideReasonDescMap.put("AA", "TRIAL");

        ctpVehicleUseDescMap.put("B", "BUSINESS");
        ctpVehicleUseDescMap.put("F", "FLEET     (VALID EFFECTIVE 11 NOVEMBER 2002)");
        ctpVehicleUseDescMap.put("G", "SUPER FLEET (GOVERMENT) - EFFECTIVE 01 JULY 2017");
        ctpVehicleUseDescMap.put("O", "BUSINESS OTHER");
        ctpVehicleUseDescMap.put("P", "PRIVATE");

        NSWaddressMap.put("0", "104 Queens Rd Hurstville NSW 2220");
        NSWaddressMap.put("1", "17A Crane Street Homebush NSW 2140");
        NSWaddressMap.put("2", "17B Crane Street Homebush NSW 2140");
        NSWaddressMap.put("3", "51 Chard Rd Brookvale NSW 2100");
        NSWaddressMap.put("4", "11 Silverwater Rd Auburn NSW 2144");
        NSWaddressMap.put("5", "74 Oak Rd Kirrawee NSW 2232");
        NSWaddressMap.put("6", "4 Hillview Rd Eastwood NSW 2122");
        NSWaddressMap.put("7", "99 York St Sydney NSW 2000");
        NSWaddressMap.put("8", "388 George Street Sydney NSW 2000");
        NSWaddressMap.put("9", "31 ALFRED ST SYDNEY NSW 2000");
        NSWaddressMap.put("10", "Unit B210 Level 2 110 Queens Rd Hurstville NSW 2220");
        NSWaddressMap.put("11", "Suite 100 100-106 Marrickville st Marrickville NSW 2204");
        NSWaddressMap.put("12", "Unit 17 Level 4 167-173 Parramatta Rd North Strathfield NSW 2137");
        NSWaddressMap.put("13", "483 GEORGE ST SYDNEY NSW 2000");
        NSWaddressMap.put("14", "220 GEORGE ST PARRAMATTA NSW 2150");
        NSWaddressMap.put("15", "220 GEORGE ST ERSKINEVILLE NSW 2043");
        NSWaddressMap.put("16", "220 GEORGES RIVER RD KENTLYN NSW 2560");
        NSWaddressMap.put("17", "220 GEORGE ST HAY NSW 2711");
        NSWaddressMap.put("18", "220 GEORGES RIVER RD CROYDON PARK NSW 2133");
        NSWaddressMap.put("19", "220 GEORGE BASS DR LILLI PILLI NSW 2536");
        NSWaddressMap.put("20", "Unit 5 220 GEORGE ST LIVERPOOL NSW 2170");
        NSWaddressMap.put("21", "Unit 8 220 GEORGE ST LIVERPOOL NSW 2170");
        NSWaddressMap.put("22", "Unit 8 220 GEORGE ST PARRAMATTA NSW 2150");
        NSWaddressMap.put("23", "Unit 3 220 GEORGE ST PARRAMATTA NSW 2150");
        NSWaddressMap.put("24", "Unit 2 220 GEORGE ST PARRAMATTA NSW 2150");
        NSWaddressMap.put("25", "Unit 4 220 GEORGE ST PARRAMATTA NSW 2150");

        riskStateMap.put("01", "AC");
        riskStateMap.put("02", "NS");
        riskStateMap.put("03", "VI");
        riskStateMap.put("04", "QL");
        riskStateMap.put("05", "SA");
        riskStateMap.put("06", "WA");
        riskStateMap.put("07", "TA");
        riskStateMap.put("08", "NT");
        riskStateMap.put("64", "NZ");

    }

}
