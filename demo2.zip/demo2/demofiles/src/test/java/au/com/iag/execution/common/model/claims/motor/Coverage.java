package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Coverage implements Serializable {


    private static final long serialVersionUID = -6737768000429686528L;

    private String policyCoverageCode;
    private String coverageType;

    public String getPolicyCoverageCode() {
        return policyCoverageCode;
    }

    public void setPolicyCoverageCode(String policyCoverageCode) {
        this.policyCoverageCode = policyCoverageCode;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

}
