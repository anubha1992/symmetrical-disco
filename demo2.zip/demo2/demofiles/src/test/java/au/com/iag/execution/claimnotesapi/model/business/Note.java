package au.com.iag.execution.claimnotesapi.model.business;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Note implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    private String body;

    private Boolean confidential;

    private String securityType;

    private String subject;

    private String topic;

}

