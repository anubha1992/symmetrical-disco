package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AssessmentDetails {
    @ApiModelProperty(
            value = "Date and time vehicle was assessed by the assessor",
            example = "2018-07-21T14:00:00")
    private String assessmentDateTime;
    private Assessor assessor;
    @ApiModelProperty(
            value = "Repairer quote Id to identify this repair/quote",
            example = "123")
    private String assessmentReference;
    @ApiModelProperty(
            value = "Service Request Allocation ID",
            example = "cc:123456")
    private String serviceRequestId;
    @ApiModelProperty(
            value = "assessment case status",
            example = "authorised")
    private String assessmentStatus;
    @ApiModelProperty(
            value = "assessment result",
            example = "cash_settlement")
    private AssessmentResult assessmentResult;

    private enum AssessmentResult { cash_settlement, total_loss,  repair; }
}
