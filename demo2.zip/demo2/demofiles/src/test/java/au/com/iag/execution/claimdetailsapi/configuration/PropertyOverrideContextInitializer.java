package au.com.iag.execution.claimdetailsapi.configuration;

import org.springframework.context.*;
import static org.springframework.test.context.support.TestPropertySourceUtils.*;

public class PropertyOverrideContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        addPropertiesFilesToEnvironment(
                configurableApplicationContext,
                "classpath:config/application-test.properties",
                "classpath:config/claimdetails-api/application-test.properties",
                "classpath:config/claimdetails-api/${env}/application-test.properties");
    }
}