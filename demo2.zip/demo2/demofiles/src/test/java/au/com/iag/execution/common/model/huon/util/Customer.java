package au.com.iag.execution.common.model.huon.util;

import au.com.iag.execution.common.exception.*;
import static org.apache.commons.lang3.time.DateUtils.*;
import java.lang.reflect.*;
import java.text.*;
import java.util.*;
import java.util.Map.*;

/**
 * This is a common client (Customer) class used by both MCP and HUON.
 * It is called Customer not Client because there are Java classes called Client. If we use the same name, sometimes, may import wrong class.
 */
public class Customer {


    public final static String INDIVIDUAL = "Individual";
    public final static String COMPANY = "Company";


    private static LinkedHashMap<String, String> companyType = null;

    private String clientNumber = "";
    private String crodsPartyId = "";
    private String crodsPartyAddressId = "";
    private String crodsAddressId = "";
    private String clientType = "";
    private String givenName = "";
    private String middleName = "";

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }


    private String surname = "";
    private Date dob = null;
    private String gender = "";
    private String title = "";
    private String companyName = "";
    private String companyAbn = "";
    private String staff = "";

    private boolean restrict = false;
    private String refused = "";

    private Address address = null;

    private String phone1Type = "";
    private String phone1Area = "";
    private String phone1Number = "";
    private String phone2Type = "";
    private String phone2Area = "";
    private String phone2Number = "";
    private String email = "";

    private int declaredClaims = 0;
    private String abn;
    private String organizationtype;

    public String getAbn() {
        List<String> abnlist = new ArrayList<String>();
        abnlist.add("51824753556");
        abnlist.add("92983933887");
        abnlist.add("33051775556");
        abnlist.add("22024824889");
        abnlist.add("17140551846");
        abnlist.add("70087650191");
        abnlist.add("26055004978");
        abnlist.add("66099895413");
        abnlist.add("33051775556");
        abnlist.add("45057808938");
        abnlist.add("35003429883");
        abnlist.add("72008056700");
        abnlist.add("96972476461");
        abnlist.add("72069279027");
        abnlist.add("82069279072");
        abnlist.add("29601537928");
        abnlist.add("86007422522");
        abnlist.add("41125607454");
        abnlist.add("64960036639");
        abnlist.add("77108792016");
        abnlist.add("55127499763");
        abnlist.add("76071920806");
        abnlist.add("16620218312");
        abnlist.add("25061796414");
        abnlist.add("78151664569");
        abnlist.add("29715975053");
        abnlist.add("90003730112");
        abnlist.add("49133930677");
        abnlist.add("34169313419");
        abnlist.add("29145593362");
        abnlist.add("69151615486");
        abnlist.add("60152983563");
        abnlist.add("73089181790");
        abnlist.add("60154780953");
        abnlist.add("27121604846");
        abnlist.add("80523537938");
        abnlist.add("88134460576");
        abnlist.add("12547913801");
        abnlist.add("50140202857");
        abnlist.add("67111317518");
        abnlist.add("53116550077");
        this.abn = abnlist.get(new Random().nextInt(abnlist.size()));
        return abn;
    }


    // addedd for refusal and cancellations for Retrieve Policy Authorization
    private String refusalDate = "";

    public String getRefusalDate() {
        return refusalDate;
    }

    public void setRefusalDate(String refusalDate) {
        this.refusalDate = refusalDate;
    }

    public String getAsset() {
        return asset;
    }

    public void setAsset(String asset) {
        this.asset = asset;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public boolean isRefusedCancellations() {
        return RefusedCancellations;
    }

    public void setRefusedCancellations(Customer customer, String RefusalDate, String asset, String condition, String reasoncode) {
        this.RefusedCancellations = true;
        this.clientNumber = customer.getClientNumber();
        this.refusalDate = RefusalDate;
        this.asset = asset;
        this.condition = condition;
        this.reasonCode = reasoncode;

    }

    private String asset = "";
    private String condition = "";
    private String reasonCode = "";
    private boolean RefusedCancellations = false;

    /*
     * Staff
     */
    private static LinkedHashMap<String, String> staffMap = null;

    /**
     * Create a new customer with nothing.
     * After creation by this constructor, you have to set the client's information or call setDefault function to set all of those information.
     */
    public Customer() {
        initStaffMap();
        setDefault("NSW", INDIVIDUAL);
    }


    /**
     * Create a customer object with file list
     *
     * @param fieldList a list of McpField
     * @throws ParseException
     * @throws InvalidDataException
     */
    public Customer(List<DataRow> fieldList) throws ParseException, InvalidDataException {
        initStaffMap();
        String state = "NSW";
        String type = INDIVIDUAL;
        for (DataRow field : fieldList) {
            if (field.getEntity().equalsIgnoreCase("CUSTOMER")) {
                if (field.getField().equalsIgnoreCase("TYPE")) {
                    if (field.getValue().equalsIgnoreCase(COMPANY))
                        type = COMPANY;
                }

                if (field.getField().equalsIgnoreCase("STATE"))
                    state = field.getValue();
            }
        }

        setDefault(state, type);

        boolean useAge = false;
//		String firstName = "";
//		String lastName = "";
//		String companyName = "";
        String indicator = "";
        String unitNo = "";
        String streetNo = "";
        String streetName = "";
        String streetType = "";
        String suburb = "";
        String postcode = "";

        for (DataRow field : fieldList) {
            if (field.getEntity().equalsIgnoreCase("CUSTOMER")) {
                switch (field.getField()) {
                    case "TYPE":
                        break;
//				case "FIRSTNAME":
//					if (type.equalsIgnoreCase(INDIVIDUAL)) {
//						setGivenName(field.getValue());
//					}
//					break;
//				case "LASTNAME":
//					if (type.equalsIgnoreCase(INDIVIDUAL)) {
//						setSurname(field.getValue());
//					}
//					break;
//				case "COMPANYNAME":
//					if (type.equalsIgnoreCase(COMPANY)) {
//						setCompanyName(field.getValue());
//					}
//					break;					
                    case "AGE":
                        useAge = true;
                        setDobByAge(Integer.parseInt(field.getValue()));
                        break;
                    case "DOB":
                        if (!useAge) {
                            setDob(field.getValue());
                        }
                        break;
                    case "GENDER":
                        setGender(field.getValue());
                        break;
                    case "TITLE":
                        setTitle(field.getValue());
                        break;
                    case "STATE":
                        break;
                    case "POSTCODE":
                        postcode = field.getValue();
                        break;
                    case "SUBURB":
                        suburb = field.getValue();
                        break;
                    case "ADDRESSINDICATOR":
                        indicator = field.getValue();
                        break;
                    case "UNITNO":
                        unitNo = field.getValue();
                        break;
                    case "STREETNO":
                        streetNo = field.getValue();
                        break;
                    case "STREETNAME":
                        streetName = field.getValue();
                        break;
                    case "STREETTYPE":
                        streetType = field.getValue();
                        break;
                    default:
                        throw new InvalidDataException("The field value for customer is invalid: " + field.getField());
                }
            }
        }

        if (!suburb.isEmpty() && !postcode.isEmpty()) {
            this.address.setSuburb(suburb);
            this.address.setPostcode(postcode);

            if (!streetNo.isEmpty() && !streetName.isEmpty() && !streetType.isEmpty()) {
                this.address.setStreetNo(streetNo);
                this.address.setStreetName(streetName);
                this.address.setStreetType(streetType, true);
            }

        }

        if (!indicator.isEmpty()) {
            this.address.setIndicator(indicator);
            this.address.setUnitNo(unitNo);
        }

    }

    /**
     * Create a new customer only with client type.
     * After creation by this constructor, you have to set the client's information or call setDefault function to set all of those information.
     */
    public Customer(String clientType) {
        initStaffMap();
        setDefault("NSW", clientType);
//		this.clientType = clientType;
    }

    /**
     * Create a new customer and set default values.
     *
     * @param state
     * @param clientType
     */
    public Customer(String state, String clientType) {
        initStaffMap();
        setDefault(state, clientType);
    }

    /**
     * Set default values for a client based on state
     *
     * @param state e.g. "NSW"
     */
    public void setDefault(String state, String clientType) {
        this.clientType = clientType;
        if (clientType.equalsIgnoreCase(INDIVIDUAL)) {
            givenName = getRandomName(12);
            surname = getRandomName(20);
            middleName = getRandomName(20);

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.YEAR, -30);
            dob = cal.getTime();
            gender = "Male";
            title = "Mr";
            companyName = "";
            companyAbn = "";

            //Default email
            email = givenName + "." + surname + "@iag.com.au";
            role = getRandomName(4);
            phone1Number = "04" + getRandomNumber(8);

        } else {
            givenName = "";
            surname = "";
            dob = null;
            gender = "";
            title = "";
            companyName = getRandomName(25);
            companyAbn = getAbn();
            email = companyName + "@iag.com.au";
            phone1Number = "04" + getRandomNumber(8);
        }

        address = new Address(state);
        address.setDefault(state);

    }


    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }


    public int getDeclaredClaims() {
        return declaredClaims;
    }

    public void setDeclaredClaims(int declaredClaims) {
        this.declaredClaims = declaredClaims;
    }

    public String getCrodsPartyId() {
        return crodsPartyId;
    }

    public void setCrodsPartyId(String crodsPartyId) {
        this.crodsPartyId = crodsPartyId;
    }

    public String getCrodsPartyAddressId() {
        return crodsPartyAddressId;
    }

    public void setCrodsPartyAddressId(String crodsPartyAddressId) {
        this.crodsPartyAddressId = crodsPartyAddressId;
    }

    public String getCrodsAddressId() {
        return crodsAddressId;
    }

    public void setCrodsAddressId(String crodsAddressId) {
        this.crodsPartyAddressId = crodsAddressId;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
        if (clientType.equalsIgnoreCase(COMPANY)) {
            this.givenName = "";
            this.surname = "";
            this.title = "";
            this.gender = "";
        }

    }

    public boolean isCompany() {
        if (this.clientType.equalsIgnoreCase(COMPANY))
            return true;
        else
            return false;
    }

    public String getGivenName() {
        return givenName;
    }

    /**
     * Set given name
     *
     * @param givenName if its length > 15, truncate it
     */
    public void setGivenName(String givenName) {
        if (givenName.length() > 15)
            givenName = givenName.substring(0, 15);
        this.givenName = givenName;
    }

    public void setRandomGivenName() {
        this.givenName = getRandomName(12);
    }

    public void setRandomGivenName(int length) {
        this.givenName = getRandomName(length);
    }

    public String getSurname() {
        return surname;
    }

    /**
     * Set surname
     *
     * @param surname if its length > 30, truncate it
     */
    public void setSurname(String surname) {
        if (surname.length() > 30)
            surname = surname.substring(0, 30);
        this.surname = surname;
    }

    public void setRandomSurname() {
        this.surname = getRandomName(20);
    }

    public void setRandomSurname(int length) {
        this.surname = getRandomName(length);
    }

    /**
     * Set given name and surname by full name with format as Title + " " + givenname + " " + surname.
     * It also supports middle name between them.
     *
     * @param fullName
     */
    public void setTitleNamesByFullName(String fullName) {
        String[] names = fullName.split(" ");
        this.setTitle(names[0]);
        this.setGivenName(names[1]);
        this.setSurname(names[names.length - 1]);
    }

    public Date getDob() {
        return dob;
    }

    public int getAge() {
        if (this.clientType.equalsIgnoreCase(COMPANY))
            return 0;

        return DataHandler.getAgeByToday(dob);
    }

    /**
     * Get DOB as a string.
     *
     * @return format is "dd/MM/yyyy".
     */
    public String getDobString() {
        if (dob == null)
            return "";
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(dob);
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    /**
     * Set client's DOB with a string
     *
     * @param dob format is "dd/MM/yyyy"
     */
    public void setDob(String dob) throws ParseException {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        this.dob = formatter.parse(dob);
    }

    public void setDobForDBFormat(String dob) throws ParseException {
        this.dob = parseDate(dob, "yyyy-MM-dd");
    }

    /**
     * Set DOB by age. The DOB will be today of "age" years ago compared to current year.
     * It does not consider policy's effective date.
     *
     * @param age
     */
    public void setDobByAge(int age) {
        int years = 0 - age;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, years);
//		cal.set(Calendar.DAY_OF_MONTH, 1);
//		cal.set(Calendar.MONTH, 0);
        this.dob = cal.getTime();

    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        if (gender.toUpperCase().startsWith("M"))
            gender = "Male";
        if (gender.toUpperCase().startsWith("F")) {
            gender = "Female";
            if (this.title.equalsIgnoreCase("Mr"))
                this.title = "Ms";
        }
        this.gender = gender;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCompanyName() {
        return companyName;
    }

    /**
     * Set company name
     *
     * @param companyName if its length > 40, truncate it
     */
    public void setCompanyName(String companyName) {
        if (givenName.length() > 40)
            givenName = givenName.substring(0, 40);
        this.companyName = companyName;
    }

    /**
     * Set a random company name with default length as 20
     */
    public void setRandomCompanyName() {
        this.companyName = getRandomName(20);
    }

    /**
     * Set a random company name with length
     *
     * @param length the leng of the name. If it is more than 40, set it to 40; if it is less then 1, set it to 5.
     */
    public void setRandomCompanyName(int length) {
        if (length < 1) {
            length = 5;
        }
        if (length > 40) {
            length = 40;
        }
        this.companyName = getRandomName(length);
    }


    public String getCompanyAbn() {
        return companyAbn;
    }

    public void setCompanyAbn(String companyAbn) {
        this.companyAbn = companyAbn;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void setAddress(String streetNo, String streetName, String streetType, String suburb, String postcode, String state) {
        Address address = new Address(streetNo, streetName, streetType, suburb, postcode, state);
        this.address = address;

    }

    public void setAddress(String indicator, String unitNo, String streetNo, String streetName, String streetType, String suburb, String postcode, String state) throws InvalidDataException {
        Address address = new Address(indicator, unitNo, streetNo, streetName, streetType, suburb, postcode, state);
        this.address = address;

    }


    public boolean isRestrict() {
        return restrict;
    }

    /**
     * Set whether the client is RESTRICT
     *
     * @param restrict
     */
    public void setRestrict(boolean restrict) {
        this.restrict = restrict;
    }

    public String getRefused() {
        return refused;
    }

    /**
     * Set Refused flag
     * "": not refused, it is default
     * "D": INDICATES ALL BUSINESS IS TO BE DECLINED.
     * "R": INDICATES REFER ALL BUSINESS TO THE APPROPRIATE SUPERVISOR
     *
     * @param refused
     */
    public void setRefused(String refused) {
        this.refused = refused;
    }

    public String getPhone1Type() {
        return phone1Type;
    }

    public void setPhone1Type(String phone1Type) {
        this.phone1Type = phone1Type.trim();
    }

    public String getPhone1Area() {
        return phone1Area;
    }

    public void setPhone1Area(String phone1Area) {
        this.phone1Area = phone1Area.trim();
    }

    public String getPhone1Number() {
        return phone1Number;
    }

    public void setPhone1Number(String phone1Number) {
        this.phone1Number = phone1Number.trim();
    }

    /**
     * Set phone 1
     *
     * @param type
     * @param area
     * @param number
     */
    public void setPhone1(String type, String area, String number) {
        setPhone1Type(type);
        setPhone1Area(area);
        setPhone1Number(number);
    }

    public String getPhone2Type() {
        return phone2Type;
    }

    public void setPhone2Type(String phone2Type) {
        this.phone2Type = phone2Type.trim();
    }

    public String getPhone2Area() {
        return phone2Area;
    }

    public void setPhone2Area(String phone2Area) {
        this.phone2Area = phone2Area.trim();
    }

    public String getPhone2Number() {
        return phone2Number;
    }

    public void setPhone2Number(String phone2Number) {
        this.phone2Number = phone2Number.trim();
    }

    /**
     * Set phone 2
     *
     * @param type
     * @param area
     * @param number
     */
    public void setPhone2(String type, String area, String number) {
        setPhone2Type(type);
        setPhone2Area(area);
        setPhone2Number(number);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email.trim();
    }


    /**
     * Get staff flag with Web format, like "IAG VICTORIA"
     *
     * @return
     */
    public String getWebStaff() {
        String value = "";
        for (Entry<String, String> entry : staffMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(this.staff) || entry.getKey().equalsIgnoreCase(this.staff)) {
                value = entry.getValue();
                break;
            }

        }

        return value;
    }


    /**
     * Get staff flag for HUON flag, like "V"
     *
     * @return
     */
    public String getHuonStaff() {
        String key = "";
        for (Entry<String, String> entry : staffMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(this.staff) || entry.getKey().equalsIgnoreCase(this.staff)) {
                key = entry.getKey();
                break;
            }

        }

        return key;
    }


    /**
     * Staff flags:
     * <p>
     * 01 A         25 YEARS
     * 02 B         TPD
     * 03 H         HSBC STAFF
     * 04 L         LONG TERM STAFF (SGIO/SGIC ONLY)
     * 05 M         NRMA MOTORING AND SERVICES STAFF
     * 06 N         NO
     * 07 R         RACV STAFF
     * 08 T         LEAVE IAG DUE TO A TOTAL AND PERMANENT DISABILITY
     * 09 V         IAG VICTORIA
     * 10 Y         YES
     *
     * @param staff
     */
    public void setStaff(String staff) {
        this.staff = staff.trim();
    }


    /**
     * Generate a random name.
     *
     * @param length the length of the name.
     * @return
     */
    public String getRandomName(int length) {
        Random random = new Random(System.nanoTime());
        char[] letters = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(letters[random.nextInt(letters.length)]);
        }

        return sb.toString();
    }


    public String getRandomNumber(int length) {
        Random random = new Random(System.nanoTime());
        char[] letters = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(letters[random.nextInt(letters.length)]);
        }

        return sb.toString();
    }

    /**
     * To check whether 2 customers are the same customer by:
     * Individual: given name, surname, date of birth, gender.
     * Company: company name, suburb, postcode, state
     *
     * @param customer2
     * @return
     */
    public boolean equals(Customer customer2) {
        if (!this.clientType.equalsIgnoreCase(customer2.clientType))
            return false;

        if (this.clientType.equalsIgnoreCase(Customer.INDIVIDUAL)) {
            if (!this.givenName.equalsIgnoreCase(customer2.getGivenName()))
                return false;
            if (!this.surname.equalsIgnoreCase(customer2.getSurname()))
                return false;
            if (!this.gender.substring(0, 1).equalsIgnoreCase(customer2.getGender().substring(0, 1)))
                return false;

            Calendar me = Calendar.getInstance();
            me.setTime(this.dob);
            Calendar him = Calendar.getInstance();
            him.setTime(customer2.getDob());

            if (me.get(Calendar.YEAR) != him.get(Calendar.YEAR))
                return false;

            if (me.get(Calendar.MONTH) != him.get(Calendar.MONTH))
                return false;

            if (me.get(Calendar.DAY_OF_MONTH) != him.get(Calendar.DAY_OF_MONTH))
                return false;

        } else {
            if (!this.companyName.equalsIgnoreCase(customer2.getCompanyName()))
                return false;

            Address myAddress = this.address;
            Address hisAddress = customer2.getAddress();
            if (!myAddress.getState().equalsIgnoreCase(hisAddress.getState()))
                return false;
            if (!myAddress.getPostcode().equalsIgnoreCase(hisAddress.getPostcode()))
                return false;
            if (!myAddress.getSuburb().equalsIgnoreCase(hisAddress.getSuburb()))
                return false;
        }

        return true;
    }


    /**
     * Check whether it is the same individual customer
     *
     * @param customer
     * @return
     */
    public boolean isSameIndividual(Customer customer) {
        if (customer.getClientType().equalsIgnoreCase(COMPANY))
            return false;

        if (!this.givenName.equalsIgnoreCase(customer.givenName))
            return false;

        if (!this.surname.equalsIgnoreCase(customer.surname))
            return false;


        if (!this.getDobString().equalsIgnoreCase(customer.getDobString()))
            return false;

        if (!this.getGender().equalsIgnoreCase(customer.getGender()))
            return false;

        return true;
    }

    public void copy(Customer customer) throws IllegalArgumentException, IllegalAccessException {
        Class<?> thisClass = this.getClass();
        String thisName = Customer.class.getName();
        while (!thisClass.getName().equalsIgnoreCase(thisName)) {
            thisClass = thisClass.getSuperclass();
        }
        Class<?> thatClass = customer.getClass();
        while (!thatClass.getName().equalsIgnoreCase(thisName)) {
            thatClass = thatClass.getSuperclass();
        }
        Field[] thisFields = thisClass.getDeclaredFields();
        Field[] thatFields = thatClass.getDeclaredFields();
        for (int i = 0; i < thisFields.length; i++) {
            if (Modifier.isStatic(thisFields[i].getModifiers()))
                continue;
            thisFields[i].setAccessible(true);
            thatFields[i].setAccessible(true);
            thisFields[i].set(this, thatFields[i].get(customer));
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");

        Class<?> myClass = this.getClass();
        try {
            Field[] fields = myClass.getDeclaredFields();
            for (Field field : fields) {
                int modifier = field.getModifiers();
                if (Modifier.isStatic(modifier))
                    continue;
                sb.append(field.getName());
                sb.append("=");
                if (field.getType().getName().endsWith("Date")) {
                    Date date = (Date) field.get(this);
                    if (date != null) {
                        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                        sb.append(formatter.format(date));
                    } else {
                        sb.append("");
                    }
                } else {
                    sb.append(field.get(this));
                }
                sb.append(";");
            }
        } catch (IllegalAccessException iae) {

        }
        sb.replace(sb.length() - 1, sb.length(), "]");
        return sb.toString();
    }

    private void initStaffMap() {
//		private LinkedHashMap<String, String> staffMap = null;
        if (staffMap == null)
            staffMap = new LinkedHashMap<String, String>();
		
		/*staffMap.put("A","25 YEARS");
		staffMap.put("B","TPD");
		staffMap.put("H","HSBC STAFF");
		staffMap.put("L","LONG TERM STAFF (SGIO/SGIC ONLY)");
		staffMap.put("M","NRMA MOTORING AND SERVICES STAFF");
		staffMap.put("N","NO");
		staffMap.put("R","RACV STAFF");
		staffMap.put("T","LEAVE IAG DUE TO A TOTAL AND PERMANENT DISABILITY");
		staffMap.put("V","IAG VICTORIA");
		staffMap.put("Y","YES");*/

        staffMap.put("A", "IAG staff with over 25 year service");
        staffMap.put("B", "Total or Permanent Disability");
        staffMap.put("H", "HSBC Staff");
        staffMap.put("L", "SGIO/SGIC Long Term staff");
        staffMap.put("M", "NRMA Motoring and Services staff");
        staffMap.put("N", "Non Staff");
        staffMap.put("R", "RACV Staff");
        staffMap.put("T", "Leave IAG due to total disability");
        staffMap.put("V", "IAG Staff Victoria");
        staffMap.put("Y", "IAG Staff");
        staffMap.put("Z", "IAG NZ Staff");
    }

    public String getcompanyType() {
        if (companyType == null)
            companyType = new LinkedHashMap<String, String>();

        companyType.put("CHARORG", "Charitable Org");
        companyType.put("CLUB", "Club / Association");
        companyType.put("DR", "Doctor");
        companyType.put("GOV", "Government Dept");
        companyType.put("INC", "Incorporated");
        companyType.put("LTD", "Limited");
        companyType.put("PTR", "Partnership");
        companyType.put("PTYLTD", "PTY LTD");
        companyType.put("RELORG", "Religious Org	");
        companyType.put("ST", "Sole Trader");
        companyType.put("TR", "Trustee");
        companyType.put("Unknown", "Unknown");

        List<String> list = new ArrayList<String>(companyType.keySet());
        this.organizationtype = list.get(new Random().nextInt(companyType.size()));
        return organizationtype;
    }


    private String role = "";


    /**
     * Generate a random name.
     */

    public void setDefault() {

        role = getRandomName(2);

    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


}

class CustomerRole {
    //Chetan Added code for role

    public CustomerRole() {

    }

    public CustomerRole(List<DataRow> fieldList) throws ParseException, InvalidDataException {
        try {
            for (DataRow field : fieldList) {
                if (field.getField().equalsIgnoreCase("ROLE")) {

                    //	role = field.getValue();
                }

            }
        } catch (Exception e) {
        }
    }
}
