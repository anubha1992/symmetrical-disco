package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PhoneNumber implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("area_code")
    private String areaCode ;
    @JsonProperty("country_code")
    private String countryCode ;
    @JsonProperty("effective_from")
    private String effectiveFrom ;
    @JsonProperty("effective_to")
    private String effectiveTo ;
    @JsonProperty("id")
    private String id ;
    @JsonProperty("number")
    private String number ;
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("temp_id")
    private String tempId ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "The area code of respective phone number.",
        example = "03",
        required = false
    )
    public String getAreaCode() {
       return areaCode;
    }
 
    @ApiModelProperty(
        value = "Country code of respective phone number. Short description from Ref Data [Ref Data: phone_country_codes]",
        example = "+61",
        required = false
    )
    public String getCountryCode() {
       return countryCode;
    }
 
    @ApiModelProperty(
        value = "Effective from date",
        example = "2019-12-01",
        required = false
    )
    public String getEffectiveFrom() {
       return effectiveFrom;
    }
 
    @ApiModelProperty(
        value = "Effective to date",
        example = "2020-12-01",
        required = false
    )
    public String getEffectiveTo() {
       return effectiveTo;
    }
 
    @ApiModelProperty(
        value = "The phone identifier",
        required = false
    )
    public String getId() {
       return id;
    }
 
    @ApiModelProperty(
        value = "The phone number",
        example = "0400123456",
        required = false
    )
    public String getNumber() {
       return number;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "pc:581911",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000111",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 
    @ApiModelProperty(
        value = "The phone usage type. [Ref Data: phone_types]",
        example = "HOME",
        required = false
    )
    public String getType() {
       return type;
    }
 

}