package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains details for the policy")
public class PolicyDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("payments")
    private PaymentDetailsResponse payments = new PaymentDetailsResponse();
    @JsonProperty("policy_dates")
    private PolicyDates policyDates = new PolicyDates();
    @JsonProperty("policy_history")
    private PolicyHistory policyHistory = new PolicyHistory();
    @JsonProperty("policy_number")
    private String policyNumber ;
    @JsonProperty("status")
    private String status ;

  
    @ApiModelProperty(
        value = "Payment details of the policy",
        required = false
    )
    public PaymentDetailsResponse getPayments() {
       return payments;
    }
 
    @ApiModelProperty(
        value = "Policy dates",
        required = false
    )
    public PolicyDates getPolicyDates() {
       return policyDates;
    }
 
    @ApiModelProperty(
        value = "The policy history details",
        required = false
    )
    public PolicyHistory getPolicyHistory() {
       return policyHistory;
    }
 
    @ApiModelProperty(
        value = "Quote number or Policy number",
        example = "QTE1234567",
        required = false
    )
    public String getPolicyNumber() {
       return policyNumber;
    }
 
    @ApiModelProperty(
        value = "Status of the business entity. [Ref Data: quote_status, policy_status]",
        example = "DRAFT",
        required = false
    )
    public String getStatus() {
       return status;
    }
 

}