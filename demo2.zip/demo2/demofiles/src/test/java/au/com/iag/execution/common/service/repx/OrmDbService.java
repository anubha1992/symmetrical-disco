package au.com.iag.execution.common.service.repx;

import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.artifacts.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.glados.model.artifacts.DatabaseConnectionArtifact.*;
import java.sql.*;
import java.util.*;

import static junit.framework.TestCase.fail;

@Service
public class OrmDbService {

    @Autowired
    private DatabaseClient databaseClient;

    @Value("${orm.datasource.username}")
    private String username;
    @Value("${orm.datasource.password}")
    private String password;
    @Value("${orm.datasource.url}")
    private String connectionString;
    @Value("${orm.datasource.driver-class-name}")
    private String driverName;

    private DatabaseConnectionArtifact buildDatabaseConnectionDetails() {
        return builder().connectionString(connectionString)
                .jdbcClassName(driverName)
                .username(username)
                .password(password)
                .build();
    }

    public List<Map<String, Object>> getRequestForQuoteDetailsForClaim(String vehicleRego, String claimNo) throws SQLException, ClassNotFoundException {

        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String sqlQuery = "select * from ORM.TB_REQUESTFORQUOTE tb_requestforquote " +
                "where tb_requestforquote.NUM_CLAIMVEHICLE in ( " +
                "select tb_claimvehicle.NUM_CLAIMVEHICLE from ORM.TB_CLAIMVEHICLE tb_claimvehicle " +
                "where tb_claimvehicle.NUM_CLAIM in ( " +
                "select tb_claim.NUM_CLAIM from ORM.TB_CLAIM tb_claim " +
                "where tb_claim.CDE_CLAIM = '" + claimNo + "' " +
                ") " +
                "and tb_claimvehicle.TXT_VEHICLEREGISTRATION = '" + vehicleRego + "' " +
                ") " +
                "Order by tb_requestforquote.NUM_REINSTATEMENTSEQ Desc ";
        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, sqlQuery);

        if (!(resultList.size() > 0)) {
            fail("---------Can't find a booking inspection that is not reallocated ------------");
        }

        return resultList;
    }
}
