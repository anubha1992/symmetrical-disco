package au.com.iag.execution.claimdetailsapi.model.business;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ClaimSearchRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<Policy> policies;
    private String rangeEndDate;
    private String rangeStartDate;

}
