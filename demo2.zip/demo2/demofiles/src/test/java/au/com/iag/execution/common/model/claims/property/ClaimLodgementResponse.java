package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ClaimLodgementResponse implements Serializable {
    private static final long serialVersionUID = 5963576926641039756L;

    private String claimIdentifier;
    private String claimDecisionStatus;
    private String coveragePendingReason;
    private ApplicableExcess applicableExcess;
    private List<Incident> incidents;
    private ClaimManager claimManager;

    public String getClaimIdentifier() {
        return claimIdentifier;
    }

    public void setClaimIdentifier(String claimIdentifier) {
        this.claimIdentifier = claimIdentifier;
    }

    public String getClaimDecisionStatus() {
        return claimDecisionStatus;
    }

    public void setClaimDecisionStatus(String claimDecisionStatus) {
        this.claimDecisionStatus = claimDecisionStatus;
    }

    public String getCoveragePendingReason() {
        return coveragePendingReason;
    }

    public void setCoveragePendingReason(String coveragePendingReason) {
        this.coveragePendingReason = coveragePendingReason;
    }

    public ApplicableExcess getApplicableExcess() {
        return applicableExcess;
    }

    public void setApplicableExcess(ApplicableExcess applicableExcess) {
        this.applicableExcess = applicableExcess;
    }

    public ClaimManager getClaimManager() {
        return claimManager;
    }

    public void setClaimManager(ClaimManager claimManager) {
        this.claimManager = claimManager;
    }

    public List<Incident> getIncidents() {
        return incidents;
    }

    public void setIncidents(List<Incident> incidents) {
        this.incidents = incidents;
    }
}
