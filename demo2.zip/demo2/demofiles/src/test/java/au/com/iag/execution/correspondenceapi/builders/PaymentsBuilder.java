package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.execution.correspondenceapi.model.business.PremiumDetails;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentsBuilder {

    @Autowired private MiscDataBuilder miscDataBuilder;

    public PremiumDetails getPremiumDetails(PolicyCorrespondence policyCorrespondence){
        PremiumDetails premiumDetails;
        try {
            premiumDetails = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getPayments().getBillingPlanOptions().get(0).getAggregatePremiumDetails());
            getPremiumDetails(premiumDetails.getBasePremium(), false, 0);
        }
        catch (NullPointerException npe){
            premiumDetails = getPremiumDetails(null, false, 0);
        }
        return premiumDetails;
    }

    public PremiumDetails getPremiumDetails(PolicyCorrespondence policyCorrespondence, double adjustmentPercentage){
        PremiumDetails premiumDetails;
        try {
            premiumDetails = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getPayments().getBillingPlanOptions().get(0).getAggregatePremiumDetails());
            getPremiumDetails(premiumDetails.getBasePremium(), true, adjustmentPercentage);
        }
        catch (NullPointerException npe){
            premiumDetails = getPremiumDetails(null, false, 0);
        }
        return premiumDetails;
    }

    public PremiumDetails getPremiumDetails() {
        return getPremiumDetails(null, false, 0);
    }

    private PremiumDetails getPremiumDetails(Double basePremiumIn, boolean adjust, double adjustmentPercentage) {
        double basePremium = basePremiumIn!=null?basePremiumIn.doubleValue():miscDataBuilder.formatDouble(miscDataBuilder.getDouble(750.30, 1500.65));
        double esl = miscDataBuilder.formatDouble(basePremium*(5.5/100));
        double gst = miscDataBuilder.formatDouble(basePremium*(5.5/100));
        double stampDuty = miscDataBuilder.formatDouble(basePremium*(2.1/100));
        double netAmount = miscDataBuilder.formatDouble(basePremium-(esl+gst+stampDuty));
        PremiumDetails premiumDetails = new PremiumDetails();
        premiumDetails.setBasePremium(basePremium-2);
        premiumDetails.setEsl(esl);
        premiumDetails.setTotalPremium(basePremium);
        premiumDetails.setGst(gst);
        premiumDetails.setTotalPremium(netAmount);
        premiumDetails.setStampDuty(stampDuty);
        return premiumDetails;
    }
}
