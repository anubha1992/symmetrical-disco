package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Party implements Serializable {
    private static final long serialVersionUID = 8064877838575592963L;

    private Boolean policyContact;
    private String partyType;
    private List<Contact> contactDetails = new ArrayList<>();
    private List<String> roles;
    private Boolean registeredForGst;
    private String additionalInformation;
    private String partyIdentifier;
    private String officialType;
    private String witnessStatementObtained;
    private String witnessPerspective;

    public Boolean getRegisteredForGst() {
        return registeredForGst;
    }

    public void setRegisteredForGst(Boolean registeredForGst) {
        this.registeredForGst = registeredForGst;
    }

    public Boolean isPolicyContact() {
        return policyContact;
    }

    public void setPolicyContact(Boolean policyContact) {
        this.policyContact = policyContact;
    }

    public String getPartyType() {
        return partyType;
    }

    public void setPartyType(String partyType) {
        this.partyType = partyType;
    }

    public List<Contact> getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(List<Contact> contactDetails) {
        this.contactDetails = contactDetails;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    public String getPartyIdentifier() {
        return partyIdentifier;
    }

    public void setPartyIdentifier(String partyIdentifier) {
        this.partyIdentifier = partyIdentifier;
    }

    public String getAdditionalInformation() {
        return additionalInformation;
    }

    public void setAdditionalInformation(String additionalInformation) {
        this.additionalInformation = additionalInformation;
    }


    public String getOfficialType() {
        return officialType;
    }

    public void setOfficialType(String officialType) {
        this.officialType = officialType;
    }

    public String getWitnessPerspective() {
        return witnessPerspective;
    }

    public void setWitnessPerspective(String witnessPerspective) {
        this.witnessPerspective = witnessPerspective;
    }

    public String getWitnessStatementObtained() {
        return witnessStatementObtained;
    }

    public void setWitnessStatementObtained(String witnessStatementObtained) {
        this.witnessStatementObtained = witnessStatementObtained;
    }

}