package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ExcessDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("base_excess")
    private Double baseExcess ;
    @JsonProperty("excesses")
    private java.util.List<Excess> excesses = new java.util.ArrayList<Excess>();
    @JsonProperty("total_excess")
    private Double totalExcess ;

  
    @ApiModelProperty(
        value = "Base excess for the vehicle asset",
        example = "500.0",
        required = false
    )
    public Double getBaseExcess() {
       return baseExcess;
    }
 
    @ApiModelProperty(
        value = "List of excesses",
        required = false
    )
    public java.util.List<Excess> getExcesses() {
       return excesses;
    }
 
    @ApiModelProperty(
        value = "Total excess amount",
        example = "1500.9",
        required = false
    )
    public Double getTotalExcess() {
       return totalExcess;
    }
 

}