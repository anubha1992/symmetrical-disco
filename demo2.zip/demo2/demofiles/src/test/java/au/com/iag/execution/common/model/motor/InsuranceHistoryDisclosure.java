package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class InsuranceHistoryDisclosure implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("asset_number")
    private String assetNumber ;
    @JsonProperty("asset_on_policy")
    private Boolean assetOnPolicy ;
    @JsonProperty("event_date")
    private String eventDate ;
    @JsonProperty("event_type")
    private String eventType ;
    @JsonProperty("party_id")
    private String partyId ;
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("temp_id")
    private String tempId ;

  
    @ApiModelProperty(
        value = "Asset Number",
        example = "12345",
        required = false
    )
    public String getAssetNumber() {
       return assetNumber;
    }
 
    @ApiModelProperty(
        value = "Asset on the policy indicator - used for address on policy or vehicle on policy",
        example = "true",
        required = false
    )
    public Boolean getAssetOnPolicy() {
       return assetOnPolicy;
    }
 
    @ApiModelProperty(
        value = "Event date.  Date format: yyyy",
        example = "2019",
        required = false
    )
    public String getEventDate() {
       return eventDate;
    }
 
    @ApiModelProperty(
        value = "Insurance event type [Ref Data: history_disclosure_event_type]",
        example = "INSURANCE_DECLINED",
        required = false
    )
    public String getEventType() {
       return eventType;
    }
 
    @ApiModelProperty(
        value = "Party identifier.",
        example = "12345567890",
        required = false
    )
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "pc:581944",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000444",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 

}