package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PaymentInstruments implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("bank_account_details")
    private BankAccountDetails bankAccountDetails = new BankAccountDetails();
    @JsonProperty("card_details")
    private CardDetails cardDetails = new CardDetails();
    @JsonProperty("pay_pal_details")
    private PayPalDetails payPalDetails = new PayPalDetails();

  
    @ApiModelProperty(
        value = "Bank account details.",
        required = false
    )
    public BankAccountDetails getBankAccountDetails() {
       return bankAccountDetails;
    }
 
    @ApiModelProperty(
        value = "Payment card details. Can be credit or debit card",
        required = false
    )
    public CardDetails getCardDetails() {
       return cardDetails;
    }
 
    @ApiModelProperty(
        value = "Pay pal details",
        required = false
    )
    public PayPalDetails getPayPalDetails() {
       return payPalDetails;
    }
 

}