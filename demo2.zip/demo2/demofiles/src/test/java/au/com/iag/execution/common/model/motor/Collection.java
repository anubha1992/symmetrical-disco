package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Optional. Link to the definition of referenced subsections.")
public class Collection implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("ask_if")
    private java.util.List<AskIf> askIf = new java.util.ArrayList<AskIf>();
    @JsonProperty("biz_constraints")
    private CollectionBizConstraints bizConstraints = new CollectionBizConstraints();
    @JsonProperty("name")
    private String name ;
    @JsonProperty("section_ref")
    private String sectionRef ;

  
    @ApiModelProperty(
        value = "Optional. Specifies the conditions under which the section should be shown/asked.",
        required = false
    )
    public java.util.List<AskIf> getAskIf() {
       return askIf;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public CollectionBizConstraints getBizConstraints() {
       return bizConstraints;
    }
 
    @ApiModelProperty(
        value = "The name of the collection as it appears in the data structure",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "The reference to the section&#x27;s &#x27;ref_name&#x27; that this is a collection of.",
        required = false
    )
    public String getSectionRef() {
       return sectionRef;
    }
 

}