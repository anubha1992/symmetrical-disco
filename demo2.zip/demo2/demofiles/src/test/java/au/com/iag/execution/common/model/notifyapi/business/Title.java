package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class Title implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("attribute")
    private java.util.List<Attribute> attribute;

  
    @ApiModelProperty(
        value = "",
        required = false
    )
    public java.util.List<Attribute> getAttribute() {
       return attribute;
    }
 

}