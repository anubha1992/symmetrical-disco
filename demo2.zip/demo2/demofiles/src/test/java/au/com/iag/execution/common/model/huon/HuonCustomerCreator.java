package au.com.iag.execution.common.model.huon;

import au.com.iag.execution.common.exception.*;
import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.*;
import com.jagacy.util.*;
import java.text.*;
import java.util.*;

/**
 * A class to create or get client information from HUON
 */
public class HuonCustomerCreator extends HuonCreator {
    boolean isDebug = false;

    /**
     * Constructor to create a new HuonSession
     */
    public HuonCustomerCreator(String env, String testcaseDir) throws HuonException, JagacyException {
        super(env, testcaseDir);
    }

    /**
     * Constructor to start from an existing HuonSession
     *
     * @param huon
     */
    public HuonCustomerCreator(HuonSession huon, String testcaseDir) throws JagacyException {
        super(huon, testcaseDir);
    }

    /**
     * Search an existing client from HUON.
     * The SearchIntermediaryDocuments criteria:
     * Individual: Given name + Surname + Gender + DOB
     * Company: company name + Suburb + postcode
     *
     * @param customer the customer object which has client information to SearchIntermediaryDocuments.
     * @return client number, which is also set to customer object. null if not found.
     */
    public String searchClient(Customer customer) throws JagacyException {
        String clientNumber = "";

//		System.out.println("[INFO]Search an existing client from HUON: " + customer );
        if (customer.getClientType().equalsIgnoreCase(Customer.INDIVIDUAL)) {
            clientNumber = searchIndividual(customer);
        } else {
            clientNumber = searchCompany(customer);
        }

        if (!clientNumber.isEmpty()) {
            customer.setClientNumber(clientNumber);
//			System.out.println("[INFO]Search an existing client from HUON done: " + customer);
        } else {
//			System.out.println("[WARNING]Search an existing client from HUON failed: couldn't find the client");
        }
        return clientNumber;
    }

    private String searchIndividual(Customer customer) throws JagacyException {
        String clientNumber = "";

        huon.gotoScreen("HY000");
        huon.input(3, 13, "1");
        huon.eraseField(5, 13);
        huon.input(7, 18, "N");
        String surname = customer.getSurname().trim().toUpperCase();
        if (surname.length() > 20) {
            surname = surname.substring(0, 20);
        }
        huon.input(7, 20, surname);
        huon.input(7, 43, "D");
        huon.input(7, 45, customer.getDobString());
        huon.enter();

        huon.waitForScreen("HY011");
//		boolean isFound = false;
        boolean nextPage = true;
        List<String> candidates = new ArrayList<>();
        while (nextPage) {
            for (int iRow = 9; iRow < 22; iRow = iRow + 2) {
                String number = huon.readFromField(iRow, 3, 11).trim();
                if (number.isEmpty()) {
                    nextPage = false;
                    break;
                }

                String fullName = huon.readFromField(iRow, 21, 71).trim();
                String[] names = fullName.split(" ");
                String huonGivenName = names[0];
                if (huonGivenName.equalsIgnoreCase(customer.getGivenName().trim())) {
                    candidates.add(number);
                }
//				String dob = huon.readFromField(iRow+1, 66, 75).trim();
//				if (dob.equals(customer.getDobString())) {
//					candidates.add(number);
//				}
            }

            //Next page
            if (huon.extractErrorCode().equals("108")) {
                break;
            }
            huon.pressKey(Key.PF8);

        }

        huon.pressKey(Key.PF11);

        //Check all the candidates with gender
        for (String candidate : candidates) {
            huon.gotoScreen("HY012");
            huon.eraseField(2, 10);
            huon.input(2, 10, candidate);
            huon.enter();
            huon.waitForScreen("HY012");
            String huonSurname = huon.readFromField(5, 9, 48).trim();
            String gender = huon.readFromField(9, 27, 27);

            if (customer.getGender().toUpperCase().startsWith(gender)
                    && huonSurname.equalsIgnoreCase(customer.getSurname().trim())) {
                //found
//				isFound = true;
                clientNumber = candidate;
                break;
            }
        }

        return clientNumber;

    }

    private String searchCompany(Customer customer) throws JagacyException {
        String clientNumber = "";


        huon.gotoScreen("HY000");
        huon.input(3, 13, "1");
        huon.eraseField(5, 13);
        huon.input(7, 18, "N");
        String companyName = customer.getCompanyName().trim();
        if (companyName.length() > 20) {
            companyName = companyName.substring(0, 20);
        }
        huon.input(7, 20, companyName);
        huon.input(7, 43, "M");
        huon.input(7, 45, customer.getAddress().getPostcode());
        huon.enter();

        huon.waitForScreen("HY011");
        boolean isFound = false;
        boolean nextPage = true;
        while (nextPage && !isFound) {
            for (int iRow = 9; iRow < 22; iRow = iRow + 2) {
                String number = huon.readFromField(iRow, 3, 11).trim();
                if (number.isEmpty()) {
                    nextPage = false;
                    break;
                }
                String name = huon.readFromField(iRow, 18, 71).trim();
                if (!name.equalsIgnoreCase(customer.getCompanyName()))
                    continue;

                String address = huon.readFromField(iRow + 1, 6, 75).trim();
                String[] addressArray = address.split(" ");
                int length = addressArray.length;

                StringBuilder sb = new StringBuilder();
                String suburb1 = customer.getAddress().getSuburb().trim();
                String[] suburbArray1 = suburb1.split(" ");
                for (int i = suburbArray1.length; i > 0; i--) {
                    if (sb.length() > 0)
                        sb.append(" ");
                    sb.append(addressArray[length - 2 - i]);
                }

                String huonSuburb = sb.toString();

                if (huonSuburb.equalsIgnoreCase(suburb1)) {
                    clientNumber = number;
                    isFound = true;
                    nextPage = false;
                    break;
                }
            }

            if (isFound && !nextPage)
                break;

            //Next page
            if (huon.extractErrorCode().equals("108")) {
                break;
            }
            huon.pressKey(Key.PF8);

        }

        huon.pressKey(Key.PF11);

        return clientNumber;
    }

    /**
     * Get a customer's information by a client number.
     *
     * @param clientNumber
     * @return true if found, false if not
     * @throws JagacyException
     * @throws ParseException
     * @throws InvalidDataException
     */
    public boolean getByNumber(String clientNumber, Customer customer) throws JagacyException, ParseException, InvalidDataException {
        clientNumber = clientNumber.trim();

//		System.out.println("[INFO]Get an existing client from HUON from client number: " + clientNumber);

        //Try 3 times just because sometimes it cannot be found even the client is there
        for (int i = 0; i < 3; i++) {
            huon.gotoScreen("HY000");
            huon.input(3, 13, "7");
            huon.eraseField(5, 13);
            huon.input(5, 13, clientNumber.trim());
            huon.enter();

            //error
            String errorCode = huon.extractErrorCode();
            if (!errorCode.equals("4001")) {
                break;
            }
        }
        String errorCode = huon.extractErrorCode();
        if (errorCode.equals("4001")) { // 4001 - CLIENT NOT ON FILE
            // System.out.println("[INFO]Get an existing client from HUON from client number failed: 4001 - CLIENT NOT ON FILE");
            return false;
        }

        //3476 - CLIENT HAS RESTRICTED VIEWING
        if (errorCode.equals("3476")) {
            customer.setRestrict(true);
            return true;
        }

        customer.setClientNumber(clientNumber);

        String screen = huon.waitForScreens(new String[]{"HY012", "HY084"});
        String street;
        Address address = new Address("NSW");

        String phoneFlag = "";
        String detailFlag = "";

        if (screen.equalsIgnoreCase("HY012")) {// Individual
            customer.setClientType(Customer.INDIVIDUAL);

            customer.setSurname(huon.readFromField(5, 9, 49).trim());
            customer.setGivenName(huon.readFromField(6, 9, 23).trim());
            customer.setDob(huon.readFromField(9, 12, 21));
            customer.setGender(huon.readFromField(9, 27, 27));
            customer.setTitle(huon.readFromField(6, 43, 80).trim());

            //Staff
            customer.setStaff(huon.readFromField(10, 68, 68).trim());

            //Refused
            customer.setRefused(huon.readFromField(11, 79, 79).trim());

            //Phone number1
            String phone1Type = huon.readFromField(12, 6, 10).trim();
            if (!phone1Type.isEmpty())
                customer.setPhone1(phone1Type, huon.readFromField(13, 6, 18).trim(), huon.readFromField(13, 27, 38).trim());

            address.setIndicator(huon.readFromField(17, 9, 9).trim());
            address.setUnitNo(huon.readFromField(17, 14, 22).trim());
            address.setIndicator2(huon.readFromField(17, 30, 30).trim());
            address.setUnitNo2(huon.readFromField(17, 35, 43).trim());
            street = huon.readFromField(18, 9, 80).trim();

            address.setSuburb(huon.readFromField(19, 9, 43).trim());
            address.setStateByCode(huon.readFromField(19, 51, 52));
            address.setPostcode(huon.readFromField(19, 58, 61));

            phoneFlag = huon.readFromField(22, 27, 27).trim();
            detailFlag = huon.readFromField(22, 60, 60).trim();

        } else {    //Company
            customer.setClientType(Customer.COMPANY);
            customer.setCompanyName(huon.readFromField(5, 9, 49).trim());
            //Refused
            customer.setRefused(huon.readFromField(9, 77, 77).trim());
            //Phone number1
            String phone1Type = huon.readFromField(11, 6, 10).trim();
            if (!phone1Type.isEmpty())
                customer.setPhone1(phone1Type, huon.readFromField(12, 6, 18).trim(), huon.readFromField(12, 27, 38).trim());
            address.setIndicator(huon.readFromField(16, 9, 9).trim());
            address.setUnitNo(huon.readFromField(16, 14, 22).trim());
            address.setIndicator2(huon.readFromField(16, 30, 30).trim());
            address.setUnitNo2(huon.readFromField(16, 35, 43).trim());
            street = huon.readFromField(17, 9, 80).trim();
            address.setSuburb(huon.readFromField(18, 9, 43).trim());
            address.setStateByCode(huon.readFromField(18, 51, 52));
            address.setPostcode(huon.readFromField(18, 58, 61));
            phoneFlag = huon.readFromField(21, 26, 26).trim();
            detailFlag = huon.readFromField(21, 59, 59).trim();
        }

        //Street
        address.extractStreet(street);
//		int index = street.indexOf(" ");
//		address.setStreetNo(street.substring(0, index).trim());
//		street = street.substring(index + 1).trim();
//		index = street.lastIndexOf(" ");
//		String streetType = street.substring(index + 1).trim();
//		address.setStreetType(streetType, true);
//		street = street.substring(0, index).trim();
//		address.setStreetName(street);

        //more phone number and/or email
        if (phoneFlag.equalsIgnoreCase("Y") || detailFlag.equalsIgnoreCase("Y")) {
            huon.enter();

            //YCX - HYO130          CLIENT LIST - ADDRESSES - VIEW
            screen = huon.waitForScreens(new String[]{"HY130", "HY001", "HY020"});
            if (screen.equalsIgnoreCase("HY130")) {
                huon.enter();
                screen = huon.waitForScreens(new String[]{"HY001", "HY020"});
            }

            if (screen.equalsIgnoreCase("HY001")) {
                //Phone 2
                String phone2Type = huon.readFromField(8, 6, 11).trim();
                if (!phone2Type.isEmpty()) {
                    customer.setPhone1(phone2Type, huon.readFromField(8, 13, 22).trim(), huon.readFromField(8, 25, 36).trim());
                }
                huon.enter();
                screen = huon.waitForScreens(new String[]{"HY020", "HY011", "HY000"});
            }

            //email
            if (screen.equalsIgnoreCase("HY020")) {
                customer.setCompanyAbn(huon.readFromField(16, 40, 55).trim());
                customer.setEmail(huon.readFromField(17, 16, 78).trim());
                huon.enter();
            }
        }

        customer.setAddress(address);

//		System.out.println("[INFO]Get an existing client from HUON from client number done: " + customer);
        return true;
    }

    /**
     * Create a new client from HUON.
     *
     * @param customer the client to create.
     * @return client number, and customer object is also updated with client number.
     * @throws JagacyException
     */
    public String createClient(Customer customer) throws JagacyException {
        String clientNumber = "";

//		System.out.println("[INFO]Create a client from HUON: " + customer);

        if (customer.getClientType().equalsIgnoreCase(Customer.INDIVIDUAL)) {
            clientNumber = createIndividual(customer);
        } else {
            clientNumber = createCompany(customer);
        }

//		System.out.println("[INFO]Create a client from HUON done: " + customer);

        return clientNumber;
    }

    private String createIndividual(Customer customer) throws JagacyException {
        String clientNumber = "";

        huon.gotoScreen("HY000");
        huon.input(3, 13, "9");
        huon.eraseField(5, 13);
        huon.input(7, 18, "N");        //Surname option
        String surname = customer.getSurname().trim();
        if (surname.length() > 20) {
            surname = surname.substring(0, 20);
        }
        huon.input(7, 20, surname);
        huon.input(7, 43, "D");        //DOB
        huon.input(7, 45, customer.getDobString());
        huon.enter();

        //Error handling

        huon.waitForScreen("HY011");
        huon.input(5, 18, "N");
        huon.enter();

        huon.waitForScreen("HY016");

        //Get client number here in order to bypass VE issue
        clientNumber = huon.readFromField(2, 10, 19).trim();

        //Bypass issue
        if (huon.readFromField(4, 9, 10).trim().isEmpty())
            huon.input(4, 9, "LN");
        if (huon.readFromField(15, 9, 10).trim().isEmpty())
            huon.input(15, 9, "MA");

        huon.input(5, 9, customer.getSurname().trim());
        huon.input(6, 9, customer.getGivenName().trim());
        huon.input(6, 30, customer.getGivenName().substring(0, 1));
        huon.input(6, 43, customer.getTitle().trim());
        huon.input(9, 12, customer.getDobString().trim());
        huon.input(9, 27, customer.getGender().substring(0, 1));
        //staff
        if (!customer.getHuonStaff().isEmpty())
            huon.input(10, 67, customer.getHuonStaff().substring(0, 1));

        //Restrict and Refused
        if (customer.isRestrict())
            huon.input(11, 65, "Y");
        if (!customer.getRefused().isEmpty())
            huon.input(11, 79, customer.getRefused());

        //Phone1
        if (!customer.getPhone1Type().isEmpty()) {
            huon.input(12, 9, customer.getPhone1Type());
            huon.input(13, 9, customer.getPhone1Area());
            huon.input(13, 28, customer.getPhone1Number());
        }
        //Indicator
        if (!customer.getAddress().getHuonIndicator().isEmpty())
            huon.input(17, 9, customer.getAddress().getHuonIndicator().trim());
        if (!customer.getAddress().getUnitNo().isEmpty())
            huon.input(17, 14, customer.getAddress().getUnitNo().trim());
        if (!customer.getAddress().getHuonIndicator2().isEmpty())
            huon.input(17, 30, customer.getAddress().getHuonIndicator2().trim());
        if (!customer.getAddress().getUnitNo2().isEmpty())
            huon.input(17, 35, customer.getAddress().getUnitNo2().trim());

        huon.input(18, 9, customer.getAddress().getStreetNo().trim());
        huon.input(18, 20, customer.getAddress().getStreetName().trim());
        huon.input(18, 61, customer.getAddress().getHuonStreetType().trim());
        if (!customer.getAddress().getHuonStreetDirection().isEmpty())
            huon.input(18, 66, customer.getAddress().getHuonStreetDirection().trim());
        huon.input(19, 9, customer.getAddress().getSuburb().trim());
        huon.input(19, 51, customer.getAddress().getStateCode().trim());
        huon.input(19, 58, customer.getAddress().getPostcode().trim());
        //Debug
        if (isDebug) {
            String number = huon.readFromField(2, 10, 19).trim();
            System.out.println("[DEBUG] HY016 before ENTER:" + number);
            reporter.captureScreenshot("DEBUG");
        }

        /*
         * If more than 1 phone number, and/or email
         */
        if (!customer.getPhone2Type().isEmpty())
            huon.input(22, 35, "Y");
        if (!customer.getEmail().isEmpty())
            huon.input(22, 68, "Y");

        huon.enter();

        if (isDebug) {
            //Debug
            System.out.println("[DEBUG] HY016 after ENTER:");
            reporter.captureScreenshot("DEBUG");
        }

        //Check error
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "Failed to create client -- " + customer
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
//			System.err.println("[ERROR]Failed to create client -- " + customer + " -- and Error is [" + errorHandler.getErrorMessage() + "]");
//			return "";
        }

        String screen = huon.waitForScreens(new String[]{"HZ700", "HY011", "HY004", "HY018"});
        if (screen.equalsIgnoreCase("HZ700")) {
			/*if (!huon.readFromField(9, 6, 15).trim().isEmpty()) {
				huon.input(9, 2, "S");
			} else {			
				huon.input(6, 79, "Y");
			}*/
            huon.input(6, 79, "Y");
            huon.enter();
            huon.waitForScreen("HY016");

            if (isDebug) {
                // Debug
                System.out.println("[DEBUG] HZ700 after ENTER:");
                reporter.captureScreenshot("DEBUG");
            }

            huon.enter();

            if (isDebug) {
                // Debug
                System.out.println("[DEBUG] HZ700 after ENTER:");
                reporter.captureScreenshot("DEBUG");
            }

            //Check error
            if (!errorHandler.perform()) {
                throw new JagacyException(JagacyException.MODEL_ERROR,
                        "Failed to create client -- " + customer
                                + " -- and Error is ["
                                + errorHandler.getErrorMessage() + "]");
            }
            huon.waitForScreens(new String[]{"HY011", "HY004", "HY018"});
        }

        screen = huon.readScreenName();
        //More phone number
        if (screen.equalsIgnoreCase("HYO004")) {
            //Phone2
            if (!customer.getPhone2Type().isEmpty()) {
                huon.input(6, 7, customer.getPhone2Type());
                huon.input(7, 7, customer.getPhone2Area());
                huon.input(7, 27, customer.getPhone2Number());
            }
            huon.enter();
        }

        screen = huon.waitForScreens(new String[]{"HY011", "HY018"});
        //email
        if (screen.equalsIgnoreCase("HY018")) {
            // email
            if (!customer.getEmail().isEmpty()) {
                huon.input(22, 18, customer.getEmail());
            }
            huon.enter();
        }

        huon.waitForScreen("HY011");

//		clientNumber = huon.readFromField(9, 3, 11).trim();

//		//to delete
//		String full = huon.readFromField(10, 6, 50).trim();
//		customer.getAddress().fullAddress = full;

        if (isDebug) {
            // Debug
            System.out.println("[DEBUG] Get client number from screen --- "
                    + screen + " and client number is: " + clientNumber);
            reporter.captureScreenshot("DEBUG");
        }

        //Sometimes on virtual machine, it is blank, so we do it twice
        if (clientNumber.isEmpty())
            clientNumber = huon.readFromField(9, 3, 11).trim();

        if (isDebug) {
            System.out.println("[DEBUG] Get client number from screen --- "
                    + screen + " and client number is: " + clientNumber);
            reporter.captureScreenshot("DEBUG");
        }

        huon.input(4, 18, "E");
        huon.enter();

        if (customer.isRefusedCancellations()) {

            try {
                creatRefusalCancellations(customer);
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }
        customer.setClientNumber(clientNumber);

        return clientNumber;
    }

    private String createCompany(Customer customer) throws JagacyException {
        String clientNumber = "";

        huon.gotoScreen("HY000");
        huon.input(3, 13, "9");
        huon.eraseField(5, 13);
        huon.input(7, 18, "N"); // Surname option
        String companyName = customer.getCompanyName().trim();
        if (companyName.length() > 20) {
            companyName = companyName.substring(0, 20);
        }
        huon.input(7, 20, companyName);
        huon.input(7, 43, "M"); // DOB
        huon.input(7, 45, customer.getAddress().getPostcode());
        huon.enter();

        // Check error
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "Failed to create client -- " + customer
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
        }

        huon.waitForScreen("HY011");
        huon.input(5, 42, "N");
        huon.enter();

        huon.waitForScreen("HY082");

        //Get client number here in order to bypass VE issue
        clientNumber = huon.readFromField(2, 10, 19).trim();

        //Bypass issue
        if (huon.readFromField(4, 9, 10).trim().isEmpty())
            huon.input(4, 9, "LN");
        if (huon.readFromField(14, 9, 10).trim().isEmpty())
            huon.input(14, 9, "MA");

        huon.input(5, 9, customer.getCompanyName());

        //Restrict and Refused
        if (customer.isRestrict())
            huon.input(10, 43, "Y");
        if (!customer.getRefused().isEmpty())
            huon.input(10, 70, customer.getRefused());

        // Phone1
        if (!customer.getPhone1Type().isEmpty()) {
            huon.input(11, 9, customer.getPhone1Type());
            huon.input(12, 9, customer.getPhone1Area());
            huon.input(12, 28, customer.getPhone1Number());
        }

        //Indicator
        if (!customer.getAddress().getHuonIndicator().isEmpty())
            huon.input(16, 9, customer.getAddress().getHuonIndicator());
        if (!customer.getAddress().getUnitNo().isEmpty())
            huon.input(16, 14, customer.getAddress().getUnitNo());
        if (!customer.getAddress().getHuonIndicator2().isEmpty())
            huon.input(16, 30, customer.getAddress().getHuonIndicator2());
        if (!customer.getAddress().getUnitNo2().isEmpty())
            huon.input(16, 35, customer.getAddress().getUnitNo2());
        huon.input(17, 9, customer.getAddress().getStreetNo());
        huon.input(17, 20, customer.getAddress().getStreetName());
        huon.input(17, 61, customer.getAddress().getHuonStreetType());
        if (!customer.getAddress().getHuonStreetDirection().isEmpty())
            huon.input(17, 66, customer.getAddress().getHuonStreetDirection());
        huon.input(18, 9, customer.getAddress().getSuburb());
        huon.input(18, 51, customer.getAddress().getStateCode());
        huon.input(18, 58, customer.getAddress().getPostcode());

        /*
         * If more than 1 phone number, and/or email
         */
        if (!customer.getPhone2Type().isEmpty())
            huon.input(21, 26, "Y");
        if (!customer.getEmail().isEmpty() || !customer.getCompanyAbn().isEmpty())
            huon.input(21, 59, "Y");

        huon.enter();

        // Check error
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "Failed to create client -- " + customer
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
            // System.err.println("[ERROR]Failed to create client -- " +
            // customer + " -- and Error is [" + errorHandler.getErrorMessage()
            // + "]");
            // return "";
        }

        String screen = huon.waitForScreens(new String[]{"HZ700", "HY011", "HY004", "HY018"});
        if (screen.equalsIgnoreCase("HZ700")) {
			/*if (!huon.readFromField(9, 6, 15).trim().isEmpty()) {
				huon.input(9, 2, "S");
			} else {			
				huon.input(6, 79, "Y");
			}*/
            huon.input(6, 79, "Y");
            huon.enter();
            huon.waitForScreen("HY082");
            huon.enter();
            // Check error
            if (!errorHandler.perform()) {
                throw new JagacyException(JagacyException.MODEL_ERROR,
                        "Failed to create client -- " + customer
                                + " -- and Error is ["
                                + errorHandler.getErrorMessage() + "]");
            }
        }
        screen = huon.readScreenName();
        //More phone number
        if (screen.equalsIgnoreCase("HYO004")) {
            //Phone2
            if (!customer.getPhone2Type().isEmpty()) {
                huon.input(6, 7, customer.getPhone2Type());
                huon.input(7, 7, customer.getPhone2Area());
                huon.input(7, 27, customer.getPhone2Number());
            }
            huon.enter();
        }

        screen = huon.waitForScreens(new String[]{"HY011", "HY018"});

        if (screen.equalsIgnoreCase("HY018")) {
            //ABN
            if (!customer.getCompanyAbn().isEmpty()) {
                huon.input(20, 40, customer.getAbn());
            }

            // email
            if (!customer.getEmail().isEmpty()) {
                huon.input(22, 18, customer.getEmail());
            }

            huon.enter();
            // Check error
            if (!errorHandler.perform()) {
                throw new JagacyException(JagacyException.MODEL_ERROR,
                        "Failed to create client -- " + customer
                                + " -- and Error is ["
                                + errorHandler.getErrorMessage() + "]");
            }

            huon.waitForScreen("HY011");
        }

//		clientNumber = huon.readFromField(9, 3, 11).trim();
        huon.enter();
        huon.enter();
        huon.input(4, 18, "E");
        huon.enter();

        if (customer.isRefusedCancellations()) {

            try {
                creatRefusalCancellations(customer);
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }

        customer.setClientNumber(clientNumber);


        return clientNumber;
    }


    /**
     * Create Refusals and cancellations for null an void drivers
     */

    public void creatRefusalCancellations(Customer customer) throws JagacyException, ParseException {

        //REFUSALS/CANCELLATIONS NEW/AMEND
        huon.gotoScreen("YY718");
        huon.waitForScreen("YY718");
        huon.input(4, 18, customer.getClientNumber());
        huon.enter();
        //Refusal date
        Date date = DataHandler.today();
        SimpleDateFormat fromUser = new SimpleDateFormat("ddMMyyyy");

        String effectivedate = fromUser.format(date);
        //System.out.println("FromDate " + date + "toDateString" + effectivedate);
        huon.input(9, 23, customer.getRefusalDate());
        huon.input(13, 23, customer.getAsset());
        huon.input(17, 23, customer.getCondition());
        huon.input(19, 23, customer.getReasonCode());
        huon.enter();
        huon.pressKey(Key.PF3);
        huon.gotoHH100();
    }


}
