package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class FieldReference implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("context")
    private String context ;
    @JsonProperty("path")
    private String path ;

  
    @ApiModelProperty(
        value = "Identifies a field reference as being relative. Use ./ and ../ to define the starting path relative to the object i.e. ../location/country or ./flat_unit_type",
        required = false
    )
    public String getContext() {
       return context;
    }
 
    @ApiModelProperty(
        value = "Absolute or relative path to the field in the JSON structure. Path is absolute if context is null or empty.",
        required = false
    )
    public String getPath() {
       return path;
    }
 

}