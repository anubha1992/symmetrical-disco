package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains coverage information for the vehicle")
public class MotorVehicleAsset implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("asset_number")
    private String assetNumber ;
    @JsonProperty("asset_type")
    private String assetType ;
    @JsonProperty("cover_type")
    private String coverType ;
    @JsonProperty("coverages")
    private VehicleCoverages coverages = new VehicleCoverages();
    @JsonProperty("discounts")
    private java.util.List<DiscountDetails> discounts = new java.util.ArrayList<DiscountDetails>();
    @JsonProperty("embargoes_exclusions_conditions")
    private MotorVehicleEmbargoExclusionConditionGroup embargoesExclusionsConditions = new MotorVehicleEmbargoExclusionConditionGroup();
    @JsonProperty("excess_details")
    private ExcessDetails excessDetails = new ExcessDetails();
    @JsonProperty("exempt_from_stamp_duty")
    private Boolean exemptFromStampDuty ;
    @JsonProperty("financed")
    private Boolean financed ;
    @JsonProperty("line_of_business")
    private String lineOfBusiness ;
    @JsonProperty("location")
    private Address location = new Address();
    @JsonProperty("parking_location")
    private String parkingLocation ;
    @JsonProperty("parties")
    private VehicleAssetParty parties = new VehicleAssetParty();
    @JsonProperty("premium_details")
    private PremiumDetails premiumDetails = new PremiumDetails();
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("sum_insured")
    private SumInsured sumInsured = new SumInsured();
    @JsonProperty("temp_id")
    private String tempId ;
    @JsonProperty("usage")
    private VehicleUsage usage = new VehicleUsage();
    @JsonProperty("vehicle")
    private MotorVehicleDetails vehicle = new MotorVehicleDetails();

  
    @ApiModelProperty(
        value = "Asset Number",
        example = "12345",
        required = false
    )
    public String getAssetNumber() {
       return assetNumber;
    }
 
    @ApiModelProperty(
        value = "Risk asset type [Ref Data: asset_type]",
        example = "MOTOR_VEHICLE",
        required = false
    )
    public String getAssetType() {
       return assetType;
    }
 
    @ApiModelProperty(
        value = "Indicates the cover type. [Ref Data: cover_type]",
        example = "SILVER",
        required = false
    )
    public String getCoverType() {
       return coverType;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public VehicleCoverages getCoverages() {
       return coverages;
    }
 
    @ApiModelProperty(
        value = "Discount details at asset level",
        required = false
    )
    public java.util.List<DiscountDetails> getDiscounts() {
       return discounts;
    }
 
    @ApiModelProperty(
        value = "Embargoes, exclusions and conditions details",
        required = false
    )
    public MotorVehicleEmbargoExclusionConditionGroup getEmbargoesExclusionsConditions() {
       return embargoesExclusionsConditions;
    }
 
    @ApiModelProperty(
        value = "Excess details [Ref Data: motor_vehicle_excess_type,property_excess_type]",
        required = false
    )
    public ExcessDetails getExcessDetails() {
       return excessDetails;
    }
 
    @ApiModelProperty(
        value = "Indicates status of stamp duty exemption for vehicle. Values - true for vehicle is exempt from stamp duty, false for vehicle not exempt from stamp duty.",
        required = false
    )
    public Boolean getExemptFromStampDuty() {
       return exemptFromStampDuty;
    }
 
    @ApiModelProperty(
        value = "Indicates vehicle financing. Values - true for vehicle is financed, false for vehicle is not financed.",
        example = "true",
        required = false
    )
    public Boolean getFinanced() {
       return financed;
    }
 
    @ApiModelProperty(
        value = "Line of business or the Policy Line - PERSONAL_MOTOR, PERSONAL_PROPERTY, TRAVEL, LIABILITY etc. Ref Data[line_of_business]",
        example = "PERSONAL_MOTOR",
        required = false
    )
    public String getLineOfBusiness() {
       return lineOfBusiness;
    }
 
    @ApiModelProperty(
        value = "Risk address info",
        required = false
    )
    public Address getLocation() {
       return location;
    }
 
    @ApiModelProperty(
        value = "Vehicles parking location. [Ref Data: parking_location]",
        example = "ALARMED_GARAGE",
        required = false
    )
    public String getParkingLocation() {
       return parkingLocation;
    }
 
    @ApiModelProperty(
        value = "Vehicle party information",
        required = false
    )
    public VehicleAssetParty getParties() {
       return parties;
    }
 
    @ApiModelProperty(
        value = "Premium details",
        required = false
    )
    public PremiumDetails getPremiumDetails() {
       return premiumDetails;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "PUB000066",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "Sum insured details",
        required = false
    )
    public SumInsured getSumInsured() {
       return sumInsured;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000666",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 
    @ApiModelProperty(
        value = "Vehicle usage details",
        required = false
    )
    public VehicleUsage getUsage() {
       return usage;
    }
 
    @ApiModelProperty(
        value = "Detailed information of vehicle",
        required = false
    )
    public MotorVehicleDetails getVehicle() {
       return vehicle;
    }
 

}