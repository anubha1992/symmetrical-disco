package au.com.iag.execution.bindandissueapi.configuration;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;

import static org.springframework.test.context.support.TestPropertySourceUtils.addPropertiesFilesToEnvironment;

public class PropertyOverrideContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        addPropertiesFilesToEnvironment(
                configurableApplicationContext,
                "classpath:config/application-test.properties",
                "classpath:config/bind-and-issue-api/application-test.properties",
                "classpath:config/bind-and-issue-api/${env}/application-test.properties");
    }
}
