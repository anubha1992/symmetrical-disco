package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class CorrespondenceBusiness implements Serializable {

	@JsonProperty("sourceSystemName")
	private String sourceSystemName;

	@JsonProperty("businessType")
	private String businessType;

	@JsonProperty("referenceId")
	private String referenceId;

	public void setSourceSystemName(String sourceSystemName){
		this.sourceSystemName = sourceSystemName;
	}

	public String getSourceSystemName(){
		return sourceSystemName;
	}

	public void setBusinessType(String businessType){
		this.businessType = businessType;
	}

	public String getBusinessType(){
		return businessType;
	}

	public void setReferenceId(String referenceId){
		this.referenceId = referenceId;
	}

	public String getReferenceId(){
		return referenceId;
	}

	@Override
 	public String toString(){
		return 
			"CorrespondenceBusiness{" + 
			"sourceSystemName = '" + sourceSystemName + '\'' + 
			",businessType = '" + businessType + '\'' + 
			",referenceId = '" + referenceId + '\'' + 
			"}";
		}
}