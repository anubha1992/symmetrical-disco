package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class DynamicReferenceDataList implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("ref_id")
    private String refId ;
    @JsonProperty("ref_name")
    private String refName ;
    @JsonProperty("value_list")
    private java.util.List<ValueObject> valueList = new java.util.ArrayList<ValueObject>();

  
    @ApiModelProperty(
        value = "Identifier that is used to tie the dynamic section to an object instance. i.e Dynamic section lookup key - Coverable.PublicID",
        required = false
    )
    public String getRefId() {
       return refId;
    }
 
    @ApiModelProperty(
        value = "The reference name of the dynamic value list. All &#x27;section_ref&#x27; values reference a sections &#x27;ref_name&#x27;",
        required = false
    )
    public String getRefName() {
       return refName;
    }
 
    @ApiModelProperty(
        value = "List of Value Objects",
        required = false
    )
    public java.util.List<ValueObject> getValueList() {
       return valueList;
    }
 

}