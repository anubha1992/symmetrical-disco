package au.com.iag.execution.common.quotes.service;

import au.com.iag.execution.common.builders.security.SecurityTokenBuilder;

import au.com.iag.execution.motorapi.model.business.PolicyDetails;
import au.com.iag.execution.motorapi.model.business.QuoteResponse;
import au.com.iag.glados.common.GladosEnrichmentService;

import au.com.iag.glados.service.JsonMapperService;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.io.IOException;

import java.util.HashMap;
import java.util.Map;

import static au.com.iag.glados.model.constants.GladosConstants.*;
import static org.apache.http.HttpStatus.SC_CREATED;
import static org.apache.http.HttpStatus.SC_OK;

@Service
public class MotorQuoteService {

    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityTokenBuilder securityTokenBuilder;
    @Autowired private JsonMapperService jsonMapperService;

    private static final String MOTOR_QUOTE_PATH = "/services/v2/product/motor/quotes/";

    public QuoteResponse createMotorQuote(final PolicyDetails createMotorQuoteRequest) throws IOException {
        final Response response = gladosEnrichmentService
                .sendPostRequest(getHeaders(), MOTOR_QUOTE_PATH, createMotorQuoteRequest, SC_CREATED);

        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), QuoteResponse.class);
    }

    public QuoteResponse offerMotorQuote(final PolicyDetails offerMotorQuoteRequest, String quoteId) throws IOException {
        Map<String, Object> headers = getHeaders();
        headers.put(X_IAG_AUTH_USER, securityTokenBuilder.getAuthAnonymousUserToken(quoteId));

        final Response response = gladosEnrichmentService
                .sendPutRequest(headers, MOTOR_QUOTE_PATH + quoteId + "/offer", offerMotorQuoteRequest, SC_OK);

        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), QuoteResponse.class);
    }

    private Map<String, Object> getHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityTokenBuilder.getSystemSecurityToken(false));
        return requestHeaders;
    }
}
