package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PaymentDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("payment_instruments")
    private PaymentInstruments paymentInstruments = new PaymentInstruments();

  
    @ApiModelProperty(
        value = "Payment instruments",
        required = false
    )
    public PaymentInstruments getPaymentInstruments() {
       return paymentInstruments;
    }
 

}