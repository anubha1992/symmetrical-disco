package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.*;
import com.github.javafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.BILLING_PLAN_ANNUAL;
import static org.assertj.core.api.Assertions.fail;

@Component
public class CoverageBuilder {

    @Autowired private MiscDataBuilder miscDataBuilder;
    @Autowired private BillingPlanBuilder billingPlanBuilder;

    public <T> T getCoveragesByType(PolicyCorrespondence policyCorrespondence, Class<T> coverageClass) {
        try {
            Class<?> covergeClassName = coverageClass.forName(coverageClass.getName());
            Constructor<?> covergeClassConstructor = covergeClassName.getConstructors()[0];
            Object coverageObject = covergeClassConstructor.newInstance();
            Method[] allPublicMethods = covergeClassName.getMethods();
            int i = 1;
            for (Method method : allPublicMethods) {
                if (method.getName().startsWith("set") && method.getParameterCount() == 1) {
                    if(Arrays.asList(method.getParameterTypes()).contains(BasicCoverage.class)){
                        BasicCoverage basicCoverage = getBasicCoverage((i % 2) == 0);
                        method.invoke(coverageObject, basicCoverage);
                    }
                    else if(Arrays.asList(method.getParameterTypes()).contains(Portable.class)){
                        Portable basicCoverage = getPortables((i % 2) == 0);
                        method.invoke(coverageObject, basicCoverage);
                    }
                    else if(Arrays.asList(method.getParameterTypes()).contains(Valuables.class)){
                        Valuables valuables = getValuables((i % 2) == 0, (i % 2) == 0);
                        method.invoke(coverageObject, valuables);
                    }
                }
                i++;
            }
            return (T) coverageObject;
        }
        catch (Exception e){
            fail("Building of Coverages failed!\n"+e.getMessage());
        }
        return null;
    }

    private BasicCoverage getBasicCoverage(boolean isSelected){
        return getBasicCoverage("STANDARD", isSelected, true);
    }

    public BasicCoverage getBasicCoverage(String category, boolean isSelected, boolean setPremiumDetails){
        BasicCoverage basicCoverage = new BasicCoverage();
        if(setPremiumDetails) {
            basicCoverage.setPremiumDetails(billingPlanBuilder.getPremiumDetails(miscDataBuilder.getDouble(1000, 1500), BILLING_PLAN_ANNUAL));
            basicCoverage.setLimit(Double.toString(miscDataBuilder.getDouble(100, 500)));
        }
        else {
            basicCoverage.setPremiumDetails(null);
            basicCoverage.setLimit(null);
        }
        basicCoverage.setSelected(isSelected);
        basicCoverage.setCategory(category);
        return basicCoverage;
    }

    protected Valuables getValuables(boolean increaseLimits, boolean includeSpecifiedItems){
        Faker faker = new Faker();
        Valuables valuables = new Valuables();
        valuables.setSelected(true);
        double worksOfArtAmount = 2500;
        double jewllaryAndWatchesAmount = 2500;
        double collectionsAmount = 2500;
        if(increaseLimits){
            worksOfArtAmount = worksOfArtAmount*miscDataBuilder.getRandomInt();
            jewllaryAndWatchesAmount = jewllaryAndWatchesAmount*miscDataBuilder.getRandomInt();
            collectionsAmount = collectionsAmount*miscDataBuilder.getRandomInt();
        }
        valuables.setWorksOfArt(getValuableDetails(worksOfArtAmount));
        valuables.setJewelleryAndWatches(getValuableDetails(jewllaryAndWatchesAmount));
        valuables.setCollections(getValuableDetails(collectionsAmount));

        valuables.setIncludeSpecifiedItems(includeSpecifiedItems);
        if(includeSpecifiedItems) {
            ValuableSpecifiedItems valuableSpecifiedItems = new ValuableSpecifiedItems();
            valuableSpecifiedItems.setWorksOfArt(Arrays.asList(getValuableItem("Precious canvas art by " + faker.artist().name(), (2500.0 * miscDataBuilder.getRandomInt() * 7))));
            valuableSpecifiedItems.setJewelleryAndWatches(Arrays.asList(getValuableItem("Wedding ring with carving \'" + faker.shakespeare().romeoAndJulietQuote() + "\'", (2500.0 * miscDataBuilder.getRandomInt() * 10))));
            valuableSpecifiedItems.setCollections(Arrays.asList(getValuableItem(miscDataBuilder.getRandomCollectionName(), (2500.0 * miscDataBuilder.getRandomInt() * 8))));
            valuables.setSpecifiedItems(valuableSpecifiedItems);
        }

        return valuables;
    }

    private ValuableItem getValuableItem(String desc, double sumInsured){
        ValuableItem valuableItem = new ValuableItem();
        valuableItem.setDescription(desc);
        valuableItem.setSumInsured(sumInsured);
        return valuableItem;
    }

    private ValuableDetails getValuableDetails(double sumInsured){
        ValuableDetails valuableDetails = new ValuableDetails();
        valuableDetails.setSumInsured(sumInsured);
        return valuableDetails;
    }

    protected Portable getPortables(boolean includeSpecifiedItems){
        Portable portable = new Portable();
        portable.setSelected(true);
        portable.setSportingAndRecreational(getPortableDetails(2500));
        portable.setPortableElectronicDevices(getPortableDetails(2500));
        portable.setMobilityScooters(getPortableDetails(2500));
        portable.setJewelleryAndWatches(getPortableDetails(2500));
        portable.setGlassesAndMedicalEquipment(getPortableDetails(2500));
        portable.setClothingAndLuggage(getPortableDetails(2500));

        portable.setIncludeSpecifiedItems(includeSpecifiedItems);
        if(includeSpecifiedItems) {
            PortableSpecifiedItems portableSpecifiedItems = new PortableSpecifiedItems();
            portableSpecifiedItems.setSportingAndRecreational(Arrays.asList(getPortableItem("A Cricket Bat used by Sir. Don Bradman", (2500.0 * miscDataBuilder.getRandomInt()))));
            portableSpecifiedItems.setPortableElectronicDevices(Arrays.asList(getPortableItem("Jumanji game console on original 1996 movie", (2500.0 * miscDataBuilder.getRandomInt() * 10))));
            portableSpecifiedItems.setMobilityScooters(Arrays.asList(getPortableItem("Drive King Cobra Mobility Scooter", (2500.0 * miscDataBuilder.getRandomInt() * 4))));
            portableSpecifiedItems.setJewelleryAndWatches(Arrays.asList(getPortableItem("Paul Newman's Rolex Daytona", (2500.0 * miscDataBuilder.getRandomInt() * 100))));
            portableSpecifiedItems.setGlassesAndMedicalEquipment(Arrays.asList(getPortableItem("Chopard Sunglasses as a gift from  my Uncle", (2500.0 * miscDataBuilder.getRandomInt() * 100))));
            portableSpecifiedItems.setClothingAndLuggage(Arrays.asList(getPortableItem("Gucci Diamante Heritage Trunk", (2500.0 * miscDataBuilder.getRandomInt() * 100))));
            portable.setSpecifiedItems(portableSpecifiedItems);
        }

        return portable;
    }

    private PortableDetails getPortableDetails(double sumInsured){
        PortableDetails portableDetails = new PortableDetails();
        portableDetails.setSumInsured(sumInsured);
        return portableDetails;
    }

    private PortableItem getPortableItem(String desc, double sumInsured){
        PortableItem portableItem = new PortableItem();
        portableItem.setDescription(desc);
        portableItem.setSumInsured(sumInsured);
        return portableItem;
    }
}
