package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class DamageArea implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("engine")
    private Boolean engine;
    @JsonProperty("front_left")
    private Boolean frontLeft;
    @JsonProperty("front_right")
    private Boolean frontRight;
    @JsonProperty("interior")
    private Boolean interior;
    @JsonProperty("middle_left")
    private Boolean middleLeft;
    @JsonProperty("middle_right")
    private Boolean middleRight;
    @JsonProperty("rear_left")
    private Boolean rearLeft;
    @JsonProperty("rear_right")
    private Boolean rearRight;
    @JsonProperty("roof")
    private Boolean roof;


    @ApiModelProperty(
            value = "Is there damage to engine",
            example = "true",
            required = false
    )
    public Boolean getEngine() {
        return engine;
    }

    @ApiModelProperty(
            value = "Is there damage to front left hand side",
            example = "true",
            required = false
    )
    public Boolean getFrontLeft() {
        return frontLeft;
    }

    @ApiModelProperty(
            value = "Is there damage to front right hand side",
            example = "true",
            required = false
    )
    public Boolean getFrontRight() {
        return frontRight;
    }

    @ApiModelProperty(
            value = "Is there damage to interior",
            example = "true",
            required = false
    )
    public Boolean getInterior() {
        return interior;
    }

    @ApiModelProperty(
            value = "Is there damage to middle left hand side",
            example = "true",
            required = false
    )
    public Boolean getMiddleLeft() {
        return middleLeft;
    }

    @ApiModelProperty(
            value = "Is there damage to middle right hand side",
            example = "true",
            required = false
    )
    public Boolean getMiddleRight() {
        return middleRight;
    }

    @ApiModelProperty(
            value = "Is there damage to rear left hand side",
            example = "true",
            required = false
    )
    public Boolean getRearLeft() {
        return rearLeft;
    }

    @ApiModelProperty(
            value = "Is there damage to rear right hand side",
            example = "true",
            required = false
    )
    public Boolean getRearRight() {
        return rearRight;
    }

    @ApiModelProperty(
            value = "Is there damage to roof",
            example = "true",
            required = false
    )
    public Boolean getRoof() {
        return roof;
    }


}