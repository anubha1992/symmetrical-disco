package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class PolicyRoleBuilder {

    List<CoverableToPartyRoleSpec> getIndividualWithSingleAsset(String product){
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getIndividualWithSingleHomeAsset();
            case PRODUCT_MOTOR_INSURANCE:
                return getIndividualWithSingleMotorAsset();
            case PRODUCT_LANDLORD_INSURANCE:
                return getIndividualWithSingleMotorAsset();
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    List<CoverableToPartyRoleSpec> getIndividualWithMultipleAssets(String product){
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getIndividualWithMultipleHomeAssets();
            case PRODUCT_MOTOR_INSURANCE:
                return getIndividualWithMultipleMotorAssets();
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    List<CoverableToPartyRoleSpec> getOrganisationWithSingleAsset(String product){
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getOrganisationWithSingleHomeAsset();
            case PRODUCT_MOTOR_INSURANCE:
                return getOrganisationWithSingleMotorAsset();
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    List<CoverableToPartyRoleSpec> getOrganisationWithMultipleAssets(String product){
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getOrganisationWithMultipleHomeAssets();
            case PRODUCT_MOTOR_INSURANCE:
                return getOrganisationWithMultipleMotorAssets();
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    List<CoverableToPartyRoleSpec> getIndividualWithSingleMotorAsset() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG000000200100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , Collections.singletonList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), Map.of(0, Collections.singletonList(ASSET_ROLE_DRIVER))),
                getCoverableToPartyRoleSpec("IAG000000300100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , Collections.singletonList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , null, Map.of(0, Collections.singletonList(ASSET_ROLE_DRIVER)))
        );
    }

    List<CoverableToPartyRoleSpec> getIndividualWithMultipleMotorAssets() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG000000200100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , Collections.singletonList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), Map.of(0, Collections.singletonList(ASSET_ROLE_DRIVER))),
                getCoverableToPartyRoleSpec("IAG000000300100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , Collections.singletonList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), Map.of(1, Collections.singletonList(ASSET_ROLE_DRIVER))),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , null, Map.of(1, Collections.singletonList(ASSET_ROLE_DRIVER), 2, Collections.singletonList(ASSET_ROLE_DRIVER)))
        );
    }

    List<CoverableToPartyRoleSpec> getOrganisationWithSingleMotorAsset() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG0000006200100201", PRIMARY_RECIPIENT_TYPE_ORGANISATION
                        , Collections.singletonList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100301", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , Collections.singletonList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), Map.of(0, Collections.singletonList(ASSET_ROLE_DRIVER))),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , null, Map.of(0, Collections.singletonList(ASSET_ROLE_DRIVER)))
        );
    }

    List<CoverableToPartyRoleSpec> getOrganisationWithMultipleMotorAssets() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG0000006200100201", PRIMARY_RECIPIENT_TYPE_ORGANISATION
                        , Collections.singletonList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100301", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , null, Map.of(0, Collections.singletonList(ASSET_ROLE_DRIVER))),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL
                        , null, Map.of(1, Collections.singletonList(ASSET_ROLE_DRIVER)))
        );
    }

    List<CoverableToPartyRoleSpec> getIndividualWithSingleHomeAsset() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG000000200100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_ORGANISATION, null, Map.of(0, Arrays.asList(ASSET_ROLE_OTHER_PARTY)))
        );
    }

    List<CoverableToPartyRoleSpec> getIndividualWithSingleHomeAssetNoOtherParty() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG000000200100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), null)
        );
    }

    List<CoverableToPartyRoleSpec> getIndividualWithMultipleHomeAssets() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG000000200100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100201", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_ORGANISATION, null, Map.of(0, Arrays.asList(ASSET_ROLE_OTHER_PARTY)
                        , 1, Arrays.asList(ASSET_ROLE_OTHER_PARTY)))
        );
    }

    List<CoverableToPartyRoleSpec> getOrganisationWithSingleHomeAsset() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG0000006200100201", PRIMARY_RECIPIENT_TYPE_ORGANISATION, Arrays.asList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100301", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_ORGANISATION, null, Map.of(0, Arrays.asList(ASSET_ROLE_OTHER_PARTY)))
        );
    }

    List<CoverableToPartyRoleSpec> getOrganisationWithMultipleHomeAssets() {
        return Arrays.asList(
                getCoverableToPartyRoleSpec("IAG0000006200100201", PRIMARY_RECIPIENT_TYPE_ORGANISATION, Arrays.asList(PARTY_ROLE_PRIMARY_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000300100301", PRIMARY_RECIPIENT_TYPE_INDIVIDUAL, Arrays.asList(PARTY_ROLE_ADDITIONAL_POLICY_HOLDER), null),
                getCoverableToPartyRoleSpec("IAG000000400100202", PRIMARY_RECIPIENT_TYPE_ORGANISATION, null, Map.of(1, Arrays.asList(ASSET_ROLE_OTHER_PARTY)))
        );
    }

    private CoverableToPartyRoleSpec getCoverableToPartyRoleSpec(String partyId
            , String type
            , List<String> listOfPolicyLevelRoles
            , Map<Integer, List<String>> mapOfAssetIndexToAssetLevelRoles){
        return CoverableToPartyRoleSpec.builder()
                .partyId(partyId)
                .partyType(type)
                .listOfPolicyLevelRoles(listOfPolicyLevelRoles)
                .mapOfAssetIndexToAssetLevelRoles(mapOfAssetIndexToAssetLevelRoles)
                .build();
    }
}
