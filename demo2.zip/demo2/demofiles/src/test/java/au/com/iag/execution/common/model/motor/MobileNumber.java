package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class MobileNumber implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("country_code")
    private String countryCode ;
    @JsonProperty("effective_from")
    private String effectiveFrom ;
    @JsonProperty("effective_to")
    private String effectiveTo ;
    @JsonProperty("id")
    private String id ;
    @JsonProperty("number")
    private String number ;
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("temp_id")
    private String tempId ;

  
    @ApiModelProperty(
        value = "Country code of respective phone number. Short Description from Ref Data [Ref Data: phone_country_codes]",
        example = "+61",
        required = false
    )
    public String getCountryCode() {
       return countryCode;
    }
 
    @ApiModelProperty(
        value = "Effective from date",
        example = "2019-12-01",
        required = false
    )
    public String getEffectiveFrom() {
       return effectiveFrom;
    }
 
    @ApiModelProperty(
        value = "Effective to date",
        example = "2020-12-01",
        required = false
    )
    public String getEffectiveTo() {
       return effectiveTo;
    }
 
    @ApiModelProperty(
        value = "The phone identifier",
        example = "1",
        required = false
    )
    public String getId() {
       return id;
    }
 
    @ApiModelProperty(
        value = "The phone number",
        example = "0400123456",
        required = false
    )
    public String getNumber() {
       return number;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "pc:581900",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000000",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 

}