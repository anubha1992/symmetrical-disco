package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.*;

@Data
@ApiModel(description = "Organisation information")
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
@EqualsAndHashCode(callSuper = true)
public class Organisation extends Party {
    private static final long serialVersionUID = 1L;

    @JsonProperty("organisation_names")
    private List<Name> organisationNames;
}