package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class RiskUnit implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("risk_type")
    private String riskType;
    @JsonProperty("vehicle")
    private Vehicle vehicle;


    @ApiModelProperty(
            value = "Risk type",
            example = "PERSONAL_MOTOR",
            required = false
    )
    public String getRiskType() {
        return riskType;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Vehicle getVehicle() {
        return vehicle;
    }


}