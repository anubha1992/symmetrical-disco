package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Field value technical validation")
public class BizConstraints implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("default_value")
    private String defaultValue ;
    @JsonProperty("range")
    private Range range = new Range();
    @JsonProperty("ref_data_list")
    private ReferenceDataList refDataList = new ReferenceDataList();
    @JsonProperty("validate_on_answer")
    private Boolean validateOnAnswer ;

  
    @ApiModelProperty(
        value = "The default value of the data field.",
        required = false
    )
    public String getDefaultValue() {
       return defaultValue;
    }
 
    @ApiModelProperty(
        value = "Range of values",
        required = false
    )
    public Range getRange() {
       return range;
    }
 
    @ApiModelProperty(
        value = "Optional. For type &#x3D; enumeration, the source reference data list name.",
        required = false
    )
    public ReferenceDataList getRefDataList() {
       return refDataList;
    }
 
    @ApiModelProperty(
        value = "Optional. Specifies that changes to this field must be validated by the back end system.",
        required = false
    )
    public Boolean getValidateOnAnswer() {
       return validateOnAnswer;
    }
 

}