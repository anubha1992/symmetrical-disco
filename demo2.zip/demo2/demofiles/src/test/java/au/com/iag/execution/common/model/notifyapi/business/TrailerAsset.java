package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "Contains coverage information for the trailer")
public class TrailerAsset implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("asset_number")
    private String assetNumber;
    @JsonProperty("asset_type")
    private String assetType;
    @JsonProperty("cover_type")
    private String coverType;
    @JsonProperty("location")
    private Address location;
    @JsonProperty("parties")
    private VehicleAssetParty parties;
    @JsonProperty("trailer")
    private TrailerDetails trailer;

  
    @ApiModelProperty(
        value = "Asset Number",
        example = "12345",
        required = false
    )
    public String getAssetNumber() {
       return assetNumber;
    }
 
    @ApiModelProperty(
        value = "Asset type [Ref Data: asset_type]",
        example = "MOTOR_VEHICLE",
        required = false
    )
    public String getAssetType() {
       return assetType;
    }
 
    @ApiModelProperty(
        value = "Indicates the cover type. [Ref Data: cover_type]",
        example = "SILVER",
        required = false
    )
    public String getCoverType() {
       return coverType;
    }
 
    @ApiModelProperty(
        value = "Risk address info",
        required = false
    )
    public Address getLocation() {
       return location;
    }
 
    @ApiModelProperty(
        value = "Vehicle party information",
        required = false
    )
    public VehicleAssetParty getParties() {
       return parties;
    }
 
    @ApiModelProperty(
        value = "Trailer details",
        required = false
    )
    public TrailerDetails getTrailer() {
       return trailer;
    }
 

}