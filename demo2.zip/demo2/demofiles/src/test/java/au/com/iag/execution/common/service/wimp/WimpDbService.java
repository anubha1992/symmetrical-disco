package au.com.iag.execution.common.service.wimp;

import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.artifacts.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.glados.model.artifacts.DatabaseConnectionArtifact.*;
import java.sql.*;
import java.util.*;

@Service
public class WimpDbService {

    @Autowired
    private DatabaseClient databaseClient;

    @Value("${test.datasource.username}")
    private String username;
    @Value("${test.datasource.password}")
    private String password;
    @Value("${test.datasource.url}")
    private String connectionString;
    @Value("${test.datasource.driver-class-name}")
    private String driverName;

    public String ensurePolicyIsInWimpAndReturnClaimId(List<Map<String, Object>> claimIdDetails, String brand) throws Exception {
        Map<String, Object> claimIdDetailMap = ensurePolicyIsInWimp(claimIdDetails, brand);

        if (!claimIdDetailMap.isEmpty()){
            return claimIdDetailMap.get(DB_CC_CLAIMNUMBER).toString();
        }
        return null;
    }

    public String ensurePolicyIsInWimpAndReturnPolicyId(List<Map<String, Object>> claimIdDetails, String brand) throws Exception {
        Map<String, Object> claimIdDetailMap = ensurePolicyIsInWimp(claimIdDetails, brand);

        if (!claimIdDetailMap.isEmpty()){
            return claimIdDetailMap.get(DB_CC_POLICYNUMBER).toString();
        }
        return null;
    }

    private Map<String, Object> ensurePolicyIsInWimp(List<Map<String, Object>> claimIdDetails, String brand) throws Exception {
        Map<String, Object> claimIdDetailMap = new HashMap<>();
        Set<String> policyIds = new HashSet<>();
        //Data mining from claim centre database + extra check to WIMP database that policy exists in WIMP as well

        //HUON policies will not be in WIMP, so removing call to WIMP for below brands
        if (!(brand.equalsIgnoreCase("NRMA") || brand.equalsIgnoreCase("SGIO") || brand.equalsIgnoreCase("SGIC") || brand.equalsIgnoreCase("RACV"))) {
            for (Map<String, Object> claimdIdMap : claimIdDetails) {
                claimIdDetailMap = claimdIdMap;
                String policyId = claimIdDetailMap.get(DB_CC_POLICYNUMBER).toString();
                if (!policyIds.contains(policyId)){
                    policyIds.add(policyId);
                    if (doesPolicyExistsInWIMP(policyId)) {
                        break;
                    }
                    System.out.println("[INFO] - Policy number " +policyId+ " retrieved from claim center cannot be found in WIMP");
                }
            }
        }
        return claimIdDetailMap;
    }

    public List<Map<String, Object>> getPolicyRiskAddress(String policyNumber) throws Exception {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String queryString = "select * from WIMPLOCATION where fk_id in "
                + "(select pk_id from WIMPPOLICY pol where pol.policynum = '" + policyNumber + "' ) "
                + "And POLICYLOCATIONTYPE = 'RISK' order by effectivedate desc ";

        List<Map<String, Object>> result = databaseClient.executeQuery(connection, queryString);
        return result;
    }


    public boolean doesPolicyExistsInWIMP(String policyNumber) throws SQLException, ClassNotFoundException {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);
        String queryString = "select count(*) from WIMPPOLICY where POLICYNUM = '" + policyNumber + "'";

        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, queryString);
        if (resultList.get(0).toString().equalsIgnoreCase("{1=0}")) {
            System.out.println("Policy number does not exists in WIMP "+policyNumber);
            return false;
        }
        else{
            return true;
        }
    }

    public List<Map<String, Object>> getCurrentMotorPoliciesForSourceSystem(String sourceSystem) throws SQLException, ClassNotFoundException {

        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String queryString = "select pol.policynum, polItem.policyitemdesc,pol.inceptiondate, pol.expirydate from WIMPPOLICY pol " + "left join WIMPPOLICYITEM polItem "
                + "on polItem.fk_id = pol.pk_id " + "where polItem.POLICYITEMTYPE = 'VEHICLE REG NO' "
                + "And pol.SOURCESYSTEMID = '" + sourceSystem + "' "
                + "And pol.SOURCESYSTEMID != 'CUDOS' And pol.SOURCESYSTEMENVID Not in ('TEST', 'SIT') "
                + "And pol.EXPIRYDATE >  (SELECT current date FROM sysibm.sysdummy1) "
                + "And pol.INCEPTIONDATE < (SELECT current date FROM sysibm.sysdummy1) "
                + "And pol.policynum not in (select policynum from WIMPPOLICY where policystatus='CANCELLED') "
                + "group by pol.policynum, polItem.policyitemdesc,pol.inceptiondate, pol.expirydate "
                + "ORDER BY policyNum DESC FETCH FIRST 50 rows only";

        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, queryString);
        return resultList;
    }

    public List<Map<String, Object>> getCurrentPoliciesForSourceSystemAndProduct(String sourceSystem,String productCode) throws SQLException, ClassNotFoundException {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String queryString = "select pol.policynum,pol.inceptiondate, pol.expirydate from WIMPPOLICY pol "
                + "where pol.producttype = '" + productCode + "' "
                + "And pol.SOURCESYSTEMID = '" + sourceSystem + "' "
                + "And pol.SOURCESYSTEMID != 'CUDOS' And pol.SOURCESYSTEMENVID Not in ('TEST', 'SIT') "
                + "And pol.EXPIRYDATE >  (SELECT current date FROM sysibm.sysdummy1) "
                + "And pol.INCEPTIONDATE < (SELECT current date FROM sysibm.sysdummy1) "
                + "And pol.policynum not in (select policynum from WIMPPOLICY where policystatus='CANCELLED') "
                + "ORDER BY policyNum DESC FETCH FIRST 50 rows only";

        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, queryString);
        return resultList;
    }


    private DatabaseConnectionArtifact buildDatabaseConnectionDetails() {
        return builder().connectionString(connectionString)
                .jdbcClassName(driverName)
                .username(username)
                .password(password)
                .build();
    }
}
