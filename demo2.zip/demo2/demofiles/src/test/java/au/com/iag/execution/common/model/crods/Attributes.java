package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Attributes{

	@JsonProperty("bsbNumber")
	private String bsbNumber;

	@JsonProperty("demerits")
	private String demerits;

	@JsonProperty("flyBuysNumber")
	private String flyBuysNumber;

	@JsonProperty("contactPointsConfirmedDate")
	private String contactPointsConfirmedDate;

	@JsonProperty("lifeOfCustomer")
	private boolean lifeOfCustomer;

	@JsonProperty("staffNumber")
	private String staffNumber;

	@JsonProperty("abn")
	private String abn;

	@JsonProperty("acn")
	private String acn;

	@JsonProperty("ctpfleetExpiryDate")
	private String ctpfleetExpiryDate;

	@JsonProperty("demeritReference")
	private String demeritReference;

	@JsonProperty("lifeReferral")
	private boolean lifeReferral;

	@JsonProperty("staffMember")
	private String staffMember;

	@JsonProperty("ctpfleet")
	private String ctpfleet;

	public void setBsbNumber(String bsbNumber){
		this.bsbNumber = bsbNumber;
	}

	public String getBsbNumber(){
		return bsbNumber;
	}

	public void setDemerits(String demerits){
		this.demerits = demerits;
	}

	public String getDemerits(){
		return demerits;
	}

	public void setFlyBuysNumber(String flyBuysNumber){
		this.flyBuysNumber = flyBuysNumber;
	}

	public String getFlyBuysNumber(){
		return flyBuysNumber;
	}

	public void setContactPointsConfirmedDate(String contactPointsConfirmedDate){
		this.contactPointsConfirmedDate = contactPointsConfirmedDate;
	}

	public String getContactPointsConfirmedDate(){
		return contactPointsConfirmedDate;
	}

	public void setLifeOfCustomer(boolean lifeOfCustomer){
		this.lifeOfCustomer = lifeOfCustomer;
	}

	public boolean isLifeOfCustomer(){
		return lifeOfCustomer;
	}

	public void setStaffNumber(String staffNumber){
		this.staffNumber = staffNumber;
	}

	public String getStaffNumber(){
		return staffNumber;
	}

	public void setAbn(String abn){
		this.abn = abn;
	}

	public String getAbn(){
		return abn;
	}

	public void setAcn(String acn){
		this.acn = acn;
	}

	public String getAcn(){
		return acn;
	}

	public void setCtpfleetExpiryDate(String ctpfleetExpiryDate){
		this.ctpfleetExpiryDate = ctpfleetExpiryDate;
	}

	public String getCtpfleetExpiryDate(){
		return ctpfleetExpiryDate;
	}

	public void setDemeritReference(String demeritReference){
		this.demeritReference = demeritReference;
	}

	public String getDemeritReference(){
		return demeritReference;
	}

	public void setLifeReferral(boolean lifeReferral){
		this.lifeReferral = lifeReferral;
	}

	public boolean isLifeReferral(){
		return lifeReferral;
	}

	public void setStaffMember(String staffMember){
		this.staffMember = staffMember;
	}

	public String getStaffMember(){
		return staffMember;
	}

	public void setCtpfleet(String ctpfleet){
		this.ctpfleet = ctpfleet;
	}

	public String getCtpfleet(){
		return ctpfleet;
	}

	@Override
 	public String toString(){
		return 
			"Attributes{" + 
			"bsbNumber = '" + bsbNumber + '\'' + 
			",demerits = '" + demerits + '\'' + 
			",flyBuysNumber = '" + flyBuysNumber + '\'' + 
			",contactPointsConfirmedDate = '" + contactPointsConfirmedDate + '\'' + 
			",lifeOfCustomer = '" + lifeOfCustomer + '\'' + 
			",staffNumber = '" + staffNumber + '\'' + 
			",abn = '" + abn + '\'' + 
			",acn = '" + acn + '\'' + 
			",ctpfleetExpiryDate = '" + ctpfleetExpiryDate + '\'' + 
			",demeritReference = '" + demeritReference + '\'' + 
			",lifeReferral = '" + lifeReferral + '\'' + 
			",staffMember = '" + staffMember + '\'' + 
			",ctpfleet = '" + ctpfleet + '\'' + 
			"}";
		}
}