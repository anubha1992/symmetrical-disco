package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Exposure implements Serializable {

    private String exposureId;
    private String lossPartyType;
    private Coverage coverage;

    public String getExposureId() {
        return exposureId;
    }

    public void setExposureId(String exposureId) {
        this.exposureId = exposureId;
    }

    public String getLossPartyType() {
        return lossPartyType;
    }

    public void setLossPartyType(String lossPartyType) {
        this.lossPartyType = lossPartyType;
    }

    public Coverage getCoverage() {
        return coverage;
    }

    public void setCoverage(Coverage coverage) {
        this.coverage = coverage;
    }

}