package au.com.iag.execution.common.bindandissue.builders;


import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueRequest;
import au.com.iag.execution.common.core.builders.RequestBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class BindAndIssueRequestBuilder {
    @Autowired private RequestBuilder requestBuilder;

    private static final String BIND_AND_ISSUE_REQUEST = "requests/bind-and-issue-api/bindAndIssue.json";

    public BindAndIssueRequest buildBindAndIssueRequest(String quoteNumber) throws IOException {
        BindAndIssueRequest bindAndIssueRequest = requestBuilder.buildRequest(BIND_AND_ISSUE_REQUEST, BindAndIssueRequest.class);
        bindAndIssueRequest.setTransactionNumber(quoteNumber);
        return bindAndIssueRequest;
    }
}
