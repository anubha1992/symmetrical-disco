package au.com.iag.execution.common.service.lodgeclaims;

import au.com.iag.execution.common.model.claims.motor.*;
import au.com.iag.execution.common.model.huon.util.*;
import au.com.iag.execution.common.service.crods.*;
import au.com.iag.execution.common.service.huon.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.apache.http.HttpStatus.*;
import static org.junit.Assert.*;
import static au.com.iag.execution.common.constants.ApiConstants.X_IAG_USER_PROFILE;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.common.constants.WimpConstants.*;
import static au.com.iag.execution.propertyvaluationapi.model.PropertyValuationsConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.text.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

@Service
public class LodgeMotorClaimService {

    @Autowired
    private JsonMapperService jsonMapperService;
    @Autowired
    private ResourceReaderService resourceReaderService;
    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired
    WimpDbService wimpDbService;
    @Autowired
    CrodsDbService crodsDbService;
    @Autowired
    private SecurityService securityService;

    @Autowired
    SearchHUONPolicies searchHUONPolicies;

    @Value("${test.api.source.system}")
    private String apiSourceSystem;
    @Value("${test.api.product.code}")
    private String productCode;
    @Value("${test.api.source.system.brand}")
    private String brand;
    @Value("${test.api.lodgemotorclaim.route}")
    private String lodgeMotorClaimPath;
    @Value("${test.api.retrieveclaimpolicy.route}")
    private String retriveClaimPolicyPath;

    @Value("${test.api.claimPolicyRetrieveService.authorization}")
    public String authorizationDetails;

    @Value("${env.name.huon}")
    public String envNameHUON;

    private String lodgeClaimsRequestPath = "requests/motor-claim-lodgement-api/";

    public Claim buildClaim(Claim claim) throws Exception {

        return buildMotorPolicyDetails(claim);
    }

    public Response lodgeClaim(int expectStatusCode) throws Exception {
        String fileName = "lodgeMotorClaim.json";
        if (brand.equalsIgnoreCase("NZ STATE")) { //This is for NZ State lodgement in test2 environment
            fileName = "lodgeNZSTATEMotorClaim.json";
        } else if (brand.equalsIgnoreCase("AMI")) {  //AMI lodge in Test2 and UAT
            fileName = "lodgeNZAMIMotorClaim.json";
        }
        Claim claim = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(lodgeClaimsRequestPath + fileName), Claim.class);

        claim = buildMotorPolicyDetails(claim);

        return executeClaimLodgement(claim, expectStatusCode);
    }

    private Claim buildMotorPolicyDetails(Claim claim) throws Exception {
        Policy huonPolicy = null;
        String policyIdentifier= "";
        String inceptionDate = "";
        String expiryDate = "";
        String registrationNumber = "";

        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            if (brand.equalsIgnoreCase("NZ STATE")) {
                // Policy in UAT env
                return setUpNZData(claim);
            } else { //NRMA, RACV, SGIO, SGIC - HUON AUS brands
                huonPolicy = searchHUONPolicies.findHuonPolicyDetails(huonPolicy, envNameHUON, productCode);
                policyIdentifier = huonPolicy.getPolicyNumber();
                inceptionDate = searchHUONPolicies.getEffectiveDateForHUONPolicy(huonPolicy);
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
                expiryDate = LocalDate.parse(inceptionDate, dtf).plusYears(1).toString();

            }
        } else if (apiSourceSystem.equalsIgnoreCase("EXIGEN")) {
            if (brand.equalsIgnoreCase("AMI")) {
                // Policy in UAT env
                policyIdentifier = "M0010162288";
                inceptionDate = "2018-12-03T00:00:00";
                expiryDate = "2019-02-04T00:00:00";
                registrationNumber = "SLOWMO";
            }
        } else { //FOR COLES policies, do WIMP search
            List<Map<String, Object>> policies = wimpDbService.getCurrentMotorPoliciesForSourceSystem(apiSourceSystem);
            Map<String, Object> policy = policies.get(new Random().nextInt(policies.size()));
            policyIdentifier = policy.get(DB_POLICY_NUMBER).toString();
            registrationNumber = policy.get(DB_VEHICLE_REGISTRATION).toString();
            inceptionDate = policy.get(DB_POLICY_INCEPTION).toString();
            expiryDate = policy.get(DB_POLICY_EXPIRY).toString();
        }
        System.out.println("POLICY NUMBER ****** " + policyIdentifier);

        String dateOfLoss = getDateOfLoss(inceptionDate, expiryDate);
        // incase of huon policies
        if (registrationNumber.isEmpty()){
            Response response = executeRetrieveClaimPolicyDetails(policyIdentifier, dateOfLoss, SC_OK);
            registrationNumber = response.path("product_offering.risk[0].coverable.vehicle.registration").toString();
        }

        claim.setPolicyIdentifier(policyIdentifier);
        claim.setDateOfLoss(OffsetDateTime.parse(dateOfLoss));
        claim.getIncidents().get(0).getRiskUnit().getRiskItem().setRegistration(registrationNumber);
        return claim;
    }

    private Response executeClaimLodgement(Claim claim, Map<String, Object> requestHeaders, int expectStatusCode){

        Response response = gladosEnrichmentService.sendPostRequest(
                requestHeaders,
                lodgeMotorClaimPath,
                claim,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Response executeClaimLodgement(Claim claim, int expectStatusCode){

        Response response = gladosEnrichmentService.sendPostRequest(
                getLodgeMotorClaimHeader(),
                lodgeMotorClaimPath,
                claim,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeRetrieveClaimPolicyDetails(String policyNumber, String dateOfLoss, int expectStatusCode){

        String queryString = "policy_id=" + policyNumber + "&as_at_date=" + dateOfLoss;
        Response response = gladosEnrichmentService.sendGetRequest(
                getClaimsPolicyRetrieveHeaders(),
                retriveClaimPolicyPath,
                queryString,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Claim setUpNZData(Claim claim) throws Exception {
        if (brand.equalsIgnoreCase("AMI")) {
            claim.setPolicyIdentifier("C3082228");
        } else {

            List<String> riskTypes = Arrays.asList("CRCP");
            String crodsBrand = "STATE";
            Map<String, Object> policyIdDetails = crodsDbService.getPoliciesByBrand(crodsBrand, riskTypes, productCode, apiSourceSystem);
            String policyIdentifier = policyIdDetails.get(DB_CRODS_POLICYNUMBER).toString();
            String[] riskUnit = policyIdDetails.get(DB_CRODS_VEHICLE_REGISTRATION).toString().split(" ");
            String registrationNumber = riskUnit[riskUnit.length - 1];
            String inceptionDate = policyIdDetails.get(DB_CRODS_POLICY_INCEPTION).toString();
            String expiryDate = policyIdDetails.get(DB_CORDS_POLICY_EXPIRY).toString();

            String dateOfLoss = getDateOfLoss(inceptionDate, expiryDate);

            claim.setPolicyIdentifier(policyIdentifier);
            claim.setDateOfLoss(OffsetDateTime.parse(dateOfLoss));
            claim.getIncidents().get(0).getRiskUnit().getRiskItem().setRegistration(registrationNumber);

        }

        return claim;
    }

    private String getDateOfLoss(String inceptionDate, String expiryDate) throws Exception {
        String dateOfLoss = null;
        System.out.println("Inception Date is ****** " + inceptionDate);
        System.out.println("Expiry Date is ****** " + expiryDate);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cInceptionDate = Calendar.getInstance();
        cInceptionDate.setTime(sdf.parse(inceptionDate));
        Date currentDate = new Date();

        //We cant have claims raised on the same date for a given policy, as CC treats it as duplicate claim and lodgement fails.
        //hence a logic is added below to add radomise dates [Inception date + random days = date of loss]

        //Also need to incorporate below rules when deciding date of loss
        //1. Date of loss should be greater than inception date but less than expiry date of policy
        //2. If policy expiry is a future date, then date of loss should be between inception date and today's date

        long term = (sdf.parse(expiryDate).getTime() - currentDate.getTime()) / ((1000 * 60 * 60 * 24));
        if (term > 0) { //Expiry date > current date
            long n = (currentDate.getTime() - sdf.parse(inceptionDate).getTime()) / ((1000 * 60 * 60 * 24));
            System.out.println("Difference in date from inception to current day is ****** " + n);
            cInceptionDate.add(Calendar.DATE, getRandom((int) (long) n));
            inceptionDate = sdf.format(cInceptionDate.getTime());
            dateOfLoss = inceptionDate + "T00:03:00+00:00";
            System.out.println("Date of loss is ****** " + dateOfLoss);
        } else { //Expiry date < current date
            long n = (sdf.parse(expiryDate).getTime() - sdf.parse(inceptionDate).getTime()) / ((1000 * 60 * 60 * 24));
            System.out.println("Difference in date from inception to expiry day is ****** " + n);
            cInceptionDate.add(Calendar.DATE, getRandom((int) (long) n));
            inceptionDate = sdf.format(cInceptionDate.getTime());
            dateOfLoss = inceptionDate + "T00:03:00+00:00";
            System.out.println("Date of loss is ****** " + dateOfLoss);
        }
        return dateOfLoss;
    }

    private int getRandom(int limit) {
        Random rand = new Random();
        return rand.nextInt(limit) + 1;
    }

    // LodgeMotorClaims
    private Map<String, Object> getLodgeMotorClaimHeader(){
        Map<String, Object> requestHeaders = getRequestHeaders();

        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            requestHeaders.put(X_IAG_DISTRIBUTOR, brand);
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            if (brand.equalsIgnoreCase("NZ STATE")) {
                requestHeaders.put(X_IAG_USER, "WEBZIIP");
                requestHeaders.put(X_IAG_USER_PROFILE, "IAGNZ");
            } else {
                requestHeaders.put(X_IAG_USER, "WEBNIIP");
                requestHeaders.put(X_IAG_USER_PROFILE, "IAGSM");
                requestHeaders.put(X_IAG_USER_ALIASES, "HUON=MRJUSER");
            }
        }
        return requestHeaders;
    }

    private Map<String, Object> getRequestHeaders(){
        Map<String, Object> requestHeaders = new HashMap<>();

        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "BAPI");
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(SOURCE_ID, "DC");

        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken("BAPI", "business-api-provider"));
        return requestHeaders;
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }

    private Map<String, Object> getClaimsPolicyRetrieveHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put("Accept", APPLICATION_JSON);
        requestHeaders.put(AUTHORIZATION, authorizationDetails);
        requestHeaders.put("policy_system", apiSourceSystem.toLowerCase());
        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            requestHeaders = getBasicHuonHeaders(requestHeaders, brand.toUpperCase());
            if (productCode.equalsIgnoreCase("CTP")) {
                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
                requestHeaders.put("X-Iag-Operation", "retrieveCTPPolicy");

            } else {
                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
                requestHeaders.put("X-Iag-Operation", "retrievePolicy");
                requestHeaders.put("policy_system", "huon_" + productCode.toLowerCase());
                if (brand.equalsIgnoreCase("NZ STATE")) {
                    requestHeaders = getBasicHuonNzStateHeaders(requestHeaders, brand.toUpperCase());
                    requestHeaders.put("X-Iag-Operation", "retrievePolicy");
                    requestHeaders.put("policy_system", "huon_" + productCode.toLowerCase());
                }
            }
        }
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken("BAPI", "business-api-provider"));
        return requestHeaders;
    }

    private Map<String, Object> getBasicHuonNzStateHeaders(Map<String, Object> requestHeaders, String brand) {
        requestHeaders = getBasicHuonHeaders(requestHeaders, brand.toUpperCase());
        requestHeaders.put("X-Iag-User", "WEBZIIP");
        requestHeaders.put("X-Iag-Consumer-System", "BAPI");
        requestHeaders.put("X-Iag-User-Profile", "IAGNZ");
        requestHeaders.put("X-Iag-User-Aliases", "HUON=WEBZIIP");
        return requestHeaders;
    }

    private Map<String, Object> getBasicHuonHeaders(Map<String, Object> requestHeaders, String brand) {
        requestHeaders.put("Content-Type", "text/xml");
        requestHeaders.put("X-Iag-Brand", brand);
        requestHeaders.put("X-Iag-Agent-Id", "INT");
        requestHeaders.put("X-Iag-Distributor", brand);
        requestHeaders.put("X-Iag-Channel", "Digital");
        return requestHeaders;
    }

    private Map<String, Object> getAdditionalHuonHeaders(Map<String, Object> requestHeaders) {
        requestHeaders.put("X-Iag-User", "WEBNIIP");
        requestHeaders.put("X-Iag-Consumer-System", "BAPI");
        requestHeaders.put("X-Iag-User-Profile", "IAGSM");
        requestHeaders.put("X-Iag-User-Aliases", "MRJUSER");
        return requestHeaders;
    }
}
