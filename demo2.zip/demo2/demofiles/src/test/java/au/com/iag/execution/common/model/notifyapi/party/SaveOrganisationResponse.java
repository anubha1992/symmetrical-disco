package au.com.iag.execution.common.model.notifyapi.party;

import java.io.Serializable;
import java.util.List;

import au.com.iag.execution.partyapi.model.business.Organisation;
import au.com.iag.execution.partyapi.model.business.ValidationError;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class SaveOrganisationResponse implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("errors")
    private List<ValidationError> errors;
    @JsonProperty("organisation")
    private Organisation organisation;

  
    @ApiModelProperty(
        value = "List of validation errors.",
        required = false
    )
    public List<ValidationError> getErrors() {
       return errors;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public Organisation getOrganisation() {
       return organisation;
    }
 

}