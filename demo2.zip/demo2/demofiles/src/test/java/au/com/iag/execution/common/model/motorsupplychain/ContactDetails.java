package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class ContactDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("address")
    private Address address;
    @JsonProperty("allow_email_notification")
    private Boolean allowEmailNotification;
    @JsonProperty("allow_sms_notification")
    private Boolean allowSmsNotification;
    @JsonProperty("alternate_email")
    private String alternateEmail;
    @JsonProperty("business")
    private String business;
    @JsonProperty("email")
    private String email;
    @JsonProperty("fax")
    private String fax;
    @JsonProperty("home")
    private String home;
    @JsonProperty("mobile")
    private String mobile;
    @JsonProperty("preferred_contact")
    private String preferredContact;
    @JsonProperty("relationship")
    private String relationship;
    @JsonProperty("team_email")
    private String teamEmail;
    @JsonProperty("team_phone")
    private String teamPhone;
    @JsonProperty("work")
    private String work;
    @JsonProperty("work_extension")
    private String workExtension;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public Address getAddress() {
        return address;
    }

    @ApiModelProperty(
            value = "Flag to indicate party can be contacted via Email.",
            example = "true",
            required = false
    )
    public Boolean getAllowEmailNotification() {
        return allowEmailNotification;
    }

    @ApiModelProperty(
            value = "Flag to indicate party can be contacted via SMS.",
            example = "true",
            required = false
    )
    public Boolean getAllowSmsNotification() {
        return allowSmsNotification;
    }

    @ApiModelProperty(
            value = "Alternate email address of the party",
            example = "alternateContact@iag.co.nz",
            required = false
    )
    public String getAlternateEmail() {
        return alternateEmail;
    }

    @ApiModelProperty(
            value = "Business phone number of the party. Must include area code",
            example = "2.98766457E8",
            required = false
    )
    public String getBusiness() {
        return business;
    }

    @ApiModelProperty(
            value = "Email address of the party",
            example = "jane.doe@iag-xyz.com.au",
            required = false
    )
    public String getEmail() {
        return email;
    }

    @ApiModelProperty(
            value = "Fax number of the party. Must include area code",
            example = "2.97456321E8",
            required = false
    )
    public String getFax() {
        return fax;
    }

    @ApiModelProperty(
            value = "Home phone number of the party. Must include area code",
            example = "2.97456321E8",
            required = false
    )
    public String getHome() {
        return home;
    }

    @ApiModelProperty(
            value = "Mobile phone number of the party",
            example = "4.12345678E8",
            required = false
    )
    public String getMobile() {
        return mobile;
    }

    @ApiModelProperty(
            value = "Preferred person method",
            example = "mobile",
            required = false
    )
    public String getPreferredContact() {
        return preferredContact;
    }

    @ApiModelProperty(
            value = "Relationship of the party.",
            example = "Exclusive Partner",
            required = false
    )
    public String getRelationship() {
        return relationship;
    }

    @ApiModelProperty(
            value = "Email address of the team",
            example = "jane.doe@iag-xyz.com.au",
            required = false
    )
    public String getTeamEmail() {
        return teamEmail;
    }

    @ApiModelProperty(
            value = "Team phone number of the party. Must include area code",
            example = "2.98766457E8",
            required = false
    )
    public String getTeamPhone() {
        return teamPhone;
    }

    @ApiModelProperty(
            value = "Work phone number of the party. Must include area code",
            example = "2.98766457E8",
            required = false
    )
    public String getWork() {
        return work;
    }

    @ApiModelProperty(
            value = "Work phone number extension.",
            example = "99994444",
            required = false
    )
    public String getWorkExtension() {
        return workExtension;
    }


}