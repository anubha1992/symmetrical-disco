package au.com.iag.execution.common.service.motorsupplychain;

import au.com.iag.execution.common.model.motorsupplychain.*;
import au.com.iag.glados.common.*;
import au.com.iag.glados.model.security.*;
import au.com.iag.glados.service.*;
import com.fasterxml.jackson.core.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.math.*;
import java.time.*;
import java.util.*;

@Service
public class ServiceRequestAllocationService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    @Autowired
    ResourceReaderService resourceReaderService;

    @Autowired
    JsonMapperService jsonMapperService;

    @Autowired
    private SecurityService securityService;
    @Value("${test.api.source.system.brand}") public String brand;

    private String serviceAllocationJsonReqPath = "requests/motor-supply-chain-api";

    public ServiceRequestAllocationRequest buildServiceRequestAllocationRequestFromJson(){
        try {
            ServiceRequestAllocationRequest serviceRequestAllocationRequest = jsonMapperService.getObjectMapper().
                    readValue(resourceReaderService.generateStringFromResource(serviceAllocationJsonReqPath + "/ServiceAllocationRequest.json"), ServiceRequestAllocationRequest.class);
            return serviceRequestAllocationRequest;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ServiceRequestAllocationRequest buildServiceRequestAllocationRequest(Response retrieveClaimDetailsResponse, Response retrievePolicyDetailsResponse, Response motorRepairerSearchResponse, String serviceRequestId){
        ServiceRequestAllocationRequest serviceRequestAllocationRequest = new ServiceRequestAllocationRequest();

        serviceRequestAllocationRequest.setServiceRequestId(serviceRequestId);
        serviceRequestAllocationRequest.setClaim(getClaim(retrieveClaimDetailsResponse));

        serviceRequestAllocationRequest.setPolicy(getPolicy(retrievePolicyDetailsResponse, retrieveClaimDetailsResponse));
        serviceRequestAllocationRequest.setServiceProvider(getServiceProvider(motorRepairerSearchResponse));

        serviceRequestAllocationRequest.setExcess(getExcess(retrieveClaimDetailsResponse));

        serviceRequestAllocationRequest.setCollectExcessHub(Boolean.TRUE);
        serviceRequestAllocationRequest.setCollectExcessRepairer(Boolean.TRUE);
        serviceRequestAllocationRequest.setServiceRequestJobType("ASSESS_AND_AUTHORISE");
        serviceRequestAllocationRequest.setServiceRequestType("MOTOR_GLASS");
        serviceRequestAllocationRequest.setSpecialInstructions("Car Comprehensive");
        return serviceRequestAllocationRequest;
    }

    public Response executeServiceRequestAllocation(ServiceRequestAllocationRequest serviceRequestAllocationRequest, String path){
        return gladosEnrichmentService.sendPostRequest(getHeaders(serviceRequestAllocationRequest),
                path,
                serviceRequestAllocationRequest,
                SC_CREATED);
    }

    private Map<String, Object> getHeaders(ServiceRequestAllocationRequest serviceRequestAllocationRequest){

        String claimId = serviceRequestAllocationRequest.getClaim().getClaimNumber();
        String serviceRequestId = serviceRequestAllocationRequest.getServiceRequestId();
        String serviceProviderId = serviceRequestAllocationRequest.getServiceProvider().getIdentifier();
        UserTokenRequestPayload userTokenRequestPayload = buildUserTokenRequestPayload(claimId, serviceRequestId, serviceProviderId);

        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "BAPI");
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken("BAPI", "business-api-provider"));

        requestHeaders.put(X_IAG_USER, "claimStaff");
        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        return requestHeaders;
    }

    private UserTokenRequestPayload buildUserTokenRequestPayload(String claimId, String serviceRequestId, String serviceProviderId){
        UserTokenRequestPayload userTokenRequestPayload = new UserTokenRequestPayload();
        userTokenRequestPayload.setAudience("business-api-provider");
        userTokenRequestPayload.setAuthentication("NONE");
        userTokenRequestPayload.setContext("claimcenter");
        userTokenRequestPayload.setGrantType("NOTARY");
        userTokenRequestPayload.setIss("calim-center");
        userTokenRequestPayload.setName("");
        userTokenRequestPayload.setScope("w:claim.claim_number:"+claimId+" w:service_request_id:"+serviceRequestId+" w:service_provider.identifier:"+serviceProviderId);
        userTokenRequestPayload.setSubject("claimStaff");

        return userTokenRequestPayload;

    }

    private Claim getClaim(Response retrieveClaimDetailsResponse){
        Claim claim = new Claim();
        String dateOfLoss = retrieveClaimDetailsResponse.path("claim.date_of_loss").toString();
        String lodgementDate = retrieveClaimDetailsResponse.path("claim.claim_lodgement_date").toString();

        Address address = retrieveClaimDetailsResponse.jsonPath().getObject("claim.location_of_loss", Address.class);
        VehicleIncident vehicleIncident = retrieveClaimDetailsResponse.jsonPath().getObject("claim.incidents[0]", VehicleIncident.class);
        vehicleIncident.getOwner().setPartyType("Person");
        Person person = (Person) vehicleIncident.getOwner();
        person.setTitle("MR");

        Amount dailyRateAmount = new Amount();
        dailyRateAmount.setAmount(new BigDecimal("50"));
        dailyRateAmount.setCurrency("AUSTRALIAN_DOLLAR");
        vehicleIncident.getHireCar().setMaximumDays(Integer.valueOf(100));
        vehicleIncident.getHireCar().setDailyRate(dailyRateAmount);
        vehicleIncident.getHireCar().setMaximumLimit(dailyRateAmount);

        Vehicle vehicle = retrieveClaimDetailsResponse.jsonPath().getObject("claim.incidents[0].vehicle", Vehicle.class);

        TaxiBenefit taxiBenefit = new TaxiBenefit();
        taxiBenefit.setEntitlement("STANDARD");
        taxiBenefit.setFareLimit("$50 per journey");
        taxiBenefit.setJourneyLimit("1 journey each way");

        vehicleIncident.setTaxiBenefit(taxiBenefit);
        vehicleIncident.getDamageArea().setEngine(Boolean.TRUE);
        vehicleIncident.getDamageArea().setFrontRight(Boolean.FALSE);
        vehicleIncident.getDamageArea().setMiddleRight(Boolean.FALSE);
        vehicleIncident.getDamageArea().setMiddleLeft(Boolean.TRUE);
        vehicleIncident.getDamageArea().setRearRight(Boolean.FALSE);
        vehicleIncident.getDamageArea().setRoof(Boolean.TRUE);
        vehicleIncident.getDamageArea().setInterior(Boolean.TRUE);

        ContactDetails contactDetails = vehicleIncident.getOwner().getContactDetails().get(0);
        contactDetails.setEmail("test@iag.com.au");
        contactDetails.setWork("02-6345");
        contactDetails.setHome("02-9789");
        contactDetails.setFax("02-1000");
        contactDetails.setMobile("040321");

        claim.setClaimDecisionStatus(retrieveClaimDetailsResponse.path("claim.claim_decision_status").toString());
        claim.setClaimNumber(retrieveClaimDetailsResponse.path("claim.claim_identifier").toString());
        claim.setCauseOfLoss(retrieveClaimDetailsResponse.path("claim.cause_of_loss").toString());
        claim.setDateOfLoss(ZonedDateTime.parse(dateOfLoss));
        claim.setDescriptionOfLoss(retrieveClaimDetailsResponse.path("claim.description_of_loss").toString());
        //claim.setGeneralNatureOfLoss(retrieveClaimDetailsResponse.path("claim.general_nature_of_loss").toString());
        claim.setGeneralNatureOfLoss("COLLISION");
        claim.setLocationOfLoss(address);
        claim.setLodgementDate(ZonedDateTime.parse(lodgementDate));
        claim.setStatus(retrieveClaimDetailsResponse.path("claim.claim_status").toString());
        claim.setVehicleIncident(vehicleIncident);
        claim.getVehicleIncident().getRiskUnit().setVehicle(vehicle);

        return claim;
    }

    private Policy getPolicy(Response policyDetailsResponse, Response claimDetailsResponse){
        Policy policy = new Policy();
        policy.setAnyRepairerOption(Boolean.TRUE);
        policy.setBrand(policyDetailsResponse.path("policy_brand").toString());
        policy.setFleet(Boolean.TRUE);
        //TODO: Confirm insured details
        policy.setInsured(claimDetailsResponse.jsonPath().getObject("claim.insured", Party.class));
        policy.getInsured().setPartyType("Person");

        ContactDetails contactDetails = policy.getInsured().getContactDetails().get(0);
        contactDetails.setEmail("iag-policy@iag.com.au");
        contactDetails.setWork("02-1111");
        contactDetails.setHome("02-2222");
        contactDetails.setFax("02-9999");
        contactDetails.setMobile("041225");

        policy.setPolicyIdentifier(policyDetailsResponse.path("policy_id").toString());
        Amount amount = new Amount();
        amount.setAmount(new BigDecimal("5000"));
        amount.setCurrency("AUSTRALIAN_DOLLAR");
        policy.setSumInsured(amount);
        policy.setTermExpiryDate(ZonedDateTime.parse(policyDetailsResponse.path("term_period.end_date").toString()));
        policy.setTermInceptionDate(ZonedDateTime.parse(policyDetailsResponse.path("term_period.start_date").toString()));
        // TODO: mandatory field
        policy.setValuationType("MARKET_VALUE");
        return policy;
    }

    private ServiceProvider getServiceProvider(Response response){
        ServiceProvider serviceProvider = new ServiceProvider();
        serviceProvider.setIdentifier(response.path("repairers[0].supplier_id").toString());
        serviceProvider.setRelationship(response.path("repairers[0].relationship").toString());
        serviceProvider.setIsHub(Boolean.TRUE);
        //serviceProvider.setSystemOfEngagement(response.path("repairers[0].repairer_type").toString());
        return serviceProvider;
    }

    private Excess getExcess(Response retrieveClaimDetailsResponse){
        Excess excess = new Excess();
        String owingAmountStr = retrieveClaimDetailsResponse.path("claim.applicable_excess.amount_owing.amount").toString();
        String owingAmountCurrency = retrieveClaimDetailsResponse.path("claim.applicable_excess.amount_owing.currency").toString();
        Amount owingAmount = new Amount();
        owingAmount.setAmount(new BigDecimal(owingAmountStr));
        owingAmount.setCurrency(owingAmountCurrency);

        String paidAmountStr = retrieveClaimDetailsResponse.path("claim.applicable_excess.amount_paid.amount").toString();
        Amount paidAmount = new Amount();
        paidAmount.setAmount(new BigDecimal(paidAmountStr));
        paidAmount.setCurrency(owingAmountCurrency);

        String totalAmountStr = retrieveClaimDetailsResponse.path("claim.applicable_excess.total_payable_excess.amount").toString();
        Amount totalAmount = new Amount();
        totalAmount.setAmount(new BigDecimal(totalAmountStr));
        totalAmount.setCurrency(owingAmountCurrency);

        excess.setAmountOwing(owingAmount);
        excess.setAmountPaid(paidAmount);
        excess.setAmountTotal(totalAmount);

        return excess;
    }
}
