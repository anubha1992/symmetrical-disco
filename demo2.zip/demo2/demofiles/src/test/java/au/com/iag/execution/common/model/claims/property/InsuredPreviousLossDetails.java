package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class InsuredPreviousLossDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    private String lossDetails;
    private String lossDate;
    private Amount lossAmount;

    public String getLossDetails() {
        return lossDetails;
    }

    public void setLossDetails(String lossDetails) {
        this.lossDetails = lossDetails;
    }

    public String getLossDate() {
        return lossDate;
    }

    public void setLossDate(String lossDate) {
        this.lossDate = lossDate;
    }

    public Amount getLossAmount() {
        return lossAmount;
    }

    public void setLossAmount(Amount lossAmount) {
        this.lossAmount = lossAmount;
    }
}
