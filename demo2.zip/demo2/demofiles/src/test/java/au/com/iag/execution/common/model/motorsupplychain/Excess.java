package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Excess implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("amount_owing")
    private Amount amountOwing;
    @JsonProperty("amount_paid")
    private Amount amountPaid;
    @JsonProperty("amount_total")
    private Amount amountTotal;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public Amount getAmountOwing() {
        return amountOwing;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Amount getAmountPaid() {
        return amountPaid;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Amount getAmountTotal() {
        return amountTotal;
    }


}