package au.com.iag.execution.common.bindandissue.service;


import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueRequest;
import au.com.iag.execution.bindandissueapi.model.business.BindAndIssueResponse;
import au.com.iag.execution.common.builders.security.SecurityTokenBuilder;
import au.com.iag.glados.common.GladosEnrichmentService;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.SecurityService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static org.apache.http.HttpStatus.SC_CREATED;
import static au.com.iag.execution.propertyvaluationapi.model.PropertyValuationsConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static org.apache.http.HttpStatus.SC_OK;

@Service
public class BindAndIssueService {
    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private SecurityService securityService;
    @Autowired private SecurityTokenBuilder securityTokenBuilder;



    private static final String BIND_AND_ISSUE_PATH = "/services/v2/product/policy/bind-and-issue";
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;


    public BindAndIssueResponse executeBindAndIssue(BindAndIssueRequest bindAndIssueRequest) throws JsonProcessingException {
        final Response response = gladosEnrichmentService
                .sendPostRequest(getHeaders(bindAndIssueRequest.getTransactionNumber()), BIND_AND_ISSUE_PATH, bindAndIssueRequest, SC_OK);
        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), BindAndIssueResponse.class);
    }

    public BindAndIssueResponse executeBindAndIssueWithOkta(BindAndIssueRequest bindAndIssueRequest, String userToken) throws JsonProcessingException {
        Map<String, Object> requestHeaders = getHeaders(bindAndIssueRequest.getTransactionNumber());
        requestHeaders.put(X_IAG_AUTH_USER, userToken);
        final Response response = gladosEnrichmentService
                .sendPostRequest(requestHeaders, BIND_AND_ISSUE_PATH, bindAndIssueRequest, SC_OK);
        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), BindAndIssueResponse.class);
    }

    private Map<String, Object> getHeaders(final String quoteId) {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_AUTH_USER, securityTokenBuilder.getAuthAnonymousUserToken(quoteId));
        return requestHeaders;
    }



}
