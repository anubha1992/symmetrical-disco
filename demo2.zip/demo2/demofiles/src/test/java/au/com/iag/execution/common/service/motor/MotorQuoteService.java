package au.com.iag.execution.common.service.motor;

import au.com.iag.execution.common.model.motor.PolicyDetails;
import au.com.iag.execution.common.model.motor.QuoteResponse;
import au.com.iag.execution.common.model.rdm.EnterpriseReferenceDataPayload;
import au.com.iag.glados.common.GladosEnrichmentService;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.SecurityService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static au.com.iag.glados.model.constants.GladosConstants.*;

@Service
public class MotorQuoteService {

    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityService securityService;
    @Autowired private JsonMapperService jsonMapperService;

    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;

    public QuoteResponse createMotorQuote(final PolicyDetails createMotorQuoteRequest, final int expectStatusCode) throws IOException {
        final Response response = gladosEnrichmentService
                .sendPostRequest(getHeaders(), "/services/v2/product/motor/quotes", createMotorQuoteRequest, expectStatusCode);

        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), QuoteResponse.class);
    }

    public QuoteResponse offerMotorQuote(final PolicyDetails offerMotorQuoteRequest, final String quoteNumber, final int expectStatusCode) throws IOException {
        final Response response = gladosEnrichmentService
                .sendPutRequest(getHeaders(), "/services/v2/product/motor/quotes/" + quoteNumber + "/offer", offerMotorQuoteRequest, expectStatusCode);

        final ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        return objectMapper.readValue(objectMapper.writeValueAsString(response.jsonPath().get()), QuoteResponse.class);
    }

    private Map<String, Object> getHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        return requestHeaders;
    }
}
