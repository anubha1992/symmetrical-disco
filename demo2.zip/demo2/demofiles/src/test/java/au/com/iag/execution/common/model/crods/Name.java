package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Name{

	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("middleName")
	private String middleName;

	@JsonProperty("preferredName")
	private String preferredName;

	@JsonProperty("title")
	private String title;

	public void setFirstName(String firstName){
		this.firstName = firstName;
	}

	public String getFirstName(){
		return firstName;
	}

	public void setLastName(String lastName){
		this.lastName = lastName;
	}

	public String getLastName(){
		return lastName;
	}

	public void setMiddleName(String middleName){
		this.middleName = middleName;
	}

	public String getMiddleName(){
		return middleName;
	}

	public void setPreferredName(String preferredName){
		this.preferredName = preferredName;
	}

	public String getPreferredName(){
		return preferredName;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return title;
	}

	@Override
 	public String toString(){
		return 
			"Name{" + 
			"firstName = '" + firstName + '\'' + 
			",lastName = '" + lastName + '\'' + 
			",middleName = '" + middleName + '\'' + 
			",preferredName = '" + preferredName + '\'' + 
			",title = '" + title + '\'' + 
			"}";
		}
}