package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PaymentTransaction implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("amount")
    private Double amount ;
    @JsonProperty("decline_category")
    private String declineCategory ;
    @JsonProperty("receipt_number")
    private String receiptNumber ;
    @JsonProperty("transaction_date")
    private java.time.LocalDate transactionDate ;
    @JsonProperty("transaction_result")
    private String transactionResult ;

  
    @ApiModelProperty(
        value = "The payment amount",
        example = "1500.0",
        required = false
    )
    public Double getAmount() {
       return amount;
    }
 
    @ApiModelProperty(
        value = "The payment transaction decline category [Ref Data: payment_transaction_decline_category]",
        example = "INSUFFICIENT_FUND",
        required = false
    )
    public String getDeclineCategory() {
       return declineCategory;
    }
 
    @ApiModelProperty(
        value = "The receipt number for this payment transaction",
        example = "840848888",
        required = false
    )
    public String getReceiptNumber() {
       return receiptNumber;
    }
 
    @ApiModelProperty(
        value = "The payment transaction date",
        example = "2019-12-31",
        required = false
    )
    public java.time.LocalDate getTransactionDate() {
       return transactionDate;
    }
 
    @ApiModelProperty(
        value = "The payment transaction result [Ref Data: payment_transaction_result]",
        example = "DECLINED",
        required = false
    )
    public String getTransactionResult() {
       return transactionResult;
    }
 

}