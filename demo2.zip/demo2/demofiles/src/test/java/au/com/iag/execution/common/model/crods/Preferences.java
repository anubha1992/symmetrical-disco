package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Preferences{

	@JsonProperty("eDocsConsent")
	private boolean eDocsConsent;

	@JsonProperty("eDocsEmail")
	private String eDocsEmail;

	@JsonProperty("marketingConsentFlag")
	private String marketingConsentFlag;

	@JsonProperty("marketingConsent")
	private boolean marketingConsent;

	@JsonProperty("eDocsConsentDate")
	private String eDocsConsentDate;

	public void setEDocsConsent(boolean eDocsConsent){
		this.eDocsConsent = eDocsConsent;
	}

	public boolean isEDocsConsent(){
		return eDocsConsent;
	}

	public void setEDocsEmail(String eDocsEmail){
		this.eDocsEmail = eDocsEmail;
	}

	public String getEDocsEmail(){
		return eDocsEmail;
	}

	public void setMarketingConsentFlag(String marketingConsentFlag){
		this.marketingConsentFlag = marketingConsentFlag;
	}

	public String getMarketingConsentFlag(){
		return marketingConsentFlag;
	}

	public void setMarketingConsent(boolean marketingConsent){
		this.marketingConsent = marketingConsent;
	}

	public boolean isMarketingConsent(){
		return marketingConsent;
	}

	public void setEDocsConsentDate(String eDocsConsentDate){
		this.eDocsConsentDate = eDocsConsentDate;
	}

	public String getEDocsConsentDate(){
		return eDocsConsentDate;
	}

	@Override
 	public String toString(){
		return 
			"Preferences{" + 
			"eDocsConsent = '" + eDocsConsent + '\'' + 
			",eDocsEmail = '" + eDocsEmail + '\'' + 
			",marketingConsentFlag = '" + marketingConsentFlag + '\'' + 
			",marketingConsent = '" + marketingConsent + '\'' + 
			",eDocsConsentDate = '" + eDocsConsentDate + '\'' + 
			"}";
		}
}