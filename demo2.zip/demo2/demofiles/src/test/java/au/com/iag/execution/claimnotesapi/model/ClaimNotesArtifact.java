package au.com.iag.execution.claimnotesapi.model;

import au.com.iag.execution.claimnotesapi.model.business.*;
import lombok.Data;
import java.util.*;

@Data
public class ClaimNotesArtifact {
    private Map<String, Object> headers;
    private String path;
    private ClaimNotesRequest claimNotesRequest;
}
