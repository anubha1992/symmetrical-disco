package au.com.iag.execution.bindandissueapi;

import au.com.iag.execution.bindandissueapi.builders.BindAndIssueRequestBuilder;

import au.com.iag.execution.bindandissueapi.configuration.BindAndIssueConfiguration;
import au.com.iag.execution.bindandissueapi.configuration.PropertyOverrideContextInitializer;

import au.com.iag.execution.bindandissueapi.model.BindAndIssueArtifact;
import au.com.iag.execution.bindandissueapi.model.ErrorMapper;

import au.com.iag.execution.bindandissueapi.service.BindAndIssueService;

import au.com.iag.execution.bindandissueapi.verifiers.BindAndIssueVerifier;
import au.com.iag.execution.bindandissueapi.verifiers.ErrorMessageVerifier;


import au.com.iag.execution.bindandissueapi.verifiers.SessionAffinityVerifier;
import au.com.iag.execution.common.builders.security.SecurityTokenBuilder;
import au.com.iag.glados.common.GladosRunnerExtension;

import io.restassured.response.Response;

import org.apache.http.HttpStatus;

import org.junit.jupiter.api.*;

import org.junit.jupiter.api.extension.ExtendWith;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.context.ContextConfiguration;

import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static au.com.iag.glados.model.constants.GladosConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_SESSION_ID;
import static org.apache.http.HttpStatus.*;

@SpringBootTest()
@ExtendWith({SpringExtension.class, GladosRunnerExtension.class})
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = {BindAndIssueConfiguration.class})
@Tags({@Tag("bind-and-issue")})
@TestInstance(TestInstance.Lifecycle.PER_METHOD)
public class BindAndIssueOperationTest {

    @Autowired private BindAndIssueRequestBuilder bindAndIssueRequestBuilder;
    @Autowired private SecurityTokenBuilder securityTokenBuilder;

    @Autowired private BindAndIssueService bindAndIssueService;

    @Autowired private BindAndIssueVerifier bindAndIssueVerifier;
    @Autowired private ErrorMessageVerifier errorMessageVerifier;
    @Autowired private SessionAffinityVerifier sessionAffinityVerifier;


    private BindAndIssueArtifact bindAndIssueArtifact;

    @BeforeEach
    public void setupEach() throws IOException {
        String motorQuote = bindAndIssueRequestBuilder.createMotorQuote();
        bindAndIssueRequestBuilder.offerMotorQuote(motorQuote);
        bindAndIssueArtifact = bindAndIssueRequestBuilder.setupRequestDefaults(motorQuote);
        bindAndIssueArtifact.getHeaders().put(X_IAG_AUTH_USER, securityTokenBuilder.getAuthAnonymousUserToken(motorQuote));
    }

    @Test
    public void validBindAndIssue() throws IOException {
        // When
        Response response = bindAndIssueService.executeRequest(bindAndIssueArtifact, HttpStatus.SC_OK);

        // Then
        bindAndIssueVerifier.verifyBindAndIssue(response, bindAndIssueArtifact.getBindAndIssueRequest().getTransactionNumber());
    }

    @ParameterizedTest(name = "withSessionId = {0}")
    @ValueSource(strings = {"true", "false"})
    public void verifySessionIdInBindAndIssue(final boolean withSessionId) {
        // Given
        if (withSessionId)
            bindAndIssueArtifact.getHeaders().put(X_IAG_SESSION_ID, X_IAG_SESSION_ID);

        // When
        final Response response = bindAndIssueService.executeRequest(bindAndIssueArtifact, HttpStatus.SC_OK);

        // Then
        final String traceId = response.getHeader(X_B3_TRACE_ID);
        if (withSessionId)
            sessionAffinityVerifier.verifySessionAffinity(
                    traceId,
                    (String) bindAndIssueArtifact.getHeaders().get(X_IAG_SESSION_ID));
        else
            sessionAffinityVerifier.verifySessionAffinity(traceId);
    }

    @Test
    public void validBindAndIssueWithOptionalHeaders() throws IOException {
        // Given
        bindAndIssueArtifact.setHeaders(bindAndIssueRequestBuilder.buildOptionalHeaders());

        // When
        Response response = bindAndIssueService.executeRequest(bindAndIssueArtifact, HttpStatus.SC_OK);

        // Then
        bindAndIssueVerifier.verifyBindAndIssue(response, bindAndIssueArtifact.getBindAndIssueRequest().getTransactionNumber());
    }

    @Test
    public void whenSystemSecurityTokenIsMissing(){
        // Given
        bindAndIssueArtifact.getHeaders().remove(X_IAG_AUTH_CONSUMER_SYSTEM);

        // When
        final Response error = bindAndIssueService.executeRequest(bindAndIssueArtifact, SC_UNAUTHORIZED);

        // Then
        errorMessageVerifier.verifyErrorDetails(error, ErrorMapper.MISSING_SECURITY_TOKEN);
    }

    @Test
    public void whenSystemSecurityTokenIsInvalid() {
        // Given
        bindAndIssueArtifact.getHeaders().put(X_IAG_AUTH_CONSUMER_SYSTEM, "01234");

        // When
        final Response error = bindAndIssueService.executeRequest(bindAndIssueArtifact, SC_UNAUTHORIZED);

        // Then
        errorMessageVerifier.verifyErrorDetails(error, ErrorMapper.INVALID_SECURITY_TOKEN);
    }

    @Test
    public void whenMotorQuoteStatusIsDraft() throws IOException {
        // Given
        final String motorQuote = bindAndIssueRequestBuilder.createMotorQuote();
        bindAndIssueArtifact.getBindAndIssueRequest().setTransactionNumber(motorQuote);

        // When
        final Response error = bindAndIssueService.executeRequest(bindAndIssueArtifact, SC_BAD_REQUEST);

        // Then
        errorMessageVerifier.verifyErrorDetails(error, ErrorMapper.QUOTE_STATUS_DRAFT);
    }

    @Test
    public void whenPaymentInstrumentIsInvalid() throws IOException {
        // Given
        bindAndIssueRequestBuilder
                .offerMotorQuote(bindAndIssueArtifact.getBindAndIssueRequest().getTransactionNumber());
        bindAndIssueArtifact
                .getBindAndIssueRequest()
                .getPayments()
                .getPaymentInstruments()
                .getBankAccountDetails()
                .setBsb("INVALID");

        // When
        final Response error = bindAndIssueService.executeRequest(bindAndIssueArtifact, SC_UNPROCESSABLE_ENTITY);

        // Then
        errorMessageVerifier.verifyPaymentsValidationError(error);
    }
}