package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class DynamicSectionMetadata implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("collections")
    private java.util.List<Collection> collections = new java.util.ArrayList<Collection>();
    @JsonProperty("dynamic_sub_sections")
    private java.util.List<DynamicSubSection> dynamicSubSections = new java.util.ArrayList<DynamicSubSection>();
    @JsonProperty("fields")
    private java.util.List<FieldMetadata> fields = new java.util.ArrayList<FieldMetadata>();
    @JsonProperty("ref_id")
    private String refId ;
    @JsonProperty("ref_name")
    private String refName ;

  
    @ApiModelProperty(
        value = "Optional. Link to the definition of collection content.",
        required = false
    )
    public java.util.List<Collection> getCollections() {
       return collections;
    }
 
    @ApiModelProperty(
        value = "Optional. Link to the definition of referenced subsections.",
        required = false
    )
    public java.util.List<DynamicSubSection> getDynamicSubSections() {
       return dynamicSubSections;
    }
 
    @ApiModelProperty(
        value = "The list of fields/questions for this section",
        required = false
    )
    public java.util.List<FieldMetadata> getFields() {
       return fields;
    }
 
    @ApiModelProperty(
        value = "Identifier that is used to tie the dynamic section to an object instance.",
        required = false
    )
    public String getRefId() {
       return refId;
    }
 
    @ApiModelProperty(
        value = "The reference name of the section. All &#x27;section_ref&#x27; values reference a sections &#x27;ref_name&#x27;",
        required = false
    )
    public String getRefName() {
       return refName;
    }
 

}