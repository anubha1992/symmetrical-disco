package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class VehicleIncident extends Incident {

    private Driver driver;
    private Boolean vehicleParked;
    private Boolean safeToDrive;
    private Boolean vehicleTowed;
    private Boolean towingRequired;
    private Boolean windscreenDamageOnly;
    private DamageArea damageArea;
    private Boolean noDamage;

    private Boolean vehicleModified;
    private List<VehicleModificationDetails> vehicleModificationDetails = new ArrayList<>();
    private Vehicle vehicle;

    private String alcoholDrugsConsumed;
    private Integer numberOfAlcoholicDrinks;
    private String alcoholReading;
    private String typeOfAlcoholConsumed;
    private String whenWasAlcoholConsumed;
    private String amountOfAlcoholConsumed;
    private Boolean alcoholOrDrugsUsed;
    private Boolean drivingConvictionExists;
    private List<DrivingConvictionDetails> drivingConvictionDetails = new ArrayList<>();

    private Boolean thirdPartyVehicleInsured;
    private String thirdPartyInsuranceDetails;

    public String getFrontWindscreenDamageOnly() {
        return frontWindscreenDamageOnly;
    }

    public void setFrontWindscreenDamageOnly(String frontWindscreenDamageOnly) {
        this.frontWindscreenDamageOnly = frontWindscreenDamageOnly;
    }

    private String frontWindscreenDamageOnly;

    private Boolean policeSampleRequired;

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public Boolean isVehicleParked() {
        return vehicleParked;
    }

    public void setVehicleParked(Boolean vehicleParked) {
        this.vehicleParked = vehicleParked;
    }

    public Boolean isSafeToDrive() {
        return safeToDrive;
    }

    public void setSafeToDrive(Boolean safeToDrive) {
        this.safeToDrive = safeToDrive;
    }

    public Boolean isVehicleTowed() {
        return vehicleTowed;
    }

    public void setVehicleTowed(Boolean vehicleTowed) {
        this.vehicleTowed = vehicleTowed;
    }

    public Boolean isTowingRequired() {
        return towingRequired;
    }

    public void setTowingRequired(Boolean towingRequired) {
        this.towingRequired = towingRequired;
    }

    public Boolean isNoDamage() {
        return noDamage;
    }

    public void setNoDamage(Boolean noDamage) {
        this.noDamage = noDamage;
    }

    public DamageArea getDamageArea() {
        return damageArea;
    }

    public void setDamageArea(DamageArea damageArea) {
        this.damageArea = damageArea;
    }

    public Boolean getVehicleModified() {
        return vehicleModified;
    }

    public void setVehicleModified(Boolean vehicleModified) {
        this.vehicleModified = vehicleModified;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Boolean isWindscreenDamageOnly() {
        return windscreenDamageOnly;
    }

    public void setWindscreenDamageOnly(Boolean windscreenDamageOnly) {
        this.windscreenDamageOnly = windscreenDamageOnly;
    }

    public String getAlcoholDrugsConsumed() {
        return alcoholDrugsConsumed;
    }

    public void setAlcoholDrugsConsumed(String alcoholDrugsConsumed) {
        this.alcoholDrugsConsumed = alcoholDrugsConsumed;
    }

    public Integer getNumberOfAlcoholicDrinks() {
        return numberOfAlcoholicDrinks;
    }

    public void setNumberOfAlcoholicDrinks(Integer numberOfAlcoholicDrinks) {
        this.numberOfAlcoholicDrinks = numberOfAlcoholicDrinks;
    }

    public String getAlcoholReading() {
        return alcoholReading;
    }

    public void setAlcoholReading(String alcoholReading) {
        this.alcoholReading = alcoholReading;
    }

    public String getTypeOfAlcoholConsumed() {
        return typeOfAlcoholConsumed;
    }

    public void setTypeOfAlcoholConsumed(String typeOfAlcoholConsumed) {
        this.typeOfAlcoholConsumed = typeOfAlcoholConsumed;
    }

    public String getWhenWasAlcoholConsumed() {
        return whenWasAlcoholConsumed;
    }

    public void setWhenWasAlcoholConsumed(String whenWasAlcoholConsumed) {
        this.whenWasAlcoholConsumed = whenWasAlcoholConsumed;
    }

    public String getAmountOfAlcoholConsumed() {
        return amountOfAlcoholConsumed;
    }

    public void setAmountOfAlcoholConsumed(String amountOfAlcoholConsumed) {
        this.amountOfAlcoholConsumed = amountOfAlcoholConsumed;
    }

    public Boolean isAlcoholOrDrugsUsed() {
        return alcoholOrDrugsUsed;
    }

    public void setAlcoholOrDrugsUsed(Boolean alcoholOrDrugsUsed) {
        this.alcoholOrDrugsUsed = alcoholOrDrugsUsed;
    }

    public List<VehicleModificationDetails> getVehicleModificationDetails() {
        return vehicleModificationDetails;
    }

    public void setVehicleModificationDetails(List<VehicleModificationDetails> vehicleModificationDetails) {
        this.vehicleModificationDetails = vehicleModificationDetails;
    }

    public Boolean isDrivingConvictionExists() {
        return drivingConvictionExists;
    }

    public void setDrivingConvictionExists(Boolean drivingConvictionExists) {
        this.drivingConvictionExists = drivingConvictionExists;
    }

    public List<DrivingConvictionDetails> getDrivingConvictionDetails() {
        return drivingConvictionDetails;
    }

    public Boolean isThirdPartyVehicleInsured() {
        return thirdPartyVehicleInsured;
    }

    public void setThirdPartyVehicleInsured(Boolean thirdPartyVehicleInsured) {
        this.thirdPartyVehicleInsured = thirdPartyVehicleInsured;
    }

    public String getThirdPartyInsuranceDetails() {
        return thirdPartyInsuranceDetails;
    }

    public void setThirdPartyInsuranceDetails(String thirdPartyInsuranceDetails) {
        this.thirdPartyInsuranceDetails = thirdPartyInsuranceDetails;
    }

    public Boolean getPoliceSampleRequired() {
        return policeSampleRequired;
    }

    public void setPoliceSampleRequired(Boolean policeSampleRequired) {
        this.policeSampleRequired = policeSampleRequired;
    }
}