package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class Address implements Serializable {

    private static final long serialVersionUID = 1L;

    private String addressLineOne;
    private String addressLineTwo;
    private String addressLineThree;
    private String suburb;
    private String postcode;
    private String state;
    private String country;
    private String city;
    private String description;
    private String identifier;
}
