package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.As.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.*;
import java.io.*;

@Data
@ApiModel(description = "Party information")
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
@JsonTypeInfo(use = NAME, property = "party_type", visible = true, include = EXISTING_PROPERTY)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Person.class, name = "Person"),
        @JsonSubTypes.Type(value = Person.class, name = "PERSON"),
        @JsonSubTypes.Type(value = Person.class, name = "person"),
        @JsonSubTypes.Type(value = Organisation.class, name = "Organisation"),
        @JsonSubTypes.Type(value = Organisation.class, name = "ORGANISATION"),
        @JsonSubTypes.Type(value = Organisation.class, name = "organisation")
})
public class Party implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("contact_details")
    private java.util.List<ContactDetails> contactDetails;
    @JsonProperty("party_type")
    private String partyType;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public java.util.List<ContactDetails> getContactDetails() {
        return contactDetails;
    }

    @ApiModelProperty(
            value = "Party type. Select either Person or Organisation",
            example = "Person",
            required = false
    )
    public String getPartyType() {
        return partyType;
    }


}