package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class Contact implements Serializable {

    private static final long serialVersionUID = 1L;

    private String mobile;
    private String work;
    private String home;
    private String email;
    private String teamEmail;
    private String teamPhone;
    private String preferredContact;
    private Address address;
    private Boolean allowEmailNotification;
    private Boolean allowSmsNotification;
    private String referenceNumber;
}
