package au.com.iag.execution.common.model.crods;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EmailAddressesItem{

	@JsonProperty("note")
	private String note;

	@JsonProperty("emailAddress")
	private String emailAddress;

	@JsonProperty("purposes")
	private List<String> purposes;

	@JsonProperty("effectiveToDate")
	private String effectiveToDate;

	@JsonProperty("emailAddressKey")
	private String emailAddressKey;

	@JsonProperty("effectiveFromDate")
	private String effectiveFromDate;

	public void setNote(String note){
		this.note = note;
	}

	public String getNote(){
		return note;
	}

	public void setEmailAddress(String emailAddress){
		this.emailAddress = emailAddress;
	}

	public String getEmailAddress(){
		return emailAddress;
	}

	public void setPurposes(List<String> purposes){
		this.purposes = purposes;
	}

	public List<String> getPurposes(){
		return purposes;
	}

	public void setEffectiveToDate(String effectiveToDate){
		this.effectiveToDate = effectiveToDate;
	}

	public String getEffectiveToDate(){
		return effectiveToDate;
	}

	public void setEmailAddressKey(String emailAddressKey){
		this.emailAddressKey = emailAddressKey;
	}

	public String getEmailAddressKey(){
		return emailAddressKey;
	}

	public void setEffectiveFromDate(String effectiveFromDate){
		this.effectiveFromDate = effectiveFromDate;
	}

	public String getEffectiveFromDate(){
		return effectiveFromDate;
	}

	@Override
 	public String toString(){
		return 
			"EmailAddressesItem{" + 
			"note = '" + note + '\'' + 
			",emailAddress = '" + emailAddress + '\'' + 
			",purposes = '" + purposes + '\'' + 
			",effectiveToDate = '" + effectiveToDate + '\'' + 
			",emailAddressKey = '" + emailAddressKey + '\'' + 
			",effectiveFromDate = '" + effectiveFromDate + '\'' + 
			"}";
		}
}