package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class Assessor {
    @ApiModelProperty(
            value = "Assessor User Id",
            example = "EXT12345")
    private String assessorId;
    @ApiModelProperty(
            value = "Assessors name",
            example = "Bob Assessor")
    private String assessorName;
    @ApiModelProperty(
            value = "Assessors email address",
            example = "Bill@Assessment.abc.xyz")
    private String assessorEmail;
    @ApiModelProperty(
            value = "Assessor Mobile phone number",
            example = "123446444")
    private String assessorMobile;
    @ApiModelProperty(
            value = "Assessor Company",
            example = "AAMC")
    private String assessorCompany;

}
