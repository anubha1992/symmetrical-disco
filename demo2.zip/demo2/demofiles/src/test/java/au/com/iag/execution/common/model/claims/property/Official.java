package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)

public class Official extends Party {

    private String officialType;
    private List<OrganisationName>
            organisationName;

    public String getOfficialType() {
        return officialType;
    }

    public void setOfficialType(String officialType) {
        this.officialType = officialType;
    }

    public List<OrganisationName> getOrganisationName() {
        return organisationName;
    }

    public void setOrganisationName(List<OrganisationName> organisationName) {
        this.organisationName = organisationName;
    }
}
