package au.com.iag.execution.common.service.notifyapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.iag.execution.notifyapi.model.NotifyRequestArtifact;
import au.com.iag.glados.common.GladosEnrichmentService;
import io.restassured.response.Response;

@Service
public class NotifyPolicyUpdateService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    public Response executePolicyUpdate(
            final NotifyRequestArtifact requestArtifact,
            int expectStatusCode) {

        return gladosEnrichmentService.sendPostRequest(
                requestArtifact.getHeaders(),
                requestArtifact.getPath(),
                requestArtifact.getRequest(),
                expectStatusCode);
    }

}
