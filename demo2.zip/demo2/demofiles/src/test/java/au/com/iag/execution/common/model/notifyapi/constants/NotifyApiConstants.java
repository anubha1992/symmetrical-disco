package au.com.iag.execution.common.model.notifyapi.constants;

import java.time.format.DateTimeFormatter;

public final class NotifyApiConstants {

    public static final String HEADER = "header";

    //IAG Headers
    public static final String X_IAG_USER_ID = "X-Iag-User";
    public static final String X_IAG_AGENT_ID = "X-Iag-Agent-Id";
    public static final String X_IAG_OPERATION = "X-Iag-Operation";
    public static final String X_B3_TRACE_ID = "X-B3-TraceId";
    public static final String X_IAG_TRACE_ID = "X-Iag-Trace-Id";
    public static final String X_B3_SPAN_ID = "X-B3-SpanId";
    public static final String X_B3_PARENT_SPAN_ID = "X-B3-ParentSpanId";
    public static final String X_IAG_SESSION = "X-Iag-Session-Id";
    public static final String X_IAG_BRAND = "X-Iag-Brand";
    public static final String X_IAG_DISTRIBUTOR = "X-Iag-Distributor";
    public static final String X_IAG_CHANNEL = "X-Iag-Channel";
    public static final String X_IAG_CONSUMING_SYSTEM = "X-Iag-Consumer-System";
    public static final String X_IAG_PRODUCT = "X-Iag-Product";
    public static final String X_IAG_DATE = "X-Iag-Date";
    public static final String X_IAG_USER_ALIASES = "X-Iag-User-Aliases";
    public static final String X_IAG_USER_PROFILE = "X-Iag-User-Profile";
    public static final String X_IAG_CONSUMER_HOST_ID = "X-Iag-Consumer-Host-Id";
    public static final String X_IAG_BUSINESS_SOURCE = "X-Iag-Business-Source";

    // Asset Type Constants
    public static final String MOTOR_VEHICLE = "MOTOR_VEHICLE";
    public static final String HOME = "HOME";

    // Product Type Constants
    public static final String MOTOR_PRODUCT = "MOTOR_INSURANCE";
    public static final String HOME_PRODUCT = "HOME_INSURANCE";
    public static final String MOTORCYCLE_PRODUCT = "MOTORCYCLE_INSURANCE";
    public static final String CARAVAN_PRODUCT = "CARAVAN_INSURANCE";
    public static final String TRAILER_PRODUCT = "TRAILER_INSURANCE";
    public static final String BOAT_PRODUCT = "BOAT_INSURANCE";
    public static final String CLASSIC_PRODUCT = "CLASSIC_INSURANCE";

    // Product mapping crods
    public static final String NICHE_PRODUCT_CRODS = "NICHE";
    public static final String HOME_PRODUCT_CRODS = "HOM";
    public static final String MOTOR_PRODUCT_CRODS = "MOT";



    //Party ID constants
    public static final String IAG = "IAG";
    public static final String IAG_ZERO = "IAG000000";


    //HttpStatus codes
    public static final int CODE_401 = 401;
    public static final int CODE_400 = 400;
    public static final int CODE_403 = 403;
    public static final int CODE_404 = 404;
    public static final int CODE_422 = 422;
    public static final int CODE_500 = 500;
    public static final int CODE_200 = 200;
    public static final int CODE_202 = 202;

    public static final String BAD_REQUEST_MESSAGE = "Request Invalid";
    public static final String UNAUTHORIZED_MESSAGE = "Authentication has failed";
    public static final String FORBIDDEN_MESSAGE = "The request is forbidden";
    public static final String NOT_FOUND_MESSAGE = "Not Found";
    public static final String UNPROCESSABLE_ENTITY_MESSAGE = "Request syntax is correct, but request data was unable to satisfy validation.";
    public static final String INTERNAL_SERVER_ERROR_MESSAGE = "Unexpected server error";
    public static final String PARTY_ID_NOT_PROVIDED = "Party Id must be provided";
    public static final String PARTY_ID = "party_id";
    public static final String VERSION_TIMESTAMP = "version_timestamp";
    public static final String VERSION_TIMESTAMP_PROVIDED = "Version timestamp must be provided";


    public static final String X_IAG_AUTH_USER = "X-Iag-Auth-User";
    public static final String X_IAG_UPDATE_AUTH_USER = "X-Iag-Update-Auth-User";

    public static final String SOURCE_SYSTEM_FORBIDDEN =
        "Source System entered is not authorised to use this API. Contact Core Product Platform if access is required.";

    //Swagger constants
    public static final String CONSUMER_SYSTEM_HEADER = "Source System Id. Provided by API team to each API consumer.";
    public static final String CUSTOM_ID_DESCRIPTION = "Customer Id policies are being retrieved for";
    public static final String API_NOTES =
        "This API will return a list of policies for a customer. Includes Third party authorities if specified";
    public static final String API_VALUE = "return policies for customer. Includes Third party authorities if specified";
    public static final String THIRD_PARTY_AUTHORITY = "Includes Third party authorities if specified";

    //Information logs
    public static final String ENTRY_POINT_LOG = "Requested policy summary for customerId: ";
    public static final String COMPLETED_LOG = "Completed policy summary for customerId: ";
    public static final String GENERIC_ERROR_MESSAGE = "Please contact your administrator";
    public static final String JSON_CONVERSION_ERROR = "Could not map json response to object model. Refer to \n";
    public static final DateTimeFormatter HEADER_DATE_TIME_FORMATTER =
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");

    public static final DateTimeFormatter YMD_DATE_PATTERN = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final String AUSTRALIA_MELBOURNE = "Australia/Melbourne";

    //Crods Headers
    public static final String CRODS_USER_PROFILE = "X-CRODS-User-Profile";
    public static final String CRODS_USER_ID = "X-CRODS-User-Id";
    public static final String CRODS_USER_HUON_ID = "X-CRODS-User-HUON-Id";
    public static final String CRODS_USER_LOCATION = "X-CRODS-User-Location";
    public static final String CRODS_REQUESTING_SYSTEM = "X-CRODS-Requesting-System";
    public static final String CRODS_CORELATION_ID = "X-CRODS-Conversation-Id";
    public static final String CRODS_MESSAGE_ID = "X-CRODS-Message-Id";
    public static final String CRODS_DATE = "X-CRODS-Date";
    public static final String CRODS_AUTH_CONSUMER_SYSTEM = "X-Iag-Auth-Consumer-System";

    // Headers value
    public static final String CHANNEL_DIGITAL = "DIGITAL";
    public static final String CHANNEL_ASSISTED = "ASSISTED";
    public static final String CRODS_REQ_SYS_SSC = "SSC";
    public static final String CRODS_REQ_SYS_SCV = "SCV";

    // Error
    public static final String ERROR_NO_CODE_FOUND_FOR_TYPE = "No code found for %s of type %s";

    //Reference Data types
    public static final String REF_TYPE_EFFECTIVE_DATE = "effective_date";
    public static final String REF_TYPE_NAMES = "names";
    public static final String REF_TYPE_BRAND = "brand";
    public static final String REF_TYPE_MANUFACTURER = "manufacturer";
    public static final String REF_TYPE_COVER_TYPE = "cover_type";
    public static final String REF_TYPE_PARTY_ROLE = "party_role";
    public static final String REF_TYPE_BILLING_PLAN = "billing_plan";
    public static final String REF_TYPE_PRODUCT = "product";
    public static final String REF_TYPE_REGO_STATE = "registration_state";
    public static final String REF_TYPE_ADDR_LOCATION_TYPES = "address_location_types";
    public static final String REF_TYPE_ADDR_TYPES = "address_types";
    public static final String REF_TYPE_RISK_TYPES = "asset_type";
    public static final String REF_TYPE_QUOTE_STATUS = "quote_status";

    public static final String SOURCE_SYSTEM_MDM = "MDM";
    public static final String ADDRESS_TYPE_MAILING = "MAIL";
    public static final String SOURCE_SYSTEM = "GPC";

    public static final String POLICY_HOLDER = "PRIMARY_POLICY_HOLDER";
    public static final String ADDITIONAL_POLICY_HOLDER = "ADDITIONAL_POLICY_HOLDER";
    public static final String DRIVER = "DRIVER";
    public static final String OTHER_PARTY = "OTHER_PARTY";

    public static final String COVER_TYPE_COMPREHENSIVE_SILVER = "COMPREHENSIVE_SILVER";


    private NotifyApiConstants() {
    }
}
