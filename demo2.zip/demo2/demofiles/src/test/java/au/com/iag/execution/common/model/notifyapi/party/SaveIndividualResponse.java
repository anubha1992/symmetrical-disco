package au.com.iag.execution.common.model.notifyapi.party;

import java.io.Serializable;

import au.com.iag.execution.partyapi.model.business.Individual;
import au.com.iag.execution.partyapi.model.business.ValidationError;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class SaveIndividualResponse implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("errors")
    private java.util.List<ValidationError> errors;
    @JsonProperty("individual")
    private Individual individual;

  
    @ApiModelProperty(
        value = "List of validation errors.",
        required = false
    )
    public java.util.List<ValidationError> getErrors() {
       return errors;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public Individual getIndividual() {
       return individual;
    }
 

}