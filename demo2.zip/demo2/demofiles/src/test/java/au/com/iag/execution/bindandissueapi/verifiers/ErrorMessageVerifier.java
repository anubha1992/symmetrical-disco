package au.com.iag.execution.bindandissueapi.verifiers;

import au.com.iag.execution.bindandissueapi.model.ErrorMapper;
import au.com.iag.execution.motorapi.model.business.ValidationMessage;

import au.com.iag.glados.service.JsonMapperService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.assertj.core.api.SoftAssertions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@Component
public class ErrorMessageVerifier {

    @Autowired private JsonMapperService jsonMapperService;

    public void verifyErrorDetails(final Response response, ErrorMapper errorMapper) {
        Map<String, Object> FailureMessage = getFailureMessage(response);

        final SoftAssertions softly = new SoftAssertions();

        softly.assertThat(FailureMessage.get("message").toString())
                .as("Assert -> errorMessage")
                .contains(errorMapper.getValue());

        softly.assertThat(FailureMessage.get("trace_id").toString())
                .as("Assert -> errorTraceId")
                .isNotBlank();

        softly.assertAll();
    }

    public void verifyPaymentsValidationError(final Response response) throws IOException {
        List<ValidationMessage> actualValidationMessages = getActualValidationMessages(response);
        assertThat(actualValidationMessages.stream().map(ValidationMessage::getDescription)
                .anyMatch(description -> description.contains("BSB Number  is not valid : INVALID")))
                .as("Assert -> ValidationMessage:description")
                .isTrue();
    }

    private List<ValidationMessage> getActualValidationMessages(final Response response) throws IOException {
        final ObjectMapper mapper = jsonMapperService.getObjectMapper();
        final String validationMessages = mapper.writeValueAsString(response.path("validation_messages"));
        return mapper.readValue(validationMessages,
                mapper.getTypeFactory().constructCollectionType(ArrayList.class, ValidationMessage.class));
    }

    private Map<String, Object> getFailureMessage(final Response response) {
        return response.path("");
    }

}
