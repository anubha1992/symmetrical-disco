package au.com.iag.execution.common.service.crods;

import au.com.iag.execution.common.model.crods.CrodsCustomer;
import au.com.iag.glados.common.GladosEnrichmentService;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import au.com.iag.glados.service.SecurityService;
import io.restassured.response.Response;
import io.swagger.models.HttpMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.USER_SC_APP_ADMIN;
import static au.com.iag.glados.model.constants.GladosConstants.*;

@Service
public class CrodsService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityService securityService;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;

    @Value("${correspondence.tracker.url}")
    private String correspondenceTrackerUrl;
    @Value("${test.security.consumer}")
    private String consumerSystem;
    @Value("${test.security.provider}")
    private String providerSystem;
    @Value("${test.api.brand}")
    private String brand;

    private static final String CREATE_CUSTOMER_PATH = "/CRODS_R3_Web/api/customer/";

    public String createCustomer(String effectiveDate, String expiryDate, String reviewDate, String referralStatus, int statusCode) throws IOException {
        String url = correspondenceTrackerUrl+CREATE_CUSTOMER_PATH;
        CrodsCustomer crodsCustomer = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/policy-documents-api/createCrodsIndividualRequest.json")
                        , CrodsCustomer.class);
        crodsCustomer.getSecurityAssessment().setEffectiveDate(effectiveDate);
        crodsCustomer.getSecurityAssessment().setExpiryDate(expiryDate);
        crodsCustomer.getSecurityAssessment().setReviewDate(reviewDate);
        crodsCustomer.getSecurityAssessment().setReferredDeclined(referralStatus);
        Response response = gladosEnrichmentService.sendRequestToCustomHost(buildHeaders(), url
                , null, new HashMap<>(), crodsCustomer, statusCode, HttpMethod.POST.name());
        return "IAG000000"+response.as(CrodsCustomer.class).getSourceSystemParties().get(0).getPartyIdentifier().getPartyId();
    }

    private Map<String, Object> buildHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_USER, USER_SC_APP_ADMIN);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM,
                securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put("X-CRODS-User-Id", "S45673");
        requestHeaders.put("X-CRODS-Requesting-System", "ORBIT");
        requestHeaders.put("X-CRODS-User-HUON-Id", "PGZ854");
        requestHeaders.put("X-CRODS-User-Profile", "IAGSM");
        requestHeaders.put("X-CRODS-User-Location", "CIT");
        requestHeaders.put("X-CRODS-Date", getCrodsHeaderDate());
        return requestHeaders;
    }

    private String getCrodsHeaderDate() {
        LocalDateTime ldt = LocalDateTime.now().minusYears(3);
        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC);
        return zdt.toString();
    }
}
