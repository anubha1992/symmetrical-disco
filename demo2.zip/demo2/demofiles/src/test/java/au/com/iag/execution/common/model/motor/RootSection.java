package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class RootSection implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("name")
    private String name ;
    @JsonProperty("section_ref")
    private String sectionRef ;

  
    @ApiModelProperty(
        value = "the name of the root section as it appears in the data structure.",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "The reference to the section&amp;#x27;s reference name.",
        required = false
    )
    public String getSectionRef() {
       return sectionRef;
    }
 

}