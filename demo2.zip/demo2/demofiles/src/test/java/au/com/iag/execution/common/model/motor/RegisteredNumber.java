package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class RegisteredNumber implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("number")
    private String number ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "The registered number such as ABN number value",
        example = "123 455 678",
        required = false
    )
    public String getNumber() {
       return number;
    }
 
    @ApiModelProperty(
        value = "Type of registered number. [Ref Data: organisation_registration_types]",
        example = "ABN",
        required = false
    )
    public String getType() {
       return type;
    }
 

}