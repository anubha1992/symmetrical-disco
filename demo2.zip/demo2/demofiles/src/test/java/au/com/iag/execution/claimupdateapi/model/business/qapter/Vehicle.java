package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class Vehicle {

    private String make;
    private String model;
    private String registration;
    private String registrationState;
    private String salvageState;
    private String vehicleStyle;
    private String vin;
    private String year;


    @ApiModelProperty(
            value = "vehicle make (brand)",
            example = "Toyota",
            required = false
    )
    public String getMake() {
        return make;
    }

    @ApiModelProperty(
            value = "vehicle model",
            example = "Camry",
            required = false
    )
    public String getModel() {
        return model;
    }

    @ApiModelProperty(
            value = "registration identifier - number plate",
            example = "TTY414",
            required = false
    )
    public String getRegistration() {
        return registration;
    }

    @ApiModelProperty(
            value = "stat where vehicle is registered",
            example = "VIC",
            required = false
    )
    public String getRegistrationState() {
        return registrationState;
    }

    @ApiModelProperty(
            value = "state where vehicle is registered",
            example = "VIC",
            required = false
    )
    public String getSalvageState() {
        return salvageState;
    }


    @ApiModelProperty(
            value = "type / style of vehicle https://confluence.iag.com.au/display/GICP/CC+Vehicle+Style",
            example = "Motor home",
            required = false
    )
    public String getVehicleStyle() {
        return vehicleStyle;
    }

    @ApiModelProperty(
            value = "vehicle identification number",
            example = "2132134457678",
            required = false
    )
    public String getVin() {
        return vin;
    }

    @ApiModelProperty(
            value = "vehicle year of manufacture",
            example = "2001",
            required = false
    )
    public String getYear() {
        return year;
    }

}

