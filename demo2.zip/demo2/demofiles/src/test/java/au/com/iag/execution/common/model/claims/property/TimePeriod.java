package au.com.iag.execution.common.model.claims.property;

import java.io.*;
import java.time.*;

public class TimePeriod implements Serializable {

    private static final long serialVersionUID = 1L;

    private OffsetDateTime startDate;
    private OffsetDateTime endDate;

    public OffsetDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(OffsetDateTime startDate) {
        this.startDate = startDate;
    }

    public OffsetDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(OffsetDateTime endDate) {
        this.endDate = endDate;
    }
}
