package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.As.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonTypeInfo(use = NAME, include = PROPERTY, property = "loss_items", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = LossEstimateItem.class, name = "Loss_Estimate_Item_Content")
})
public class LossEstimateItemContent extends LossEstimateItem {

    @JsonProperty("The Loss Item’s Age")
    private Integer age;

/*    @ApiModelProperty(example = "integer", value = "The Loss Item’s Age", required = false)
    private Integer age;*/

    @JsonProperty("The Loss Item’s Brand")
    private String brand;

//    @ApiModelProperty(example = "string", value = "The Loss Item’s Brand", required = true)
//    private String brand;

    @JsonProperty("The Loss Item contents category")
    private String contentsCategory;

//    @ApiModelProperty(example = "string", value = "The Loss Item contents category", required = true)
//    private String contentsCategory;

    private List<LossEstimateItemFeature> features;

    @JsonProperty("The make of the Loss Item")
    private String make;

//    @ApiModelProperty(example = "string", value = "The make of the Loss Item", required = false)
//    private String make;

    @JsonProperty("The model of the Loss Item")
    private String model;

//    @ApiModelProperty(example = "string", value = "The model of the Loss Item", required = false)
//    private String model;

    @JsonProperty("Verbal Proof")
    private String proofOfOwnershipRequired;

//    @ApiModelProperty(example = "string",
//            value = "Is Proof of Ownership required for the Loss Item - https://confluence.iag.com.au/display/GICP/CC+Proof+Of+Ownership+Required", required = false)
//    private String proofOfOwnershipRequired;

    @JsonProperty("Cash settlement")
    private String settlement;

//    @ApiModelProperty(example = "string", value = "The type of Settlement for the Loss Item - https://confluence.iag.com.au/display/GICP/CC+Settlement", required = false)
//    private String settlement;

    @JsonProperty("The Loss Item contents subcategory")
    private String contentsSubcategory;
//
//    @ApiModelProperty(example = "string", value = "The Loss Item contents subcategory", required = true)
//    private String contentsSubcategory;

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getContentsCategory() {
        return contentsCategory;
    }

    public void setContentsCategory(String contentsCategory) {
        this.contentsCategory = contentsCategory;
    }

    public List<LossEstimateItemFeature> getFeatures() {
        return features;
    }

    public void setFeatures(List<LossEstimateItemFeature> features) {
        this.features = features;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getProofOfOwnershipRequired() {
        return proofOfOwnershipRequired;
    }

    public void setProofOfOwnershipRequired(String proofOfOwnershipRequired) {
        this.proofOfOwnershipRequired = proofOfOwnershipRequired;
    }

    public String getSettlement() {
        return settlement;
    }

    public void setSettlement(String settlement) {
        this.settlement = settlement;
    }

    public String getContentsSubcategory() {
        return contentsSubcategory;
    }

    public void setContentsSubcategory(String contentsSubcategory) {
        this.contentsSubcategory = contentsSubcategory;
    }
}