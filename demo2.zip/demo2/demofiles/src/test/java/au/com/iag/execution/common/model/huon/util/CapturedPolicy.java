package au.com.iag.execution.common.model.huon.util;

import java.util.*;

/**
 * Some common functions for captured policy
 */
public interface CapturedPolicy {
    /**
     * Add a coverage level premium breakdown
     *
     * @param premiumBreakdown
     */
    public void addPremiumBreakdown(PremiumBreakdown premiumBreakdown);

    /**
     * Get the list of all coverage level premium breakdown
     *
     * @return
     */
    public List<PremiumBreakdown> getPremiumBreakdownList();

    /**
     * Set coverage level premium breakdown
     *
     * @param premiumBreakdownList
     */
    public void setPremiumBreakdownList(List<PremiumBreakdown> premiumBreakdownList);

    /**
     * get policy level premium breakdown
     *
     * @return
     */
    public PremiumBreakdown getPolicyPremiumBreakdown();

    public PremiumBreakdown getmonthlyPolicyPremiumBreakdown();

    /**
     * Set policy level premium breakdown
     */
    public void setPolicyPremiumBreakdown(PremiumBreakdown policyPremiumBreakdown);

    public void setmonthlyPolicyPremiumBreakdown(PremiumBreakdown policyPremiumBreakdown);

    /**
     * Add one adjustment points
     *
     * @param adjustmentPoints
     */
    public void addAdjustmentPoints(AdjustmentPoints adjustmentPoints);

    /**
     * Get adjustment points list
     *
     * @return
     */
    public List<AdjustmentPoints> getAdjustmentPointsList();

    /**
     * Set adjustment points list
     *
     * @param adjustmentPointsList
     */
    public void setAdjustmentPointsList(List<AdjustmentPoints> adjustmentPointsList);

    public String getDafMatch();

    public void setDafMatch(String dafMatch);

    public void setpolicyMsgDetails(ArrayList msgDetails);

    public ArrayList getpolicyMsgDetails();

}
