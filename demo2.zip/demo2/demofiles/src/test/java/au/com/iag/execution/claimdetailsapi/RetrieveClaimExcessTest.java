package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.*;
import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_AUTH_USER;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.common.constants.ApiConstants.INVALID_SYSTEM_TOKEN;
import static au.com.iag.execution.common.constants.ApiConstants.INVALID_USER_TOKEN;

import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tags({@Tag("RecoveryJourney"), @Tag("RetrieveClaimTest"), @Tag("ClaimDetails"), @Tag("RetrieveClaimExcessDetailsTest")})
public class RetrieveClaimExcessTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    ClaimDetailService claimDetailService;
    @Autowired
    ClaimsDbService claimsDbService;
    @Autowired
    WimpDbService wimpDbService;
    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    List<Map<String, Object>> claimIdDetails;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;
    private ClaimDetailsArtifact claimDetailsArtifact;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimsHavingServiceRequest(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        setClaimDetailsArtifact(claimDetailsRequestBuilder.setUpRetrieveClaimDetails());
    }

    //Invalid Consumer System
    @Test
    public void inValidSecuritySystemRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_FAILURE);
    }

    //without Consumer System
    @Test
    public void noConsumerSystemRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_SYSTEM);
    }

    @Test
    //AuthenticationAndValidation_02 - without the consumer system Token
    public void noConsumerSystemTokenRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_TOKEN_MISSING);
    }

    @Test
    //AuthenticationAndValidation_03 - Invalid consumer system Token
    public void inValidSystemSecurityTokenRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_SYSTEM_TOKEN);
    }

    @Test
    //AuthenticationAndValidation_04 - expired System Token
    public void expiredSystemSecurityTokenRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJ0ZXN0XzFfd2VlayIsInNjb3BlIjoicjpzeXN0ZW06Q1NTX0NsYWltIHI6dXNlci50eXBlOkN1c3RvbWVyIHI6cG9saWN5Lm5iOkNWVDAyMjA3Nzg5MyByOnBvbGljeU51bWJlcjpDVlQwMjIwNzc4OTMgcjpjbGFpbUlkOkNPTDE5MDAzMjQ5MiByOmJyYW5kOkNPTEVTIiwic3ViIjoieHl6KHVuaWQpQGFub255bW91cyIsIm5vdGFyeSI6Imh0dHBzOlwvXC9hdXRoc2VydmVyLXVhdC5hdWlhZy5jb3JwIiwiZXhwIjoxNTU5MTc4Nzk4LCJpYXQiOjE1NTg1NzM5OTgsImF1ZCI6Imh0dHA6XC9cL2FwcC5hdWlhZy5jb3JwXC9hcGlcLzFcL2xvZGdlQ2xhaW0ifQ.i7FC6JG3SoaE3MMZ0dH4dSKTqZTq7CgJWGvlRknOp8WCMQGUh7eom8qmqQxienS6EjOYJv3_J0DPbec-qwr30Id55hPeMtBKEWR3zL-xCiKvg-GlwBXSQo25l9tOw0JpyCElhOGT7a-gsHBfwn_KZ728U3aI2kxruTMhvcbQD5We6bpxr3HzK8Fub3sh2X23VUbmfEc35X_FvOxWdz1FrOtkCwWfe5NtrL-6bA8NoFgYp1alqNA3XXG3Qsea-SDfxszLAWSJAwwu3jmkXW6TKMzeNFUak7kwn63UvlNjO3RbsA81VdtahGGXDoTAYX0jkVjS4naomtKdlccKNtLAag");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, EXPIRED_SYSTEM_TOKEN);
    }

    //AuthenticationAndValidation_06 - Invalid User Auth Token
    @Test
    public void inValidUserSecurityTokenRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_USER, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_USER_TOKEN);
    }

    //AuthenticationAndValidation_07 - no User Auth Token
    @Test
    public void noUserSecurityTokenRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.remove(X_IAG_AUTH_USER);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, USER_SECURITY_TOKEN_MISSING);
    }

    @Test
    //AuthenticationAndValidation_08 - Expired User Auth Token
    public void expiredUserSecurityTokenRetrieveClaimExcessDetails() {
        ClaimDetailsArtifact claimDetailsArtifact = getClaimDetailsArtifact();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_AUTH_USER, "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJ0ZXN0XzFfd2VlayIsInNjb3BlIjoicjpzeXN0ZW06Q1NTX0NsYWltIHI6dXNlci50eXBlOkN1c3RvbWVyIHI6cG9saWN5Lm5iOkNWVDAyMjA3Nzg5MyByOnBvbGljeU51bWJlcjpDVlQwMjIwNzc4OTMgcjpjbGFpbUlkOkNPTDE5MDAzMjQ5MiByOmJyYW5kOkNPTEVTIiwic3ViIjoieHl6KHVuaWQpQGFub255bW91cyIsIm5vdGFyeSI6Imh0dHBzOlwvXC9hdXRoc2VydmVyLXVhdC5hdWlhZy5jb3JwIiwiZXhwIjoxNTU5MTc4Nzk4LCJpYXQiOjE1NTg1NzM5OTgsImF1ZCI6Imh0dHA6XC9cL2FwcC5hdWlhZy5jb3JwXC9hcGlcLzFcL2xvZGdlQ2xhaW0ifQ.i7FC6JG3SoaE3MMZ0dH4dSKTqZTq7CgJWGvlRknOp8WCMQGUh7eom8qmqQxienS6EjOYJv3_J0DPbec-qwr30Id55hPeMtBKEWR3zL-xCiKvg-GlwBXSQo25l9tOw0JpyCElhOGT7a-gsHBfwn_KZ728U3aI2kxruTMhvcbQD5We6bpxr3HzK8Fub3sh2X23VUbmfEc35X_FvOxWdz1FrOtkCwWfe5NtrL-6bA8NoFgYp1alqNA3XXG3Qsea-SDfxszLAWSJAwwu3jmkXW6TKMzeNFUak7kwn63UvlNjO3RbsA81VdtahGGXDoTAYX0jkVjS4naomtKdlccKNtLAag");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM00000", ""), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, EXPIRED_USER_TOKEN);
    }

    //AuthenticationAndValidation_09 : The request header contains a valid user auth token with a claim_id in the scope that DOES NOT match the claim_id in the request url
    @Test
    public void retrieveClaimExcessDetailsForValidTokenWithDiffClaimId() {
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), "CLAIM00000");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("SGW190140364", ""), SC_UNAUTHORIZED);
        String errorMessage = "CLAIM_ID_SCOPE_NOT_MATCHED";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    //AuthenticationAndValidation_10: the request header contains a valid user auth token WITHOUT a claim_id in the scope
    //AND the postcode parameter has NOT been passed
    @Test
    public void anonymousUserSecurityTokenRetrieveClaimExcessDetails() {
        String claimId = "CLAIM00001";
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), "");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, ""), SC_UNAUTHORIZED);
        String errorMessage = "POSTCODE_MISSING";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    //AuthenticationAndValidation_11:valid user auth token WITHOUT a claim_id in the scope
    //AND postcode parameter has been passed and  matches with neither risk unit nor insured address
    @Test
    public void anonymousUserSecurityTokenPostcodeNoMatchRetrieveClaimExcessDetails() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), "");
        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, "5151"), SC_NOT_FOUND);
    }

    // AuthenticationAndValidation_13 : valid user auth token WITHOUT a claim_id in the scope
    //postcode matches to either risk unit or insured contact address
    @Test
    public void retrieveClaimExcessDetailsForValidTokenWithoutClaimIdInScope() throws Exception {
        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), "");

        List<String> postCodes = retrieveClaimDetailsForExcessDetails(claimId);
        String postCodeTest = postCodes.get(new Random().nextInt(postCodes.size()));
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, postCodeTest), SC_OK);

        claimDetailsVerifier.verifyClaimIdentifier(response, claimId);
        claimDetailsVerifier.verifyClaimDetailsRetrieveClaimDetailsResponse(response);
    }

    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @Test
    public void retrieveClaimExcessDetailsForInvalidClaimWithoutPostcode() {
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), "CLAIM2345");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails("CLAIM2345", ""), SC_NOT_FOUND);
        String errorMessage = "Could not find Claim 'CLAIM2345'";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    //AuthenticationAndValidation_14 : the request header contains a valid user auth token with a claim_id in the scope that
    // matches the claim_id in the request url
    @Test
    public void retrieveClaimExcessDetailsForValidTokenWithoutPostcode() throws Exception {

        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, ""), SC_OK);

        claimDetailsVerifier.verifyClaimIdentifier(response, claimId);
        claimDetailsVerifier.verifyClaimDetailsRetrieveClaimDetailsResponse(response);
    }

    @Test
    public void retrieveClaimExcessDetailsForInvalidPostCode() throws Exception {
        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), "");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, "A353235"), SC_NOT_FOUND);

        String errorMessage = "RESOURCE_NOT_FOUND";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    // AuthenticationAndValidation_13 : valid user auth token WITHOUT a claim_id in the scope
    //postcode matches to either risk unit or insured contact address
    @Test
    public void retrieveClaimExcessDetailsForValidTokenWithoutClaimIdInScopeExternal() throws Exception {
        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.buildClaimDetailsExternal(getClaimDetailsArtifact());
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);

        List<String> postCodes = retrieveClaimDetailsForExcessDetails(claimId);
        String postCodeTest = postCodes.get(new Random().nextInt(postCodes.size()));
        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, postCodeTest), SC_OK);

        claimDetailsVerifier.verifyClaimIdentifier(response, claimId);
        claimDetailsVerifier.verifyClaimDetailsRetrieveClaimDetailsResponse(response);
    }

    @Test
    public void retrieveClaimExcessDetailsForValidTokenWithoutPostcodeExternal() throws Exception {

        String claimId = wimpDbService.ensurePolicyIsInWimpAndReturnClaimId(claimIdDetails, brand);
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.buildClaimDetailsExternal(getClaimDetailsArtifact());
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, ""), SC_OK);

        claimDetailsVerifier.verifyClaimIdentifier(response, claimId);
        claimDetailsVerifier.verifyClaimDetailsRetrieveClaimDetailsResponse(response);
    }

    @Test
    @Disabled
    public void testRetrieveClaimExcessHavingApplicableExcessAmountOwingNull(){
        // JAPI:947 This claim number with applicable excess amount owing null is only available in UAT
        String claimId = "NRA200057123";
        ClaimDetailsArtifact claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(getClaimDetailsArtifact(), claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToRetrieveClaimExcessDetails(claimId, ""), SC_OK);

        claimDetailsVerifier.verifyClaimIdentifier(response, claimId);
        //claimDetailsVerifier.verifyClaimDetailsRetrieveClaimDetailsResponse(response);
    }


    private String createRequestToRetrieveClaimExcessDetails(String claimId, String postCodeTest) {
        StringBuffer url = new StringBuffer();
        url.append("/"+claimId+"/excess");
        if (!(postCodeTest.isEmpty())) {
            url.append("?postcode=" + postCodeTest);
        }
        return url.toString();
    }

    public ClaimDetailsArtifact getClaimDetailsArtifact() {
        return claimDetailsArtifact;
    }

    public void setClaimDetailsArtifact(ClaimDetailsArtifact claimDetailsArtifact) {
        this.claimDetailsArtifact = claimDetailsArtifact;
    }

    private ArrayList<String> retrieveClaimDetailsForExcessDetails(String claimId) throws Exception {

        ClaimDetailsArtifact claimDetailsArtifact1 = claimDetailsRequestBuilder.setUpRetrieveClaimDetails();
        claimDetailsArtifact1 = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact1, claimId);
        String path = claimDetailsArtifact1.getPath();

        path = path + "/get/"+claimId;

        claimDetailsArtifact1.setPath(path);

        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact1, "", SC_OK);
        ArrayList<String> postCodes = new ArrayList<>();
        int incidentsSize = response.jsonPath().getList("claim.incidents").size();
        for(int i=0; i<incidentsSize; i++)
            postCodes.add(response.path("claim.incidents["+i+"].risk_unit.risk_address.postcode"));


        int insuredContactPostcodesSize=response.jsonPath().getList("claim.insured.contact_details").size();
        for(int k=0; k<insuredContactPostcodesSize; k++)
        {
            String postCodeTemp= response.path("claim.insured.contact_details["+k+"].address.postcode");
            if(!(postCodeTemp== null))
                postCodes.add(postCodeTemp);
        }
        return postCodes;

    }

}
