package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Organisation{

	@JsonProperty("tradingName")
	private String tradingName;

	@JsonProperty("name")
	private String name;

	@JsonProperty("type")
	private String type;

	public void setTradingName(String tradingName){
		this.tradingName = tradingName;
	}

	public String getTradingName(){
		return tradingName;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setType(String type){
		this.type = type;
	}

	public String getType(){
		return type;
	}

	@Override
 	public String toString(){
		return 
			"Organisation{" + 
			"tradingName = '" + tradingName + '\'' + 
			",name = '" + name + '\'' + 
			",type = '" + type + '\'' + 
			"}";
		}
}