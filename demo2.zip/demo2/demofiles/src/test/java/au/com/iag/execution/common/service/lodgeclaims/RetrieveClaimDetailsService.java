package au.com.iag.execution.common.service.lodgeclaims;

import au.com.iag.glados.common.*;
import au.com.iag.glados.model.security.*;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.apache.http.HttpStatus.*;
import static org.junit.Assert.*;
import static au.com.iag.execution.common.constants.ApiConstants.X_IAG_OPERATION;
import static au.com.iag.execution.common.constants.ApiConstants.X_IAG_REGION;
import static au.com.iag.execution.common.constants.ApiConstants.X_IAG_USER_PROFILE;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.propertyvaluationapi.model.PropertyValuationsConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.util.*;

@Service
public class RetrieveClaimDetailsService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired
    private SecurityService securityService;

    @Value("${test.api.retrieveclaim.route}")
    private String retriveClaimPath;
    @Value("${test.apigee.retrieveclaim.route}")
    private String retriveClaimPathApigee;
    @Value("${test.api.source.system.brand}")
    private String brand;

    public Response retrieveClaimDetailsByClaimId(String claimId){
        return retrieveClaimDetailsByClaimId(claimId, SC_OK);
    }

    public Response retrieveClaimDetailsByClaimId(String claimId, int expectStatusCode){
        return executeRetrieveClaimDetails(claimId, expectStatusCode);
    }

    private Response executeRetrieveClaimDetails(String claimId, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendGetRequest(
                retrieveClaimDetailsHeader(claimId),
                retriveClaimPath,
                claimId,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Map<String, Object> retrieveClaimDetailsHeader(String claimId){
        Map<String, Object> requestHeaders = getRequestHeaders();
        UserTokenRequestPayload userTokenRequestPayload = buildUserTokenRequestPayload(claimId);
        if (brand.equalsIgnoreCase("NRMA") || brand.equalsIgnoreCase("SGIO") || brand.equalsIgnoreCase("SGIC") || brand.equalsIgnoreCase("RACV")) {
            requestHeaders.put(X_IAG_USER, "WEBNIIP");
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_DISTRIBUTOR, brand);
            requestHeaders.put(X_IAG_OPERATION, "retrievePolicy");
        } else if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI")) {
            requestHeaders.put(X_IAG_USER, "WEBZIIP");
            requestHeaders.put(X_IAG_USER_PROFILE, "IAGNZ");
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_DISTRIBUTOR, "NRMA");
            requestHeaders.put(X_IAG_OPERATION, "retrievePolicy");
            requestHeaders.put(X_IAG_REGION, "NZ");
        }
        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        return requestHeaders;
    }

    private UserTokenRequestPayload buildUserTokenRequestPayload(String claimId){
        UserTokenRequestPayload userTokenRequestPayload = new UserTokenRequestPayload();
        userTokenRequestPayload.setAudience("business-api-provider");
        userTokenRequestPayload.setAuthentication("business-api-provider");
        userTokenRequestPayload.setContext("");
        userTokenRequestPayload.setGrantType("NOTARY");
        userTokenRequestPayload.setIss("");
        userTokenRequestPayload.setName("");
        userTokenRequestPayload.setScope("r:claimId:"+claimId);
        userTokenRequestPayload.setSubject("LAA008C9705F@anonymous");

        return userTokenRequestPayload;

    }

    private Map<String, Object> getRequestHeaders(){
        Map<String, Object> requestHeaders = new HashMap<>();

        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "BAPI");
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(SOURCE_ID, "DC");

        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken("BAPI", "business-api-provider"));
        return requestHeaders;
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }
}
