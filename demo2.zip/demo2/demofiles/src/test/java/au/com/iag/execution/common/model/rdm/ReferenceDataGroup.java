package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ReferenceDataGroup implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("data")
    private java.util.List<ReferenceData> data;
    @JsonProperty("type")
    private String type;

  
    @ApiModelProperty(
        value = "",
        required = false
    )
    public java.util.List<ReferenceData> getData() {
       return data;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public String getType() {
       return type;
    }
 

}