package au.com.iag.execution.common.model.claims.property;

import java.io.*;

public class VariableAmount implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private Amount value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Amount getValue() {
        return value;
    }

    public void setValue(Amount value) {
        this.value = value;
    }
}
