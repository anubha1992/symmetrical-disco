package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class OrganisationName implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("name")
    private String name ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Name of the organisation",
        example = "IAG Pty Ltd.",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "Type of name [Ref Data: organisation_name_types]",
        example = "TRADING",
        required = false
    )
    public String getType() {
       return type;
    }
 

}