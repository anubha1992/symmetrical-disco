package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PostalAddress{

	@JsonProperty("boxLobbyName")
	private String boxLobbyName;

	@JsonProperty("buildingName")
	private String buildingName;

	@JsonProperty("postalType")
	private String postalType;

	@JsonProperty("postalNumber")
	private String postalNumber;

	public void setBoxLobbyName(String boxLobbyName){
		this.boxLobbyName = boxLobbyName;
	}

	public String getBoxLobbyName(){
		return boxLobbyName;
	}

	public void setBuildingName(String buildingName){
		this.buildingName = buildingName;
	}

	public String getBuildingName(){
		return buildingName;
	}

	public void setPostalType(String postalType){
		this.postalType = postalType;
	}

	public String getPostalType(){
		return postalType;
	}

	public void setPostalNumber(String postalNumber){
		this.postalNumber = postalNumber;
	}

	public String getPostalNumber(){
		return postalNumber;
	}

	@Override
 	public String toString(){
		return 
			"PostalAddress{" + 
			"boxLobbyName = '" + boxLobbyName + '\'' + 
			",buildingName = '" + buildingName + '\'' + 
			",postalType = '" + postalType + '\'' + 
			",postalNumber = '" + postalNumber + '\'' + 
			"}";
		}
}