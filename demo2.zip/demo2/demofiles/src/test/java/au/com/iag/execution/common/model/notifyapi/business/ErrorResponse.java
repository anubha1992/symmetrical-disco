package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class ErrorResponse implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("error_code")
    private Integer errorCode;
    @JsonProperty("message")
    private String message;
    @JsonProperty("trace_id")
    private String traceId;

  
    @ApiModelProperty(
        value = "Error Code returned. Possible Values are HTTP Status Codes",
        example = "200, 401, 403, 404, 500, etc....",
        required = false
    )
    public Integer getErrorCode() {
       return errorCode;
    }
 
    @ApiModelProperty(
        value = "Message describing the error that occurred. This message, along with the HTTP code, should always provide enough description to consumers about what has gone wrong.",
        example = "Unauthorised access to API.",
        required = false
    )
    public String getMessage() {
       return message;
    }
 
    @ApiModelProperty(
        value = "Trace Id for the exception scenario based on Zipkin Brave tracing",
        example = "281bcfd8cf392377",
        required = false
    )
    public String getTraceId() {
       return traceId;
    }
 

}