package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class TotalLoss {
    @ApiModelProperty(
            value = "Name of Towing Company. Used also to set salvage towed flag",
            example = "ABC Towing")
    private String towContractorName;
    @ApiModelProperty(
            value = "Towing company/contractor Id",
            example = "ABC123")
    private String towContractorId;
    @ApiModelProperty(
            value = "Total Loss disposal method\n"
                    +
                    "https://confluence.iag.com.au/display/GICP/CC+Vehicle+Disposal+Method",
            example = "Auction House")
    private String disposalMethod;
    @ApiModelProperty(
            value = "salvage condition - total loss type \n"
                    +
                    "https://confluence.iag.com.au/display/GICP/CC+Salvage+Condition",
            example = "statutory write off")
    private String salvageCondition;
    @ApiModelProperty(
            value = "salvage centre id",
            example = "82005")
    private String salvageLocation;
    private Amount vehiclePriorValue;
    private Amount salvageValue;
}
