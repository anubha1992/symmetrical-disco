package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class PropertyServiceRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private String claimIdentifier;

    List<ServiceRequest> serviceRequests;

    public String getClaimIdentifier() {
        return claimIdentifier;
    }

    public void setClaimIdentifier(String claimIdentifier) {
        this.claimIdentifier = claimIdentifier;
    }

    public List<ServiceRequest> getServiceRequests() {
        return serviceRequests;
    }

    public void setServiceRequests(List<ServiceRequest> serviceRequests) {
        this.serviceRequests = serviceRequests;
    }
}
