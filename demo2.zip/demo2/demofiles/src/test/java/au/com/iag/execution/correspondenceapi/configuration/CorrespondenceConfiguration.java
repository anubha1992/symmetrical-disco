package au.com.iag.execution.correspondenceapi.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({
    "au.com.iag.glados*",
    "au.com.iag.execution.correspondenceapi*",
    "au.com.iag.execution.common.service.rdm",
    "au.com.iag.execution.common.service.motor",
    "au.com.iag.execution.common.service.corrotracker"
})
public class CorrespondenceConfiguration {
}
