package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class DocumentsItem implements Serializable {

	@JsonProperty("sourceSystemDocumentId")
	private String sourceSystemDocumentId;

	@JsonProperty("generationTime")
	private String generationTime;

	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@JsonProperty("title")
	private String title;

	public void setSourceSystemDocumentId(String sourceSystemDocumentId){
		this.sourceSystemDocumentId = sourceSystemDocumentId;
	}

	public String getSourceSystemDocumentId(){
		return sourceSystemDocumentId;
	}

	public void setGenerationTime(String generationTime){
		this.generationTime = generationTime;
	}

	public String getGenerationTime(){
		return generationTime;
	}

	public void setSourceSystem(String sourceSystem){
		this.sourceSystem = sourceSystem;
	}

	public String getSourceSystem(){
		return sourceSystem;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return title;
	}

	@Override
 	public String toString(){
		return 
			"DocumentsItem{" + 
			"sourceSystemDocumentId = '" + sourceSystemDocumentId + '\'' + 
			",generationTime = '" + generationTime + '\'' + 
			",sourceSystem = '" + sourceSystem + '\'' + 
			",title = '" + title + '\'' + 
			"}";
		}
}