package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Address{

	@JsonProperty("country")
	private String country;

	@JsonProperty("dpid")
	private String dpid;

	@JsonProperty("postcode")
	private String postcode;

	@JsonProperty("rdNumber")
	private String rdNumber;

	@JsonProperty("internationalAddress")
	private InternationalAddress internationalAddress;

	@JsonProperty("displayAddressLine2")
	private String displayAddressLine2;

	@JsonProperty("displayAddressLine1")
	private String displayAddressLine1;

	@JsonProperty("addressId")
	private int addressId;

	@JsonProperty("localityName")
	private String localityName;

	@JsonProperty("postalAddress")
	private PostalAddress postalAddress;

	@JsonProperty("geoLocation")
	private GeoLocation geoLocation;

	@JsonProperty("streetAddress")
	private StreetAddress streetAddress;

	@JsonProperty("fullAddress")
	private String fullAddress;

	@JsonProperty("townCityName")
	private String townCityName;

	@JsonProperty("attention")
	private String attention;

	@JsonProperty("state")
	private String state;

	public void setCountry(String country){
		this.country = country;
	}

	public String getCountry(){
		return country;
	}

	public void setDpid(String dpid){
		this.dpid = dpid;
	}

	public String getDpid(){
		return dpid;
	}

	public void setPostcode(String postcode){
		this.postcode = postcode;
	}

	public String getPostcode(){
		return postcode;
	}

	public void setRdNumber(String rdNumber){
		this.rdNumber = rdNumber;
	}

	public String getRdNumber(){
		return rdNumber;
	}

	public void setInternationalAddress(InternationalAddress internationalAddress){
		this.internationalAddress = internationalAddress;
	}

	public InternationalAddress getInternationalAddress(){
		return internationalAddress;
	}

	public void setDisplayAddressLine2(String displayAddressLine2){
		this.displayAddressLine2 = displayAddressLine2;
	}

	public String getDisplayAddressLine2(){
		return displayAddressLine2;
	}

	public void setDisplayAddressLine1(String displayAddressLine1){
		this.displayAddressLine1 = displayAddressLine1;
	}

	public String getDisplayAddressLine1(){
		return displayAddressLine1;
	}

	public void setAddressId(int addressId){
		this.addressId = addressId;
	}

	public int getAddressId(){
		return addressId;
	}

	public void setLocalityName(String localityName){
		this.localityName = localityName;
	}

	public String getLocalityName(){
		return localityName;
	}

	public void setPostalAddress(PostalAddress postalAddress){
		this.postalAddress = postalAddress;
	}

	public PostalAddress getPostalAddress(){
		return postalAddress;
	}

	public void setGeoLocation(GeoLocation geoLocation){
		this.geoLocation = geoLocation;
	}

	public GeoLocation getGeoLocation(){
		return geoLocation;
	}

	public void setStreetAddress(StreetAddress streetAddress){
		this.streetAddress = streetAddress;
	}

	public StreetAddress getStreetAddress(){
		return streetAddress;
	}

	public void setFullAddress(String fullAddress){
		this.fullAddress = fullAddress;
	}

	public String getFullAddress(){
		return fullAddress;
	}

	public void setTownCityName(String townCityName){
		this.townCityName = townCityName;
	}

	public String getTownCityName(){
		return townCityName;
	}

	public void setAttention(String attention){
		this.attention = attention;
	}

	public String getAttention(){
		return attention;
	}

	public void setState(String state){
		this.state = state;
	}

	public String getState(){
		return state;
	}

	@Override
 	public String toString(){
		return 
			"Address{" + 
			"country = '" + country + '\'' + 
			",dpid = '" + dpid + '\'' + 
			",postcode = '" + postcode + '\'' + 
			",rdNumber = '" + rdNumber + '\'' + 
			",internationalAddress = '" + internationalAddress + '\'' + 
			",displayAddressLine2 = '" + displayAddressLine2 + '\'' + 
			",displayAddressLine1 = '" + displayAddressLine1 + '\'' + 
			",addressId = '" + addressId + '\'' + 
			",localityName = '" + localityName + '\'' + 
			",postalAddress = '" + postalAddress + '\'' + 
			",geoLocation = '" + geoLocation + '\'' + 
			",streetAddress = '" + streetAddress + '\'' + 
			",fullAddress = '" + fullAddress + '\'' + 
			",townCityName = '" + townCityName + '\'' + 
			",attention = '" + attention + '\'' + 
			",state = '" + state + '\'' + 
			"}";
		}
}