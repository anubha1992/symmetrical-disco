package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class AbstractExclusion implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("selected")
    private Boolean selected ;

  
    @ApiModelProperty(
        value = "Indicates if the exclusion is selected or not",
        example = "true",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Boolean getSelected() {
       return selected;
    }
 

}