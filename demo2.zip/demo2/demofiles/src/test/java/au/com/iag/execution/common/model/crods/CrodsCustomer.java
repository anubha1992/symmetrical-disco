package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class CrodsCustomer{

	@JsonProperty("preferences")
	private Preferences preferences;

	@JsonProperty("temporaryPhone")
	private TemporaryPhone temporaryPhone;

	@JsonProperty("address")
	private Address address;

	@JsonProperty("individual")
	private Individual individual;

	@JsonProperty("homePhone")
	private HomePhone homePhone;

	@JsonProperty("linkIndicator")
	private String linkIndicator;

	@JsonProperty("organisation")
	private Organisation organisation;

	@JsonProperty("customerGroupState")
	private String customerGroupState;

	@JsonProperty("lastModifiedTimestamp")
	private String lastModifiedTimestamp;

	@JsonProperty("phoneNumbers")
	private List<PhoneNumbersItem> phoneNumbers;

	@JsonProperty("legalEntity")
	private String legalEntity;

	@JsonProperty("emailAddresses")
	private List<EmailAddressesItem> emailAddresses;

	@JsonProperty("mobilePhone")
	private MobilePhone mobilePhone;

	@JsonProperty("customerId")
	private int customerId;

	@JsonProperty("securityAssessment")
	private SecurityAssessment securityAssessment;

	@JsonProperty("attributes")
	private Attributes attributes;

	@JsonProperty("workPhone")
	private WorkPhone workPhone;

	@JsonProperty("customerCategory")
	private String customerCategory;

	@JsonProperty("fax")
	private Fax fax;

	@JsonProperty("sourceSystemParties")
	private List<SourceSystemPartiesItem> sourceSystemParties;

	@JsonProperty("email")
	private String email;

	@JsonProperty("status")
	private String status;

	public void setPreferences(Preferences preferences){
		this.preferences = preferences;
	}

	public Preferences getPreferences(){
		return preferences;
	}

	public void setTemporaryPhone(TemporaryPhone temporaryPhone){
		this.temporaryPhone = temporaryPhone;
	}

	public TemporaryPhone getTemporaryPhone(){
		return temporaryPhone;
	}

	public void setAddress(Address address){
		this.address = address;
	}

	public Address getAddress(){
		return address;
	}

	public void setIndividual(Individual individual){
		this.individual = individual;
	}

	public Individual getIndividual(){
		return individual;
	}

	public void setHomePhone(HomePhone homePhone){
		this.homePhone = homePhone;
	}

	public HomePhone getHomePhone(){
		return homePhone;
	}

	public void setLinkIndicator(String linkIndicator){
		this.linkIndicator = linkIndicator;
	}

	public String getLinkIndicator(){
		return linkIndicator;
	}

	public void setOrganisation(Organisation organisation){
		this.organisation = organisation;
	}

	public Organisation getOrganisation(){
		return organisation;
	}

	public void setCustomerGroupState(String customerGroupState){
		this.customerGroupState = customerGroupState;
	}

	public String getCustomerGroupState(){
		return customerGroupState;
	}

	public void setLastModifiedTimestamp(String lastModifiedTimestamp){
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}

	public String getLastModifiedTimestamp(){
		return lastModifiedTimestamp;
	}

	public void setPhoneNumbers(List<PhoneNumbersItem> phoneNumbers){
		this.phoneNumbers = phoneNumbers;
	}

	public List<PhoneNumbersItem> getPhoneNumbers(){
		return phoneNumbers;
	}

	public void setLegalEntity(String legalEntity){
		this.legalEntity = legalEntity;
	}

	public String getLegalEntity(){
		return legalEntity;
	}

	public void setEmailAddresses(List<EmailAddressesItem> emailAddresses){
		this.emailAddresses = emailAddresses;
	}

	public List<EmailAddressesItem> getEmailAddresses(){
		return emailAddresses;
	}

	public void setMobilePhone(MobilePhone mobilePhone){
		this.mobilePhone = mobilePhone;
	}

	public MobilePhone getMobilePhone(){
		return mobilePhone;
	}

	public void setCustomerId(int customerId){
		this.customerId = customerId;
	}

	public int getCustomerId(){
		return customerId;
	}

	public void setSecurityAssessment(SecurityAssessment securityAssessment){
		this.securityAssessment = securityAssessment;
	}

	public SecurityAssessment getSecurityAssessment(){
		return securityAssessment;
	}

	public void setAttributes(Attributes attributes){
		this.attributes = attributes;
	}

	public Attributes getAttributes(){
		return attributes;
	}

	public void setWorkPhone(WorkPhone workPhone){
		this.workPhone = workPhone;
	}

	public WorkPhone getWorkPhone(){
		return workPhone;
	}

	public void setCustomerCategory(String customerCategory){
		this.customerCategory = customerCategory;
	}

	public String getCustomerCategory(){
		return customerCategory;
	}

	public void setFax(Fax fax){
		this.fax = fax;
	}

	public Fax getFax(){
		return fax;
	}

	public void setSourceSystemParties(List<SourceSystemPartiesItem> sourceSystemParties){
		this.sourceSystemParties = sourceSystemParties;
	}

	public List<SourceSystemPartiesItem> getSourceSystemParties(){
		return sourceSystemParties;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	@Override
 	public String toString(){
		return 
			"CrodsCustomer{" + 
			"preferences = '" + preferences + '\'' + 
			",temporaryPhone = '" + temporaryPhone + '\'' + 
			",address = '" + address + '\'' + 
			",individual = '" + individual + '\'' + 
			",homePhone = '" + homePhone + '\'' + 
			",linkIndicator = '" + linkIndicator + '\'' + 
			",organisation = '" + organisation + '\'' + 
			",customerGroupState = '" + customerGroupState + '\'' + 
			",lastModifiedTimestamp = '" + lastModifiedTimestamp + '\'' + 
			",phoneNumbers = '" + phoneNumbers + '\'' + 
			",legalEntity = '" + legalEntity + '\'' + 
			",emailAddresses = '" + emailAddresses + '\'' + 
			",mobilePhone = '" + mobilePhone + '\'' + 
			",customerId = '" + customerId + '\'' + 
			",securityAssessment = '" + securityAssessment + '\'' + 
			",attributes = '" + attributes + '\'' + 
			",workPhone = '" + workPhone + '\'' + 
			",customerCategory = '" + customerCategory + '\'' + 
			",fax = '" + fax + '\'' + 
			",sourceSystemParties = '" + sourceSystemParties + '\'' + 
			",email = '" + email + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}
}