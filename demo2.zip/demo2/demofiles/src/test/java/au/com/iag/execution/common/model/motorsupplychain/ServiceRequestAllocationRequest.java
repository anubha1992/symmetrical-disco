package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class ServiceRequestAllocationRequest implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("claim")
    private Claim claim;
    @JsonProperty("collect_excess_hub")
    private Boolean collectExcessHub;
    @JsonProperty("collect_excess_repairer")
    private Boolean collectExcessRepairer;
    @JsonProperty("excess")
    private Excess excess;
    @JsonProperty("policy")
    private Policy policy;
    private Party primaryContact;
    @JsonProperty("service_provider")
    private ServiceProvider serviceProvider;
    @JsonProperty("service_request_id")
    private String serviceRequestId;
    @JsonProperty("service_request_job_type")
    private String serviceRequestJobType;
    @JsonProperty("service_request_type")
    private String serviceRequestType;
    @JsonProperty("special_instructions")
    private String specialInstructions;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public Claim getClaim() {
        return claim;
    }

    @ApiModelProperty(
            value = "Indicates if the Hub collects the excess amount from the customer",
            example = "true",
            required = false
    )
    public Boolean getCollectExcessHub() {
        return collectExcessHub;
    }

    @ApiModelProperty(
            value = "Indicates if the Repairer collects the excess amount from the customer",
            example = "true",
            required = false
    )
    public Boolean getCollectExcessRepairer() {
        return collectExcessRepairer;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Excess getExcess() {
        return excess;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public Policy getPolicy() {
        return policy;
    }

    @ApiModelProperty(
            value = "",
            required = false
    )
    public ServiceProvider getServiceProvider() {
        return serviceProvider;
    }

    @ApiModelProperty(
            value = "identifier for the Service Request",
            example = "CC:1234567",
            required = false
    )
    public String getServiceRequestId() {
        return serviceRequestId;
    }

    @ApiModelProperty(
            value = "Describes if the job on the claim is authorised to proceed for assessing to authorise (Assess and Authorise) or "
                    + "if there are outstanding validation required (Assess Without Prejudice). "
                    + "https://confluence.iag.com.au/display/GICP/CC+SR+Job+Type",
            example = "Assess_and_Authorise",
            required = false
    )
    public String getServiceRequestJobType() {
        return serviceRequestJobType;
    }

    @ApiModelProperty(
            value = "type of service request https://confluence.iag.com.au/display/GICP/CC+SR+Type",
            example = "Motor:Glass",
            required = false
    )
    public String getServiceRequestType() {
        return serviceRequestType;
    }

    @ApiModelProperty(
            value = "text specific to this service request",
            example = "Car Comprehensive",
            required = false
    )
    public String getSpecialInstructions() {
        return specialInstructions;
    }


}