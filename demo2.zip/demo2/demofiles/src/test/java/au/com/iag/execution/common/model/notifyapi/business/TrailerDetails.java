package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "Contains trailer information")
public class TrailerDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("make")
    private String make;
    @JsonProperty("model")
    private String model;
    @JsonProperty("registration_number")
    private String registrationNumber;
    @JsonProperty("registration_state")
    private String registrationState;
    @JsonProperty("year")
    private Integer year;

  
    @ApiModelProperty(
        value = "Vehicle make.",
        example = "Mustang",
        required = false
    )
    public String getMake() {
       return make;
    }
 
    @ApiModelProperty(
        value = "Vehicle model.",
        example = "GT-X",
        required = false
    )
    public String getModel() {
       return model;
    }
 
    @ApiModelProperty(
        value = "Vehicle Registration Number",
        example = "BS46LL",
        required = false
    )
    public String getRegistrationNumber() {
       return registrationNumber;
    }
 
    @ApiModelProperty(
        value = "Vehicle registered state",
        example = "VIC",
        required = false
    )
    public String getRegistrationState() {
       return registrationState;
    }
 
    @ApiModelProperty(
        value = "Year vehicle was manufactured.",
        example = "2019",
        required = false
    )
    public Integer getYear() {
       return year;
    }
 

}