package au.com.iag.execution.claimnotesapi;

import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_CREATED;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_UNAUTHORIZED;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_AUTH_USER;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.execution.common.constants.ApiConstants.API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI;

import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.DisabledIf;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import au.com.iag.execution.claimnotesapi.builders.ClaimNotesRequestBuilder;
import au.com.iag.execution.claimnotesapi.configurations.ClaimsConfiguration;
import au.com.iag.execution.claimnotesapi.configurations.PropertyOverrideContextInitializer;
import au.com.iag.execution.claimnotesapi.model.ClaimNotesArtifact;
import au.com.iag.execution.claimnotesapi.service.ClaimNotesService;
import au.com.iag.execution.claimnotesapi.verifiers.ClaimsVerifier;
import au.com.iag.execution.common.service.claims.ClaimsDbService;
import au.com.iag.glados.common.GladosRunnerExtension;
import io.restassured.response.Response;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimsConfiguration.class})
@Tags({@Tag("RecoveryJourney"), @Tag("ClaimNotes")})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ClaimNotesTest {

    @Autowired private ClaimNotesRequestBuilder claimNotesRequestBuilder;
    @Autowired private ClaimNotesService claimsService;
    @Autowired private ClaimsDbService claimsDbService;
    @Autowired private ClaimsVerifier claimsVerifier;

    private ClaimNotesArtifact claimNotesArtifact;

    @Value("${test.api.source.system.brand}") private String brand;
    @Value("${test.api.product.code}") private String productCode;

    List<Map<String, Object>> claimIdDetails;
    private String claimId;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimResultSet(productCode);
        claimId = claimNotesRequestBuilder.getClaimId(claimIdDetails, productCode);
    }

    @BeforeEach
    public void setup() throws Exception {
        setClaimNotesArtifact(claimNotesRequestBuilder.setupClaimNote(claimId));
    }

    @Test
    public void createClaimNotes() {
        getClaimNotesArtifact().getClaimNotesRequest().setCreateDefaultActivity(null);
        Response response =  claimsService.executeClaimNotes(getClaimNotesArtifact(), SC_CREATED);
        claimsVerifier.verifyClaimNotesResponse(getClaimNotesArtifact(), response, brand);
    }

    @DisabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void createClaimNotesDefaultActivityTrue() {
        getClaimNotesArtifact().getClaimNotesRequest().setCreateDefaultActivity(true);
        Response response =  claimsService.executeClaimNotes(getClaimNotesArtifact(), SC_CREATED);
        claimsVerifier.verifyClaimNotesResponse(getClaimNotesArtifact(), response, brand);
    }

    @DisabledIf(expression = API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI, loadContext = true)
    @Test
    public void createClaimNotesDefaultActivityFalse() {
        getClaimNotesArtifact().getClaimNotesRequest().setCreateDefaultActivity(false);
        Response response =  claimsService.executeClaimNotes(getClaimNotesArtifact(), SC_CREATED);
        claimsVerifier.verifyClaimNotesResponse(getClaimNotesArtifact(), response, brand);
    }

    @Test
    public void createClaimNotesWithNoBody() {
        getClaimNotesArtifact().getClaimNotesRequest().getNotes().get(0).setBody(null);
        claimsService.executeClaimNotes(getClaimNotesArtifact(), SC_BAD_REQUEST);
    }

    @Tags({@Tag("health"), @Tag("healthClaimNotes")})
    @Test
    public void createClaimNotesWithInvalidClaimId() throws Exception {
        ClaimNotesArtifact claimNotesArtifact = claimNotesRequestBuilder.setupClaimNote("COL1234");
        claimsService.executeClaimNotes(claimNotesArtifact, SC_NOT_FOUND);
    }

    @Test
    public void createClaimNotesWithNoSubject() {
        getClaimNotesArtifact().getClaimNotesRequest().getNotes().get(0).setSubject(null);
        claimsService.executeClaimNotes(getClaimNotesArtifact(), SC_BAD_REQUEST);
    }

    @Test
    public void inValidSecuritySystemClaimNotes() {
        getClaimNotesArtifact().getHeaders().put(X_IAG_CONSUMER_SYSTEM, "invalid");
        claimsService.executeClaimNotes(getClaimNotesArtifact(),SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityConsumerSystemClaimNotes() {
        getClaimNotesArtifact().getHeaders().remove(X_IAG_CONSUMER_SYSTEM);
        claimsService.executeClaimNotes(getClaimNotesArtifact(),SC_UNAUTHORIZED);
    }

    @Test
    public void noSecurityTokenClaimNotes() {
        getClaimNotesArtifact().getHeaders().remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        claimsService.executeClaimNotes(getClaimNotesArtifact(),SC_UNAUTHORIZED);
    }

    @Test
    public void inValidSecurityTokenClaimNotes() {
        getClaimNotesArtifact().getHeaders().put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        claimsService.executeClaimNotes(getClaimNotesArtifact(),SC_UNAUTHORIZED);
    }

    @Test
    public void noUserSecurityTokenRetrieveClaim() {
        getClaimNotesArtifact().getHeaders().remove(X_IAG_AUTH_USER);
        claimsService.executeClaimNotes(getClaimNotesArtifact(),SC_UNAUTHORIZED);
    }

    @Test
    public void createClaimNotesApigee() throws Exception {
        ClaimNotesArtifact claimNotesArtifact = claimNotesRequestBuilder.setupClaimNotesExternal(claimId);
        claimNotesArtifact.getClaimNotesRequest().setCreateDefaultActivity(null);
        Response response =  claimsService.executeExternalClaimNotes(claimNotesArtifact, SC_CREATED);
        claimsVerifier.verifyClaimNotesResponse(getClaimNotesArtifact(), response, brand);
    }

    public ClaimNotesArtifact getClaimNotesArtifact() {
        return claimNotesArtifact;
    }

    public void setClaimNotesArtifact(ClaimNotesArtifact claimNotesArtifact) {
        this.claimNotesArtifact = claimNotesArtifact;
    }
}
