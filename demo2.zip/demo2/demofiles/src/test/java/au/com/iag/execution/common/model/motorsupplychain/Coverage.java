package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Coverage implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("coverage_type")
    private String coverageType;


    @ApiModelProperty(
            value = "Coverage typeComprehensive, Third Party Fire and Theft etc.",
            example = "Comprehensive",
            required = false
    )
    public String getCoverageType() {
        return coverageType;
    }


}