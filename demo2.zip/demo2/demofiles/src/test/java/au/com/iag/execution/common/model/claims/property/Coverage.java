package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Coverage implements Serializable {

    private static final long serialVersionUID = 1L;

    private String coverageType;
    private String policyCoverageCode;
    private List<LossEstimateItem> lossItems= new ArrayList();
    
    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public String getPolicyCoverageCode() {
        return policyCoverageCode;
    }

    public void setPolicyCoverageCode(String policyCoverageCode) {
        this.policyCoverageCode = policyCoverageCode;
    }


    public List<LossEstimateItem> getLossItems() {return lossItems;  }

    public void setLossItems(List<LossEstimateItem> lossItems) {this.lossItems = lossItems;  }
}
