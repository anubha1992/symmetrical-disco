package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.ClaimDetailsRequestBuilder;
import au.com.iag.execution.claimdetailsapi.configuration.ClaimDetailsConfiguration;
import au.com.iag.execution.claimdetailsapi.configuration.PropertyOverrideContextInitializer;
import au.com.iag.execution.claimdetailsapi.model.VerifyClaimUserArtifact;
import au.com.iag.execution.claimdetailsapi.service.ClaimDetailService;
import au.com.iag.execution.claimdetailsapi.verifiers.ClaimDetailsVerifier;
import au.com.iag.execution.common.service.claims.ClaimsDbService;
import au.com.iag.execution.common.service.crods.InsuredDetailsService;
import au.com.iag.glados.common.GladosRunnerExtension;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Map;
import java.util.Random;

import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.INVALID_SYSTEM_TOKEN;
import static au.com.iag.glados.model.constants.GladosConstants.INVALID_USER_TOKEN;
import static org.apache.http.HttpStatus.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest()
@ExtendWith({SpringExtension.class, GladosRunnerExtension.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = {ClaimDetailsConfiguration.class})
@Tags({@Tag("VerifyClaimUserTest"), @Tag("claim-details-api")})
public class VerifyClaimUserTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Autowired
    InsuredDetailsService insuredDetailsService;
    @Autowired
    ClaimsDbService claimsDbService;
    @Autowired
    ClaimDetailService claimDetailService;
    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    List<Map<String, Object>> claimIdDetails;
    Map<String, Object> claimIdDetailsMap;
    private String claimId;
    private String partyId;
    private String crodsCustomerId;
    private String contactId;

    private VerifyClaimUserArtifact verifyClaimUserArtifact;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimsByBrand("NRA");
        if (claimIdDetails.isEmpty()) {
            Assertions.fail("No claim found for NRA with status open");
        }
        claimIdDetailsMap = claimIdDetails.get(new Random().nextInt(claimIdDetails.size()));
        claimId = claimIdDetailsMap.get(DB_CC_CLAIMNUMBER).toString();
        contactId = "cc:" + claimIdDetailsMap.get(DB_CC_INSUREDDENORMID).toString();
        partyId = claimIdDetailsMap.get(DB_CC_CGU_CUSTOMERNUMBER).toString();
        crodsCustomerId = insuredDetailsService.getCustomerBySourceSystemPartyId("HUON", partyId);
    }

    @BeforeEach
    public void setup() throws Exception {
        VerifyClaimUserArtifact verifyClaimUserArtifact = claimDetailsRequestBuilder.setupVerifyClaimUserDefaults(claimId, crodsCustomerId);
        setVerifyClaimUserArtifact(verifyClaimUserArtifact);
    }

    @Test
    public void verifyClaimUserForValidClaimId() {
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(), verifyClaimUserQueryPath(claimId), SC_OK);
        claimDetailsVerifier.verifyClaimUserResponse(contactId, response);
    }

    @Test
    public void claimNotFound() {
        verifyClaimUserArtifact = claimDetailsRequestBuilder.setupVerifyClaimUserDefaults("NRA12345", crodsCustomerId);
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(), verifyClaimUserQueryPath(claimId), SC_NOT_FOUND);
        assertEquals("Claim not found.", response.path("message"));
    }

    @Test
    public void customerNotFound() {
        verifyClaimUserArtifact = claimDetailsRequestBuilder.setupVerifyClaimUserDefaults("NRA12345", "123456");
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(),verifyClaimUserQueryPath(claimId), SC_UNAUTHORIZED);
        assertEquals(USER_NOT_AUTHORISED_TO_ACCESS.trim(), response.path("message"));
    }

    @Test
    public void missingSystemToken() {
        verifyClaimUserArtifact.getHeaders().remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(), verifyClaimUserQueryPath(claimId), SC_UNAUTHORIZED);
        assertEquals(MISSING_SYSTEM_TOKEN, response.path("message"));
    }

    @Test
    public void invalidSystemToken() {
        String invalidToken = verifyClaimUserArtifact.getHeaders().get(X_IAG_AUTH_CONSUMER_SYSTEM) + "i";
        verifyClaimUserArtifact.getHeaders().put(X_IAG_AUTH_CONSUMER_SYSTEM, invalidToken);
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(),verifyClaimUserQueryPath(claimId), SC_UNAUTHORIZED);
        assertEquals(INVALID_SYSTEM_TOKEN, response.path("message"));
    }

    @Test
    public void missingUserToken() {
        verifyClaimUserArtifact.getHeaders().remove(X_IAG_AUTH_USER);
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(), verifyClaimUserQueryPath(claimId), SC_UNAUTHORIZED);
        assertEquals(MISSING_USER_TOKEN, response.path("message"));
    }

    @Test
    public void invalidUserToken() {
        String invalidToken = verifyClaimUserArtifact.getHeaders().get(X_IAG_AUTH_USER) + "i";
        verifyClaimUserArtifact.getHeaders().put(X_IAG_AUTH_USER, invalidToken);
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(), verifyClaimUserQueryPath(claimId), SC_UNAUTHORIZED);
        assertEquals(INVALID_USER_TOKEN, response.path("message"));
    }

    @Test
    public void userTokenWithDifferentClaimId() {
        verifyClaimUserArtifact.setClaimId("NRA123456");
        Response response = claimDetailService.executeVerifyClaimUser(getVerifyClaimUserArtifact(), verifyClaimUserQueryPath(claimId), SC_UNAUTHORIZED);
        assertEquals(USER_NOT_AUTHORISED_TO_ACCESS, response.path("message"));
    }

    private VerifyClaimUserArtifact getVerifyClaimUserArtifact() {
        return verifyClaimUserArtifact;
    }

    private void setVerifyClaimUserArtifact(VerifyClaimUserArtifact verifyClaimUserArtifact) {
        this.verifyClaimUserArtifact = verifyClaimUserArtifact;
    }

    private String verifyClaimUserQueryPath(String claimId) {
        StringBuffer url = new StringBuffer();
        url.append("/" + claimId+ "/verify-user");
        return url.toString();
    }
}
