package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ExcessDetail implements Serializable {

    private static final long serialVersionUID = 5368370526961246362L;
    private String additionalDetails;
    private String description;
    private Amount itemTotal;

    public String getAdditionalDetails() {
        return additionalDetails;
    }

    public void setAdditionalDetails(String additionalDetails) {
        this.additionalDetails = additionalDetails;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Amount getItemTotal() {
        return itemTotal;
    }

    public void setItemTotal(Amount itemTotal) {
        this.itemTotal = itemTotal;
    }
}
