package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PremiumDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("base_premium")
    private Double basePremium ;
    @JsonProperty("esl")
    private Double esl ;
    @JsonProperty("gst")
    private Double gst ;
    @JsonProperty("stamp_duty")
    private Double stampDuty ;
    @JsonProperty("total_outstanding_premium")
    private Double totalOutstandingPremium ;
    @JsonProperty("total_premium")
    private Double totalPremium ;

  
    @ApiModelProperty(
        value = "Base Premium Amount",
        example = "70.0",
        required = false
    )
    public Double getBasePremium() {
       return basePremium;
    }
 
    @ApiModelProperty(
        value = "Emergency Services Levy amount",
        example = "5.5",
        required = false
    )
    public Double getEsl() {
       return esl;
    }
 
    @ApiModelProperty(
        value = "Goods and services tax",
        example = "10.0",
        required = false
    )
    public Double getGst() {
       return gst;
    }
 
    @ApiModelProperty(
        value = "Stamp Duty Amount",
        example = "15.0",
        required = false
    )
    public Double getStampDuty() {
       return stampDuty;
    }
 
    @ApiModelProperty(
        value = "Total outstanding premium for this asset.",
        required = false
    )
    public Double getTotalOutstandingPremium() {
       return totalOutstandingPremium;
    }
 
    @ApiModelProperty(
        value = "Total premium or the gross premium",
        example = "85.0",
        required = false
    )
    public Double getTotalPremium() {
       return totalPremium;
    }
 

}