package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class IndividualNameDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("first_name")
    private String firstName ;
    @JsonProperty("last_name")
    private String lastName ;
    @JsonProperty("middle_name")
    private String middleName ;
    @JsonProperty("title")
    private String title ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Individual&#x27;s first name. [Constraint: &#x60;individual_first_name&#x60;]",
        example = "John",
        required = false
    )
    public String getFirstName() {
       return firstName;
    }
 
    @ApiModelProperty(
        value = "Individual&#x27;s surname. [Constraint: &#x60;individual_last_name&#x60;]",
        example = "Smith",
        required = false
    )
    public String getLastName() {
       return lastName;
    }
 
    @ApiModelProperty(
        value = "Individual&#x27;s middle name. [Constraint: &#x60;individual_middle_name&#x60;]",
        example = "Franklin",
        required = false
    )
    public String getMiddleName() {
       return middleName;
    }
 
    @ApiModelProperty(
        value = "The individual&#x27;s title [Ref Data: individual_titles]",
        example = "MRS",
        required = false
    )
    public String getTitle() {
       return title;
    }
 
    @ApiModelProperty(
        value = "Type of name [Ref Data: individual_name_types]",
        example = "LEGAL",
        required = false
    )
    public String getType() {
       return type;
    }
 

}