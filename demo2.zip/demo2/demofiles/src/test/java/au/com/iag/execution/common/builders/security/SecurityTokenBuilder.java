package au.com.iag.execution.common.builders.security;

import static java.util.Map.entry;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import au.com.iag.execution.common.builders.security.okta.OktaUserTokenRequestBuilder;
import au.com.iag.glados.service.SecurityService;
import javax.annotation.PostConstruct;

@Component
public class SecurityTokenBuilder {

    @Autowired private OktaUserTokenRequestBuilder oktaUserTokenRequestBuilder;

    @Autowired private SecurityService securityService;

    @Value("${test.security.consumer}") private String consumerWithUserAuthDisabled;
    @Value("${okta.test.security.consumer}") private String consumerWithUserAuthEnabled;
    @Value("${test.security.provider}") private String providerSystem;

    private Map<Boolean, String> systemSecurityTokenMapper;
    private Map<Boolean, String> userSecurityTokenMapper;
    private Map<Boolean, String> consumerSystemMapper;

    @PostConstruct
    private void buildSystemSecurityToken() {
        systemSecurityTokenMapper = Map.ofEntries(
                entry(true, getSystemSecurityTokenWithOktaUserAuthEnabled()),
                entry(false, getSystemSecurityTokenWithOktaUserAuthDisabled()));
        userSecurityTokenMapper = Map.ofEntries(
                entry(true, getAuthUserToken()),
                entry(false, getDummyAuthUserToken()));
        consumerSystemMapper = Map.ofEntries(
                entry(true, consumerWithUserAuthEnabled),
                entry(false, consumerWithUserAuthDisabled));
    }

    public String getSystemSecurityToken(final boolean isAuthUserEnabled) {
        return systemSecurityTokenMapper.get(isAuthUserEnabled);
    }

    public String getAuthUserToken(final boolean isAuthUserEnabled) {
        return userSecurityTokenMapper.get(isAuthUserEnabled);
    }

    public String getConsumerSystem(final boolean isAuthUserEnabled) {
        return consumerSystemMapper.get(isAuthUserEnabled);
    }

    private String getSystemSecurityTokenWithOktaUserAuthEnabled() {
        return securityService.getSystemSecurityToken(consumerWithUserAuthEnabled, providerSystem);
    }

    private String getSystemSecurityTokenWithOktaUserAuthDisabled() {
        return securityService.getSystemSecurityToken(consumerWithUserAuthDisabled, providerSystem);
    }

    public String getAuthUserToken() {
        return securityService.getOktaUserSecurityToken(oktaUserTokenRequestBuilder.buildOktaUserTokenRequest());
    }

    public String getAuthAnonymousUserToken(final String quoteId) {
        return securityService.issueOktaAnonymousUserSecurityToken(oktaUserTokenRequestBuilder.buildOktaAnonymousUserTokenRequest(quoteId));
    }

    private String getDummyAuthUserToken() {
        return "dummy";
    }
}
