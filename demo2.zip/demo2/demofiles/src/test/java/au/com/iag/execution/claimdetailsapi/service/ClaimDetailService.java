package au.com.iag.execution.claimdetailsapi.service;

import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.junit.Assert.*;

@Service
public class ClaimDetailService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    public Response executeClaimDetails(ClaimDetailsArtifact claimDetailsArtifact, String queryString, int expectStatusCode){
        Response response = gladosEnrichmentService.sendGetRequest(
                claimDetailsArtifact.getHeaders(),
                claimDetailsArtifact.getPath(),
                queryString, expectStatusCode
        );
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeClaimDetailsExternal(ClaimDetailsArtifact claimDetailsArtifact, String queryString, int expectStatusCode){
        Response response = gladosEnrichmentService.sendGetRequestExternal(
                claimDetailsArtifact.getHeaders(),
                claimDetailsArtifact.getPath(),
                queryString, expectStatusCode
        );
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeClaimDetailsSearch(ClaimDetailsArtifact claimDetailsArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequest(
                claimDetailsArtifact.getHeaders(),
                claimDetailsArtifact.getPath(),
                claimDetailsArtifact.getClaimSearchRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeClaimDetailsSearchExternal(ClaimDetailsArtifact claimDetailsArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequestExternal(
                claimDetailsArtifact.getHeaders(),
                claimDetailsArtifact.getPath(),
                claimDetailsArtifact.getClaimSearchRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeClaimRetrievePolicy(ClaimPolicyRetrieveArtifact claimPolicyRetrieveArtifact, String queryString, int expectStatusCode){
        Response response = gladosEnrichmentService.sendGetRequest(
                claimPolicyRetrieveArtifact.getHeaders(),
                claimPolicyRetrieveArtifact.getPath(),
                queryString, expectStatusCode
        );
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeVerifyClaimUser(VerifyClaimUserArtifact verifyClaimUserArtifact, String queryString, int expectStatusCode){
        Response response = gladosEnrichmentService.sendGetRequest(
                verifyClaimUserArtifact.getHeaders(),
                verifyClaimUserArtifact.getPath(),
                queryString,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }
}
