package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "Contains details for the policy term inception date")
public class PolicyDates implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("original_inception_date")
    private String originalInceptionDate;
    @JsonProperty("period_effective_from")
    private String periodEffectiveFrom;
    @JsonProperty("term_expiry_date")
    private String termExpiryDate;
    @JsonProperty("term_inception_date")
    private String termInceptionDate;

  
    @ApiModelProperty(
        value = "The original inception date of the policy e.g. New Business inception date. Note: The date must include zone, format is ISO-8601. Pattern: yyyy-MM-dd&#x27;T&#x27;HH:mm:ss.SSSz Example values:   - &quot;2019-08-30T15:47:55.123+10:00&quot; or   - &quot;2019-08-30T15:47:55.123+10:00[Australia/Sydney]&quot; or   - &quot;2019-08-30T15:47:55.123Z&quot; for Zulu Time  - &quot;1567123200&quot; milliseconds since &#x27;1970-01-01T00:00:00Z[UTC]&#x27;",
        example = "2019-08-30T15:47:55.123Z",
        required = false
    )
    public String getOriginalInceptionDate() {
       return originalInceptionDate;
    }
 
    @ApiModelProperty(
        value = "The date when respective change is effective from on the policy. Note: The date must include zone, format is ISO-8601. Pattern: yyyy-MM-dd&#x27;T&#x27;HH:mm:ss.SSSz Example values:   - &quot;2019-08-30T15:47:55.123+10:00&quot; or   - &quot;2019-08-30T15:47:55.123+10:00[Australia/Sydney]&quot; or   - &quot;2019-08-30T15:47:55.123Z&quot; for Zulu Time  - &quot;1567123200&quot; milliseconds since &#x27;1970-01-01T00:00:00Z[UTC]&#x27;",
        example = "2019-08-30T15:47:55.123Z",
        required = false
    )
    public String getPeriodEffectiveFrom() {
       return periodEffectiveFrom;
    }
 
    @ApiModelProperty(
        value = "The term expiry date of the Quote or Policy. For example, the renewal term end date. Note: The date must include zone, format is ISO-8601. Pattern: yyyy-MM-dd&#x27;T&#x27;HH:mm:ss.SSSz Example values:   - &quot;2019-08-30T15:47:55.123+10:00&quot; or   - &quot;2019-08-30T15:47:55.123+10:00[Australia/Sydney]&quot; or   - &quot;2019-08-30T15:47:55.123Z&quot; for Zulu Time  - &quot;1567123200&quot; milliseconds since &#x27;1970-01-01T00:00:00Z[UTC]&#x27;",
        example = "2019-08-30T15:47:55.123Z",
        required = false
    )
    public String getTermExpiryDate() {
       return termExpiryDate;
    }
 
    @ApiModelProperty(
        value = "Term inception date of the Policy. For example, the renewal term start date. Note: The date must include zone, format is ISO-8601. Pattern: yyyy-MM-dd&#x27;T&#x27;HH:mm:ss.SSSz Example values:   - &quot;2019-08-30T15:47:55.123+10:00&quot; or   - &quot;2019-08-30T15:47:55.123+10:00[Australia/Sydney]&quot; or   - &quot;2019-08-30T15:47:55.123Z&quot; for Zulu Time  - &quot;1567123200&quot; milliseconds since &#x27;1970-01-01T00:00:00Z[UTC]&#x27;",
        example = "2019-08-30T15:47:55.123Z",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getTermInceptionDate() {
       return termInceptionDate;
    }
 

}