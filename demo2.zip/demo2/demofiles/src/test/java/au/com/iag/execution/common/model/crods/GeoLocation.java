package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GeoLocation{

	@JsonProperty("levelType")
	private int levelType;

	@JsonProperty("aliasType")
	private String aliasType;

	@JsonProperty("confidence")
	private int confidence;

	@JsonProperty("geoId")
	private int geoId;

	@JsonProperty("latitude")
	private int latitude;

	@JsonProperty("reliability")
	private int reliability;

	@JsonProperty("externalGeoId")
	private String externalGeoId;

	@JsonProperty("longitude")
	private int longitude;

	public void setLevelType(int levelType){
		this.levelType = levelType;
	}

	public int getLevelType(){
		return levelType;
	}

	public void setAliasType(String aliasType){
		this.aliasType = aliasType;
	}

	public String getAliasType(){
		return aliasType;
	}

	public void setConfidence(int confidence){
		this.confidence = confidence;
	}

	public int getConfidence(){
		return confidence;
	}

	public void setGeoId(int geoId){
		this.geoId = geoId;
	}

	public int getGeoId(){
		return geoId;
	}

	public void setLatitude(int latitude){
		this.latitude = latitude;
	}

	public int getLatitude(){
		return latitude;
	}

	public void setReliability(int reliability){
		this.reliability = reliability;
	}

	public int getReliability(){
		return reliability;
	}

	public void setExternalGeoId(String externalGeoId){
		this.externalGeoId = externalGeoId;
	}

	public String getExternalGeoId(){
		return externalGeoId;
	}

	public void setLongitude(int longitude){
		this.longitude = longitude;
	}

	public int getLongitude(){
		return longitude;
	}

	@Override
 	public String toString(){
		return 
			"GeoLocation{" + 
			"levelType = '" + levelType + '\'' + 
			",aliasType = '" + aliasType + '\'' + 
			",confidence = '" + confidence + '\'' + 
			",geoId = '" + geoId + '\'' + 
			",latitude = '" + latitude + '\'' + 
			",reliability = '" + reliability + '\'' + 
			",externalGeoId = '" + externalGeoId + '\'' + 
			",longitude = '" + longitude + '\'' + 
			"}";
		}
}