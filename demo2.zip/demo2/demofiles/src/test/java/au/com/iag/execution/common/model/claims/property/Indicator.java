package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Indicator implements Serializable {
    private static final long serialVersionUID = -223287988050039386L;
    private Boolean customerAcknowledgement;
    private String securityType;

    public Boolean isCustomerAcknowledgement() {
        return customerAcknowledgement;
    }

    public void setCustomerAcknowledgement(Boolean customerAcknowledgement) {
        this.customerAcknowledgement = customerAcknowledgement;
    }

    public String getSecurityType() {
        return securityType;
    }

    public void setSecurityType(String securityType) {
        this.securityType = securityType;
    }
}
