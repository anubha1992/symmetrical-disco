package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class AssetPartyRole implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("party_id")
    private String partyId;
    @JsonProperty("role")
    private String role;

  
    @ApiModelProperty(
        value = "Party identifier.",
        example = "12345567890",
        required = false
    )
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Role of the party. [Ref Data: party_role]",
        example = "ADDITIONAL_INSURED",
        required = false
    )
    public String getRole() {
       return role;
    }
 

}