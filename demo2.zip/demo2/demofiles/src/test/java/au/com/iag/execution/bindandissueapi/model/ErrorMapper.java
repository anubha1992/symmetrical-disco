package au.com.iag.execution.bindandissueapi.model;

public enum ErrorMapper {

    INVALID_SECURITY_TOKEN("Security Token Validation Failure: Invalid System Token provided"),
    MISSING_SECURITY_TOKEN("System Security Token missing"),
    QUOTE_STATUS_DRAFT("Submission is either Bound or in draft status - Not ready for Bind and Issue");

    private final String value;

    ErrorMapper(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
