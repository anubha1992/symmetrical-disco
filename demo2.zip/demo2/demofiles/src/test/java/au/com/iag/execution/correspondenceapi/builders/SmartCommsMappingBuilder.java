package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.AssessmentListItem;
import au.com.iag.execution.correspondenceapi.model.SmartCommsMappingBase;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SmartCommsMappingBuilder {

    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private JsonMapperService jsonMapperService;

    public List<AssessmentListItem> getCommonMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-common.json")
                        , SmartCommsMappingBase.class);
        return smartCommsMappingBase.getRules().get(0).getAssessmentList();
    }

    public List<AssessmentListItem> getLetterMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-letter.json")
                        , SmartCommsMappingBase.class);
        return smartCommsMappingBase.getRules().get(0).getAssessmentList();
    }

    public List<AssessmentListItem> getHomeMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-home.json")
                        , SmartCommsMappingBase.class);
        return checkValidationClues(smartCommsMappingBase.getRules().get(0).getAssessmentList());
    }

    public List<AssessmentListItem> getLandlordMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-landlord.json")
                        , SmartCommsMappingBase.class);
        return checkValidationClues(smartCommsMappingBase.getRules().get(0).getAssessmentList());
    }

    public List<AssessmentListItem> getMotorMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-motor.json")
                        , SmartCommsMappingBase.class);
        return smartCommsMappingBase.getRules().get(0).getAssessmentList();
    }

    public List<AssessmentListItem> getSmsMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-sms.json")
                        , SmartCommsMappingBase.class);
        return smartCommsMappingBase.getRules().get(0).getAssessmentList();
    }

    public List<AssessmentListItem> getResendMappings() throws IOException {
        SmartCommsMappingBase smartCommsMappingBase = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService
                                .generateStringFromResource("data/correspondence-api/sc-validation/smartcomms-mappings-resend.json")
                        , SmartCommsMappingBase.class);
        return smartCommsMappingBase.getRules().get(0).getAssessmentList();
    }

    private List<AssessmentListItem> checkValidationClues(List<AssessmentListItem> list){
        return list.stream().filter(assessmentListItem -> !(assessmentListItem.getValidationClues() != null
                && assessmentListItem.getValidationClues().isIgnore() == true
                && assessmentListItem.getValidationClues().getReason().matches("FIRE-[0-9]{4}")))
                .collect(Collectors.toList());
    }
}