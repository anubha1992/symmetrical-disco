package au.com.iag.execution.common.service.repx;

import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.artifacts.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.glados.model.artifacts.DatabaseConnectionArtifact.*;
import java.sql.*;
import java.util.*;

import static junit.framework.TestCase.fail;

@Service
public class RepxRepairTrackingDbService {

    @Autowired
    private DatabaseClient databaseClient;

    @Value("${repx.tracking.datasource.username}")
    private String username;
    @Value("${repx.tracking.datasource.password}")
    private String password;
    @Value("${repx.tracking.datasource.url}")
    private String connectionString;
    @Value("${repx.datasource.driver-class-name}")
    private String driverName;

    private DatabaseConnectionArtifact buildDatabaseConnectionDetails() {
        return builder().connectionString(connectionString)
                .jdbcClassName(driverName)
                .username(username)
                .password(password)
                .build();
    }

    public List<Map<String, Object>> getAllRepairersCredentialsHasVendorCodeAndToken() throws SQLException, ClassNotFoundException {

        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String sqlQuery = "select * from supplier_authentication where vendor_code is not null and repairer_token is not null";
        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, sqlQuery);
        if (!(resultList.size()>0)){
            fail("---------Repair credentials details are not found which has vendor code and token ------------");
        }
        return resultList;
    }

    public Map<String, Object> getRepairerCredentials(String repairer_id) throws SQLException, ClassNotFoundException {

        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String sqlQuery = "select * from supplier_authentication where orm_supplier_id ='"+repairer_id+"'";
        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, sqlQuery);
        if (!(resultList.size()>0)){
            fail("---------Repair credentials details are not found ------------");
        }
        return resultList.get(0);
    }

    public List<Map<String, Object>> getAllocationNoBookings(String repairer_id, Boolean isHub, String fromDate, String toDate) throws SQLException, ClassNotFoundException {

        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        StringBuilder sqlQuery = new StringBuilder("select * from repair_state_tracking where orm_supplier_id = '"+repairer_id+"'");
        if (null != isHub){
            if (isHub){
                sqlQuery.append(" and hub_id is not null");
            } else {
                sqlQuery.append(" and hub_id is null and (inspection_booked = false or inspection_booked is null)");
            }
        }

        sqlQuery.append(" and start_datetime is null and date_allocated between '"+fromDate+ " 00:00:00' and '"+toDate+" 23:59:59'");
        //sqlQuery.append(" and (inspection_booked = false or inspection_booked is null)");

        List<Map<String, Object>> resultList = databaseClient.executeQuery(connection, sqlQuery.toString());

        return resultList;
    }
}
