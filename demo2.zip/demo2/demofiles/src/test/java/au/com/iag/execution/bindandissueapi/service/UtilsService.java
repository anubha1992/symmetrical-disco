package au.com.iag.execution.bindandissueapi.service;

import org.apache.commons.lang3.SerializationUtils;
import org.springframework.stereotype.Service;

import java.io.Serializable;

@Service
public class UtilsService {

    public <T extends Serializable> T clone(T t) {
        return SerializationUtils.clone(t);
    }

}
