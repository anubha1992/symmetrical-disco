package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.glados.service.RandomContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.CORRESPONDENCE_CHANNEL_SMS;

@Component
public class SmsCorrespondenceRequestBuilder {

    @Autowired private RandomContentService randomContentService;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private PolicyBuilder policyBuilder;

    PolicyCorrespondence getSmsCorrespondenceRequest(PolicyCorrespondence policyCorrespondence, final String correspondenceType
            , String primaryRecipientType) {
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        primaryRecipientBuilder.updatePrimaryRecipient(policyCorrespondence, primaryRecipientType);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_SMS);
        policyBuilder.updatePolicyCorrespondenceByType(correspondenceType, policyCorrespondence);
        return policyCorrespondence;
    }
}
