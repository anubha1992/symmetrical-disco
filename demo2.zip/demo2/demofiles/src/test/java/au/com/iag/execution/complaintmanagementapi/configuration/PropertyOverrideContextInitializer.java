package au.com.iag.execution.complaintmanagementapi.configuration;

import static org.springframework.test.context.support.TestPropertySourceUtils.addPropertiesFilesToEnvironment;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;

public class PropertyOverrideContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        addPropertiesFilesToEnvironment(
            configurableApplicationContext,
            "classpath:config/application-test.properties",
            "classpath:config/complaint-management-api/application-test.properties",
            "classpath:config/complaint-management-api/${env}/application-test.properties");
    }
}
