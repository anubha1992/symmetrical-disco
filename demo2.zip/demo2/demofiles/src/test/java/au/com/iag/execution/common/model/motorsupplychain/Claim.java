package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Claim implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("cause_of_loss")
    private String causeOfLoss;
    @JsonProperty("claim_decision_status")
    private String claimDecisionStatus;
    @JsonProperty("claim_number")
    private String claimNumber;
    @JsonProperty("date_of_loss")
    private java.time.ZonedDateTime dateOfLoss;
    @JsonProperty("description_of_loss")
    private String descriptionOfLoss;
    @JsonProperty("general_nature_of_loss")
    private String generalNatureOfLoss;
    @JsonProperty("location_of_loss")
    private Address locationOfLoss;
    @JsonProperty("lodgement_date")
    private java.time.ZonedDateTime lodgementDate;
    @JsonProperty("status")
    private String status;
    @JsonProperty("vehicle_incident")
    private VehicleIncident vehicleIncident;


    @ApiModelProperty(
            value = "More specific detail of the loss. https://confluence.iag.com.au/display/GICP/CC+Loss+Cause",
            example = "HSO",
            required = false
    )
    public String getCauseOfLoss() {
        return causeOfLoss;
    }

    @ApiModelProperty(
            value = "https://confluence.iag.com.au/display/GICP/CC+Claim+Decision+Status",
            example = "accepted",
            required = false
    )
    public String getClaimDecisionStatus() {
        return claimDecisionStatus;
    }

    @ApiModelProperty(
            value = "Claim identifier that uniquely references the claim",
            example = "NRA902321312",
            required = false
    )
    public String getClaimNumber() {
        return claimNumber;
    }

    @ApiModelProperty(
            value = "date and time the of the loss",
            example = "2020-09-15T15:53:00+11:00",
            required = false
    )
    public java.time.ZonedDateTime getDateOfLoss() {
        return dateOfLoss;
    }

    @ApiModelProperty(
            value = "Description of the accident or loss.",
            example = "Was trying to reverse into a parking spot and accelerated",
            required = false
    )
    public String getDescriptionOfLoss() {
        return descriptionOfLoss;
    }

    @ApiModelProperty(
            value = "General nature of loss. https://confluence.iag.com.au/display/GICP/CC+Nature+of+Loss",
            example = "COLL_AUTO",
            required = false
    )
    public String getGeneralNatureOfLoss() {
        return generalNatureOfLoss;
    }

    @ApiModelProperty(
            value = "Address of accident.",
            required = false
    )
    public Address getLocationOfLoss() {
        return locationOfLoss;
    }

    @ApiModelProperty(
            value = "date claim lodged",
            example = "2020-09-15T15:53:00+11:00",
            required = false
    )
    public java.time.ZonedDateTime getLodgementDate() {
        return lodgementDate;
    }

    @ApiModelProperty(
            value = "Claim status. https://confluence.iag.com.au/display/GICP/CC+Claim+Status",
            example = "Open",
            required = false
    )
    public String getStatus() {
        return status;
    }

    @ApiModelProperty(
            value = "Vehicle Incident contact_details",
            required = false
    )
    public VehicleIncident getVehicleIncident() {
        return vehicleIncident;
    }


}