package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.*;

@Data
public class Amount {

    @ApiModelProperty(value = "Amount", example = "20420")
    private BigDecimal amount;
    @ApiModelProperty(value = "Currency", example = "aud")
    private String currency;
}
