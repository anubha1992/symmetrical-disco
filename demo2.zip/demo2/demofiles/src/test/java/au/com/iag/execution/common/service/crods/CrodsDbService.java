package au.com.iag.execution.common.service.crods;

import au.com.iag.execution.common.model.huon.util.*;
import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.artifacts.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.glados.model.artifacts.DatabaseConnectionArtifact.*;
import java.sql.*;
import java.util.*;

/**
 * Check database for CRODS
 */
@Service
public class CrodsDbService {

    private String databaseURL= "";
    private String user= "";
    private String password= "";
    private String jdbcClassName= "";

    private static final int MAX_WAIT_TIME_CUSTOMER_SYNC = 60;

    @Autowired
    HashMap<String, CrodDataSource> crodsConfigHashMap;

    @Value("${env.name.huon}")
    private String env;

    @Autowired
    private DatabaseClient databaseClient;

    private DatabaseConnectionArtifact buildDatabaseConnectionDetails() {
        setUpDbConfig();
        return builder().connectionString(databaseURL)
                .jdbcClassName(jdbcClassName)
                .username(user)
                .password(password)
                .build();
    }

    public Map<String, Object> getPoliciesByBrand(String brand, List<String> riskTypes, String productCode, String apiSourceSystem) throws SQLException, ClassNotFoundException {
        Map<String, Object> policyDetails;
        Connection connection = getDbConnection();
        String SEPARATOR = "','";
        String riskTypesList = String.join(SEPARATOR, riskTypes);

        String sql = "Select SSBREFERENCE, LOBTYPE_CDE, LOBDISPLAYLEVEL2,START_DATE, RENEWAL_DUE_DATE"
                + "  from CRODS.SRC_SYS_BUS_CURRENT where LOBTYPE_CDE  in ( '" +riskTypesList+ "') and"
                + "  SRC_SYS_NAME_CDE ='" +apiSourceSystem + "'and BRAND_CDE ='"+ brand + "'and SSBREFERENCE like '"+productCode+"%' and RENEWAL_DUE_DATE >=  '2018-01-01' and LOBSTATUS_CDE IN ('CURRENT','RENEWAL')";

        List<Map<String, Object>> result = databaseClient.executeQuery(connection, sql);
        policyDetails = result.get(new Random().nextInt(result.size()));

        return policyDetails;
    }

    public boolean waitForCustomerExisting(String huonCustomerNumber)
            throws SQLException, ClassNotFoundException, HuonException {
        return waitForCustomerExisting(huonCustomerNumber, MAX_WAIT_TIME_CUSTOMER_SYNC);
    }

    public boolean waitForCustomerExisting(String huonCustomerNumber, int seconds)
            throws SQLException, ClassNotFoundException, HuonException {
        boolean found = false;

        Connection connection = getDbConnection();

        while (huonCustomerNumber.length() < 9) {
            huonCustomerNumber = "0" + huonCustomerNumber;
        }
        String sql = "select * from CRODS.party where SRC_SYS_PARTY_ID = '";
        sql = sql + huonCustomerNumber + "'";

        int maxTries = seconds;
        int iTry = 0;
        while (!found) {
            List<Map<String, Object>> result = databaseClient.executeQuery(connection, sql);
            ;
            if (result != null && !result.isEmpty()) {
                found = true;

            }
            iTry++;
            if (iTry > maxTries)
                break;

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }

        }

        if (!found) {
            throw new HuonException("The new client " + huonCustomerNumber + " is NOT sync to CRODS after wait for " + seconds + " seconds");
        }

        return found;
    }

    private Connection getDbConnection() throws SQLException, ClassNotFoundException {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);
        return connection;
    }

    private void setUpDbConfig() {

        CrodDataSource crodConfig;

        env = env.trim().toLowerCase();
        //Virtual envs
        if (env.startsWith("VE")) {
            crodConfig = crodsConfigHashMap.get("VE");
            String number = env.substring(2);
            databaseURL = crodConfig.getUrl();
            databaseURL = databaseURL.replace("[xxx]", number);
            user = crodConfig.getUser();
            password = crodConfig.getPassword();
            jdbcClassName = crodConfig.getDriver();
        } else {
            String envTemp = env;
            if (env.length() > 4) {
                envTemp = env.trim().toLowerCase().substring(0, 4);
            }

            crodConfig = crodsConfigHashMap.get(envTemp);
            if (crodConfig != null){
                databaseURL = crodConfig.getUrl();
                user = crodConfig.getUser();
                password = crodConfig.getPassword();
                jdbcClassName = crodConfig.getDriver();
            }
        }

    }
}