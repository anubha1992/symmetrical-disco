package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)

public class LossItemsIncident implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<Incident> incidents;
    /*private String incidentId;
    private String lossPartyType;
    private String incidentCode;
     public String getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(String incidentId) {
        this.incidentId = incidentId;
    }

    public String getLossPartyType() {
        return lossPartyType;
    }

    public void setLossPartyType(String lossPartyType) {
        this.lossPartyType = lossPartyType;
    }

    public String getIncidentCode() {
        return incidentCode;
    }

    public void setIncidentCode(String incidentCode) {
        this.incidentCode = incidentCode;
    }*/

    public List<Incident> getIncidents() { return incidents;    }

    public void setIncidents(List<Incident> incidents) { this.incidents = incidents; }

}