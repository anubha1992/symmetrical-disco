package au.com.iag.execution.common.model.huon;

import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.*;
import com.jagacy.util.*;
import java.text.*;
import java.util.*;


/**
 * A common error/warning message handler class for HUON.
 * Error/warning message is the text shown at row 23 in all HUON screens when we do some operations like ENTER.
 */
public class HuonErrorHandler {
    private HuonSession huon = null;
    private String screenName = "";
    private String errorMessage = "";
    private String huonErrorMessage = "";
    private HuonReporter reporter = null;

    /**
     * Create an error handler.
     *
     * @param huon
     */
    public HuonErrorHandler(HuonSession huon, HuonReporter reporter) throws JagacyException {
        this.huon = huon;
        this.reporter = reporter;
    }

    public HuonErrorHandler(HuonSession huon) throws JagacyException {
        this.huon = huon;
    }

    /**
     * Perform the error/warning handling.
     * todo: Continue to enrich this method by handling more and more error/warning messages...
     *
     * @return true for success and false for failure when the transaction has be to aborted.
     */
    public boolean perform() throws JagacyException {
        boolean result = true;
        boolean done = false;
        int errorRow = 0, errorCol = 0;

        this.screenName = huon.readScreenName();

        boolean abort = false;

        while (!done) {
            String errorCode = huon.extractErrorCode();
            if (errorCode == null) {
                return false;
            }

            switch (errorCode) {
                case "":
                case "107":    // 107 - BEGINNING OF SELECTED RANGE
                case "108":    // 108 - END OF SELECTED RANGE
                case "345":        //"345 - LIST - END OF FILE REACHED"
                case "8301":    //"8301 - WARNING:  THIS POLICY REQUIRES AUTHORIZATION"
                case "11621":    // "11621 - RISK MUST HAVE AT LEAST ONE ACTIVE COVERAGE IN EFFECT"
                case "800083":    //"800083 - MORE COVERAGES EXIST - PRESS F8"
                case "800302":    //"800302 - WARNING - AUTOMATIC EMBARGO APPLIES"
                case "800653":  //800653 - PLEASE ADD AT LEAST ONE DRIVER AS THE OWNER IS A COMPANY"
                case "801579":    //"801579 - ADDRESS WITHOUT DPID ATTACHED"
                case "802501":    //802501 - SYSTEM CALCULATED NCB HIGHER THAN PREVIOUS POLICY NCB"
                case "807001":    //807001 - NO MATCHES FOUND, PLEASE CHECK ADDRESS DETAILS
                case "800449":    //800449 - REFER TO SUPPORT AREA (NO $$ OR $$$ VALUES)
                case "12385":    //12385 - ACTIVITY SUCCESSFULLY APPLIED
                case "12169":    //12169 - NEXT ACTIVITY RECORD NOT FOUND FOR SELECTED POLICY
                case "800953":    //800953 - WARNING: DATE EFFECTIVE IS 42 DAYS OR MORE IN THE FUTURE
                case "800141":    //800141 - NCB DOES NOT MATCH INSURANCE HISTORY ENTERED. CONFIRM NCB.
                case "9380":        //9380 - CLIENT TYPE INVALID - SELECT AN INDIVIDUAL CLIENT/DRIVER
                case "9351":                //9351 - PRESS PF8 TO DISPLAY MORE INFORMATION
                case "800429":    //800429 - TYPE OF COVER HAS CHANGED FROM AGREED TO MARKET
                case "800506":    //800506 - ADD MORE VEHICLE DETAILS TO REDUCE THE SEARCH


                    /*
                     * No error, just go ahead
                     */
                    errorMessage = "";
                    huonErrorMessage = "";
                    result = true;
                    done = true;
                    break;

                case "800484":        //"800484 - EMBARGO SERVICE FAILURE"
                case "800952":        //800952 - WARNING: DATE EFFECTIVE IS 40 DAYS OR MORE IN THE PAST
                    //Warning, just leave it
                    errorMessage = "";
                    huonErrorMessage = "";
                    result = true;
                    done = true;
                    break;

                case "303":        //303 - SELECTION MUST BE ENTERED
                case "795":        //	795 - SECTION IS INVALID FOR AGENT
                case "420":        //420 - DATE IS INVALID
                case "3092":    //3092 - STATE MUST BE ENTERED
                case "4013":    //4013 - AGENT NUMBER MUST BE ENTERED
                case "4100":    //4100 - PRODUCT CODE MUST BE ENTERED
                case "460":        //460 - SECTION MUST BE ENTERED
                case "4266":    //"4266 - PREMIUMS NOT CALCULATED AS THE ABOVE FACTORS WERE NOT FOUND"
                case "4000":    //4000 - CLIENT NUMBERS MUST BE NUMERIC
                case "800392":    //"800392 - PREMIUM NOT CALCULATED. RATING FACTOR NOT FOUND"
                case "800482":    //"800482 - UNABLE TO OFFER POLICY. CHECK EMBARGO/REFUSAL INFO SITE"
                case "801850":        //"801850 - UNKNOWN ERROR IN DISCOUNT SERVICE - CONTACT SUPPORT"
//			case "9328": //9328 - NAME ADDRESS COMBINATION ALREADY ON FILE
                case "4906":    //4906 - FIELD MUST BE ENTERED AND NUMERIC
                case "801077":    //801077 - CLIENT AGE & AGE LICENCE OBTAINED DO NOT MATCH. RE-ENTER
                case "2809":    //2809 - FIELD MUST BE ENTERED
                case "3981":    //"3981 - FIELD IS INVALID", _
                case "4408":    //4438 - FIELD MUST BE NUMERIC
                case "4001":    //4001 - CLIENT NOT ON FILE
                case "801598":    //801598 - COMBINATION OF EXCESS VALUE AND TYPE NOT FOUND
                case "9538":    //9538 - STATE MUST EQUAL THE RATE STATE ENTERED FOR THE ITEM
                case "9361":    //9361 - FIELD IS REQUIRED
                case "843142":    //843142 - RENEWAL TOO FAR IN ADVANCE - SEE POLICY DATES
                case "12387":    //12387 - EXCEPTIONS ENCOUNTERED - ACTIVITY PROCESSING NOT COMPLETED
                case "801043":    //801043 - MIN SEC NOT MET -COVER CANNOT BE OFFERED
                case "800510":    //800510 - MODIFICATION CODE ALREADY EXISTS
                case "800440":    // 800440 - CANNOT AMEND TO AGREED VALUE MID-TERM
                case "11620":    // 11620 - CAN'T DELETE A PRIOR ENTERED COVERAGE. IT MUST BE CANCELLED
                case "800483":    //800483 - AMENDMENT NOT COMPLETE. CHECK EMBARGO/REFUSAL INFO SITE
//			case "803080":	//803080 - INVALID COMBINATION OF ANSWERS - VERIFY
                case "801891":    //801891 - "MAKE" RETURNED BY RMS NOT MATCHED. PLEASE CONFIRM DETAILS
                case "3768":    // 3768 - POLICY PROCESSING CENTER MUST BE THE SAME AS YOUR OWN

                    /*
                     * There is error to finish the transaction, so abort current transaction.
                     */
                    huonErrorMessage = huon.readErrorMessage().trim();
                    errorMessage = screenName + " - " + huonErrorMessage;
                    Location location = huon.readCursorLocation();
                    int row = location.getRow() + 1;
                    int col = location.getColumn() + 1;
                    errorMessage = errorMessage + ": row=" + row
                            + ";col=" + col;

                    if (errorCode.equalsIgnoreCase("3981")) {
                        if (screenName.equalsIgnoreCase("TBO314")) {
                            if (row == 5 && col == 13) {
                                errorMessage = errorMessage + ";The NCB value provided is incorrect for the effective date";
                            }
                        }
                    }

                    if (errorCode.equalsIgnoreCase("795")) {
                        errorMessage = errorMessage + ";Agent=" + huon.readFromField(16, 32, 40).trim();
                        errorMessage = errorMessage + ";State=" + huon.readFromField(16, 59, 60).trim();
                        errorMessage = errorMessage + ";Section=" + huon.readFromField(17, 59, 61).trim();
                    }

                    //Get all the text in the screen to exception
                    String[] screenStr = huon.readScreen();
                    List<String> screenList = new ArrayList<String>();
//				System.err.println(screenList);

                    for (int i = 0; i < screenStr.length; i++) {
                        if (!screenStr[i].trim().isEmpty()) {
                            screenList.add(screenStr[i].trim());
                        }
                    }

                    errorMessage = errorMessage + "; Screen Text: ";
                    errorMessage = errorMessage + screenList;

                    captureErrorScreenshot();
//				errorMessage = errorMessage + ";width:height: " + huon.getMaxWidth() + ":" + huon.getMaxHeight();
                    huon.abortIncomplete();
                    done = true;
                    result = false;
                    break;

                case "800390":    //800390 - PREMIUM NOT CALCULATED. xxxxx
                    /*
                     * There is PIRRI related error to finish the transaction, so abort current transaction.
                     */
                    huonErrorMessage = huon.readErrorMessage().trim();
                    errorMessage = screenName + " - " + huonErrorMessage;

                    captureErrorScreenshot();
                    huon.abortIncomplete();
                    done = true;
                    result = false;
                    break;

                case "8378":    //"8378 - PRESS ENTER TO CONTINUE"
                case "801295":    //801295 - ABN/ACN IS MISSING. PLEASE CONFIRM
                case "800340":    //800340 - ACC DAMAGE AND FUSION AUTO-SELECTED
                case "801170":        //801170 - WARNING: CHECK ACCEPTANCE CRITERIA BEFORE OFFERING COVER
                case "801017":        //801017 - WARNING: CHECK UNOCCUPANCY GUIDELINE FOR ACCEPTANCE
                case "801669":        ////801669 - MUST BE MPD AUTHORISED USER OR REFER TO SUPPORT AREA
                case "60270":    //60270 - QUOTE/POLICY PRESENT FOR REGISTRATION NUMBER
                case "9328":    //9328 - NAME ADDRESS COMBINATION ALREADY ON FILE
                case "802473":    //802473 - SUM INSURED EXCEEDS REFERRAL LEVEL. REFERRAL REQUIRED AT NB.
                case "802474":    //802474 - VEHICLE IS IN POOR CONDITION. REFERRAL REQUIRED AT NB.
                case "801657":    //801657 - PREVIOUS MPD WAS Y PLEASE UPDATE IF REQUIRED.
                case "801656":    //801656 - PREVIOUS MPD WAS N PLEASE UPDATE IF REQUIRED.
                case "802490":    // 802490 - CONTENTS IN TRANSIT-PLS REFER ORBIT KNOWLEDGE FOR GUIDELINES
                case "9304":    //9304 - WARNING: AGENT NOT LICENSED IN THIS STATE
                case "11689":    //11689 - FIELD PREVIOUSLY ENTERED HAS BEEN PROTECTED AND CLEARED

                    /*
                     * Just some warnings, and press ENTER to continue
                     */
                    huon.enter();
                    break;

                case "11119":     //"11119 - CONFIRM CHANGES TO UPDATE BILLING"
                case "800598":    //"800598 - AUW NEEDS TO BE RECONSULTED - PRESS PF2 TO RECALL AUW"
                case "800602":    //"800602 - EXCESS TYPE CHANGED, PRESS PF2 TO REVALIDATE EXCESS VALUES"
                case "800606":    //"800606 - PRESS PF2 TO REVALIDATE EXCESS VALUES"
                case "800438":    //800438 - VEHICLE CAN ONLY BE INSURED FOR MAXIMUM SI OR MARKET VALUE
                case "800439":    //800439 - VEHICLE CAN ONLY BE INSURED FOR MIMIMUM SI OR MARKET VALUE
                case "2651":        //2651 - PF2 MUST BE PRESSED (AUTO CALC) BEFORE GOING TO NEXT SCREEN
                case "802476":    //802476 - MULTIPLE CLAIMS ON DRIVERS, SPECIAL CONDITIONS APPLY AT NB
                case "800843":    //800843 - VEHICLE MUST BE INSPECTED FOR AGREED VALUE
                case "800593":    //800593 - AN INSPECTION IS REQUIRED

                    /*
                     * Press PF2 to continue
                     */
                    huon.pressKey(Key.PF2);
                    huon.enter();
                    break;

                case "800607":    //800607 - PLEASE CONFIRM DETAILS AS VEHICLE IS NOT ON VALUATION FILE
                    huonErrorMessage = huon.readErrorMessage().trim();
                    errorMessage = screenName + " - " + huonErrorMessage;

                    captureErrorScreenshot();
                    huon.abortIncomplete();
                    done = true;
                    result = false;
                    break;
                case "800447": //800447 - ERROR. RATING/NCB OVERRIDE REASON NOT REQUIRED
                case "800574":    //800574 - OVERRIDE REASON IS NOT REQUIRED
                    if (screenName.equalsIgnoreCase("TBO314") || screenName.equalsIgnoreCase("TCO314")) {
                        huon.eraseField(5, 59);
                        huon.pressKey(Key.PF2);
                        huon.enter();
                        break;
                    } else {
                        huonErrorMessage = huon.readErrorMessage().trim();
                        errorMessage = screenName + " - " + huonErrorMessage;
                        done = true;
                        result = false;
                        abort = true;
                        break;
                    }


                case "800094":    //800094 - STR ELIGIBLE - BUT EFFECT DATE > 21 DAYS FROM INCEPTION
                    huon.pressKey(Key.PF2);
                    break;

                case "801581": //For CTP:  801581 - MVI MATCH NOT FOUND, INSURANCE COMPANY CANNOT BE NRMA
                case "801594":        //For CTP: 801594 - COMPANY MUST BE NRMO, NRMF OR VVC TO INDICATE NRMA INSURANCE
                    huon.input(19, 27, "Y");
                    huon.input(19, 39, "NRMO");
                    huon.enter();
                    break;

                case "90026":    //90026 - DATE ENTERED MUST BE LESS THAN OR EQUAL TO TODAYS DATE

                    if (screenName.equalsIgnoreCase("TBO411") || screenName.equalsIgnoreCase("TBO421")) {
                        errorRow = 10;
                        errorCol = 70;
                    }

                    if (screenName.equalsIgnoreCase("TBO382")) {
                        errorRow = 10;
                        errorCol = 70;
                    }

                    huon.eraseField(errorRow, errorCol);
                    huon.input(errorRow, errorCol, (new SimpleDateFormat("dd/MM/yyyy")).format(Calendar.getInstance().getTime()));
                    huon.enter();
                    break;
                case "500071":    //500071 - FIELD IS NOT REQUIRED
                    if (screenName.equalsIgnoreCase("PPO011")) {
                        huon.eraseField(15, 18);
                        huon.enter();
                    }
                    break;
                case "803167":        //803167 - INCORRECT MPD SELECTION
                    huon.enter();

                    if (screenName.equalsIgnoreCase("TBO528")) {
                        errorRow = 6;
                        errorCol = 73;
                    }

                    if (screenName.equalsIgnoreCase("TBO410")) {
                        errorRow = 21;
                        errorCol = 59;
                    }

                    if (screenName.equalsIgnoreCase("TBO420")) {
                        errorRow = 19;
                        errorCol = 64;
                    }

                    //VVC
                    if (screenName.equalsIgnoreCase("TBO324")) {
                        errorRow = 12;
                        errorCol = 60;
                    }

                    if (huon.readFromField(errorRow, errorCol, errorCol).equalsIgnoreCase("Y"))
                        huon.input(errorRow, errorCol, "N");
                    else
                        huon.input(errorRow, errorCol, "Y");

                    huon.enter();

                    break;

                case "60271":    //60271 - CTP/NSW QUOTE/POLICY PRESENT FOR VIN/CHASSIS
                case "60272":    //60272 - CTP/NSW QUOTE/POLICY PRESENT FOR REG NO AND VIN/CHASSIS
                    if (huon.readScreenName().equals("TBO551")) {
                        String vin = DataHandler.randomAlphanumeric(17);
                        if (huon.readFromField(9, 2, 4).equalsIgnoreCase("VIN"))
                            huon.input(9, 15, vin);

                        if (huon.readFromField(10, 2, 4).equalsIgnoreCase("VIN"))
                            huon.input(10, 15, vin);

                        huon.enter();
                    }
                    break;

//			case "801850":	//801850 - UNKNOWN ERROR IN DISCOUNT SERVICE - CONTACT SUPPORT
                default:
                    huonErrorMessage = huon.readErrorMessage().trim();
                    errorMessage = screenName + " - " + huonErrorMessage;
                    captureErrorScreenshot();
                    huon.abortIncomplete();
                    done = true;
                    result = false;
                    break;
            }

        }

        if (abort) {
            huon.printScreenshot();
            huon.abortIncomplete();
        }

        return result;
    }

    /**
     * Get the error message when transaction has been aborted.
     *
     * @return error message.
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    private void captureErrorScreenshot() {
        if (this.reporter == null)
            return;

        reporter.captureScreenshot("Error");
    }

    public String getScreenName() {
        return screenName;
    }

    public String getHuonErrorMessage() {
        return huonErrorMessage;
    }


}
