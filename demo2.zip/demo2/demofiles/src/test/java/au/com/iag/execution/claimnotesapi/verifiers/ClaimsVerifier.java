package au.com.iag.execution.claimnotesapi.verifiers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.springframework.stereotype.Component;
import au.com.iag.execution.claimnotesapi.model.ClaimNotesArtifact;
import io.restassured.response.Response;

@Component
public class ClaimsVerifier {


    public void verifyClaimNotesResponse(ClaimNotesArtifact claimNotesArtifact, Response response, String brand) {
        assertNotNull(response.path("notes.id"));

        if (!(brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI") || brand.equalsIgnoreCase("NZSTATE"))) {
            if (claimNotesArtifact.getClaimNotesRequest().getCreateDefaultActivity() != null) {
                assertEquals(claimNotesArtifact.getClaimNotesRequest().getCreateDefaultActivity(),
                        response.path("create_default_activity"));
            } else {
                assertEquals(true, response.path("create_default_activity"));
            }
        }
    }
}
