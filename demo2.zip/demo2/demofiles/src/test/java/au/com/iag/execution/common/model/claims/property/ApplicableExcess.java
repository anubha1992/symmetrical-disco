package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ApplicableExcess implements Serializable {

    private static final long serialVersionUID = -3977282690348168468L;
    private Amount amountOwing;
    private Amount amountPaid;
    private Boolean waived;
    private List<ExcessDetail> excessItems = new ArrayList<>();

    public Amount getAmountOwing() {
        return amountOwing;
    }

    public void setAmountOwing(Amount amountOwing) {
        this.amountOwing = amountOwing;
    }

    public Amount getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(Amount amountPaid) {
        this.amountPaid = amountPaid;
    }

    public Boolean getWaived() {
        return waived;
    }

    public void setWaived(Boolean waived) {
        this.waived = waived;
    }

    public List<ExcessDetail> getExcessItems() {
        return excessItems;
    }
}
