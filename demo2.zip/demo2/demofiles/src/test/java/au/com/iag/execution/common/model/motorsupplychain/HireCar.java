package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class HireCar implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("daily_rate")
    private Amount dailyRate;
    @JsonProperty("entitlement")
    private String entitlement;
    @JsonProperty("maximum_days")
    private Integer maximumDays;
    @JsonProperty("maximum_limit")
    private Amount maximumLimit;
    @JsonProperty("option_on_policy")
    private Boolean optionOnPolicy;


    @ApiModelProperty(
            value = "",
            required = false
    )
    public Amount getDailyRate() {
        return dailyRate;
    }

    @ApiModelProperty(
            value = "type of hire car entitlement. ref data - https://confluence.iag.com.au/display/GICP/CC+Hire+Car+Entitlement+Type",
            example = "Corporate Rates",
            required = false
    )
    public String getEntitlement() {
        return entitlement;
    }

    @ApiModelProperty(
            value = "maximum number of days of hire car entitlement",
            example = "5",
            required = false
    )
    public Integer getMaximumDays() {
        return maximumDays;
    }

    @ApiModelProperty(
            value = "maximum amount of money allowed to be spent on hire car",
            required = false
    )
    public Amount getMaximumLimit() {
        return maximumLimit;
    }

    @ApiModelProperty(
            value = "indicates if the policy has Hire Car Option",
            example = "true",
            required = false
    )
    public Boolean getOptionOnPolicy() {
        return optionOnPolicy;
    }


}