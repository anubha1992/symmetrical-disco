package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class Parties implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("individuals")
    private java.util.List<Individual> individuals;
    @JsonProperty("organisations")
    private java.util.List<Organisation> organisations;
    @JsonProperty("party_roles")
    private java.util.List<PartyRole> partyRoles;

  
    @ApiModelProperty(
        value = "List of individuals",
        required = false
    )
    public java.util.List<Individual> getIndividuals() {
       return individuals;
    }
 
    @ApiModelProperty(
        value = "List of organisations",
        required = false
    )
    public java.util.List<Organisation> getOrganisations() {
       return organisations;
    }
 
    @ApiModelProperty(
        value = "List of party roles",
        required = false
    )
    public java.util.List<PartyRole> getPartyRoles() {
       return partyRoles;
    }
 

}