package au.com.iag.execution.common.service.crods;

import au.com.iag.glados.common.GladosEnrichmentService;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static au.com.iag.glados.model.constants.GladosConstants.*;
import static org.apache.http.HttpStatus.SC_OK;

@Service
public class InsuredDetailsService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    public String getCustomerBySourceSystemPartyId(String sourceSystem, String partyId) {

        Response response = gladosEnrichmentService.sendGetRequest(
                getHeaders(),
                "/internal/services/insured-details/customer/sourceSystem/" + sourceSystem + "/party/" + partyId,
                "", SC_OK);

        return extractCustomerId(response);
    }

    private String extractCustomerId(Response response) {
        if(response.path("individuals[0]") != null) {
            return response.path("individuals[0].customer_id");
        } else {
            return response.path("organisations[0].customer_id");
        }
    }

    private Map<String, Object> getHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        return requestHeaders;
    }
}