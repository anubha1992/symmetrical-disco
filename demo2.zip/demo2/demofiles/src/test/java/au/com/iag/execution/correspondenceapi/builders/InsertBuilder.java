package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.InsertData;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Component
public class InsertBuilder {

    public List<InsertData> readInsertDataFromConfig() throws IOException {
        String fileName = "src/test/resources/data/correspondence-api/insertData.csv";
        Path myPath = Paths.get(fileName);
        try (BufferedReader bufferedReader = Files.newBufferedReader(myPath, StandardCharsets.UTF_8)) {
            HeaderColumnNameMappingStrategy<InsertData> strategy = new HeaderColumnNameMappingStrategy<>();
            strategy.setType(InsertData.class);
            CsvToBean<InsertData> csvToBean = new CsvToBeanBuilder<InsertData>(bufferedReader)
                    .withMappingStrategy(strategy)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();
            List<InsertData> listOfInserts = csvToBean.parse();
            return listOfInserts;
        }
    }
}
