package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class BindAndIssueRequest implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("payments")
    private PaymentDetails payments = new PaymentDetails();
    @JsonProperty("transaction_number")
    private String transactionNumber ;

  
    @ApiModelProperty(
        value = "Payment details",
        required = false
    )
    public PaymentDetails getPayments() {
       return payments;
    }
 
    @ApiModelProperty(
        value = "Transaction Number, this can be Quote number or Transaction number based on the transction type",
        example = "QTE1234567",
        required = false
    )
    public String getTransactionNumber() {
       return transactionNumber;
    }
 

}