package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SourceSystemPartiesItem{

	@JsonProperty("customerId")
	private int customerId;

	@JsonProperty("partyIdentifier")
	private PartyIdentifier partyIdentifier;

	@JsonProperty("primary")
	private boolean primary;

	public void setCustomerId(int customerId){
		this.customerId = customerId;
	}

	public int getCustomerId(){
		return customerId;
	}

	public void setPartyIdentifier(PartyIdentifier partyIdentifier){
		this.partyIdentifier = partyIdentifier;
	}

	public PartyIdentifier getPartyIdentifier(){
		return partyIdentifier;
	}

	public void setPrimary(boolean primary){
		this.primary = primary;
	}

	public boolean isPrimary(){
		return primary;
	}

	@Override
 	public String toString(){
		return 
			"SourceSystemPartiesItem{" + 
			"customerId = '" + customerId + '\'' + 
			",partyIdentifier = '" + partyIdentifier + '\'' + 
			",primary = '" + primary + '\'' + 
			"}";
		}
}