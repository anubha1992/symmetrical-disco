package au.com.iag.execution.claimdetailsapi.model.business;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Policy implements Serializable {

    private static final long serialVersionUID = 1L;
    private String brand;
    private String policyIdentifier;
    private String product;
}
