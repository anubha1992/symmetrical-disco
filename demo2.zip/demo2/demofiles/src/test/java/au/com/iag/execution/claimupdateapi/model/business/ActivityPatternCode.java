package au.com.iag.execution.claimupdateapi.model.business;

public enum ActivityPatternCode {

    REVIEW_QUOTE("REVIEW_QUOTE", "please review repairer quote"),
    REVIEW_AND_ACTION_NEW_COMPLAINT("REVIEW_AND_ACTION_NEW_COMPLAINT", "Review escalated complaint in Orbit and reassign if required"),
    CASE_ACTION_FURTHER_INFO("CASE_ACTION_FURTHER_INFO", "Review details of action required in Orbit"),
    CASE_ACTION_ASSESS_INSPECT("CASE_ACTION_ASSESS_INSPECT", "Review details of action required in Orbit"),
    CASE_ACTION_PAY_SETTLE("CASE_ACTION_PAY_SETTLE", "Review details of action required in Orbit"),
    CASE_URGENT_ACTION_AFCA("CASE_URGENT_ACTION_AFCA", "Review details of action required in Orbit"),
    CASE_URGENT_PAYMENT_AFCA("CASE_URGENT_PAYMENT_AFCA", "Review details of action required in Orbit"),
    ORBIT_COMPLAINT_45_DAY_SLA_REMINDER("ORBIT_COMPLAINT_45_DAY_SLA_REMINDER", "Review details of action required in Orbit"),
    ORBIT_COMPLAINT_10_DAY_COMPLAINT_UPDATE_REMINDER("ORBIT_COMPLAINT_10_DAY_COMPLAINT_UPDATE_REMINDER", "Review details of action required in Orbit"),
    ORBIT_COMPLAINT_15_DAY_SLA_REMINDER("ORBIT_COMPLAINT_15_DAY_SLA_REMINDER", "Review details of action required in Orbit"),
    ORBIT_COMPLAINT_5_DAY_COMPLAINT_RESOLUTION_REMINDER("ORBIT_COMPLAINT_5_DAY_COMPLAINT_RESOLUTION_REMINDER", "Review details of action required in Orbit");


    private String code;
    private String description;

    ActivityPatternCode(String code, String description){
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
