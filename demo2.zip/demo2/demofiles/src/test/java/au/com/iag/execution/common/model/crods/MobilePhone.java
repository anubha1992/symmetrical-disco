package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MobilePhone{

	@JsonProperty("country")
	private String country;

	@JsonProperty("note")
	private String note;

	@JsonProperty("areaCode")
	private String areaCode;

	@JsonProperty("phoneType")
	private String phoneType;

	@JsonProperty("phoneKey")
	private String phoneKey;

	@JsonProperty("effectiveToDate")
	private String effectiveToDate;

	@JsonProperty("effectiveFromDate")
	private String effectiveFromDate;

	@JsonProperty("localNumber")
	private String localNumber;

	public void setCountry(String country){
		this.country = country;
	}

	public String getCountry(){
		return country;
	}

	public void setNote(String note){
		this.note = note;
	}

	public String getNote(){
		return note;
	}

	public void setAreaCode(String areaCode){
		this.areaCode = areaCode;
	}

	public String getAreaCode(){
		return areaCode;
	}

	public void setPhoneType(String phoneType){
		this.phoneType = phoneType;
	}

	public String getPhoneType(){
		return phoneType;
	}

	public void setPhoneKey(String phoneKey){
		this.phoneKey = phoneKey;
	}

	public String getPhoneKey(){
		return phoneKey;
	}

	public void setEffectiveToDate(String effectiveToDate){
		this.effectiveToDate = effectiveToDate;
	}

	public String getEffectiveToDate(){
		return effectiveToDate;
	}

	public void setEffectiveFromDate(String effectiveFromDate){
		this.effectiveFromDate = effectiveFromDate;
	}

	public String getEffectiveFromDate(){
		return effectiveFromDate;
	}

	public void setLocalNumber(String localNumber){
		this.localNumber = localNumber;
	}

	public String getLocalNumber(){
		return localNumber;
	}

	@Override
 	public String toString(){
		return 
			"MobilePhone{" + 
			"country = '" + country + '\'' + 
			",note = '" + note + '\'' + 
			",areaCode = '" + areaCode + '\'' + 
			",phoneType = '" + phoneType + '\'' + 
			",phoneKey = '" + phoneKey + '\'' + 
			",effectiveToDate = '" + effectiveToDate + '\'' + 
			",effectiveFromDate = '" + effectiveFromDate + '\'' + 
			",localNumber = '" + localNumber + '\'' + 
			"}";
		}
}