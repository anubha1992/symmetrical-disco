package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.PolicySendCorrespondenceArtifact;
import au.com.iag.execution.correspondenceapi.model.business.MigrationDetails;
import au.com.iag.glados.service.RandomContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class MigrationPolicyBuilder {

    @Autowired private RandomContentService randomContentService;

    public void motorRemoveAllNonMandatoryFields(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact){
        policySendCorrespondenceArtifact
                .getPolicyCorrespondenceRequest()
                .getPolicyDetails()
                .getParties()
                .getIndividuals().forEach(individual -> individual.setDateOfBirth(null));
        policySendCorrespondenceArtifact
                .getPolicyCorrespondenceRequest()
                .getPolicyDetails().getParties().getDrivers().forEach(policyDriver -> {
                    policyDriver.setAgeLicenceObtained(null);
                    policyDriver.getLicenceEvents().forEach(licenceEvent -> licenceEvent.setType(null));
        });
        policySendCorrespondenceArtifact
                .getPolicyCorrespondenceRequest()
                .getPolicyDetails().getAssets()
                .getVehicleAssets().forEach(vehicleAsset -> {
                    vehicleAsset.setParkingLocation(null);
                    vehicleAsset.setExemptFromStampDuty(null);
        });
    }

    public void homeRemoveAllNonMandatoryFields(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact){
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails()
                .getPolicyHistory().getPolicy().getMigrationDetails().get(0).setMigrated(true);
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails()
                .getAssets().getHomeAssets().forEach(homeAsset -> {
            homeAsset.getBuilding().setDistanceToBushland(null);
            homeAsset.getBuilding().setSlope(null);
            homeAsset.getBuilding().setElevated(null);
            homeAsset.getBuilding().setStoreyCount(null);
            homeAsset.getBuilding().setHeritageListed(null);
            homeAsset.getBuilding().setYearConstructed(null);
            homeAsset.getBuilding().setRoofMaterial(null);
            homeAsset.getOccupants().setAdultFemaleCount(null);
            homeAsset.getOccupants().setAdultMaleCount(null);
            homeAsset.getOccupants().setChildrenCount(null);
        });
    }

    public void addMigratedFlag(PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact){
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().setGenerateMigrationLetter(true);
        MigrationDetails migrationDetails = new MigrationDetails();
        migrationDetails.setMigrated(true);
        migrationDetails.setPreviousPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails()
                .getPolicyHistory().getPolicy().setMigrationDetails(Arrays.asList(migrationDetails));
    }
}
