package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleValuation implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("country")
    private String country ;
    @JsonProperty("list_price")
    private Double listPrice ;
    @JsonProperty("retail_price_high")
    private Double retailPriceHigh ;
    @JsonProperty("retail_price_low")
    private Double retailPriceLow ;
    @JsonProperty("trade_price")
    private Double tradePrice ;

  
    @ApiModelProperty(
        value = "Country ISO code [Ref Data: address_countries]",
        example = "AUS",
        required = false
    )
    public String getCountry() {
       return country;
    }
 
    @ApiModelProperty(
        value = "The list price of the vehicle",
        example = "60000.0",
        required = false
    )
    public Double getListPrice() {
       return listPrice;
    }
 
    @ApiModelProperty(
        value = "The highest retail price of the vehicle",
        example = "40000.0",
        required = false
    )
    public Double getRetailPriceHigh() {
       return retailPriceHigh;
    }
 
    @ApiModelProperty(
        value = "The lowest retail price of the vehicle",
        example = "30000.0",
        required = false
    )
    public Double getRetailPriceLow() {
       return retailPriceLow;
    }
 
    @ApiModelProperty(
        value = "The trading price of the vehicle",
        example = "40000.0",
        required = false
    )
    public Double getTradePrice() {
       return tradePrice;
    }
 

}