package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import com.fasterxml.jackson.datatype.jsr310.deser.*;
import com.fasterxml.jackson.datatype.jsr310.ser.*;
import lombok.Data;
import java.io.*;
import java.time.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class Party implements Serializable {

    private static final long serialVersionUID = 1L;

    private Boolean policyContact;
    private String partyType;
    private List<Contact> contactDetails = new ArrayList<>();
    private List<String> roles;
    private String notes;
    private String partyIdentifier;
    private String witnessStatementObtained;
    private String witnessPerspective;
    private Boolean registeredForGst;
    private List<OrganisationName> organisationName = new ArrayList<>();
    private String title;
    private String firstName;
    private String lastName;
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate dateOfBirth;
    private String genderCode;
    private Boolean dateOfBirthKnown;
}