package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains payment related information for the policy")
public class PaymentDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("billing_frequency")
    private String billingFrequency ;
    @JsonProperty("billing_plan_options")
    private java.util.List<BillingPlanOptions> billingPlanOptions = new java.util.ArrayList<BillingPlanOptions>();
    @JsonProperty("direct_debit")
    private Boolean directDebit ;
    @JsonProperty("payment_instruments")
    private PaymentInstruments paymentInstruments = new PaymentInstruments();
    @JsonProperty("payment_method")
    private String paymentMethod ;
    @JsonProperty("payment_summary")
    private PaymentSummary paymentSummary = new PaymentSummary();
    @JsonProperty("refund_details")
    private RefundDetails refundDetails = new RefundDetails();

  
    @ApiModelProperty(
        value = "Billing frequency. [Ref Data: billing_frequency]",
        example = "MONTHLY",
        required = false
    )
    public String getBillingFrequency() {
       return billingFrequency;
    }
 
    @ApiModelProperty(
        value = "Instalment details for respective billing plan",
        required = false
    )
    public java.util.List<BillingPlanOptions> getBillingPlanOptions() {
       return billingPlanOptions;
    }
 
    @ApiModelProperty(
        value = "Indicates if billing plan has instalments.",
        example = "true",
        required = false
    )
    public Boolean getDirectDebit() {
       return directDebit;
    }
 
    @ApiModelProperty(
        value = "Payment instrument details",
        required = false
    )
    public PaymentInstruments getPaymentInstruments() {
       return paymentInstruments;
    }
 
    @ApiModelProperty(
        value = "Payment method. [Ref Data: payment_method]",
        example = "Credit card",
        required = false
    )
    public String getPaymentMethod() {
       return paymentMethod;
    }
 
    @ApiModelProperty(
        value = "Payment summary details",
        required = false
    )
    public PaymentSummary getPaymentSummary() {
       return paymentSummary;
    }
 
    @ApiModelProperty(
        value = "Refund details",
        required = false
    )
    public RefundDetails getRefundDetails() {
       return refundDetails;
    }
 

}