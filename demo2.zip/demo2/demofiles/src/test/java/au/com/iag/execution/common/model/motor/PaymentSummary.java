package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PaymentSummary implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("dishonour_details")
    private DishonourDetails dishonourDetails = new DishonourDetails();
    @JsonProperty("first_payment_details")
    private PaymentAmount firstPaymentDetails = new PaymentAmount();
    @JsonProperty("next_payment_details")
    private PaymentAmount nextPaymentDetails = new PaymentAmount();
    @JsonProperty("payment_status")
    private String paymentStatus ;
    @JsonProperty("premium_paid_date")
    private java.time.LocalDate premiumPaidDate ;
    @JsonProperty("total_outstanding_premium")
    private Double totalOutstandingPremium ;

  
    @ApiModelProperty(
        value = "Dishonour payment details",
        required = false
    )
    public DishonourDetails getDishonourDetails() {
       return dishonourDetails;
    }
 
    @ApiModelProperty(
        value = "First payment details",
        required = false
    )
    public PaymentAmount getFirstPaymentDetails() {
       return firstPaymentDetails;
    }
 
    @ApiModelProperty(
        value = "Next payment details",
        required = false
    )
    public PaymentAmount getNextPaymentDetails() {
       return nextPaymentDetails;
    }
 
    @ApiModelProperty(
        value = "Payment status. [Ref Data: payment_status]",
        required = false
    )
    public String getPaymentStatus() {
       return paymentStatus;
    }
 
    @ApiModelProperty(
        value = "Premium paid date",
        required = false
    )
    public java.time.LocalDate getPremiumPaidDate() {
       return premiumPaidDate;
    }
 
    @ApiModelProperty(
        value = "Total outstanding premium.",
        required = false
    )
    public Double getTotalOutstandingPremium() {
       return totalOutstandingPremium;
    }
 

}