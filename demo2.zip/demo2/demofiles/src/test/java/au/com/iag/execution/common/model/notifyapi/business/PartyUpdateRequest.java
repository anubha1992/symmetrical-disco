package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class PartyUpdateRequest implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("party_id")
    private String partyId;
    @JsonProperty("version_timestamp")
    private String versionTimestamp;

  
    @ApiModelProperty(
        value = "Id of the party.",
        example = "1.2345678E7",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "The version timestamp of the party record. Note: The date must include zone, format is ISO-8601. Pattern: yyyy-MM-dd&#x27;T&#x27;HH:mm:ss.SSSz Example values:   - &quot;2019-08-30T15:47:55.123+10:00&quot; or   - &quot;2019-08-30T15:47:55.123+10:00[Australia/Sydney]&quot; or   - &quot;2019-08-30T15:47:55.123Z&quot; for Zulu Time  - &quot;1567123200&quot; milliseconds since &#x27;1970-01-01T00:00:00Z[UTC]&#x27;",
        example = "2019-08-30T15:47:55.123Z",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getVersionTimestamp() {
       return versionTimestamp;
    }
 

}