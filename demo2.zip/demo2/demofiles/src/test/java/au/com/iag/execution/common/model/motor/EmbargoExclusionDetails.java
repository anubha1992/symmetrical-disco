package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class EmbargoExclusionDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("end_date_time")
    private java.time.ZonedDateTime endDateTime ;
    @JsonProperty("selected")
    private Boolean selected ;

  
    @ApiModelProperty(
        value = "Embargo end date time. Format yyyy-MM-dd&#x27;T&#x27;hh:mm:ss.SSSZ",
        example = "2019-08-30T15:47:55.123+10:00",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public java.time.ZonedDateTime getEndDateTime() {
       return endDateTime;
    }
 
    @ApiModelProperty(
        value = "Indicates if the exclusion is selected or not",
        example = "true",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Boolean getSelected() {
       return selected;
    }
 

}