package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.*;
import au.com.iag.glados.service.RandomContentService;
import com.github.javafaker.Faker;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;
import static org.assertj.core.api.Assertions.assertThat;

@Component
public class PartyBuilder {

    @Autowired private RandomContentService randomContentService;
    private Faker fakerAusLocale = new Faker(new Locale.Builder().setLanguageTag(FAKER_LOCALE_STRING).build());

    Parties buildParties(PolicyCorrespondence policyCorrespondence, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) {
        Parties parties = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getParties());
        List<Individual> listOfIndividuals = new ArrayList<>();
        List<Organisation> listOfOrganisations = new ArrayList<>();
        List<PolicyDriver> listOfPolicyDrivers = new ArrayList<>();
        List<PartyRole> listOfPartyRoles = new ArrayList<>();
        listOfCoverableToPartyRoleSpec.forEach(coverableToPartyRoleSpec -> {
            listOfPartyRoles.addAll(getListOfPartyRoles(coverableToPartyRoleSpec));
            listOfPolicyDrivers.addAll(getListOfPolicyDrivers(policyCorrespondence, coverableToPartyRoleSpec));
            switch (coverableToPartyRoleSpec.getPartyType()) {
                case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                    Individual individual = getIndividual(policyCorrespondence, coverableToPartyRoleSpec.getPartyId());
                    listOfIndividuals.add(individual);
                    break;
                case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                    Organisation organisation = getOrganisation(policyCorrespondence, coverableToPartyRoleSpec.getPartyId());
                    listOfOrganisations.add(organisation);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid Party Type - " + coverableToPartyRoleSpec.getPartyType());
            }
        });
        parties.setIndividuals(getDistinctIndividuals(listOfIndividuals));
        parties.setOrganisations(getDistinctOrganisations(listOfOrganisations));
        parties.setPartyRoles(listOfPartyRoles);
        parties.setDrivers(getDistinctPolicyDrivers(listOfPolicyDrivers));
        return parties;
    }

    public void updatePartyIdOnIncidentsOrClaims(PolicyCorrespondence policyCorrespondence) {
        Parties parties = policyCorrespondence.getPolicyDetails().getParties();
        Optional.ofNullable(parties.getPartyHistoryDisclosures().getIncidentOrClaims())
                .stream().filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .forEach(insuranceHistoryDisclosure -> insuranceHistoryDisclosure.setPartyId(parties.getPartyRoles().stream()
                        .filter(partyRole -> PARTY_ROLE_PRIMARY_POLICY_HOLDER.equals(partyRole.getRole())).findFirst().get().getPartyId()));
    }

    private Individual getIndividual(PolicyCorrespondence policyCorrespondence, String partyId) {
        Individual individual = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getParties().getIndividuals().get(0));
        individual.setPartyId(partyId == null ? randomContentService.getRandomNumber(9) : partyId);
        IndividualNames individualNames = new IndividualNames();
        IndividualNameDetails individualNameDetails = getIndividualNameDetails(fakerAusLocale);
        individualNames.setDetails(Collections.singletonList(individualNameDetails));
        individual.setNames(individual.getNames()!=null?individualNames:null);
        return individual;
    }

    private Organisation getOrganisation(PolicyCorrespondence policyCorrespondence, String partyId) {
        Organisation organisation = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getParties().getOrganisations().get(0));
        assertThat(organisation).as("The Base JSON is expected to have at least one Organisation entity!").isNotNull();
        organisation.setPartyId(partyId == null ? randomContentService.getRandomNumber(9) : partyId);
        OrganisationName organisationName = new OrganisationName();
        organisationName.setName(fakerAusLocale.company().name());
        organisation.setNames(organisation.getNames()!=null?Collections.singletonList(organisationName):null);
        return organisation;
    }

    private List<PartyRole> getListOfPartyRoles(CoverableToPartyRoleSpec coverableToPartyRoleSpec) {
        List<PartyRole> listOfPartyRoles = new ArrayList<>();
        List<String> listOfPolicyLevelRoles = coverableToPartyRoleSpec.getListOfPolicyLevelRoles();
        if (listOfPolicyLevelRoles != null) {
            listOfPolicyLevelRoles.forEach(policyRole -> {
                PartyRole partyRole = new PartyRole();
                partyRole.setPartyId(coverableToPartyRoleSpec.getPartyId());
                partyRole.setRole(policyRole);
                listOfPartyRoles.add(partyRole);
            });
        }
        return listOfPartyRoles;
    }

    private List<PolicyDriver> getListOfPolicyDrivers(PolicyCorrespondence policyCorrespondence, CoverableToPartyRoleSpec coverableToPartyRoleSpec) {
        List<PolicyDriver> lidOfPolicyDriver = new ArrayList<>();
        Map<Integer, List<String>> mapOfAssetIndexToAssetLevelRoles = coverableToPartyRoleSpec.getMapOfAssetIndexToAssetLevelRoles();
        if (mapOfAssetIndexToAssetLevelRoles != null) {
            mapOfAssetIndexToAssetLevelRoles.values().stream().flatMap(Collection::stream).filter("DRIVER"::equals).forEach(driver -> {
                PolicyDriver policyDriver = getPolicyDriver(policyCorrespondence, coverableToPartyRoleSpec.getPartyId());
                lidOfPolicyDriver.add(policyDriver);
            });
        }
        return lidOfPolicyDriver;
    }

    private PolicyDriver getPolicyDriver(PolicyCorrespondence policyCorrespondence, String partyId) {
        Optional<List<PolicyDriver>> listOptionalPolicyDrivers = Optional.of(policyCorrespondence)
                .map(PolicyCorrespondence::getPolicyDetails).map(PolicyDetails::getParties).map(Parties::getDrivers);
        if (listOptionalPolicyDrivers.isPresent()) {
            PolicyDriver policyDriver = SerializationUtils.clone(listOptionalPolicyDrivers.get().get(0));
            policyDriver.setPartyId(partyId);
            return policyDriver;
        }
        return null;
    }

    private IndividualNameDetails getIndividualNameDetails(Faker faker) {
        IndividualNameDetails individualNameDetails = new IndividualNameDetails();
        List<String> listOfTitles = Arrays.asList("RIGHT_REVEREND", "DEACON", "LIEUTENANT_GENERAL", "DAME");//invokeRdmRefData(Map.of("name", "individual_titles"), false);
        individualNameDetails.setTitle(listOfTitles.get(new Random().nextInt(listOfTitles.size())));
        individualNameDetails.setFirstName(faker.name().firstName());
        individualNameDetails.setLastName(faker.name().lastName());
        individualNameDetails.setType("LEGAL");
        return individualNameDetails;
    }

    private List<Individual> getDistinctIndividuals(List<Individual> listOfIndividuals) {
        return listOfIndividuals.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(Individual::getPartyId))),
                        ArrayList::new));
    }

    private List<Organisation> getDistinctOrganisations(List<Organisation> listOfOrganisations) {
        return listOfOrganisations.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(Organisation::getPartyId))),
                        ArrayList::new));
    }

    private List<PolicyDriver> getDistinctPolicyDrivers(List<PolicyDriver> listOfPolicyDrivers) {
        if (listOfPolicyDrivers != null && !listOfPolicyDrivers.stream().noneMatch(Objects::nonNull)) {
            return listOfPolicyDrivers.stream()
                    .collect(Collectors.collectingAndThen(
                            Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PolicyDriver::getPartyId))),
                            ArrayList::new));
        }
        return null;
    }
}
