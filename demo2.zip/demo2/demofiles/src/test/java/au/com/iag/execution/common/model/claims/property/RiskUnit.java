package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class RiskUnit implements Serializable {

    private static final long serialVersionUID = -4191364516011880000L;
    private String riskType;
    private Address riskAddress;

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public Address getRiskAddress() {
        return riskAddress;
    }

    public void setRiskAddress(Address riskAddress) {
        this.riskAddress = riskAddress;
    }
}
