package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class Repair {
    private Amount agreedValue;
    @ApiModelProperty(
            value = "Indicate the repair authority - 'Authorised' OR 'Authority withheld'",
            example = "authorised")
    private String authorityIndicator;
    private Amount totalAmountIncludingGst;
    private Amount marketValue;
    @ApiModelProperty(
            value = "agreed, market, retail",
            example = "market")
    private String sumInsuredType;
}
