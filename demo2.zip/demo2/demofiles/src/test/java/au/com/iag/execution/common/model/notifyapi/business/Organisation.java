package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class Organisation implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("addresses")
    private java.util.List<MailingAddress> addresses;
    @JsonProperty("party_id")
    private String partyId;

  
    @ApiModelProperty(
        value = "List of addresses of the organisation",
        required = false
    )
    public java.util.List<MailingAddress> getAddresses() {
       return addresses;
    }
 
    @ApiModelProperty(
        value = "Party identifier of the organisation",
        example = "12345",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getPartyId() {
       return partyId;
    }
 

}