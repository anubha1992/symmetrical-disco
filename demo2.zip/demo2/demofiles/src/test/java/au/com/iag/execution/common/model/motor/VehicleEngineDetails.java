package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleEngineDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("capacity_value_cc")
    private String capacityValueCc ;
    @JsonProperty("capacity_value_litres")
    private String capacityValueLitres ;
    @JsonProperty("code")
    private String code ;
    @JsonProperty("transmission_type")
    private String transmissionType ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Engine Capacity in cubic centimetres (cc).",
        example = "1000",
        required = false
    )
    public String getCapacityValueCc() {
       return capacityValueCc;
    }
 
    @ApiModelProperty(
        value = "Engine Capacity in Litres.",
        example = "1.5",
        required = false
    )
    public String getCapacityValueLitres() {
       return capacityValueLitres;
    }
 
    @ApiModelProperty(
        value = "Engine Code",
        example = "1.5",
        required = false
    )
    public String getCode() {
       return code;
    }
 
    @ApiModelProperty(
        value = "Transmission type e.g. Manual, AUTO",
        example = "AUTO",
        required = false
    )
    public String getTransmissionType() {
       return transmissionType;
    }
 
    @ApiModelProperty(
        value = "Engine type e.g. Petrol, Diesel",
        example = "Petrol",
        required = false
    )
    public String getType() {
       return type;
    }
 

}