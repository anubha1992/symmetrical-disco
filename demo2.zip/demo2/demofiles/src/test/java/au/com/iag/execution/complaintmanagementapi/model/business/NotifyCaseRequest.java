package au.com.iag.execution.complaintmanagementapi.model.business;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@Data
public class NotifyCaseRequest implements Serializable {
    private static final long serialVersionUID = 2114462182242405497L;

    @ApiModelProperty(value = "identifier for the case in external system")
    public String caseId;
    @ApiModelProperty(value = "claim Id")
    public String claimId;
    @ApiModelProperty(value = "exposure Id")
    public String exposureId;
    @ApiModelProperty(value = "complaint escalation level")
    public String notificationType;
    @ApiModelProperty(value = "status of the case")
    public String caseStatus;
    @ApiModelProperty(value = "case outcome")
    public String caseOutcome;
    @ApiModelProperty(value = "the userId to be used when assigning activities")
    public String caseOwner;
    @ApiModelProperty(value = "Group name of the CC8 group that represents the CCM queues and their owners in CC8")
    public String groupName;
    @ApiModelProperty(value = "business time at which this event occurred")
    public OffsetDateTime businessTimestamp;
    @ApiModelProperty(value = "date of inception of the case")
    public LocalDate inceptionDate;
    public Boolean notifyOwner;
}
