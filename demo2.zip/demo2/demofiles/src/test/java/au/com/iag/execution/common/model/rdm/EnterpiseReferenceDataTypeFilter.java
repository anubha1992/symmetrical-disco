package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class EnterpiseReferenceDataTypeFilter implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("name")
    private String name;
    @JsonProperty("value")
    private String value;

  
    @ApiModelProperty(
        value = "Name of the reference data filter",
        example = "GENDER",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "Value for this filter",
        example = "FEMALE",
        required = false
    )
    public String getValue() {
       return value;
    }
 

}