package au.com.iag.execution.common.model.huon.util;

import java.lang.reflect.*;
import java.text.*;
import java.util.*;

/**
 * For captured adjustment points
 */
public class AdjustmentPoints {

    private String coverage = "";
    private String inclusive = "";
    private String adjustment = "";
    private String basepoints = "";
    private String excluded = "";

    public String getCoverage() {
        return coverage;
    }

    public void setCoverage(String coverage) {
        this.coverage = coverage;
    }

    public String getInclusive() {
        return inclusive;
    }

    public void setInclusive(String inclusive) {
        this.inclusive = inclusive;
    }

    public String getAdjustment() {
        return adjustment;
    }

    public void setAdjustment(String adjustment) {
        this.adjustment = adjustment;
    }

    public String getBasepoints() {
        return basepoints;
    }

    public void setBasepoints(String basepoints) {
        this.basepoints = basepoints;
    }

    public String getExcluded() {
        return excluded;
    }

    public void setExcluded(String excluded) {
        this.excluded = excluded;
    }

    public boolean equals(AdjustmentPoints otherPoints, HashMap<String, String> assertMessage) throws IllegalArgumentException, IllegalAccessException {
        boolean totalResult = true;

        Class<?> thisClass = this.getClass();
        Field[] thisFields = thisClass.getDeclaredFields();
        for (int i = 0; i < thisFields.length; i++) {
            if (Modifier.isStatic(thisFields[i].getModifiers()))
                continue;

            if (thisFields[i].getName().equals("coverage"))
                continue;

            thisFields[i].setAccessible(true);

            //
            String thisStr = (String) thisFields[i].get(this);
            String thatStr = (String) thisFields[i].get(otherPoints);
            thisStr = thisStr.trim().replaceAll(",", "");
            thatStr = thatStr.trim().replaceAll(",", "");

            boolean isSame = false;

            if (thisStr.isEmpty() || thatStr.isEmpty()) {
                if (thisStr.equalsIgnoreCase(thatStr)) {
                    isSame = true;
                }
            } else {
                float thisFloat = Float.parseFloat(thisStr);
                float thatFloat = Float.parseFloat(thatStr);

                if (thisFloat == thatFloat) {
                    isSame = true;
                }
            }

            if (!isSame) {
                totalResult = false;
                if (!this.coverage.isEmpty())
                    assertMessage.put(this.coverage + "_" + thisFields[i].getName(), thisFields[i].get(this) + ";" + thisFields[i].get(otherPoints));
                else
                    assertMessage.put("Policy" + "_" + thisFields[i].getName(), thisFields[i].get(this) + ";" + thisFields[i].get(otherPoints));
            }

        }

        return totalResult;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        sb.append(super.toString());

        Class<?> myClass = this.getClass();
        String thisName = AdjustmentPoints.class.getName();
        while (!myClass.getName().equalsIgnoreCase(thisName)) {
            myClass = myClass.getSuperclass();
        }

        try {
            Field[] fields = myClass.getDeclaredFields();

            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers()))
                    continue;
                field.setAccessible(true);
                sb.append(field.getName());
                sb.append("=");
                if (field.getType().getName().endsWith("Date")) {
                    Date date = (Date) field.get(this);
                    if (date != null) {
                        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                        sb.append(formatter.format(date));
                    } else {
                        sb.append("");
                    }
                } else {
                    sb.append(field.get(this));
                }
                sb.append(";");
            }
        } catch (IllegalAccessException iae) {

        }


        sb.append("]");
        return sb.toString();
    }

}
