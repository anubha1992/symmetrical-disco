package au.com.iag.execution.common.builders.notifyapi;

import static java.util.Map.entry;

import static au.com.iag.glados.model.constants.GladosConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.APPLICATION_JSON;
import static au.com.iag.glados.model.constants.GladosConstants.CONTENT_TYPE;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AGENT_ID;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_BRAND;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_DISTRIBUTOR;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_SALES_CHANNEL;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_SESSION_ID;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import au.com.iag.execution.notifyapi.model.NotifyRequestArtifact;
import au.com.iag.execution.notifyapi.model.business.Policy;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import au.com.iag.glados.service.SecurityService;

@Component
public class PolicyContractUpdateRequestBuilder {
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private SecurityService securityService;


    @Value("${test.api.brand}") private String brand;
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;
    @Value("${test.api.channel}") private String channel;
    @Value("${test.api.user}") private String user;
    @Value("${test.api.session}") private String sessionId;
    @Value("${test.api.distributor}") private String distributor;
    @Value("${test.api.agent-id}") private String agentId;
    @Value("${test.api.route}") private String route;

    private Map<String, String> assetRequestMapper = Map.ofEntries(
            entry("Landlord", "requests/notify-api/landlordRequest.json")

    );

//    private Map<String, String> productMapper = Map.ofEntries(
//            entry("productLandlord", "LANDLORD_INSURANCE")
//    );

    public NotifyRequestArtifact setupPolicyUpdateDefaults(String assetType) throws IOException {
        NotifyRequestArtifact notifyRequestArtifact = new NotifyRequestArtifact();
        notifyRequestArtifact.setHeaders(buildHeaders());
        notifyRequestArtifact.setPath(route + "/policy-contract-update");
        notifyRequestArtifact.setRequest(buildRequestByAsset(assetType));
        return notifyRequestArtifact;
    }

    private Policy buildRequestByAsset(String assetType) throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(assetRequestMapper.get(assetType)), Policy.class);
    }


    private Map<String, Object> buildHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(X_IAG_SALES_CHANNEL, channel);
        requestHeaders.put(X_IAG_USER, user);
        requestHeaders.put(X_IAG_SESSION_ID, sessionId);
        requestHeaders.put(X_IAG_DISTRIBUTOR, distributor);
        requestHeaders.put(X_IAG_AGENT_ID, agentId);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));

        return requestHeaders;
    }

}
