package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class MailingAddress implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("address_hash")
    private String addressHash ;
    @JsonProperty("address_id")
    private String addressId ;
    @JsonProperty("attention")
    private String attention ;
    @JsonProperty("country")
    private String country ;
    @JsonProperty("descriptive_address_line1")
    private String descriptiveAddressLine1 ;
    @JsonProperty("descriptive_address_line2")
    private String descriptiveAddressLine2 ;
    @JsonProperty("descriptive_full_address")
    private String descriptiveFullAddress ;
    @JsonProperty("display_address_line1")
    private String displayAddressLine1 ;
    @JsonProperty("display_address_line2")
    private String displayAddressLine2 ;
    @JsonProperty("dpid")
    private String dpid ;
    @JsonProperty("full_address")
    private String fullAddress ;
    @JsonProperty("international_address")
    private InternationalAddress internationalAddress = new InternationalAddress();
    @JsonProperty("locality_name")
    private String localityName ;
    @JsonProperty("postal_address")
    private PostalAddress postalAddress = new PostalAddress();
    @JsonProperty("postcode")
    private String postcode ;
    @JsonProperty("rd_number")
    private String rdNumber ;
    @JsonProperty("state")
    private String state ;
    @JsonProperty("street_address")
    private StreetAddress streetAddress = new StreetAddress();
    @JsonProperty("town_city_name")
    private String townCityName ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Salted Hash of Full Address String.",
        example = "86defd8snwwf9560bb5087dSydney2000",
        required = false
    )
    public String getAddressHash() {
       return addressHash;
    }
 
    @ApiModelProperty(
        value = "The identifier for the address",
        example = "ADD0001",
        required = false
    )
    public String getAddressId() {
       return addressId;
    }
 
    @ApiModelProperty(
        value = "The attention line on the address.",
        example = "John Smith",
        required = false
    )
    public String getAttention() {
       return attention;
    }
 
    @ApiModelProperty(
        value = "Defaults to Australia. (REFERENCE DATA type &#x27;address_countries&#x27;).",
        example = "AUS",
        required = false
    )
    public String getCountry() {
       return country;
    }
 
    @ApiModelProperty(
        value = "First line of the formatted address used mostly for displaying purposes. Does not include locality name or postcode.",
        example = "388 George Street",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getDescriptiveAddressLine1() {
       return descriptiveAddressLine1;
    }
 
    @ApiModelProperty(
        value = "Second line of the formatted address.Consists of locality name,post code and state and country in case of international address.",
        example = "Sydney 2000",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getDescriptiveAddressLine2() {
       return descriptiveAddressLine2;
    }
 
    @ApiModelProperty(
        value = "Address formatted as a single line string mostly for displaying purposes available when retrieving address",
        example = "388 George Street Sydney 2000",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getDescriptiveFullAddress() {
       return descriptiveFullAddress;
    }
 
    @ApiModelProperty(
        value = "First line of the formatted address used mostly for displaying purposes. Does not include building name.",
        example = "181 William Street",
        required = false
    )
    public String getDisplayAddressLine1() {
       return displayAddressLine1;
    }
 
    @ApiModelProperty(
        value = "Second line of the formatted address.Consists of locality name,post code and state and country in case of international address.",
        example = "Melbourne 3000",
        required = false
    )
    public String getDisplayAddressLine2() {
       return displayAddressLine2;
    }
 
    @ApiModelProperty(
        value = "Deliver point identifier - uniquely allocated to every address",
        example = "39549554",
        required = false
    )
    public String getDpid() {
       return dpid;
    }
 
    @ApiModelProperty(
        value = "Address formatted as a single line string mostly for displaying purposes available when retrieving address",
        example = "181 William Street Melbourne 3000",
        required = false
    )
    public String getFullAddress() {
       return fullAddress;
    }
 
    @ApiModelProperty(
        value = "Address as per a given country format",
        required = false
    )
    public InternationalAddress getInternationalAddress() {
       return internationalAddress;
    }
 
    @ApiModelProperty(
        value = "Name of the suburb, town, city or locality",
        example = "Lane Cove",
        required = false
    )
    public String getLocalityName() {
       return localityName;
    }
 
    @ApiModelProperty(
        value = "Postal address details",
        required = false
    )
    public PostalAddress getPostalAddress() {
       return postalAddress;
    }
 
    @ApiModelProperty(
        value = "Post code of the suburb",
        example = "3134",
        required = false
    )
    public String getPostcode() {
       return postcode;
    }
 
    @ApiModelProperty(
        value = "Rural delivery number used in NZL addresses.",
        example = "RD 1",
        required = false
    )
    public String getRdNumber() {
       return rdNumber;
    }
 
    @ApiModelProperty(
        value = "State or other administrative area name in case of international address",
        example = "VIC",
        required = false
    )
    public String getState() {
       return state;
    }
 
    @ApiModelProperty(
        value = "Street address details",
        required = false
    )
    public StreetAddress getStreetAddress() {
       return streetAddress;
    }
 
    @ApiModelProperty(
        value = "Name of the town or city. Required for NZ.",
        example = "Auckland",
        required = false
    )
    public String getTownCityName() {
       return townCityName;
    }
 
    @ApiModelProperty(
        value = "The type of address e.g. Mailing Address, Residential",
        example = "Residential",
        required = false
    )
    public String getType() {
       return type;
    }
 

}