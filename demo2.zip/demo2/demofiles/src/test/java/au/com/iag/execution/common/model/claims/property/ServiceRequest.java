package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ServiceRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private String type;
    private String jobType;
    private String specialInstruction;
    private Boolean collectExcess;
    private String supplierId;
    private List<Incident> incidents;
    private Boolean customerAcknowledgement;
    @JsonProperty("is_make_safe_required")
    private Boolean makeSafeRequired;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getSpecialInstruction() {
        return specialInstruction;
    }

    public void setSpecialInstruction(String specialInstruction) {
        this.specialInstruction = specialInstruction;
    }

    public Boolean getCollectExcess() {
        return collectExcess;
    }

    public void setCollectExcess(Boolean collectExcess) {
        this.collectExcess = collectExcess;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public List<Incident> getIncidents() {
        return incidents;
    }

    public void setIncidents(List<Incident> incidents) {
        this.incidents = incidents;
    }

    public Boolean getCustomerAcknowledgement() {
        return customerAcknowledgement;
    }

    public void setCustomerAcknowledgement(Boolean customerAcknowledgement) {
        this.customerAcknowledgement = customerAcknowledgement;
    }

    public Boolean getMakeSafeRequired() {
        return makeSafeRequired;
    }

    public void setMakeSafeRequired(Boolean makeSafeRequired) {
        this.makeSafeRequired = makeSafeRequired;
    }
}
