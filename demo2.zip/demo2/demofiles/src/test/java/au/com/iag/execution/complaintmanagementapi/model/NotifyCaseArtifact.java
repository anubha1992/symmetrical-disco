package au.com.iag.execution.complaintmanagementapi.model;

import java.util.Map;
import au.com.iag.execution.complaintmanagementapi.model.business.NotifyCaseRequest;
import lombok.Data;

@Data
public class NotifyCaseArtifact {

    private Map<String, Object> headers;
    private String path;
    private NotifyCaseRequest notifyCaseRequest;
    private String caseId;

}
