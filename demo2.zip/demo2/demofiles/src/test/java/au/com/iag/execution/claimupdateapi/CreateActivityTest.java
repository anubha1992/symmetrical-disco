package au.com.iag.execution.claimupdateapi;


import au.com.iag.execution.claimupdateapi.builders.ClaimUpdateRequestBuilder;
import au.com.iag.execution.claimupdateapi.configurations.ClaimUpdateConfiguration;
import au.com.iag.execution.claimupdateapi.configurations.PropertyOverrideContextInitializer;
import au.com.iag.execution.claimupdateapi.model.ClaimActivityArtifact;
import au.com.iag.execution.claimupdateapi.model.business.*;
import au.com.iag.execution.claimupdateapi.service.ClaimUpdateService;
import au.com.iag.execution.claimupdateapi.verifiers.ClaimUpdateVerifier;
import au.com.iag.execution.common.constants.ApiConstants;
import au.com.iag.execution.common.service.claims.ClaimsDbService;
import au.com.iag.glados.common.GladosRunnerExtension;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static au.com.iag.execution.common.constants.ApiConstants.DB_CC_CLAIMNUMBER;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import static org.apache.http.HttpStatus.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest()
@ExtendWith({SpringExtension.class, GladosRunnerExtension.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = {ClaimUpdateConfiguration.class})
@Tags({@Tag("CreateActivityTest"), @Tag("claim-update-api")})
public class CreateActivityTest {

    @Value("${test.api.product.code}")
    private String productCode;

    @Autowired
    ClaimsDbService claimsDbService;

    @Autowired
    ClaimUpdateService claimUpdateService;

    @Autowired
    ClaimUpdateRequestBuilder claimUpdateRequestBuilder;

    @Autowired
    ClaimUpdateVerifier claimUpdateVerifier;

    private ClaimActivityArtifact claimActivityArtifact;

    List<Map<String, Object>> claimIdDetails;
    Map<String, Object> claimIdDetailsMap;
    String claimId;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimUpdateService.getSwaggerSchema();
        claimIdDetails = claimsDbService.getClaimResultSet(productCode);
        if (claimIdDetails.isEmpty()) {
            Assert.fail("No claim found for product " + productCode);
        }
    }

    @BeforeEach
    public void setUp() {

        claimIdDetailsMap = claimIdDetails.get(new Random().nextInt(claimIdDetails.size()));
        claimId = claimIdDetailsMap.get(DB_CC_CLAIMNUMBER).toString();
        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequest(ActivityPatternCode.REVIEW_QUOTE);
    }

    @Test
    public void testCreateActivityForValidClaimId() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_CREATED);
    }

    @Test
    public void testCreateActivityWithoutDescriptionOnRequest() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getClaimActivityRequest().setDescription(null);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_CREATED);
    }

    // CCM test cases were tested against the test2 env - not deployed in test at the time of testing
    @Tag("ccm")
    @ParameterizedTest
    @EnumSource(value = ActivityPatternCode.class, names = {"REVIEW_QUOTE"}, mode = EnumSource.Mode.EXCLUDE)
    @Disabled
    public void testCreateActivityCCM(ActivityPatternCode activityPatternCode){
        claimId = "CGU190000013";
        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("t7005", activityPatternCode);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_CREATED);
    }
    @Tag("ccm")
    @ParameterizedTest
    @EnumSource(value = ActivityPatternCode.class, names = {"REVIEW_QUOTE"}, mode = EnumSource.Mode.EXCLUDE)
    @Disabled
    public void testCreateActivityCCMWithPatternCodeInLowerCases(ActivityPatternCode activityPatternCode){
        claimId = "CGU190000013";
        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("t7005", activityPatternCode);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getClaimActivityRequest().setActivityPatternCode(activityPatternCode.getCode().toLowerCase());
        claimActivityArtifact.getClaimActivityRequest().setGroupName(null);
        claimActivityArtifact.getClaimActivityRequest().setUserId(null);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_CREATED);
    }

    @Tag("ccm")
    @Test
    @Disabled
    public void testCreateActivityCCMWithChannelInUpperCase() {
        claimId = "CGU190000013";
        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("t7005", ActivityPatternCode.REVIEW_AND_ACTION_NEW_COMPLAINT);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().put(X_IAG_CHANNEL, "CCM");
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_CREATED);
    }

    @Tag("ccm")
    @Test
    @Disabled
    public void testCreateActivityCCMWithSourceIdHeaderInLowerCase() {
        claimId = "CGU190000013";
        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("t7005", ActivityPatternCode.REVIEW_AND_ACTION_NEW_COMPLAINT);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().put("source_id", "dc");
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_CREATED);
    }

    @Tag("ccm")
    @Test
    @Disabled
    public void testCreateActivityCCMWithInvalidPatternCode() throws IOException {

        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("t7005", ActivityPatternCode.REVIEW_QUOTE);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyRefDataValidationMessagesForCreateActivity(response, "activity_pattern_code", "value_not_found",
                "'"+ActivityPatternCode.REVIEW_QUOTE.getCode()+"' not found in ref data Activity Pattern Code for channel 'ccm'");
    }

    @Tag("ccm")
    @ParameterizedTest
    @EnumSource(value = ActivityPatternCode.class, names = {"REVIEW_QUOTE"}, mode = EnumSource.Mode.EXCLUDE)
    @Disabled
    public void testCreateActivityCCMWithInvalidChannel(ActivityPatternCode activityPatternCode) throws IOException {

        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("t7005", activityPatternCode);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().put(X_IAG_CHANNEL, "Digital");
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyRefDataValidationMessagesForCreateActivity(response, "activity_pattern_code", "value_not_found",
                "'"+activityPatternCode.getCode()+"' not found in ref data Activity Pattern Code for channel 'Digital'");
    }

    @Tag("ccm")
    @Test
    @Disabled
    public void testCreateActivityCCMWithInvalidUser() {

        claimActivityArtifact = claimUpdateRequestBuilder.buildClaimCreateActivityRequestCCM("invalid", ActivityPatternCode.REVIEW_AND_ACTION_NEW_COMPLAINT);
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_NOT_FOUND);
    }

    @Test
    public void testCreateActivityHavingInvalidIagUserHeader() {

        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().put(X_IAG_USER, "helloo");
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNAUTHORIZED);
    }

    @Test
    public void testCreateActivityMissingIagUserHeader() {

        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().remove(X_IAG_USER);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_BAD_REQUEST);
    }

    @Test
    public void testCreateActivityMissingClaimIdOnRequest() {
        claimId = null;
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, null);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_BAD_REQUEST);
    }

    @Test
    public void testCreateActivityWithoutActivityPatternCodeOnRequest() throws IOException {

        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getClaimActivityRequest().setActivityPatternCode(null);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyValidationErrorMessages(response, "activity_pattern_code", "mandatory",
                "Activity pattern code is required.");
    }

    @Test
    public void testCreateActivityWithChannelHeaderRemoved() {

        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().remove(X_IAG_CHANNEL);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_BAD_REQUEST);
    }

    @Test
    public void testCreateActivityWithInvalidChannelHeader() {

        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        Map<String, Object> requestHeaders = claimActivityArtifact.getHeaders();
        requestHeaders.put(X_IAG_CHANNEL, "dogital");
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_INTERNAL_SERVER_ERROR);
    }

    @Test
    public void testCreateActivityWithInvalidBrandHeader() {

        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        Map<String, Object> requestHeaders = claimActivityArtifact.getHeaders();
        requestHeaders.put(X_IAG_BRAND, "dogital");
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_INTERNAL_SERVER_ERROR);
    }

    @Test
    public void testCreateActivityWithInvalidClaimId() {
        claimId = "CLAIMOOOO";
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_NOT_FOUND);
    }

    @Test
    public void testCreateActivityWithInvalidActivityPatternCode() throws IOException {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getClaimActivityRequest().setActivityPatternCode("REVIEW_INVALID");
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNPROCESSABLE_ENTITY);
        claimUpdateVerifier.verifyRefDataValidationMessagesForCreateActivity(response, "activity_pattern_code", "value_not_found",
                "'REVIEW_INVALID' not found in ref data Activity Pattern Code for channel 'Digital'");
    }

    @Test
    public void missingSystemToken() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNAUTHORIZED);
        claimUpdateVerifier.verifyErrorResponse(response, MISSING_SYSTEM_TOKEN);
    }

    @Test
    public void invalidSystemToken() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        String invalidToken = claimActivityArtifact.getHeaders().get(X_IAG_AUTH_CONSUMER_SYSTEM) + "i";
        claimActivityArtifact.getHeaders().put(X_IAG_AUTH_CONSUMER_SYSTEM, invalidToken);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNAUTHORIZED);
        claimUpdateVerifier.verifyErrorResponse(response, ApiConstants.INVALID_SYSTEM_TOKEN);
    }

    @Test
    public void missingUserToken() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        claimActivityArtifact.getHeaders().remove(X_IAG_AUTH_USER);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNAUTHORIZED);
        claimUpdateVerifier.verifyErrorResponse(response, MISSING_USER_TOKEN);
    }

    @Test
    public void invalidUserToken() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, claimId);
        String invalidToken = claimActivityArtifact.getHeaders().get(X_IAG_AUTH_USER) + "i";
        claimActivityArtifact.getHeaders().put(X_IAG_AUTH_USER, invalidToken);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNAUTHORIZED);
        claimUpdateVerifier.verifyErrorResponse(response, ApiConstants.INVALID_USER_TOKEN);
    }

    @Test
    public void userTokenWithDifferentClaimId() {
        claimActivityArtifact = claimUpdateRequestBuilder.buildUserTokenHeader(claimActivityArtifact, "CLAIM12345");
        claimActivityArtifact.setClaimId(claimId);
        Response response = claimUpdateService.executeCreateActivity(claimActivityArtifact, SC_UNAUTHORIZED);
        assertEquals(USER_NOT_AUTHORISED_TO_ACCESS, response.path("message"));
    }
}
