package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.time.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class LossEstimateItemRentDefault extends LossEstimateItem {

    private Amount maximumRentClaimable;
    private Amount rentAmount;
    private String rentFrequency;
    private TimePeriod rentPeriod;
    private Amount bond;
    private OffsetDateTime newRentalAgreementDate;
    private String rentDefaultType;
    private Amount rentOnAccount;
    private List<VariableAmount> relettingExpenses;
    private TimePeriod relettingPeriod;

    public Amount getMaximumRentClaimable() {
        return maximumRentClaimable;
    }

    public void setMaximumRentClaimable(Amount maximumRentClaimable) {
        this.maximumRentClaimable = maximumRentClaimable;
    }

    public Amount getRentAmount() {
        return rentAmount;
    }

    public void setRentAmount(Amount rentAmount) {
        this.rentAmount = rentAmount;
    }

    public String getRentFrequency() {
        return rentFrequency;
    }

    public void setRentFrequency(String rentFrequency) {
        this.rentFrequency = rentFrequency;
    }

    public TimePeriod getRentPeriod() {
        return rentPeriod;
    }

    public void setRentPeriod(TimePeriod rentPeriod) {
        this.rentPeriod = rentPeriod;
    }

    public Amount getBond() {
        return bond;
    }

    public void setBond(Amount bond) {
        this.bond = bond;
    }

    public OffsetDateTime getNewRentalAgreementDate() {
        return newRentalAgreementDate;
    }

    public void setNewRentalAgreementDate(OffsetDateTime newRentalAgreementDate) {
        this.newRentalAgreementDate = newRentalAgreementDate;
    }

    public String getRentDefaultType() {
        return rentDefaultType;
    }

    public void setRentDefaultType(String rentDefaultType) {
        this.rentDefaultType = rentDefaultType;
    }

    public Amount getRentOnAccount() {
        return rentOnAccount;
    }

    public void setRentOnAccount(Amount rentOnAccount) {
        this.rentOnAccount = rentOnAccount;
    }

    public List<VariableAmount> getRelettingExpenses() {
        return relettingExpenses;
    }

    public void setRelettingExpenses(List<VariableAmount> relettingExpenses) {
        this.relettingExpenses = relettingExpenses;
    }

    public TimePeriod getRelettingPeriod() {
        return relettingPeriod;
    }

    public void setRelettingPeriod(TimePeriod relettingPeriod) {
        this.relettingPeriod = relettingPeriod;
    }
}