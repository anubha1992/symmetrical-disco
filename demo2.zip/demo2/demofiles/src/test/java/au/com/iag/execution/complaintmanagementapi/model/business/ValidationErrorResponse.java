package au.com.iag.execution.complaintmanagementapi.model.business;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ValidationErrorResponse{

	@JsonProperty("validation_messages")
	private List<ValidationMessagesItem> validationMessages;

	public List<ValidationMessagesItem> getValidationMessages(){
		return validationMessages;
	}
}
