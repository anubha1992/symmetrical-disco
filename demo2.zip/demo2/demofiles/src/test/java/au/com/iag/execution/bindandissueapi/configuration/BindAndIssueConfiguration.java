package au.com.iag.execution.bindandissueapi.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({
        "au.com.iag.glados*",
        "au.com.iag.execution.bindandissue*",
        "au.com.iag.execution.common.quotes",
        "au.com.iag.execution.common.core",
        "au.com.iag.execution.common.builders.security"
})
public class BindAndIssueConfiguration {

}
