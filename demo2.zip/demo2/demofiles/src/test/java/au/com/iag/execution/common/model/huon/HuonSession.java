package au.com.iag.execution.common.model.huon;

import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.*;
import com.jagacy.util.*;
import org.jasypt.util.text.*;
import java.io.*;
import java.nio.channels.*;
import java.nio.file.*;
import java.sql.*;
import java.text.*;
import java.util.Date;
import java.util.*;

//import mcp.SSCResponsive.CommonFunctions;

/**
 * This class is IAG's HUON session class.
 */

public class HuonSession extends Session3270 {
//    private String decryptionPassword = System.getenv("JASYPT_ENCRYPTOR_PASSWORD");

//    public Environment env1 = systemTestConfig.getEnv();
    public String testDbJdbcClassName = "org.postgresql.Driver";//com.ibm.db2.jcc.DB2Driver
    public String testDbDatabaseURL = "jdbc:postgresql://10.139.128.220:5432/testdb";
    public String testDbUser = "postgres";
    public String testDbPassword = ("ENC(Xkpd+lVKWgJJ+eqbprPoFKbpdyF7odoF)");

    private static String huonHost = "zsys2.mfsys.auiag.corp"; //Non-virtual env
    private static int huonPort = 23; //Non-virtual env
    private static String virtualHuonHost = "wmf0001.env-10-100-[VExxx].iagcloud";
    private static int virtualHuonPort = 8623;

    private static String huonLocalHost = "127.0.1"; //Local
    private static int huonLocalPort = 8623; //Local

    /*
     * User to be used to clear COMMAREAS for VE only
     */
    private static String USER_FOR_COMM = "MCPUSR10";
    private static String USER_FOR_COMM1 = "SCVTST10";
    private static boolean clearingCommArea = false;

    protected String env = "";
    private String envLogon;
    private boolean providedUser = false;
    private String huonUser = "";
    private String huonPassword = "";
    //	protected static String PARENT_PATH_WIN = "\\\\SDC1AS1557\\TestPro\\Execution_Do_Not_Delete\\";
    protected static String PARENT_PATH_WIN =
            System.getProperty("user.dir") + "\\src\\test\\resources\\huon\\screenshots";
    protected static String PARENT_PATH_LINUX = "/storage/TestAutomation_SDC1AS1557/";
    //	private static String HUON_USER_DIR = "\\\\SDC1AS1557\\TestPro\\Execution_Do_Not_Delete\\A_HUON\\";
    //	private static String HUON_USER_DIR = "\\\\SDC1AS701\\TestPro\\Execution_Do_Not_Delete\\A_HUON\\";
    String userFileName = "";
    String lockFileName = "";
    int userPrimaryKey = 0;

    /**
     * Create a new HUON session to use. It will pick up a free HUON user from
     * predefined user list.
     *
     * @param env accept "INTA", "INTB", "INTS", "SYSA", "BATA", "BATS", "DEVA",
     *            "DEVB", "DEVC", "DEVD", and virtual environments as "VExxx".
     * @throws JagacyException
     */
    public HuonSession(String env) throws HuonException, JagacyException {
        super("HUON", getHuonHost(env), getHuonPort(env), "IBM-3278-2-E");


        setHuonEnv(env);

        /*
         * For non-virtual environments, the first 4 letters must be real environment, like env = "sysa501" means it is SYSA huon.
         */
        String huonEnv = env.toUpperCase();
        if (!huonEnv.startsWith("VE") && !huonEnv.equalsIgnoreCase("LOCAL")) {
            if (huonEnv.length() > 4)
                huonEnv = huonEnv.substring(0, 4);
        }

        //For Linux
        huonEnv = huonEnv.toLowerCase();

        String osName = System.getProperty("os.name");
        System.out.println("[DEBUG] OS=" + osName);
        String tempDir;
        if (osName.toLowerCase().contains("win"))
            tempDir = PARENT_PATH_WIN + "A_HUON1" + File.separator;
        else
            tempDir = PARENT_PATH_LINUX + "A_HUON1" + File.separator;

        userFileName = tempDir + "huon_users_" + huonEnv + ".csv";
        lockFileName = tempDir + "lock_" + huonEnv + ".txt";

        System.out.println("[DEBUG]userFileName=" + userFileName + " ; lockFileName=" + lockFileName);

        huonUser = null;
        huonPassword = null;

    }

    public HuonSession(String s, String env) throws JagacyException {
        super(s);
        this.env = env;
    }

    /**
     * Create a new HUON session
     *
     * @param env      accept "INTA", "INTB", "INTS", "SYSA", "BATA", "BATS", "DEVA",
     *                 "DEVB", "DEVC", "DEVD"
     * @param huonUser HUON logon user name
     * @param password HUON logon user password
     * @throws JagacyException
     */
    public HuonSession(String env, String huonUser, String password) throws HuonException, JagacyException {
        super("HUON", getHuonHost(env), getHuonPort(env), "IBM-3278-2-E");

        setHuonEnv(env);

        this.huonUser = huonUser;
        this.huonPassword = password;

        providedUser = true;

        //        props = getProperties();
    }


    private static String getHuonHost(String env) {
        //SYS2 env
        String host = huonHost;
        env = env.trim().toUpperCase();

        if (env.equalsIgnoreCase("LOCAL")) {
            host = huonLocalHost;
            huonPort = huonLocalPort;
        }

        //Virtual env
        if (env.startsWith("VE")) {
            String veNumber = env.substring("VE".length());
            host = virtualHuonHost.replace("[VExxx]", veNumber);
            huonPort = virtualHuonPort;
        }

        //    	if (env.startsWith("VE")) {
        //    		host = (String) CommonFunctions.usernamePassword.get(env + "_HUON_HOST");
        ////    		huonPort = Integer.parseInt((String) CommonFunctions.usernamePassword.get(env + "_HUON_PORT"));
        //    	}
        return host;
    }

    private static int getHuonPort(String env) {
        //SYS2
        int port = huonPort;
        env = env.trim().toUpperCase();

        if (env.equalsIgnoreCase("LOCAL")) {
            port = huonLocalPort;
        }

        //Virtual env
        if (env.startsWith("VE")) {
            port = virtualHuonPort;
        }

        //    	if (env.startsWith("VE")) {
        //    		port = Integer.parseInt((String) CommonFunctions.usernamePassword.get(env + "_HUON_PORT"));
        //    	}
        return port;
    }

    private String[] pickHuonUser(String userFileName, String lockFileName) throws IOException {
        String user = "";
        String password = "";
        String used = "";
        String useTime = "";
        String[] foundUser = {"", ""};
        boolean gotFreeUser = false;

        //Check whether the HUON user file exists or not.
        //If not, copy it from other file (backup file)
        Path path = Paths.get(userFileName);
        if (!Files.exists(path)) {
            String sBackupFileName = userFileName.replace(env.toLowerCase(), "backup");
            String sBackupLockName = lockFileName.replace(env.toLowerCase(), "backup");
            Path backup = Paths.get(sBackupFileName);
            Files.copy(backup, path, StandardCopyOption.REPLACE_EXISTING);

            Path lock = Paths.get(lockFileName);
            Path backupLock = Paths.get(sBackupLockName);
            Files.copy(backupLock, lock, StandardCopyOption.REPLACE_EXISTING);
        }

        //Pick up an unused HUON user
        for (int nTry = 0; nTry < 240; nTry++) {
            try {
                File lockFile = new File(lockFileName);
                RandomAccessFile raLockFile = null;
                try {
                    raLockFile = new RandomAccessFile(lockFile, "rw");
                } catch (FileNotFoundException fnfe) {
                    //System.out.println(fnfe.getMessage());
                    if (fnfe.getMessage().toLowerCase().contains("being used by another")) {

                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException ie) {
                            //do nothing
                        }
                        continue;
                    }
                }

                FileChannel channel = raLockFile.getChannel();
                FileLock lock = channel.lock();
                BufferedReader br = new BufferedReader(new FileReader(userFileName));
                String[][] huonUsers = new String[9][];
                String line = br.readLine().trim(); // Header
                for (int i = 0; i < 9; i++) {
                    line = br.readLine();
                    if (line == null) {
                        break;
                    }
                    line = line.trim();
                    huonUsers[i] = line.split(",");
                }

                DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                Calendar calNow = Calendar.getInstance();
                Date now = calNow.getTime();
                for (int i = 0; i < 9; i++) {
                    if (huonUsers[i] != null) {
                        user = huonUsers[i][0].trim();
                        password = huonUsers[i][1].trim();
                        used = huonUsers[i][2].trim();
                        useTime = huonUsers[i][3].trim();
                        if (used.toUpperCase().startsWith("N")) {
                            gotFreeUser = true;
                            huonUsers[i][2] = "Y";
                            huonUsers[i][3] = formatter.format(now);
                            break;
                        }

                        //If used, but use time is 2 days ago or blank, use it
                        if (useTime.isEmpty()) {
                            gotFreeUser = true;
                            huonUsers[i][2] = "Y";
                            huonUsers[i][3] = formatter.format(now);
                            break;
                        }

                        Date time = null;
                        try {
                            time = formatter.parse(useTime);
                        } catch (ParseException pe) {

                            huonUsers[i][3] = formatter.format(now);
                            continue;
                        }

                        if (time != null) {
                            Calendar calUsed = Calendar.getInstance();
                            calUsed.setTime(time);

                            int yearUsed = calUsed.get(Calendar.YEAR);
                            int yearNow = calNow.get(Calendar.YEAR);
                            int dayUsed = calUsed.get(Calendar.DAY_OF_YEAR);
                            int dayNow = calNow.get(Calendar.DAY_OF_YEAR);
                            if ((yearNow > yearUsed) || (dayNow - dayUsed > 0)) {
                                gotFreeUser = true;
                                huonUsers[i][2] = "Y";
                                huonUsers[i][3] = formatter.format(now);
                                break;
                            }

                        }

                    }
                }

                br.close();

                //Set used flag and free resources
                if (gotFreeUser) {
                    //Write back
                    BufferedWriter bw = new BufferedWriter(new FileWriter(userFileName));
                    //					raFile.seek(0);
                    String newLine = "User Name,Password,Used_Or_Not";
                    bw.write(newLine);
                    int ntemp = huonUsers.length;
                    for (int i = 0; i < ntemp; i++) {
                        bw.newLine();
                        newLine = "";
                        for (int j = 0; j < huonUsers[i].length; j++) {
                            if (j > 0)
                                newLine = newLine + ",";
                            newLine = newLine + huonUsers[i][j];
                        }
                        bw.write(newLine);
                    }
                    bw.close();

                }

                lock.release();
                channel.close();
                raLockFile.close();
            } catch (IOException ioe) {

            } finally {

            }

            if (gotFreeUser) {
                foundUser[0] = user;
                foundUser[1] = password;
                break;
            }

            try {
                Thread.sleep(100);
            } catch (InterruptedException ie) {
                //do nothing
            }
        }
        return foundUser;
    }

    private void releaseHuonUser(String huonUser, String userFileName, String lockFileName) throws IOException {
        if (huonUser.isEmpty())
            return;

        if (providedUser)
            return;

        String user = "";
        boolean found = false;

        //Pick up an unused HUON user
        for (int nTry = 0; nTry < 120; nTry++) {
            try {
                File lockFile = new File(lockFileName);
                RandomAccessFile raLockFile = null;
                try {
                    raLockFile = new RandomAccessFile(lockFile, "rw");
                } catch (IOException fnfe) {
                    System.out.println(fnfe.getMessage());
                    //					if (fnfe.getMessage().toLowerCase()
                    //							.contains("being used by another")) {

                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ie) {
                        // do nothing
                    }
                    continue;
                    //					} else {
                    //						throw fnfe;
                    //				}
                }

                FileChannel channel = raLockFile.getChannel();
                FileLock lock = null;
                try {
                    lock = channel.lock();
                } catch (OverlappingFileLockException lockEx) {
                    //It is already lockec by this session
                    lock = null;
                }
                BufferedReader br = new BufferedReader(new FileReader(userFileName));
                String[][] huonUsers = new String[9][];
                String line = br.readLine().trim(); // Header
                for (int i = 0; i < 9; i++) {
                    line = br.readLine();
                    if (line == null) {
                        break;
                    }
                    line = line.trim();
                    huonUsers[i] = line.split(",");
                }

                for (int i = 0; i < 9; i++) {
                    if (huonUsers[i] != null) {
                        user = huonUsers[i][0].trim();
                        //						password = huonUsers[i][1].trim();
                        //						used = huonUsers[i][2].trim();

                        if (user.equalsIgnoreCase(huonUser)) {
                            found = true;
                            huonUsers[i][2] = "N";
                            break;
                        }

                    }
                }

                br.close();

                //Set used flag and free resources
                if (found) {
                    //Write back
                    BufferedWriter bw = new BufferedWriter(new FileWriter(userFileName));
                    //					raFile.seek(0);
                    String newLine = "User Name,Password,Used_Or_Not, Used_Time";
                    bw.write(newLine);
                    int ntemp = huonUsers.length;
                    for (int i = 0; i < ntemp; i++) {
                        bw.newLine();
                        newLine = "";
                        for (int j = 0; j < huonUsers[i].length; j++) {
                            if (j > 0)
                                newLine = newLine + ",";
                            newLine = newLine + huonUsers[i][j];
                        }
                        bw.write(newLine);
                    }
                    bw.close();

                }

                if (lock != null)
                    lock.release();
                channel.close();
                raLockFile.close();
            } finally {

            }

            if (found) {
                break;
            }

            try {
                Thread.sleep(500);
            } catch (InterruptedException ie) {
                //do nothing
            }
        }
    }

    private void setHuonEnv(String env) throws HuonException {
        this.env = env.trim().toUpperCase();
        if (this.env.startsWith("VE") || this.env.equals("LOCAL")) {
            envLogon = "";
            return;
        }

        String huonEnv = this.env;
        if (huonEnv.length() > 4)
            huonEnv = huonEnv.substring(0, 4);

        switch (huonEnv) {
            case "DEVA":
                envLogon = "S2PRJT06";
                break;
            case "DEVB":
                envLogon = "S2PRJT08";
                break;
            case "DEVC":
                envLogon = "S2PRJT05";
                break;
            case "DEVD":
                envLogon = "S2PRJT09";
                break;
            case "INTA":
                envLogon = "S2PRJT01";
                break;
            case "INTB":
                envLogon = "S2PRJT03";
                break;
            case "INTS":
                envLogon = "S2PRJT07";
                break;
            case "SYSA":
                envLogon = "DPRTCT01";
                break;
            case "BATA":
                envLogon = "ACPTCT01";
                break;
            case "BATS":
                envLogon = "ALTNCT01";
                break;

            case "SVP":
                envLogon = "S3PLET01";
                break;
            case "PERF":
                envLogon = "S3PF2T01";
                break;

            case "TRG":
                envLogon = "S3BOTT01";
                break;
            default:
                //    		System.out.println("[ERROR]Env --" + env + " -- you want to run hasn't been added to script. Please update HuonSession.java firstly.");
                throw new HuonException(
                        env + " -- you want to run hasn't been added to script. Please update HuonSession.java firstly.");
        }

    }

    /**
     * Logon a HUON environment. It is called by open() method.
     *
     * @return true for successful
     * @throws JagacyException
     */
    protected boolean logon() throws JagacyException {
        //Pick up an unused user
        if (huonUser == null) {
            System.out.println("Picking up a free HUON user...");
            String[] user = null;
            String[] users = {"", ""};
            if (this.env.equalsIgnoreCase("TRG")) {
                //TRG users SANRMA03, SANRMA04 passwords are same as username
                users[0] = "MCPUSR01";
                users[1] = "omega123";
                user = users;
                System.out.println("USERNAME = " + user[0]);
                System.out.println("Password = " + user[1]);
                System.out.println();
            } else if (this.env.equalsIgnoreCase("PERF")) {
                //TRG users SANRMA03, SANRMA04 passwords are same as username
                users[0] = "SCVTST05";
                users[1] = "scvt3st";
                user = users;
                System.out.println("USERNAME = " + user[0]);
//                System.out.println("Password = " + user[1]);
                System.out.println();
            } else {
                try {
                    //user = pickHuonUser(userFileName, lockFileName);
                    checkDataBaseTable();
                    /*  } catch (IOException ex) {
                    throw new JagacyException("[ERROR] Got IOException when trying to get a free HUON user on env -- " + env + "\n" + ex);*/
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                user = selectandUpdateUserFlagToYes();
            }

            if (user[0].isEmpty()) {
                //    		System.err.println("[ERROR] Failed to get a free HUON user on env -- " + env);
                throw new JagacyException("[ERROR] Failed to get a free HUON user on env -- " + env);
            }
            System.out.println("Sucessfully get a free HUON user -- " + user[0] + " password -- " + user[1]);
            huonUser = user[0].trim();
            huonPassword = user[1].trim();
        }

        //A reporter to write exception screenshot to 
        //		File tempFile = new File(HUON_USER_DIR);
        //		String tempDir = tempFile.getParent();
        String osName = System.getProperty("os.name");
        System.out.println("[INFO] OS=" + osName);
        String tempDir;
        if (osName.toLowerCase().contains("win"))
            //			tempDir = "\\\\SDC1AS1557\\TestPro\\Execution_Do_Not_Delete\\" + "SOA" + File.separator + this.env.toUpperCase();
            tempDir = PARENT_PATH_WIN + File.separator + this.env.toUpperCase();
        else
            tempDir = PARENT_PATH_LINUX + "A_HUON_LOGON_ERROR" + File.separator + this.env.toUpperCase();

        File tempFile = new File(tempDir);
        if (!tempFile.exists()) {
            tempFile.mkdir();
        }

        HuonReporter reporter = new HuonReporter(tempDir);

        try {
            waitForChange(1000, 10);

            if (!waitForTextAtPosition(2, 2, "N. R. M. A.   N E T W O R K")) {
                reporter.captureScreenshot("Exception");
                return false;
            }
            printScreenshot();
//            System.out.println(readScreenText());
            writePosition(5, 2, envLogon);
            waitForChange(1000, 5);
            printScreenshot();
            writeKey(Key.ENTER);
            //			writeKey(Key.ENTER);
            // test
            waitForChange(5000, 200);
            printScreenshot();

            // LOGONID and PASSWORD
            writePosition(11, 20, huonUser);
            //			if (!env.toUpperCase().startsWith("VE"))
            writePosition(12, 20, huonPassword);
            printScreenshot();
            writeKey(Key.ENTER);
            waitForChange(5000, 200);
            printScreenshot();

            //Invalid password
            String str = this.readFromField(20, 1, 60).trim();
            if (str.toLowerCase().contains("your password is invalid".toLowerCase()))
                throw new JagacyException("Wrong password:  " + str);

            //Invalid user
            str = this.readFromField(1, 1, 60).trim();
            if (!str.isEmpty())
                throw new JagacyException("HUON user doesn't exist: " + str);

            writePosition(0, 1, "HUON");
            printScreenshot();
            writeKey(Key.ENTER);
            waitForChange(5000, 200);
            printScreenshot();
            //If HZO999
            String currentScreen = readScreenName();
            if (currentScreen.equalsIgnoreCase("HZO999")) {
                return true;
            }

            gotoHH100();
        } catch (JagacyException je) {
            selectandUpdateUserFlagToNo();
            reporter.captureScreenshot("Exception");
            /*try {
            	releaseHuonUser(huonUser, userFileName, lockFileName);
            } catch (IOException ex) {
            	System.out.println("[WARNING] Failed to release HUON user from file " + userFileName);
            }*/
            throw je;
        }

        return true;
    }

    public void open() throws JagacyException {
        super.open();
        if (!clearingCommArea) {

            String currentScreen = readScreenName();
            if (currentScreen.equalsIgnoreCase("HZO999")) {
                clearingCommArea = true;
                if (!env.toLowerCase().startsWith("ve"))
                    return;
                // FOr VE only
                super.close();

                try {
                    clearCommareas(huonUser);
                } catch (HuonException e) {
                    throw new JagacyException(
                            JagacyException.CONDUIT_ERROR, "Failed to clear COMM area for user -- " + huonUser, e);
                }

                super.open();
                clearingCommArea = false;
            }

        }
    }

    public void close() throws JagacyException {
        //    	gotoHH100();
        //    	gotoScreen("PP010");
        super.close();
    }

    /*
     * (non-Javadoc)
     *
     * @see com.jagacy.Session3270#logoff()
     */
    protected void logoff() throws JagacyException {
        //    	pressKey(Key.CLEAR);
        if (!clearingCommArea) {
            selectandUpdateUserFlagToNo();
            //releaseHuonUser(huonUser, userFileName, lockFileName);

            System.out.println("Release HUON user and logoff");
        }

        //       enterKey(Key.)
    }

    /**
     * Go to a screen. Not like gotoHH100, it does not abort incomplete
     * transaction. Instead, it throws JagacyException. If you want to abort
     * incomplete transaction before go to this screen, please call
     * abortIncomplete() firstly.
     *
     * @param screenName both like "PP000" and "PPO000" are accepted.
     */
    public void gotoScreen(String screenName) throws JagacyException {
        String screen = screenName.trim().toUpperCase();
        if (screen.length() == 6) {
            screen = screen.substring(0, 2) + screen.substring(3);
        }

        input(1, 72, screen);
        enter();
        waitForScreen(screen);
    }

    /**
     * Go to the first screen -- HHO100. If there is incomplete transaction, the
     * incomplete transaction will be aborted.
     */
    public void gotoHH100() throws JagacyException {
        String currentScreen = readScreenName();
        if (currentScreen.equalsIgnoreCase("HZO999")) {
            super.close();
            super.open();
        }

        boolean incomplete = false;
        int nTry = 0;
        while (true) {
            try {
                if (incomplete) {
                    abortIncomplete();
                    break;
                } else {
                    input(1, 72, "HH100");
                    enter();
                    if (waitForScreen("HHO100"))
                        break;
                }

            } catch (JagacyException ex) {
                incomplete = true;
            }
            nTry++;
            if (nTry > 10)
                break;
        }

        String screen = "";
        String screenFull = "";
        for (int i = 0; i < 3; i++) {
            try {
                screen = readScreenName();
                screenFull = readFromField(1, 2, 61);
                if (screen.equalsIgnoreCase("HHO100"))
                    break;
                pressKey(Key.PF12);
            } catch (JagacyException je) {

            }
        }

        if (!screen.equalsIgnoreCase("HHO100")) {
            String meanableError = "";
            switch (screen) {
                case "HHO000":
                    meanableError = "The user already logon by some other tester --- " + huonUser;
                    break;
            }

            printScreenshot();

            throw new JagacyException(
                    JagacyException.SESSION_ERROR,
                    "Goto HH100 failed! The current screen is " + screenFull + "; " + meanableError);
        }
    }

    /**
     * Input a string to a position
     *
     * @param row   starts with 1
     * @param col   starts with 1
     * @param value the string to input
     */
    public void input(int row, int col, String value) throws JagacyException {
        //    	eraseField(row, col);
        System.out.println("Writing at row " + String.valueOf(row) + " at column " + String.valueOf(col) + " value " + value);
        writePosition(row - 1, col - 1, value);
//        printScreenshot();
    }

    /**
     * Try to input to the position. If the field is protected, no exception
     * will be thrown.
     *
     * @param row
     * @param col
     * @param value
     * @throws JagacyException
     */
    public boolean tryInput(int row, int col, String value) throws JagacyException {
        boolean pass = false;
        try {
            //		eraseField(row, col);
            input(row, col, value);
            pass = true;
        } catch (JagacyException je) {
            pass = false;
        }
        return pass;
    }

    public void eraseCurrentField() throws JagacyException {
        Location location = readCursorLocation();
        int row = location.getRow() + 1;
        int col = location.getColumn() + 1;
        eraseField(row, col);
    }

    public void inputCurrentField(String value) throws JagacyException {
        Location location = readCursorLocation();
        int row = location.getRow() + 1;
        int col = location.getColumn() + 1;
        input(row, col, value);
    }

    /**
     * Press ENTER with waitForChange followed
     */
    public void enter() throws JagacyException {
        printScreenshot();
        writeKey(Key.ENTER);
        waitForChange(1000, 120);
        printScreenshot();
    }

    public void pf2() throws JagacyException {
        writeKey(Key.PF2);
        waitForChange(1000, 120);
    }

    public void pf3() throws JagacyException {
        writeKey(Key.PF2);
        waitForChange(1000, 120);
    }

    /**
     * Press a key with waitForChange followed
     */
    public void pressKey(Key key) throws JagacyException {
        writeKey(key);
        waitForChange(3000, 120);
    }

    /**
     * @param row starts from 1
     * @param col starts from 1
     * @param end the end col position starts from 1
     * @return the field value
     */
    public String readFromField(int row, int col, int end) throws JagacyException {
        return readPosition(row - 1, col - 1, end - col + 1);
    }

    /**
     * Erase all the text in a field. It is same as press {END} from normal HUON
     * terminal.
     *
     * @param row starts with 1
     * @param col starts with 1
     * @throws JagacyException
     */
    public void eraseField(int row, int col) throws JagacyException {
        writeCursor(row - 1, col - 1);
        pressKey(Key.ERASE_EOF);
    }

    public void tryEraseField(int row, int col) throws JagacyException {
        try {
            writeCursor(row - 1, col - 1);
            pressKey(Key.ERASE_EOF);
        } catch (JagacyException e) {

        }
    }

    /**
     * Get error/warning message
     *
     * @return error message or null if exception happens
     */
    public String readErrorMessage() {
        try {
            return readFromField(23, 03, 80).trim();
        } catch (JagacyException ex) {
            return "";
        }
    }

    /**
     * Get error/warning code, such as 5501.
     *
     * @return error code like "2241" or null if exception happens
     */
    public String extractErrorCode() {
        String code = "";
        String error = readErrorMessage();

        if (error.isEmpty())
            return "";

        int index = error.indexOf("-");
        if (index >= 0)
            code = error.substring(0, index).trim();

        return code;
    }

    /**
     * Get current screen name, like TBO310
     *
     * @return screen name like "TBO310"
     * @throws JagacyException
     */
    public String readScreenName() throws JagacyException {
        return readFromField(1, 9, 14);
    }

    public String readScreenFullName() throws JagacyException {
        return readFromField(1, 2, 44).trim();
    }

    /**
     * Wait for a screen to be ready for at most 60 seconds.
     *
     * @param capture it is like PP0013, HHO100, etc, i.e., screen name from 01, 09
     *                to 01, 14. It also accepts like "PP013" if it should be
     *                "PPO013".
     * @return true for pass
     * @throws JagacyException
     */
    public boolean waitForScreen(String capture) throws JagacyException {
        return waitForScreen(capture, 60000);
    }

    /**
     * Wait for a screen to be ready.
     *
     * @param capture  it is like PP0013, HHO100, etc, i.e., screen name from 01, 09
     *                 to 01, 14. It also accepts like "PP013" if it should be
     *                 "PPO013".
     * @param waitTime the max wait time in milliseconds.
     * @return true for pass
     * @throws JagacyException if the waiting failed after 60 seconds
     */
    public boolean waitForScreen(String capture, int waitTime) throws JagacyException {
        String screen = capture.trim().toUpperCase();
        if (screen.length() == 5) {
            screen = screen.substring(0, 2) + "O" + screen.substring(2);
        }

        int rowScreenName = 1 - 1;
        int colScreenName = 9 - 1;
        boolean isReady = false;
        try {
            isReady = waitForPosition(rowScreenName, colScreenName, screen, waitTime);
        } catch (JagacyException ex) {
            throw new JagacyException(ex.getError(), ex.toString() + " Failed to wait for screen - " + capture);
        }

        if (!isReady) {
            String currentScreen = readScreenName();
            String error = readErrorMessage();
            throw new JagacyException(
                    JagacyException.INVALID_PROPERTY_ERROR + " Failed to wait for screen - " + capture
                            + ": Current screen is " + currentScreen + " and ERROR is [" + error + "]");
        }

        return isReady;
    }

    /**
     * Wait for one of candidate screens
     *
     * @param waitScreens a screen array. The screen names can be like "HY012" or
     *                    "HYO012" if the 3rd letter is "O".
     * @return the screen appears or "" if no candidate screen is found.
     * @throws JagacyException if none of the screens appears.
     */
    public String waitForScreens(String[] waitScreens) throws JagacyException {
        String[] screens = Arrays.copyOf(waitScreens, waitScreens.length);

        for (int i = 0; i < screens.length; i++) {
            String screen = screens[i].trim().toUpperCase();
            if (screen.length() == 5) {
                screen = screen.substring(0, 2) + "O" + screen.substring(2);
            }
            screens[i] = screen;
        }

        int rowScreenName = 1 - 1;
        int colScreenName = 9 - 1;
        boolean isReady = false;
        String screenFound = "";
        for (int iTry = 0; iTry < 60; iTry++) {
            for (int i = 0; i < screens.length; i++) {
                try {
                    isReady = waitForPosition(rowScreenName, colScreenName, screens[i], 100);
                } catch (JagacyException ex) {
                    //Not found
                    isReady = false;
                }

                if (isReady) {
                    screenFound = waitScreens[i];
                    break;
                }

            }

            if (isReady) {
                break;
            }

            try {
                Thread.sleep(500);
            } catch (InterruptedException ie) {
                //do nothing
            }
        }

        if (!isReady) {
            String currentScreen = readScreenName();
            String error = readErrorMessage();
            throw new JagacyException(
                    JagacyException.INVALID_PROPERTY_ERROR + " Failed to wait for screens - " + Arrays.toString(screens)
                            + ": Current screen is " + currentScreen + " and ERROR is [" + error + "]");
        }

        return screenFound;
    }

    /**
     * Wait for a text at given position. The max waiting time is 60 seconds.
     *
     * @param row  starts from 1
     * @param col  starts from 1
     * @param text
     * @return true if text appears at the position, otherwise false.
     * @throws JagacyException
     */
    public boolean waitForTextAtPosition(int row, int col, String text) throws JagacyException {
        return waitForPosition(row - 1, col - 1, text, 60000);
    }

    /**
     * Wait for it is not blank at given position. The max waiting time is 30
     * seconds.
     *
     * @param row starts from 1
     * @param col starts from 1
     * @param end end of the position
     * @return the text at the position
     * @throws JagacyException
     */
    public String waitForNotBlankAtPosition(int row, int col, int end) throws JagacyException {
        String text = "";
        int i = 0;
        int n = 60;
        while (text.isEmpty()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {

            }
            i++;
            if (i > n)
                break;
            text = readFromField(row, col, end).trim();
        }

        return text;

    }

    /**
     * At some screens, HUON requires all pages are gone through before going
     * ahead. This method is to do it.
     *
     * @throws JagacyException
     */
    public void gotoLastPage() throws JagacyException {
        int i = 0;
        while (!extractErrorCode().equalsIgnoreCase("108")) {
            pressKey(Key.PF8);
            i++;
            if (i > 10)
                break;
        }
    }

    /**
     * Go to the first page.
     *
     * @throws JagacyException
     */
    public void gotoFirstPage() throws JagacyException {
        while (!extractErrorCode().equalsIgnoreCase("107")) {
            pressKey(Key.PF7);
        }
    }

    /**
     * Go to the next page.
     *
     * @return if it is already last page, return false; otherwise return true
     * @throws JagacyException
     */
    public boolean gotoNextPage() throws JagacyException {
        if (extractErrorCode().equalsIgnoreCase("108"))
            //Last page already
            return false;

        pressKey(Key.PF8);

        boolean done = false;
        while (!done) {
            String errorCode = extractErrorCode();

            switch (errorCode) {
                case "800340": ///800340 - ACC DAMAGE AND FUSION AUTO-SELECTED
                case "800342": ////800342 - ANY BLOCK COVER ITEM GREATER THAN $10,000 MUST BE SPECIFIED
                    pressKey(Key.PF8);
                    break;
                default:
                    done = true;
            }
        }

        if (extractErrorCode().equalsIgnoreCase("108")) {
            //Last page already
            return false;
        } else {
            return true;
        }
    }

    public boolean gotoPrevPage() throws JagacyException {
        pressKey(Key.PF7);

        if (extractErrorCode().equalsIgnoreCase("107")) {
            //first page already
            return false;
        } else {
            return true;
        }
    }

    /**
     * Abort an incomplete transaction by enter PF14, and goes to HHO100.
     */
    public void abortIncomplete() throws JagacyException {
        String currentScreen = readScreenName();
        //PPO943        POLICY MESSAGE LIST
        if (currentScreen.equalsIgnoreCase("PPO943")) {
            input(5, 12, "E");
            enter();
        }

        //HZO999                 ABORT SCREEN 
        //    	if (currentScreen.equalsIgnoreCase("HZO999")) {
        //    		pressKey(Key.)
        //    		input(5, 12, "E");
        //    		enter();
        //    	}

        //This one is the first screen after logon if it exists
        currentScreen = readScreenName();
        if (currentScreen.equalsIgnoreCase("HHO050")) {
            input(16, 56, "N");
            enter();
        }

        currentScreen = readScreenName();
        //Embargo
        if (currentScreen.equalsIgnoreCase("WPO526")) {
            enter();
        }

        currentScreen = readScreenName();
        if (currentScreen.equalsIgnoreCase("WPO285")) {
            while (!readErrorMessage().equalsIgnoreCase("108 - END OF SELECTED RANGE"))
                pressKey(Key.PF8);
            tryInput(22, 74, "Y");
            enter();
        }

        currentScreen = readScreenName();
        if (currentScreen.equalsIgnoreCase("PPO281")) {
            enter();//Just enter
            //800667 - PLEASE SELECT Y OR N FOR IMMEDIATE PAYMENT
            if (extractErrorCode().equalsIgnoreCase("800667")) {
                input(10, 50, "N");
                enter();
            }
        }

        currentScreen = readScreenName();
        if (currentScreen.equalsIgnoreCase("WPO179")) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.YEAR, -3);
            int year = cal.get(Calendar.YEAR);
            String strYear = Integer.toString(year).trim();
            input(4, 9, strYear);
            eraseField(4, 20);
            input(4, 20, "TOYOTA");
            eraseField(4, 42);
            eraseField(4, 63);
            enter();
            waitForScreen("WP179");
            input(9, 2, "S");
            enter();
            waitForScreen("TB310");
        }

        currentScreen = readScreenName();
        if (currentScreen.equalsIgnoreCase("HZO700")) {
            input(6, 79, "Y");
            enter();
            if (extractErrorCode().equalsIgnoreCase("9318")) {
                //9318 - CITY IS INVALID FOR STATE, POSTCODE AND COUNTRY COMBINATION
                //It is a VE issue
                pressKey(Key.CLEAR);
                if (readScreenName().equalsIgnoreCase("HZO999")) {
                    pressKey(Key.CLEAR);
                }

                if (readScreenName().equalsIgnoreCase("HHO050")) {
                    input(16, 56, "N");
                    enter();
                }

            }

            //    		if (extractErrorCode().equalsIgnoreCase("9813")) {
            //    			eraseField(4, 9);
            //    			input(4, 9, "388");
            //    			eraseField(4, 20);
            //    			input(4, 20, "George");
            //    			eraseField(4, 9);
            //    			input(4, 9, "388");
            //    			eraseField(5, 9);
            //    			input(5, 9, "Sydney");
            //    			
            //    		}
        }

        if (currentScreen.equalsIgnoreCase("TBO700")) { //TB70 - TBO700                INCIDENTS TAILORED
            input(3, 18, "E");
            enter();

        }

        //WPO182
        if (currentScreen.equalsIgnoreCase("WPO182")) { //Message
            enter();
        }

        //Embargo screen
        if (currentScreen.equalsIgnoreCase("WPO526")) { //WPO526          EMBARGO  DETAILS 
            throw new JagacyException(
                    "We don't know how to exit WPO526 so it is not handled. Please don't do anything and let Gary know the HUON user and environment so that he can investigate how to exit it.");
            //    		enter();
        }

        if (currentScreen.equalsIgnoreCase("PPO157")) {
            input(3, 13, "E");
            enter();
        }

        if (currentScreen.equalsIgnoreCase("PPO160")) {
            input(4, 12, "E");
            enter();
        }

        int nTry = 0;
        while (true) {
            nTry++;
            if (nTry > 5) {
                break;
                //				throw new JagacyException(JagacyException.SESSION_ERROR, "Failed to abort current transaction on screen -- " + readScreenName());
            }
            try {
                pressKey(Key.PF14);
                if (!readErrorMessage().trim().contains("FUNCTION KEY PRESSED IS INVALID")) {
                    //					currentScreen = waitForScreens(new String[]{"PPO272", "PPO462"});
                    currentScreen = readScreenName();
                    if (currentScreen.equals("PPO272"))
                        input(18, 65, "Y");
                    else {
                        if (currentScreen.equals("PPO462"))
                            input(18, 64, "Y");
                        else
                            continue;
                    }

                    enter();
                } else {
                    pressKey(Key.PF12);
                }
                input(1, 72, "HH100");
                enter();
                if (waitForScreen("HHO100", 3000)) {
                    break;
                }
            } catch (JagacyException ex) {
                // Do nothing but just continue the loop
                //				ex.printStackTrace();
                break;
            }
        }
    }

    /**
     * wait for change
     *
     * @param timeout
     * @param intermediateScreenCount
     * @return true for successful and false for failed to get the change.
     * @throws JagacyException
     */
    public boolean waitForChange(int timeout, int intermediateScreenCount) throws JagacyException {
        if (intermediateScreenCount < 0) {
            throw new IllegalArgumentException("Invalid intermediateScreenCount: " + intermediateScreenCount);
        }
        // Add one for target screen:
        boolean isSuccess = false;
        try {
            intermediateScreenCount++;
            while (intermediateScreenCount-- > 0) {
                //This function may write "(WARN): Possible intermediate screen" to log
                try {
                    isSuccess = waitForChange(timeout);
                } catch (NullPointerException npe) {
                    //Sometimes, it throws this exception
                } catch (JagacyException je) {
                    isSuccess = false;
                }
                if (isSuccess) {
                    break;
                }

                try {
                    isSuccess = waitForUnlock(timeout);
                } catch (JagacyException je) {
                    isSuccess = false;
                }

                if (isSuccess) {
                    break;
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ie) {
                    //do nothing
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

        }

        if (!isSuccess)
            throw new JagacyException(
                    JagacyException.KEYBOARD_LOCKED_ERROR, "Wait for change/unlock timeout after waiting for "
                    + intermediateScreenCount * timeout / 1000 + " seconds!");

        return isSuccess;

    }

    public String getEnv() {
        return env;
    }

    public String getHuonUser() {
        return huonUser;
    }

    public void setHuonUser(String huonUser) {
        this.huonUser = huonUser;
    }

    public String getHuonPassword() {
        return huonPassword;
    }

    public void setHuonPassword(String huonPassword) {
        this.huonPassword = huonPassword;
    }

    public void clearCommareas(String userid) throws JagacyException, HuonException {
        HuonSession newSession = new HuonSession(env, USER_FOR_COMM, "");
        newSession.open();

        newSession.gotoHH100();
        newSession.gotoScreen("HZ982");
        newSession.input(4, 16, userid);
        newSession.input(4, 41, "Y");
        newSession.enter();

        //800173 - ALL ROWS FOR THIS ID WILL BE DELETED ON ENTER - PF11 TO EXIT 
        String errorCode = newSession.extractErrorCode();
        if (errorCode.equals("800173"))
            newSession.enter();

        newSession.pressKey(Key.PF11);

        newSession.close();
    }

    public String[] selectandUpdateUserFlagToYes() {
        int WAIT_TIME = 120;
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Calendar calNow = Calendar.getInstance();
        Date now = calNow.getTime();
        String used_time = formatter.format(now);
        Connection c = null;
        Statement stmt = null;
        String[] users = {"", ""};
        boolean foundUser = false;
        for (int i = 0; i < WAIT_TIME; i++) {
            try {
                Class.forName(testDbJdbcClassName);
                c = DriverManager.getConnection(testDbDatabaseURL, testDbUser, decryptPassword(testDbPassword));
                c.setAutoCommit(false);
                System.out.println("Opened database successfully");

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM USERS_" + this.env + " WHERE used_or_not ='N';");
                String usedby = System.getProperty("user.name");
                if (!rs.next()) {
                    System.out.println("No Users free");
                } else {
                    int id = rs.getInt("id");
                    userPrimaryKey = id;
                    String sql = "UPDATE USERS_" + this.env + " set used_or_not = 'Y', usedby ='" + usedby
                            + "',used_time ='" + used_time + "' where ID =" + id + ";";
                    String name = rs.getString("username");
                    String password = rs.getString("password");
                    users[0] = name;
                    users[1] = password;
                    System.out.println("USERNAME = " + name);
                    System.out.println("Password = " + password);
                    System.out.println();
                    stmt.executeUpdate(sql);
                    c.commit();
                    System.out.println("Update done successfully");
                    foundUser = true;
                }
                stmt.close();
                c.close();
                if (!foundUser) {
                    Thread.sleep(1000);
                } else {
                    return users;
                }
            } catch (Exception e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
                System.exit(0);
            }
        }
        return users;

    }

    public void selectandUpdateUserFlagToNo() {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Calendar calNow = Calendar.getInstance();
        Date now = calNow.getTime();
        String used_time = formatter.format(now);
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName(testDbJdbcClassName);
            c = DriverManager.getConnection(testDbDatabaseURL, testDbUser, decryptPassword(testDbPassword));
            c.setAutoCommit(false);
            System.out.println("Opened database successfully");
            stmt = c.createStatement();
            String sql = "UPDATE USERS_" + this.env + " set used_or_not = 'N', used_time ='" + used_time
                    + "' where ID =" + userPrimaryKey + ";";
            stmt.executeUpdate(sql);
            c.commit();
            System.out.println("Update done successfully");

            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    public void checkDataBaseTable() throws SQLException {
        Connection c = null;
        Statement stmt = null;
        try {
//            Class.forName("org.postgresql.Driver");
            Class.forName(testDbJdbcClassName);
            c = DriverManager.getConnection(testDbDatabaseURL, testDbUser, decryptPassword(testDbPassword));
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "select 1 from information_schema.tables where table_name = 'users_" + this.env.toLowerCase() + "';");

            if (!rs.next()) {
                System.out.println("No Database Table Exists");
                createTable();
                insertSchema();
                System.out.println("Table Created");
            } else {
                System.out.println("Database already Exists");
            }

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        } finally {
            stmt.close();
            c.close();
        }

    }

    public void createTable() {
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName(testDbJdbcClassName);
            c = DriverManager.getConnection(testDbDatabaseURL, testDbUser, decryptPassword(testDbPassword));
            System.out.println("Opened database successfully");

            stmt = c.createStatement();
            String sql = "CREATE TABLE USERS_" + this.env + "(ID INT PRIMARY KEY NOT NULL," + " UserName CHAR(50), "
                    + " Password CHAR(50), " + " Used_Or_Not CHAR(50), " + " Used_Time CHAR(50), " + " Usedby CHAR(50))";
            stmt.executeUpdate(sql);
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Table created successfully");
    }

    public void insertSchema() {
        Connection c = null;
        Statement stmt = null;
        String sql;
        try {
            Class.forName(testDbJdbcClassName);
            c = DriverManager.getConnection(testDbDatabaseURL, testDbUser, decryptPassword(testDbPassword));
            c.setAutoCommit(false);
            System.out.println("Opened database successfully");

            stmt = c.createStatement();
            String username = "SCVTST0";

            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Calendar calNow = Calendar.getInstance();
            Date now = calNow.getTime();
            String createdTime = formatter.format(now);

            for (int i = 1; i < 16; i++) {
                if (i > 9) {
                    username = "SCVTST";
                }
                if (i != 16) {
                    if (this.env.toUpperCase().contains("VE")) {
                        sql = "INSERT INTO USERS_" + this.env + "(ID, USERNAME, PASSWORD, USED_OR_NOT, USED_TIME) "
                                + "VALUES (" + i + ",'" + username + i + "', '', 'N', '" + createdTime + "');";
                    } else {
                        sql = "INSERT INTO USERS_" + this.env + "(ID, USERNAME, PASSWORD, USED_OR_NOT, USED_TIME) "
                                + "VALUES (" + i + ",'" + username + i + "', 'syst3st', 'N', '" + createdTime + "');";
                    }
                    stmt.executeUpdate(sql);
                }
                if (i == 16 && this.env.toUpperCase().contains("VE")) {
                    break;
                }
            }

            stmt.close();
            c.commit();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Records created successfully");
    }

    public void printScreenshot() {
        printScreenshot(System.out);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
    }

    public void printScreenshot(PrintStream out) {
        try {
            String[] rows = readScreen();
            if (rows.length <= 0) {
                System.out.println("[WARN] Print screenshot got nothing");
                return;
            }

            int width = rows[0].length();
            Location cursor = readCursorLocation();
            int cursorRow = cursor.getRow() + 1;
            int cursorCol = cursor.getColumn() + 1;

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < width; i++) {
                sb.append("-");
            }
            String seperatorRow = sb.toString();

            sb = new StringBuilder();
            sb.append("  ");
            for (int i = 1; i <= width; i++) {
                if (i == 1) {
                    sb.append(" ");
                    continue;
                }

                if (i == 2) {
                    sb.append("2");
                    continue;
                }

                if (i % 10 == 0) {
                    sb.append(Integer.toString(i).trim());
                    continue;
                }

                if (i % 10 == 1) {
                    continue;
                }

                sb.append(" ");
            }
            String headerRow = sb.toString();

            out.println(seperatorRow);
            out.println(headerRow);
            out.println(seperatorRow);
            for (int i = 0; i < rows.length; i++) {
                String prefix = Integer.toString(i + 1).trim();
                if (prefix.length() == 1)
                    prefix = "0" + prefix;
                String row = prefix + rows[i];
                //				if (cursorRow == i+1)
                //					row = prefix + rows[i].substring(0, cursorCol-1) + "@" + rows[i].substring(cursorCol-1);
                //				else
                //					row = prefix + rows[i];
                out.println(row);
            }

            out.println(seperatorRow);

            String sCursorRow = Integer.toString(cursorRow).trim();
            String sCursorCol = Integer.toString(cursorCol).trim();
            if (sCursorRow.length() == 1)
                sCursorRow = "0" + sCursorRow;
            if (sCursorCol.length() == 1)
                sCursorCol = "0" + sCursorCol;

            if (cursorRow <= 1) {
                out.println("Cursor is at: " + sCursorRow + "/" + sCursorCol);
            } else {
                String cursorRowStr = rows[cursor.getRow()];
                String leading = "";
                if (cursor.getColumn() > 1)
                    leading = cursorRowStr.substring(1, cursor.getColumn() - 1);
                String strTemp = cursorRowStr.substring(cursor.getColumn());
                int index = strTemp.indexOf(" ");
                String fieldValue = strTemp.substring(0, index + 1);

                if (fieldValue.equals(" ")) {
                    index = strTemp.length();
                    for (int i = 0; i < strTemp.length(); i++) {
                        char c = strTemp.charAt(i);
                        if (Character.isLetter(c)) {
                            index = i;
                            break;
                        }
                    }

                    fieldValue = strTemp.substring(0, index);
                }

                out.println(
                        "Cursor is at: " + sCursorRow + "/" + sCursorCol + "; Text before the field: " + leading
                                + "; Field value: " + fieldValue);
            }

            out.println(seperatorRow);
        } catch (JagacyException e) {
            System.out.println("[WARN] Print screenshot got error: " + e);
        }

    }

    private String decryptPassword(String passwordToDecrypt) {

        BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
        textEncryptor.setPassword("encryptglados");
        if (passwordToDecrypt.indexOf("ENC(") >= 0) {
            passwordToDecrypt = passwordToDecrypt.replace("ENC(", "").replace(")", "");
        }
        String decryptedPassword = textEncryptor.decrypt(passwordToDecrypt);
        return decryptedPassword;
    }

}
