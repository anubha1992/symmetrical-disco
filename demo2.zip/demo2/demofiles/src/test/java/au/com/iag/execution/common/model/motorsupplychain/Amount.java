package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;
import java.math.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Amount implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("gst_amount")
    private BigDecimal gstAmount;
    @JsonProperty("is_gst_inclusive")
    private Boolean isGstInclusive;


    @ApiModelProperty(
            value = "The Amount",
            example = "20420.0",
            required = false
    )
    public BigDecimal getAmount() {
        return amount;
    }

    @ApiModelProperty(
            value = "The currency",
            example = "aud",
            required = false
    )
    public String getCurrency() {
        return currency;
    }

    @ApiModelProperty(
            value = "The GST Amount",
            example = "2042.0",
            required = false
    )
    public BigDecimal getGstAmount() {
        return gstAmount;
    }

    @ApiModelProperty(
            value = "Whether the amount includes GST",
            example = "true",
            required = false
    )
    public Boolean getIsGstInclusive() {
        return isGstInclusive;
    }


}