package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "Contains details for the quote and policy")
public class Policy implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("assets")
    private AssetGroup assets;
    @JsonProperty("brand")
    private String brand;
    @JsonProperty("correspondence_preferences")
    private CorrespondencePreference correspondencePreferences;
    @JsonProperty("manufacturer")
    private Manufacturer manufacturer;
    @JsonProperty("parties")
    private Parties parties;
    @JsonProperty("payments")
    private PaymentInfo payments;
    @JsonProperty("policy_dates")
    private PolicyDates policyDates;
    @JsonProperty("policy_number")
    private String policyNumber;
    @JsonProperty("product")
    private String product;
    @JsonProperty("status")
    private String status;
    @JsonProperty("type")
    private String type;

  
    @ApiModelProperty(
        value = "List of assets for this policy",
        required = false
    )
    public AssetGroup getAssets() {
       return assets;
    }
 
    @ApiModelProperty(
        value = "The policy brand. [Ref Data: brands]",
        example = "CGU",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getBrand() {
       return brand;
    }
 
    @ApiModelProperty(
        value = "Correspondence preference details",
        required = false
    )
    public CorrespondencePreference getCorrespondencePreferences() {
       return correspondencePreferences;
    }
 
    @ApiModelProperty(
        value = "Manufacturer details",
        required = false
    )
    public Manufacturer getManufacturer() {
       return manufacturer;
    }
 
    @ApiModelProperty(
        value = "List of parties for this policy",
        required = false
    )
    public Parties getParties() {
       return parties;
    }
 
    @ApiModelProperty(
        value = "Payment details of the policy",
        required = false
    )
    public PaymentInfo getPayments() {
       return payments;
    }
 
    @ApiModelProperty(
        value = "Policy dates",
        required = false
    )
    public PolicyDates getPolicyDates() {
       return policyDates;
    }
 
    @ApiModelProperty(
        value = "Quote number or Policy number",
        example = "QTE1234567",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getPolicyNumber() {
       return policyNumber;
    }
 
    @ApiModelProperty(
        value = "Product - MOTOR_INSURANCE, HOME_INSURANCE etc. [Ref Data: product]",
        example = "Personal Motor",
        required = false
    )
    public String getProduct() {
       return product;
    }
 
    @ApiModelProperty(
        value = "Status of the business entity. [Ref Data: quote_status, policy_status]",
        example = "DRAFT",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getStatus() {
       return status;
    }
 
    @ApiModelProperty(
        value = "The business entity type. [Ref Data: business_type]",
        example = "QUOTE",
        required = false
    )
    public String getType() {
       return type;
    }
 

}