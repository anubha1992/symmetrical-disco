package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.common.model.corrotracker.CorrespondenceDocuments;
import au.com.iag.execution.common.service.corrotracker.CorrespondenceTrackerService;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

import static org.apache.http.HttpStatus.SC_OK;

@Component
public class ResendDocsBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private CorrespondenceTrackerService correspondenceTrackerService;

    public CorrespondenceDocuments attachDocuments(String correspondenceId) throws IOException {
        CorrespondenceDocuments correspondenceDocuments = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/correspondenceDocuments.json")
                        , CorrespondenceDocuments.class);
        correspondenceTrackerService.addCorrespondenceDocuments(correspondenceId, correspondenceDocuments, SC_OK);
        return correspondenceDocuments;
    }
}
