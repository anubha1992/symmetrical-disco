package au.com.iag.execution.common.service.motor;

import au.com.iag.glados.common.*;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static javax.servlet.http.HttpServletResponse.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.io.*;
import java.util.*;

@Service
public class MotorRepairService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SecurityService securityService;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired
    private ResourceReaderService resourceReaderService;

    private String path = "/services/v1/repairer-details/motor/search";

    public Response getMotorRepairer(int expectStatusCode, String brand) throws IOException {
        final Response response = gladosEnrichmentService
                .sendPostRequest(getHeaders(brand), path, getRequestBody(brand), expectStatusCode);

        return response;
    }

    public Response getMotorRepairer(String brand, String causeOfLoss, String natureOfLoss) throws IOException {
        SearchMotorRepairerRequest searchMotorRepairerRequest = getRequestBody(brand);
        searchMotorRepairerRequest.setCauseOfLoss(causeOfLoss);
        searchMotorRepairerRequest.setGeneralNatureOfLoss(natureOfLoss);
        final Response response = gladosEnrichmentService
                .sendPostRequest(getHeaders(brand), path, searchMotorRepairerRequest, SC_OK);

        return response;
    }

    private Map<String, Object> getHeaders(String brand) {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, BAPI);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(SOURCE_ID, "DC");
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken("BAPI", "business-api-provider"));
        return requestHeaders;
    }

    public SearchMotorRepairerRequest getRequestBody(String brand) throws IOException {

        String fileName = "motorRepairerRequest.json";
        if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI")) {
            fileName = "motorRepairerRequestNZ.json";
        }
        return jsonMapperService.getObjectMapper().readValue(resourceReaderService.generateStringFromResource("requests/repairer-details-api/" + fileName), SearchMotorRepairerRequest.class);
    }


}
