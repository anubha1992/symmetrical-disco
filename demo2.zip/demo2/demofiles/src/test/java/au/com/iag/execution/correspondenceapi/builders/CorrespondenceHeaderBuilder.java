package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.glados.model.security.AnonymousUserTokenRequest;
import au.com.iag.glados.model.security.OktaUserDetails;
import au.com.iag.glados.model.security.OktaUserTokenRequestPayload;
import au.com.iag.glados.service.SecurityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.*;

@Component
public class CorrespondenceHeaderBuilder {

    @Value("${test.api.brand}") public String brand;
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;
    @Value("${test.api.product.code}") private String productCode;
    @Value("${okta.test.security.consumer}") private String consumerWithUserAuthEnabled;
    @Value("${test.okta.user.customer.ff_test_serenity.id}") private String ffTestSerenityOktaCustomerId;
    @Value("${test.okta.user.customer.password}") private String oktaCustomerPassword;
    @Value("${test.okta.user.customer.scope}") private String oktaCustomerScope;
    @Value("${test.api.brand.class}") private String brandClass;

    @Autowired private SecurityService securityService;

    public Map<String, Object> buildCorrespondenceHeaders(final String correspondenceType) {
        switch (correspondenceType){
            case CORRESPONDENCE_TYPE_QUOTATION:
                return buildCorrespondenceHeadersForQuotations();
            case CORRESPONDENCE_TYPE_ANONYMOUS_QUOTE:
                return buildCorrespondenceHeadersForQuotations();
            default:
                return buildCorrespondenceHeaders();
        }
    }

    public Map<String, Object> buildCorrespondenceHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_JURISDICTION, JURISDICTION_VIC);
        requestHeaders.put(X_IAG_USER, USER_SC_APP_ADMIN);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        return requestHeaders;
    }

    public Map<String, Object> buildCorrespondenceHeadersForQuotations() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_JURISDICTION, JURISDICTION_VIC);
        requestHeaders.put(X_IAG_USER, USER_SC_APP_ADMIN);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_DISTRIBUTION_CHANNEL, CHANNEL_DIRECT);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        return requestHeaders;
    }

    public Map<String, Object> buildDigitalCorrespondenceHeaders(boolean isOktaToken) {
        Map<String, Object> requestHeaders = new HashMap<>();
        if(isOktaToken) {
            requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerWithUserAuthEnabled, providerSystem));
            requestHeaders.put(X_IAG_AUTH_USER, securityService.getOktaUserSecurityToken(buildOktaUserTokenRequest()));
        }
        else {
            requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
            requestHeaders.put(X_IAG_AUTH_USER, USER_SC_APP_ADMIN);
        }
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        return requestHeaders;
    }

    public void updateHeadersWithAnonymousToken(Map<String, Object> requestHeaders, String policyNumber){
        final String anonymousToken = securityService.issueOktaAnonymousUserSecurityToken(buildOktaAnonymousUserTokenRequest(policyNumber));
        requestHeaders.put(X_IAG_AUTH_USER, anonymousToken);
    }

    public Map<String, Object> buildAllCorrespondenceHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_JURISDICTION, JURISDICTION_VIC);
        requestHeaders.put(X_IAG_USER, USER_SC_APP_ADMIN);
        requestHeaders.put(X_IAG_AUTH_USER, USER_SC_APP_ADMIN);
        requestHeaders.put(X_IAG_DISTRIBUTION_CHANNEL, CHANNEL_ASSISTED);
        requestHeaders.put(X_IAG_SALES_CHANNEL, CHANNEL_ASSISTED);
        requestHeaders.put(X_IAG_PRODUCT, productCode);
        requestHeaders.put(X_IAG_BUSINESS_REFERENCE, "DIRECT");
        requestHeaders.put(X_IAG_SESSION_ID, UUID.randomUUID().toString());
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        return requestHeaders;
    }

    public OktaUserTokenRequestPayload buildOktaUserTokenRequest() {
        OktaUserTokenRequestPayload oktaUserTokenRequestPayload = new OktaUserTokenRequestPayload();
        oktaUserTokenRequestPayload.setBrand(brand);
        oktaUserTokenRequestPayload.setBrandClass(brandClass);
        OktaUserDetails oktaUserDetails = new OktaUserDetails();
        oktaUserDetails.setPassword(oktaCustomerPassword);
        oktaUserDetails.setScope(oktaCustomerScope);
        oktaUserDetails.setUserName(ffTestSerenityOktaCustomerId);
        oktaUserTokenRequestPayload.setOktaUserDetails(oktaUserDetails);
        return oktaUserTokenRequestPayload;
    }

    public AnonymousUserTokenRequest buildOktaAnonymousUserTokenRequest(final String quoteId) {
        AnonymousUserTokenRequest anonymousUserTokenRequest = new AnonymousUserTokenRequest();
        anonymousUserTokenRequest.setBrand(brand);
        anonymousUserTokenRequest.setBrandClass(brandClass);
        anonymousUserTokenRequest.setChannel("DIGITAL");
        anonymousUserTokenRequest.setQuoteId(quoteId);
        return anonymousUserTokenRequest;
    }

}
