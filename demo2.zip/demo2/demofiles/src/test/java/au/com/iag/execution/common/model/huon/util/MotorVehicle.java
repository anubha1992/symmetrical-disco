package au.com.iag.execution.common.model.huon.util;

import java.lang.reflect.*;

/**
 * A super class for a motor vehicle.
 */
public class MotorVehicle {
    protected String vehicleYear = "";
    protected String vehicleMaker = "";
    protected String vehicleModel = "";
    protected String vehicleShape = "";
    protected String vehicleSeries = "";
    protected String vehicleTare = "";
    protected String vehicleEquipment = "";
    protected String vehicleEngineType = "";
    protected String vehicleEngineSize = "";

    protected String vinNumber = "";

    protected String sequenceNumber = "";
    protected String regoNumber;
    protected String registrationNumber;

    public String getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(String vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public String getVehicleMaker() {
        return vehicleMaker;
    }

    public void setVehicleMaker(String vehicleMaker) {
        this.vehicleMaker = vehicleMaker;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getVehicleShape() {
        return vehicleShape;
    }

    public void setVehicleShape(String vehicleShape) {
        this.vehicleShape = vehicleShape;
    }

    public String getVehicleSeries() {
        return vehicleSeries;
    }

    public void setVehicleSeries(String vehicleSeries) {
        this.vehicleSeries = vehicleSeries;
    }


    public String getVehicleTare() {
        return vehicleTare;
    }

    public void setVehicleTare(String vehicleTare) {
        this.vehicleTare = vehicleTare;
    }

    public String getVehicleEquipment() {
        return vehicleEquipment;
    }

    public void setVehicleEquipment(String vehicleEquipment) {
        this.vehicleEquipment = vehicleEquipment;
    }

    public String getVehicleEngineType() {
        return vehicleEngineType;
    }

    public void setVehicleEngineType(String vehicleEngineType) {
        this.vehicleEngineType = vehicleEngineType;
    }

    public String getVehicleEngineSize() {
        return vehicleEngineSize;
    }

    public void setVehicleEngineSize(String vehicleEngineSize) {
        this.vehicleEngineSize = vehicleEngineSize;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getRegoNumber() {
        return regoNumber;
    }

    public void setRegoNumber(String regoNumber) {
        this.regoNumber = regoNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");

        Class<?> myClass = this.getClass();

        try {
            Field[] fields = myClass.getDeclaredFields();
            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers()))
                    continue;
                if (field.getName().startsWith("this"))
                    continue;

                sb.append(field.getName());
                sb.append("=");
                sb.append(field.get(this));
                sb.append(";");
            }
        } catch (IllegalAccessException iae) {

        }
        sb.replace(sb.length() - 1, sb.length(), "]");
        return sb.toString();
    }

}
