package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class PartyRole implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("party_id")
    private String partyId;
    @JsonProperty("role")
    private String role;

  
    @ApiModelProperty(
        value = "Party Primary Id",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getPartyId() {
       return partyId;
    }
 
    @ApiModelProperty(
        value = "Role of the party. [Ref Data: party_role]",
        example = "POLICY_HOLDER",
        required = true
    )
    @javax.validation.constraints.NotNull
    public String getRole() {
       return role;
    }
 

}