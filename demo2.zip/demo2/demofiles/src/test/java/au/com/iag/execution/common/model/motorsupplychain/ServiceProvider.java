package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class ServiceProvider implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("qapter_member_identifier")
    private String qapterMemberIdentifier;
    @JsonProperty("identifier")
    private String identifier;
    @JsonProperty("is_hub")
    private Boolean isHub;
    @JsonProperty("repairer_type")
    private String repairerType;
    @JsonProperty("relationship")
    private String relationship;
    @JsonProperty("system_of_engagement")
    private String systemOfEngagement;


}