package au.com.iag.execution.common.builders.notifyapi;

import static java.util.Map.entry;

import static au.com.iag.glados.model.constants.GladosConstants.APPLICATION_JSON;
import static au.com.iag.glados.model.constants.GladosConstants.CONTENT_TYPE;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AGENT_ID;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_BRAND;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_DISTRIBUTOR;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_SALES_CHANNEL;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_SESSION_ID;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import au.com.iag.execution.notifyapi.model.PartyRequestArtifact;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.ResourceReaderService;
import au.com.iag.glados.service.SecurityService;

@Component
public class PartyRequestBuilderNotify<T> {

    @Autowired private SecurityService securityService;
    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;

    @Value("${test.api.brand}") private String brand;
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;
    @Value("${test.api.channel}") private String channel;
    @Value("${test.api.user}") private String user;
    @Value("${test.api.session}") private String sessionId;
    @Value("${test.api.distributor}") private String distributor;
    @Value("${test.api.agent-id}") private String agentId;

    private Map<String, String> partyEndpointMapper = Map.ofEntries(
            entry("Individual", "/individuals"),
            entry("Organisation", "/organisations")
    );

    private Map<String, String> partyRequestMapper = Map.ofEntries(
            entry("Individual", "requests/party-api/individualRequest.json"),
            entry("Organisation", "requests/party-api/organisationRequest.json")
    );

//    protected PartyBuilder partyBuilder;

    public PartyRequestArtifact<T> setupCreatePartyDefaults(Class<T> partyType) throws IOException{
        PartyRequestArtifact<T> partyRequestArtifact = new PartyRequestArtifact<>();
        partyRequestArtifact.setHeaders(buildPartyHeaders());
        partyRequestArtifact.setPath("/services/v1/legal-entity/party" + partyEndpointMapper.get(partyType.getSimpleName()));
        partyRequestArtifact.setRequest(buildPartyRequest(partyType));
        return partyRequestArtifact;
    }

    public T buildPartyRequest(Class<T> partyType) throws IOException {
        return jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(partyRequestMapper.get(partyType.getSimpleName())), partyType);
    }


    private Map<String, Object> buildPartyHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(X_IAG_SALES_CHANNEL, channel);
        requestHeaders.put(X_IAG_USER, user);
        requestHeaders.put(X_IAG_SESSION_ID, sessionId);
        requestHeaders.put(X_IAG_DISTRIBUTOR, distributor);
        requestHeaders.put(X_IAG_AGENT_ID, agentId);
        return requestHeaders;
    }
}
