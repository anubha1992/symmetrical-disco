package au.com.iag.execution.claimupdateapi.builders;

import au.com.iag.execution.claimupdateapi.model.*;
import au.com.iag.execution.claimupdateapi.model.business.*;
import au.com.iag.execution.claimupdateapi.model.business.qapter.*;
import au.com.iag.execution.common.notify.service.*;
import au.com.iag.execution.common.service.lodgeclaims.*;
import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.security.UserTokenRequestPayload;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static org.apache.http.HttpStatus.*;
import java.io.*;
import java.text.*;
import java.util.*;

import static au.com.iag.glados.model.constants.GladosConstants.*;

@Component
public class ClaimUpdateRequestBuilder {

    @Autowired
    private SecurityService securityService;
    @Autowired
    private ApigeeOauthClient apigeeOauthClient;
    @Autowired
    private LodgeMotorClaimService lodgeMotorClaimService;
    @Autowired
    private LodgePropertyClaimService lodgePropertyClaimService;
    @Autowired
    private RetrieveClaimDetailsService retrieveClaimDetailsService;

    @Value("${test.api.source.system.brand}")
    public String brand;
    @Value("${test.api.route}")
    private String route;
    @Value("${test.apigee.route}")
    private String apigeeRoute;
    @Value("${test.security.consumer}")
    private String consumerSystem;
    @Value("${test.security.provider}")
    private String providerSystem;
    @Value("${test.api.source.system}")
    private String apiSourceSystem;
    @Value("${test.api.product.code}") private String productCode;
    @Value("${test.apigee.api.key}") private String apigeeKey;
    @Value("${test.apigee.api.secret}") private String apigeeSecret;

    @Value("${test.api.lodgeservicerequest.route}")
    private String lodgeServiceRequestPath;

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;

    private String claimCorrespondenceRequestJsonPath = "requests/claim-update-api/sendCorrespondence.json";
    private String motorServiceRequestJsonPath = "requests/claim-update-api/motorServiceRequest.json";

    public NotifyServiceRequestArtifact buildNotifyServiceRequest() {

        UserTokenRequestPayload userTokenRequestPayload = getUserTokenRequestPayload("w:service_request_id:serviceRequestId");

        NotifyServiceRequestArtifact notifyServiceRequestArtifact = new NotifyServiceRequestArtifact();
        notifyServiceRequestArtifact.setHeaders(getRequestHeaders());
        notifyServiceRequestArtifact.setPath(route+"/service-request/notify");
        notifyServiceRequestArtifact.getHeaders().put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        notifyServiceRequestArtifact.setNotifyServiceRequest(getNotifyServiceRequest());

        return notifyServiceRequestArtifact;
    }

    public AssessmentServiceRequestArtifact buildAssessmentServiceRequest() {
        UserTokenRequestPayload userTokenRequestPayload = getUserTokenRequestPayload("w:service_request_id:serviceRequestId");
        AssessmentServiceRequestArtifact assessmentServiceRequestArtifact = new AssessmentServiceRequestArtifact();
        assessmentServiceRequestArtifact.setHeaders(getRequestHeaders());
        assessmentServiceRequestArtifact.setPath(route+"/service-request/assessment");
        assessmentServiceRequestArtifact.getHeaders().put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        assessmentServiceRequestArtifact.setUpdateAssessment(getUpdateAssessment());

        return assessmentServiceRequestArtifact;
    }

    public ClaimActivityArtifact buildClaimCreateActivityRequest(ActivityPatternCode activityPatternCode) {
        ClaimActivityArtifact claimActivityArtifact = new ClaimActivityArtifact();
        claimActivityArtifact.setHeaders(getRequestHeaders());
        claimActivityArtifact.setPath(route+"/");

        ClaimActivityRequest claimActivityRequest = new ClaimActivityRequest();
        claimActivityRequest.setActivityPatternCode(activityPatternCode.getCode());
        claimActivityRequest.setDescription(activityPatternCode.getDescription());
        claimActivityArtifact.setClaimActivityRequest(claimActivityRequest);

        return claimActivityArtifact;
    }

    @Tag("ccm")
    public ClaimActivityArtifact buildClaimCreateActivityRequestCCM(String userId, ActivityPatternCode activityPatternCode){
        ClaimActivityArtifact claimActivityArtifact = buildClaimCreateActivityRequest(activityPatternCode);
        Map<String, Object> requestHeaders = claimActivityArtifact.getHeaders();
        requestHeaders.put(X_IAG_CHANNEL, "ccm");
        requestHeaders.put("source_id", "DC");

        claimActivityArtifact.getClaimActivityRequest().setUserId(userId);
        claimActivityArtifact.getClaimActivityRequest().setGroupName("ABC");

        return claimActivityArtifact;
    }

    public SendCorrespondenceArtifact buildSendCorrespondenceArtifact(String claimId) throws IOException {
        SendCorrespondenceArtifact sendCorrespondenceArtifact = new SendCorrespondenceArtifact();
        Map<String, Object> requestHeaders = getRequestHeaders();
        requestHeaders.put(X_IAG_USER, "LAA008C9705F@anonymous");
        sendCorrespondenceArtifact.setHeaders(requestHeaders);
        sendCorrespondenceArtifact.setPath(route + "/correspond");
        sendCorrespondenceArtifact.setClaimId(claimId);
        sendCorrespondenceArtifact.setClaimCorrespondence(getClaimCorrespondence(claimId));
        return sendCorrespondenceArtifact;
    }

    public SendCorrespondenceArtifact buildSendCorrespondenceArtifactExternal(String claimId) throws IOException {
        SendCorrespondenceArtifact sendCorrespondenceArtifact = new SendCorrespondenceArtifact();
        Map<String, Object> requestHeaders = getRequestHeaders();
        requestHeaders.put(AUTHORIZATION, getApigeeAuthToken());
        sendCorrespondenceArtifact.setHeaders(requestHeaders);
        sendCorrespondenceArtifact.setPath(apigeeRoute + "/correspond");
        sendCorrespondenceArtifact.setClaimId(claimId);
        sendCorrespondenceArtifact.setClaimCorrespondence(getClaimCorrespondence(claimId));
        return sendCorrespondenceArtifact;
    }


    public LodgeMotorServiceRequestArtifact buildMotorServiceReqArtifact(String claimId) throws Exception {
        LodgeMotorServiceRequestArtifact lodgeMotorServiceRequestArtifact = new LodgeMotorServiceRequestArtifact();
        Map<String, Object> requestHeaders = getRequestHeaders();
        requestHeaders.put("source_id", "DC");
        lodgeMotorServiceRequestArtifact.setHeaders(requestHeaders);
        lodgeMotorServiceRequestArtifact.setMotorServiceRequest(getServiceRequest(claimId));
        lodgeMotorServiceRequestArtifact.setPath(lodgeServiceRequestPath+"/"+claimId);
        return lodgeMotorServiceRequestArtifact;
    }

    public ClaimActivityArtifact buildUserTokenHeader(ClaimActivityArtifact claimActivityArtifact, String claimId) {
        Map<String, Object> requestHeaders = claimActivityArtifact.getHeaders();
        UserTokenRequestPayload userTokenRequestPayload = getUserTokenRequestPayload("r:claimId:"+claimId);
        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        claimActivityArtifact.setClaimId(claimId);
        return claimActivityArtifact;
    }

    private Map<String, Object> getRequestHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(X_IAG_USER, "LAA008C9705F@anonymous");
        return requestHeaders;
    }

    private UserTokenRequestPayload getUserTokenRequestPayload(String scope) {
        UserTokenRequestPayload userTokenRequestPayload = new UserTokenRequestPayload();
        userTokenRequestPayload.setScope(scope);
        userTokenRequestPayload.setSubject("LAA008C9705F@anonymous");
        userTokenRequestPayload.setAudience("business-api-provider");
        userTokenRequestPayload.setIss("business-api-provider");
        userTokenRequestPayload.setGrantType("NOTARY");
        return userTokenRequestPayload;
    }

    private ClaimCorrespondence getClaimCorrespondence(String claimId) throws IOException {

        ClaimCorrespondence sendCorrespondenceRequest = jsonMapperService
                .getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(claimCorrespondenceRequestJsonPath), ClaimCorrespondence.class);

        sendCorrespondenceRequest.getClaim().setClaimIdentifier(claimId);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        sendCorrespondenceRequest.getTemplateData().getAssessment().setAssessmentDate(formatter.format(date));
        if(productCode.equalsIgnoreCase("COM")||productCode.equalsIgnoreCase("MOT"))
            sendCorrespondenceRequest.getCoreCorrespondenceDetails().setLineOfBusiness("MOTOR");
        else{
            sendCorrespondenceRequest.getCoreCorrespondenceDetails().setLineOfBusiness("PROPERTY");
        }
        return sendCorrespondenceRequest;
    }

    private MotorServiceRequest getServiceRequest(String claimId) throws Exception{

        Response response = retrieveClaimDetailsService.retrieveClaimDetailsByClaimId(claimId);
        String incidentId = response.path("claim.incidents[0].incident_id").toString().replace("[", "").replace("]", "");

        MotorServiceRequest motorServiceRequest = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(motorServiceRequestJsonPath), MotorServiceRequest.class);

        motorServiceRequest.getServiceRequests().get(0).getIncidents().get(0).setIncidentId(incidentId);

        return motorServiceRequest;

    }

    public String getClaimId() throws Exception {
        Response response;
        if(productCode.equalsIgnoreCase("MOT")|| productCode.equalsIgnoreCase("COM")) {
            response = lodgeMotorClaimService.lodgeClaim(SC_OK);
            return response.path("claim_identifier");
        }
        else {
            response = lodgePropertyClaimService.lodgeClaim(SC_OK);
            return response.path("claim_identifier");
        }
    }

    private String getApigeeAuthToken(){
        return apigeeOauthClient.getToken(apigeeKey, apigeeSecret);
    }

    private NotifyServiceRequest getNotifyServiceRequest(){
        NotifyServiceRequest notifyServiceRequest = new NotifyServiceRequest();
        notifyServiceRequest.setServiceRequestId("serviceRequestId");
        return notifyServiceRequest;
    }

    private UpdateAssessment getUpdateAssessment(){
        UpdateAssessment updateAssessment = new UpdateAssessment();
        updateAssessment.setAssessmentDetails(getAssessmentDetails());
        return updateAssessment;
    }

    private AssessmentDetails getAssessmentDetails(){
        AssessmentDetails assessmentDetails = new AssessmentDetails();
        assessmentDetails.setServiceRequestId("serviceRequestId");
        return assessmentDetails;
    }
}
