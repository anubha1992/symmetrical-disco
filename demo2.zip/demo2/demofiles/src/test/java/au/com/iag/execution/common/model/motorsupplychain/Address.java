package au.com.iag.execution.common.model.motorsupplychain;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.*;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_DEFAULT)
public class Address implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("address_line_one")
    private String addressLineOne;
    @JsonProperty("address_line_three")
    private String addressLineThree;
    @JsonProperty("address_line_two")
    private String addressLineTwo;
    @JsonProperty("city")
    private String city;
    @JsonProperty("country")
    private String country;
    @JsonProperty("postcode")
    private String postcode;
    @JsonProperty("state")
    private String state;
    @JsonProperty("suburb")
    private String suburb;


    @ApiModelProperty(
            value = "Street number, name and prefix",
            example = "15 Smith St",
            required = false
    )
    public String getAddressLineOne() {
        return addressLineOne;
    }

    @ApiModelProperty(
            value = "Building or office designation",
            example = "Suite 200",
            required = false
    )
    public String getAddressLineThree() {
        return addressLineThree;
    }

    @ApiModelProperty(
            value = "Office/Floor designation",
            example = "Level 2",
            required = false
    )
    public String getAddressLineTwo() {
        return addressLineTwo;
    }

    @ApiModelProperty(
            value = "City",
            example = "Sydney",
            required = false
    )
    public String getCity() {
        return city;
    }

    @ApiModelProperty(
            value = "Country",
            example = "Australia",
            required = false
    )
    public String getCountry() {
        return country;
    }

    @ApiModelProperty(
            value = "Postal code",
            example = "2013",
            required = false
    )
    public String getPostcode() {
        return postcode;
    }

    @ApiModelProperty(
            value = "State or other administrative area name in case of international",
            example = "NSW",
            required = false
    )
    public String getState() {
        return state;
    }

    @ApiModelProperty(
            value = "Name of the suburb, town or other locality type",
            example = "Chatswood",
            required = false
    )
    public String getSuburb() {
        return suburb;
    }


}