package au.com.iag.execution.claimupdateapi.model.business;

import au.com.iag.execution.claimupdateapi.model.business.qapter.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class NotifyServiceRequest {

    @ApiModelProperty(value = "Service Request Allocation ID", example = "cc:123456")
    private String serviceRequestId;
    private Notification notification;
}
