package au.com.iag.execution.claimdetailsapi.builders;

import static au.com.iag.execution.common.constants.ApiConstants.BUSINESS_API_PROVIDER;
import static au.com.iag.execution.common.constants.ApiConstants.DB_CC_CLAIMNUMBER;
import static au.com.iag.execution.common.constants.ApiConstants.SOURCE_ID;
import static au.com.iag.glados.model.constants.GladosConstants.ACCEPT;
import static au.com.iag.glados.model.constants.GladosConstants.APPLICATION_JSON;
import static au.com.iag.glados.model.constants.GladosConstants.AUTHORIZATION;
import static au.com.iag.glados.model.constants.GladosConstants.CONTENT_TYPE;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AGENT_ID;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_USER;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_BRAND;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CHANNEL;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_DISTRIBUTOR;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_OPERATION;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_REGION;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER_ALIASES;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER_PROFILE;
import static org.apache.http.HttpStatus.SC_OK;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import au.com.iag.execution.claimdetailsapi.model.ClaimDetailsArtifact;
import au.com.iag.execution.claimdetailsapi.model.VerifyClaimUserArtifact;
import au.com.iag.execution.common.service.lodgeclaims.LodgeMotorClaimService;
import au.com.iag.execution.common.service.lodgeclaims.LodgePropertyClaimService;
import au.com.iag.glados.integration.ApigeeOauthClient;
import au.com.iag.glados.model.security.UserTokenRequestPayload;
import au.com.iag.glados.service.SecurityService;
import io.restassured.response.Response;

@Component
public class ClaimDetailsRequestBuilder {

    @Autowired private ApigeeOauthClient apigeeOauthClient;
    @Autowired private SecurityService securityService;

    @Value("${test.api.route}") private String path;
    @Value("${test.apigee.route}") private String pathApigee;
    @Value("${test.api.source.system.brand}") private String brand;
    @Value("${test.apigee.api.key}") private String apigeeKey;
    @Value("${test.apigee.api.secret}") private String apigeeSecret;
    @Value("${test.security.consumer}") private String consumerSystem;
    @Value("${test.security.provider}") private String providerSystem;
    @Autowired
    LodgeMotorClaimService lodgeMotorClaimService;

    @Autowired LodgePropertyClaimService lodgePropertyClaimService;


    public ClaimDetailsArtifact setUpClaimDetails() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = new ClaimDetailsArtifact();
        claimDetailsArtifact.setHeaders(getHeaders());
        claimDetailsArtifact.setPath(path);
        return claimDetailsArtifact;
    }

    public ClaimDetailsArtifact setUpRetrieveClaimDetails() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = setUpClaimDetails();
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        if (brand.equalsIgnoreCase("NRMA") || brand.equalsIgnoreCase("SGIO") || brand.equalsIgnoreCase("SGIC") || brand.equalsIgnoreCase("RACV")) {
            requestHeaders.put(X_IAG_USER, "WEBNIIP");
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_DISTRIBUTOR, brand);
            requestHeaders.put(X_IAG_OPERATION, "retrievePolicy");
        } else if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI")) {
            requestHeaders.put(X_IAG_USER, "WEBZIIP");
            requestHeaders.put(X_IAG_USER_PROFILE, "IAGNZ");
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_DISTRIBUTOR, brand);
            requestHeaders.put(X_IAG_REGION, "NZ");
            requestHeaders.put(X_IAG_OPERATION, "retrievePolicy");
        }
        return claimDetailsArtifact;
    }

    public ClaimDetailsArtifact setUpSearchClaimDetails() throws Exception {
        ClaimDetailsArtifact claimDetailsArtifact = setUpClaimDetails();
        String path = claimDetailsArtifact.getPath();
        claimDetailsArtifact.setPath(path+"/search");
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        if (brand.equalsIgnoreCase("NRMA") || brand.equalsIgnoreCase("SGIO") || brand.equalsIgnoreCase("SGIC") || brand.equalsIgnoreCase("RACV")) {
            requestHeaders.put(X_IAG_USER, "WEBNIIP");
            requestHeaders.put(X_IAG_USER_PROFILE, "IAGSM");
            requestHeaders.put(X_IAG_USER_ALIASES, "HUON=MRJUSER");
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_OPERATION, "searchPolicy");
        } else if (brand.equalsIgnoreCase("NZ STATE")) {
            requestHeaders.put(X_IAG_USER, "WEBZIIP");
            requestHeaders.put(X_IAG_USER_PROFILE, "IAGNZ");
            requestHeaders.put(X_IAG_OPERATION, "searchPolicy");
            requestHeaders.put(X_IAG_AGENT_ID, "CLAIMSTAFF");
        }
        return claimDetailsArtifact;
    }

    public ClaimDetailsArtifact buildClaimDetailsExternal(ClaimDetailsArtifact claimDetailsArtifact)  {
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(AUTHORIZATION, getApigeeAuthToken());
        claimDetailsArtifact.setPath(pathApigee);

        return claimDetailsArtifact;
    }

    public String getClaimId(List<Map<String, Object>> claimIdDetails, String productCode) throws Exception {

        if (isNzBrand()) {
            if (brand.equalsIgnoreCase("AMI")) {
                if(productCode.equalsIgnoreCase("MOT"))
                {
                    return "C3082228";
                } else {
                    return "C3081838";
                }
            }
            Response response = null;
            if (productCode.equalsIgnoreCase("MOT")) {
                response = lodgeMotorClaimService.lodgeClaim(SC_OK);
            } else
            {
                response = lodgePropertyClaimService.lodgeClaim(SC_OK);
            }
            return response.path("claim_identifier");

        }
        return claimIdDetails.get(new Random().nextInt(claimIdDetails.size())).get(DB_CC_CLAIMNUMBER).toString();
    }

    private boolean isNzBrand() {
        return brand.equalsIgnoreCase("NZ STATE")
                || brand.equalsIgnoreCase("AMI")
                || brand.equalsIgnoreCase("NZSTATE")
                || brand.equalsIgnoreCase("STATE");
    }

    private Map<String, Object> getHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put(ACCEPT, APPLICATION_JSON);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, consumerSystem);
        requestHeaders.put(X_IAG_CHANNEL, "Digital");
        requestHeaders.put(X_IAG_BRAND, brand);
        requestHeaders.put(SOURCE_ID, "DC");
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        return requestHeaders;
    }

    public ClaimDetailsArtifact setUserSecurityToken(ClaimDetailsArtifact claimDetailsArtifact, String scopeId){
        UserTokenRequestPayload userTokenRequestPayload = getSSCUserTokenRequestPayloadForCsg(scopeId);
        Map<String, Object> requestHeaders = claimDetailsArtifact.getHeaders();
        requestHeaders.put(X_IAG_USER, "LAA008C9705F@anonymous");
        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        return claimDetailsArtifact;
    }

    private UserTokenRequestPayload getSSCUserTokenRequestPayloadForCsg(String scopeId){
        UserTokenRequestPayload userTokenRequestPayload = new UserTokenRequestPayload();
        userTokenRequestPayload.setAudience(BUSINESS_API_PROVIDER);
        userTokenRequestPayload.setAuthentication("NONE");
        userTokenRequestPayload.setContext("ssc");
        userTokenRequestPayload.setGrantType("NOTARY");
        userTokenRequestPayload.setIss(BUSINESS_API_PROVIDER);
        userTokenRequestPayload.setName("");
        userTokenRequestPayload.setScope("");
        userTokenRequestPayload.setSubject("ANONYMOUS");
        if (StringUtils.isNotEmpty(scopeId)) {
            userTokenRequestPayload.setScope("r:claimId:" + scopeId);
            userTokenRequestPayload.setSubject("LAA008C9705F@anonymous");
        }
        return userTokenRequestPayload;
    }

    private String getApigeeAuthToken(){
        return apigeeOauthClient.getToken(apigeeKey, apigeeSecret);
    }

    public VerifyClaimUserArtifact setupVerifyClaimUserDefaults(String claimId, String crodsCustomerId) {
        VerifyClaimUserArtifact verifyClaimUserArtifact = new VerifyClaimUserArtifact();
        verifyClaimUserArtifact.setClaimId(claimId);
        verifyClaimUserArtifact.setPath(path);
        verifyClaimUserArtifact.setHeaders(buildVerifyClaimUserHeaders(claimId, crodsCustomerId));

        return verifyClaimUserArtifact;
    }

    private Map<String, Object> buildVerifyClaimUserHeaders(String claimId, String crodsCustomerId) {
        Map<String, Object> requestHeaders = getHeaders();
        UserTokenRequestPayload userTokenRequestPayload = getSSCUserTokenRequestPayloadForCsg(claimId);
        userTokenRequestPayload.setSubject(crodsCustomerId + "@crods");
        requestHeaders.put(X_IAG_AUTH_USER, securityService.getUserSecurityToken(userTokenRequestPayload));
        return requestHeaders;
    }
}
