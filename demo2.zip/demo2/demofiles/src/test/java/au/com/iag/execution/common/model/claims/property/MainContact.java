package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class MainContact extends Person implements Serializable {
    private static final long serialVersionUID = -2743588774611186111L;

    private String relationshipToInsured;
    private String contactFrequency;

    public String getRelationshipToInsured() {
        return relationshipToInsured;
    }

    public void setRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
    }

    public String getContactFrequency() {
        return contactFrequency;
    }

    public void setContactFrequency(String contactFrequency) {
        this.contactFrequency = contactFrequency;
    }
}
