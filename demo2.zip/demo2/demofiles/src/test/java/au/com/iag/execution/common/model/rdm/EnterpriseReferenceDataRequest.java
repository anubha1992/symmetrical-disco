package au.com.iag.execution.common.model.rdm;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class EnterpriseReferenceDataRequest implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("effective_date")
    private String effectiveDate;
    @JsonProperty("types")
    private java.util.List<EnterpiseReferenceDataType> types;

  
    @ApiModelProperty(
        value = "Effective date with time and zone. Format yyyy-MM-dd&#x27;T&#x27;HH:mm:ss.SSS&#x27;Z&#x27;",
        example = "2020-12-30T11:30:00+11:00",
        required = false
    )
    public String getEffectiveDate() {
       return effectiveDate;
    }
 
    @ApiModelProperty(
        value = "",
        required = false
    )
    public java.util.List<EnterpiseReferenceDataType> getTypes() {
       return types;
    }
 

}