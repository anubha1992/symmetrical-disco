package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Excess implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("amount")
    private Double amount ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Excess amount",
        example = "199.99",
        required = false
    )
    public Double getAmount() {
       return amount;
    }
 
    @ApiModelProperty(
        value = "Excess type [Ref Data: motor_vehicle_excess_type]",
        example = "VEHICLE_EXCESS",
        required = false
    )
    public String getType() {
       return type;
    }
 

}