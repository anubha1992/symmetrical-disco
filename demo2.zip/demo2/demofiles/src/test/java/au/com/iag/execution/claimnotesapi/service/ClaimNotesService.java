package au.com.iag.execution.claimnotesapi.service;

import static org.junit.Assert.assertEquals;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import au.com.iag.execution.claimnotesapi.model.ClaimNotesArtifact;
import au.com.iag.glados.common.GladosEnrichmentService;
import io.restassured.response.Response;

@Service
public class ClaimNotesService {
    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    public Response executeClaimNotes(ClaimNotesArtifact claimNotesArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequest(
                claimNotesArtifact.getHeaders(),
                claimNotesArtifact.getPath(),
                claimNotesArtifact.getClaimNotesRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeExternalClaimNotes(ClaimNotesArtifact claimNotesArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequestExternal(
                claimNotesArtifact.getHeaders(),
                claimNotesArtifact.getPath(),
                claimNotesArtifact.getClaimNotesRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }
}
