package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.execution.correspondenceapi.model.business.PremiumDetails;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class PolicyBuilder {

    @Autowired private MiscDataBuilder miscDataBuilder;
    @Autowired private PaymentsBuilder paymentsBuilder;

    public void updatePolicyCorrespondenceByType(final String correspondenceType, PolicyCorrespondence policyCorrespondence){
        switch (correspondenceType){
            case CORRESPONDENCE_TYPE_QUOTATION:
                policyCorrespondence.getPolicyDetails().setType(POLICY_TYPE_QUOTE);
                break;
            default:
                policyCorrespondence.getPolicyDetails().setType(POLICY_TYPE_POLICY);
        }
    }

    public PolicyCorrespondence switchToHomeAmendment(PolicyCorrespondence policyCorrespondence){
        PolicyCorrespondence policyCorrespondenceAmendment = SerializationUtils.clone(policyCorrespondence);
        policyCorrespondenceAmendment.getCorrespondence().setCorrespondenceType(CORRESPONDENCE_TYPE_AMENDMENT);
        return policyCorrespondenceAmendment;
    }

    public PolicyCorrespondence switchToMotorAmendment(PolicyCorrespondence policyCorrespondence){
        PolicyCorrespondence policyCorrespondenceAmendment = SerializationUtils.clone(policyCorrespondence);
        policyCorrespondenceAmendment.getCorrespondence().setCorrespondenceType(CORRESPONDENCE_TYPE_AMENDMENT);
        policyCorrespondenceAmendment.getPolicyDetails().getAssets().getVehicleAssets().forEach(vehicleAsset -> {
            PremiumDetails premiumDetails = new PremiumDetails();
            premiumDetails.setTotalPremium(miscDataBuilder.getDouble(500, 1000));
            vehicleAsset.setAdjustedPremiumDetails(premiumDetails);
        });
        policyCorrespondenceAmendment.getPolicyDetails().getPayments().getBillingPlanOptions().forEach(billingPlanOptions -> {
            billingPlanOptions.setAdjustedPremiumDetails(paymentsBuilder.getPremiumDetails(policyCorrespondence, 2.1));
        });
        return policyCorrespondenceAmendment;
    }
}
