package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.As.*;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.*;
import java.io.*;
import java.math.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonTypeInfo(use = NAME, include = EXISTING_PROPERTY, property = "type", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = LossEstimateItemContent.class, name = "Loss_Estimate_Item_Content"),
        @JsonSubTypes.Type(value = LossEstimateItemDwelling.class, name = "Loss_Estimate_Item_Dwelling"),
        @JsonSubTypes.Type(value = LossEstimateItemRentDefault.class, name = "Loss_Estimate_Item_Rent_Default"),
        @JsonSubTypes.Type(value = LossEstimateItemRentDefault.class, name = "Loss_Estimate_Item_Rent"),
        @JsonSubTypes.Type(value = LossEstimateItem.class, name = "Loss_Estimate_Item")
})
public class LossEstimateItem implements Serializable {

    private static final long serialVersionUID = 1L;

    private Boolean itcApplicable;
    private BigDecimal itcPercentage;
    private String category;
    private String subcategory;
    private String brand;
    private String type;
    private Amount limit;
    private Amount lossEstimate;
    private String description;
    private String status;
    private String note;
    private String itemCategory;

    public String getBrand() {        return brand;    }

    public void setBrand(String brand) {        this.brand = brand;    }

    public String getSubcategory() {         return subcategory;    }

    public void setSubcategory(String subcategory) {        this.subcategory = subcategory;    }

    public String getItemCategory() {        return itemCategory;    }

    public void setItemCategory(String itemCategory) {        this.itemCategory = itemCategory;    }

    public String getNote() {        return note;    }

    public void setNote(String note) {        this.note = note;    }

    public Boolean getItcApplicable() {
        return itcApplicable;
    }

    public void setItcApplicable(Boolean itcApplicable) {
        this.itcApplicable = itcApplicable;
    }

    public BigDecimal getItcPercentage() {
        return itcPercentage;
    }

    public void setItcPercentage(BigDecimal itcPercentage) {
        this.itcPercentage = itcPercentage;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Amount getLimit() {
        return limit;
    }

    public void setLimit(Amount limit) {
        this.limit = limit;
    }

    public Amount getLossEstimate() {
        return lossEstimate;
    }

    public void setLossEstimate(Amount lossEstimate) {
        this.lossEstimate = lossEstimate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}