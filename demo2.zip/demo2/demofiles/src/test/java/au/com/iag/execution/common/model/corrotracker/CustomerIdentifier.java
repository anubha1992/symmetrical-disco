package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class CustomerIdentifier implements Serializable {

	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@JsonProperty("customerId")
	private String customerId;

	public void setSourceSystem(String sourceSystem){
		this.sourceSystem = sourceSystem;
	}

	public String getSourceSystem(){
		return sourceSystem;
	}

	public void setCustomerId(String customerId){
		this.customerId = customerId;
	}

	public String getCustomerId(){
		return customerId;
	}

	@Override
 	public String toString(){
		return 
			"CustomerIdentifier{" + 
			"sourceSystem = '" + sourceSystem + '\'' + 
			",customerId = '" + customerId + '\'' + 
			"}";
		}
}