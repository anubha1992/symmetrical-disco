package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.CorrespondenceParties;
import au.com.iag.execution.correspondenceapi.model.business.Parties;
import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.RandomContentService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class LetterCorrespondenceRequestBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private PartyBuilder partyBuilder;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private RandomContentService randomContentService;
    @Autowired private BaseRequestBuilder baseRequestBuilder;

    //Policy Cancellation
    public PolicyCorrespondence buildLetterPolicyCancellationRequest(String product, String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getHomeLetterPolicyCancellationRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            case PRODUCT_MOTOR_INSURANCE:
                return getMotorLetterPolicyCancellationRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    //Dishonour Policy Cancellation
    public PolicyCorrespondence buildLetterDishonourPolicyCancellationRequest(String product, String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getHomeLetterDishonourPolicyCancellationRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            case PRODUCT_MOTOR_INSURANCE:
                return getMotorLetterDishonourPolicyCancellationRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    //Renewal Reminder Expiry
    public PolicyCorrespondence buildLetterRenewalReminderExpiryRequest(String product, String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getHomeLetterRenewalReminderExpiryRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            case PRODUCT_MOTOR_INSURANCE:
                return getMotorLetterRenewalReminderExpiryRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    //Dishonour Notification
    public PolicyCorrespondence buildLetterDishonourNotificationRequest(String product, String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        switch (product) {
            case PRODUCT_HOME_INSURANCE:
                return getHomeLetterDishonourNotificationRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            case PRODUCT_MOTOR_INSURANCE:
                return getMotorLetterDishonourNotificationRequest(correspondenceType, primaryRecipientType, listOfCoverableToPartyRoleSpec);
            default:
                throw new IllegalArgumentException("Invalid Insurance Type - "+product);
        }
    }

    public PolicyCorrespondence getMotorLetterRenewalReminderExpiryRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterMotorRenewalReminderExpiry.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getHomeLetterRenewalReminderExpiryRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterHomeRenewalReminderExpiry.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getMotorLetterPolicyCancellationRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterMotorPolicyCancellation.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getHomeLetterPolicyCancellationRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterHomePolicyCancellation.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getMotorLetterDishonourPolicyCancellationRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterMotorDishonourPolicyCancellation.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getHomeLetterDishonourPolicyCancellationRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterHomeDishonourPolicyCancellation.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getMotorLetterDishonourNotificationRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterMotorDishonourNotification.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getHomeLetterDishonourNotificationRequest() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/letterHomeDishonourNotification.json")
                        , PolicyCorrespondence.class);
    }

    private PolicyCorrespondence getMotorLetterDishonourNotificationRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getMotorLetterDishonourNotificationRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getHomeLetterDishonourNotificationRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getHomeLetterDishonourNotificationRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getMotorLetterRenewalReminderExpiryRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getMotorLetterRenewalReminderExpiryRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getHomeLetterRenewalReminderExpiryRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getHomeLetterRenewalReminderExpiryRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getMotorLetterPolicyCancellationRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getMotorLetterPolicyCancellationRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getHomeLetterPolicyCancellationRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getHomeLetterPolicyCancellationRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getMotorLetterDishonourPolicyCancellationRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getMotorLetterDishonourPolicyCancellationRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    private PolicyCorrespondence getHomeLetterDishonourPolicyCancellationRequest(final String correspondenceType
            , String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getHomeLetterDishonourPolicyCancellationRequest();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }
}
