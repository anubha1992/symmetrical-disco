package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class FieldMetadata implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("ask_if")
    private java.util.List<AskIf> askIf = new java.util.ArrayList<AskIf>();
    @JsonProperty("biz_constraints")
    private BizConstraints bizConstraints = new BizConstraints();
    @JsonProperty("dependent_fields")
    private java.util.List<FieldReference> dependentFields = new java.util.ArrayList<FieldReference>();
    @JsonProperty("editable")
    private Boolean editable ;
    @JsonProperty("hidden")
    private Boolean hidden ;
    @JsonProperty("name")
    private String name ;
    @JsonProperty("optional")
    private Boolean optional ;
    @JsonProperty("tech_constraints")
    private TechConstraints techConstraints = new TechConstraints();

  
    @ApiModelProperty(
        value = "Optional. The condition under which this question / field will be asked.",
        required = false
    )
    public java.util.List<AskIf> getAskIf() {
       return askIf;
    }
 
    @ApiModelProperty(
        value = "Field value business validation constraints",
        required = false
    )
    public BizConstraints getBizConstraints() {
       return bizConstraints;
    }
 
    @ApiModelProperty(
        value = "Optional. List of references to fields that are dependent on this field.",
        required = false
    )
    public java.util.List<FieldReference> getDependentFields() {
       return dependentFields;
    }
 
    @ApiModelProperty(
        value = "Optional. Specifies if the field&#x27;s value can be edited by the Consumer/User.",
        required = false
    )
    public Boolean getEditable() {
       return editable;
    }
 
    @ApiModelProperty(
        value = "Optional. Defines if the field should be displayed to the user supplied by the consumer application",
        required = false
    )
    public Boolean getHidden() {
       return hidden;
    }
 
    @ApiModelProperty(
        value = "The name of the data field. Appears in the data structure.",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "Optional. Identifies whether a value must be supplied for the field.",
        required = false
    )
    public Boolean getOptional() {
       return optional;
    }
 
    @ApiModelProperty(
        value = "Field value technical validation",
        required = false
    )
    public TechConstraints getTechConstraints() {
       return techConstraints;
    }
 

}