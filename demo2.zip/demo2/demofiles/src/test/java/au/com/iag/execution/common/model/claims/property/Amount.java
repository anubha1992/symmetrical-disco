package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import java.io.*;
import java.math.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Amount implements Serializable {

    private static final long serialVersionUID = -6005900331333860524L;
    private BigDecimal amount;
    private String currency;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Amount{");
        sb.append("amount=").append(amount);
        sb.append(", currency='").append(currency).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
