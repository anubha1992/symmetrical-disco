package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(description = "Contains details for the policy term inception date")
public class PolicyDates implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("offer_creation_date")
    private java.time.ZonedDateTime offerCreationDate ;
    @JsonProperty("offer_expiry_date")
    private java.time.ZonedDateTime offerExpiryDate ;
    @JsonProperty("term_expiry_date")
    private java.time.ZonedDateTime termExpiryDate ;
    @JsonProperty("term_inception_date")
    private java.time.ZonedDateTime termInceptionDate ;

  
    @ApiModelProperty(
        value = "Date to support scenario where creation date is earlier than the term inception date. e.g. Renewal or Quote created earlier than term inception date.",
        example = "2019-12-31T15:47:55.123+10:00",
        required = false
    )
    public java.time.ZonedDateTime getOfferCreationDate() {
       return offerCreationDate;
    }
 
    @ApiModelProperty(
        value = "Date to support scenario where expiry date happens later than the term expiry date.e.g. Renewal or Quote expires later than term expiry date.",
        example = "2019-12-31T15:47:55.123+10:00",
        required = false
    )
    public java.time.ZonedDateTime getOfferExpiryDate() {
       return offerExpiryDate;
    }
 
    @ApiModelProperty(
        value = "Term expiry date of the quote. For example, the renewal term expiry date",
        example = "2019-12-31T15:47:55.123+10:00",
        required = false
    )
    public java.time.ZonedDateTime getTermExpiryDate() {
       return termExpiryDate;
    }
 
    @ApiModelProperty(
        value = "Term inception date of the quote. For example, the renewal term start date",
        example = "2019-08-30T15:47:55.123+10:00",
        required = false
    )
    public java.time.ZonedDateTime getTermInceptionDate() {
       return termInceptionDate;
    }
 

}