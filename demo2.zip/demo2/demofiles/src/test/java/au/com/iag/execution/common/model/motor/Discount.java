package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Discount implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("discount_details")
    private java.util.List<DiscountDetails> discountDetails = new java.util.ArrayList<DiscountDetails>();

  
    @ApiModelProperty(
        value = "List of discounts",
        required = false
    )
    public java.util.List<DiscountDetails> getDiscountDetails() {
       return discountDetails;
    }
 

}