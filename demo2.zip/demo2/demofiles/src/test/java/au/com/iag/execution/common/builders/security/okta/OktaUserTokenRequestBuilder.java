package au.com.iag.execution.common.builders.security.okta;

import au.com.iag.glados.model.security.AnonymousUserTokenRequest;
import au.com.iag.glados.model.security.OktaUserDetails;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import au.com.iag.glados.model.security.OktaUserTokenRequestPayload;

@Component
public class OktaUserTokenRequestBuilder {

    @Value("${test.okta.user.customer.ff_test_serenity.id}") private String ffTestSerenityOktaCustomerId;
    @Value("${test.okta.user.customer.password}") private String oktaCustomerPassword;
    @Value("${test.okta.user.customer.scope}") private String oktaCustomerScope;
    @Value("${test.api.brand}") private String brand;
    @Value("${test.api.brand.class}") private String brandClass;

    public OktaUserTokenRequestPayload buildOktaUserTokenRequest() {
        OktaUserTokenRequestPayload oktaUserTokenRequestPayload = new OktaUserTokenRequestPayload();
        oktaUserTokenRequestPayload.setBrand(brand);
        oktaUserTokenRequestPayload.setBrandClass(brandClass);
        OktaUserDetails oktaUserDetails = new OktaUserDetails();
        oktaUserDetails.setPassword(oktaCustomerPassword);
        oktaUserDetails.setScope(oktaCustomerScope);
        oktaUserDetails.setUserName(ffTestSerenityOktaCustomerId);
        oktaUserTokenRequestPayload.setOktaUserDetails(oktaUserDetails);
        return oktaUserTokenRequestPayload;
    }

    public AnonymousUserTokenRequest buildOktaAnonymousUserTokenRequest(final String quoteId) {
        AnonymousUserTokenRequest anonymousUserTokenRequest = new AnonymousUserTokenRequest();
        anonymousUserTokenRequest.setBrand(brand);
        anonymousUserTokenRequest.setBrandClass(brandClass);
        anonymousUserTokenRequest.setChannel("DIGITAL");
        anonymousUserTokenRequest.setQuoteId(quoteId);
        return anonymousUserTokenRequest;
    }
}
