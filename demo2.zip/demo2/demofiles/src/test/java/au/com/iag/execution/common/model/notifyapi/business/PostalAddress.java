package au.com.iag.execution.common.model.notifyapi.business;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class PostalAddress implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("box_lobby_name")
    private String boxLobbyName;
    @JsonProperty("building_name")
    private String buildingName;
    @JsonProperty("postal_number")
    private String postalNumber;
    @JsonProperty("postal_type")
    private String postalType;

  
    @ApiModelProperty(
        value = "Used for NZL addresses",
        example = "Albany",
        required = false
    )
    public String getBoxLobbyName() {
       return boxLobbyName;
    }
 
    @ApiModelProperty(
        value = "Optional name for the place of the post box",
        example = "Batman Hill",
        required = false
    )
    public String getBuildingName() {
       return buildingName;
    }
 
    @ApiModelProperty(
        value = "Number identifying postal area",
        example = "592.0",
        required = false
    )
    public String getPostalNumber() {
       return postalNumber;
    }
 
    @ApiModelProperty(
        value = "[Ref Data: address_postal_types]",
        example = "GPO_BOX",
        required = false
    )
    public String getPostalType() {
       return postalType;
    }
 

}