package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Incident implements Serializable {

    private static final long serialVersionUID = 1L;

    private String incidentId;
    private String incidentCode;
    private List<Exposure> exposures;
    private String lossPartyType;
    private RiskUnit riskUnit;
    private String description;
    private Coverage coverage;
    private String type;

    public String getFinancialLossType() {
        return financialLossType;
    }

    public String getType() { return type;    }

    public void setType(String type) { this.type = type;    }

    public void setFinancialLossType(String financialLossType) {
        this.financialLossType = financialLossType;
    }

    private String  financialLossType;

    public List<LossEstimateItem> getLossItems() {
        return lossItems;
    }

    public void setLossItems(List<LossEstimateItem> lossItems) {
        this.lossItems = lossItems;
    }

    private List<LossEstimateItem> lossItems;
    private DateTimeRange dateUnoccupied;
    private Integer numberOfOccupants;
    private String occupancyType;
    private String occupancyUsage;
    private List<VariableData> hazardousWaste;
    private String hazardousWasteInvolved;

    public String getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(String incidentId) {
        this.incidentId = incidentId;
    }

    public String getIncidentCode() {
        return incidentCode;
    }

    public void setIncidentCode(String incidentCode) {
        this.incidentCode = incidentCode;
    }

    public List<Exposure> getExposures() {
        return exposures;
    }

    public void setExposures(List<Exposure> exposures) {
        this.exposures = exposures;
    }

    public String getLossPartyType() {
        return lossPartyType;
    }

    public void setLossPartyType(String lossPartyType) {
        this.lossPartyType = lossPartyType;
    }

    public RiskUnit getRiskUnit() {
        return riskUnit;
    }

    public void setRiskUnit(RiskUnit riskUnit) {
        this.riskUnit = riskUnit;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public DateTimeRange getDateUnoccupied() {
        return dateUnoccupied;
    }

    public void setDateUnoccupied(DateTimeRange dateUnoccupied) {
        this.dateUnoccupied = dateUnoccupied;
    }

    public Integer getNumberOfOccupants() {
        return numberOfOccupants;
    }

    public void setNumberOfOccupants(Integer numberOfOccupants) {
        this.numberOfOccupants = numberOfOccupants;
    }

    public String getOccupancyType() {
        return occupancyType;
    }

    public void setOccupancyType(String occupancyType) {
        this.occupancyType = occupancyType;
    }

    public String getOccupancyUsage() {
        return occupancyUsage;
    }

    public void setOccupancyUsage(String occupancyUsage) {
        this.occupancyUsage = occupancyUsage;
    }

    public List<VariableData> getHazardousWaste() {
        return hazardousWaste;
    }

    public void setHazardousWaste(List<VariableData> hazardousWaste) {
        this.hazardousWaste = hazardousWaste;
    }

    public String getHazardousWasteInvolved() {
        return hazardousWasteInvolved;
    }

    public void setHazardousWasteInvolved(String hazardousWasteInvolved) {
        this.hazardousWasteInvolved = hazardousWasteInvolved;
    }

    public Coverage getCoverage() {
        return coverage;
    }

    public void setCoverage(Coverage coverage) {
        this.coverage = coverage;
    }

}
