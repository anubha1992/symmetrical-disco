package au.com.iag.execution.common.model.claims.motor;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@EqualsAndHashCode(callSuper=false)
@Data
public class Driver extends Person implements Serializable {
    private static final long serialVersionUID = 3658195783264623709L;

    private String licenseNumber;
    private String licenseType;
    private String licensedMoreThanTwoYears;

    private Boolean existingDrivingConviction;
    private Boolean alcoholOrDrugsUsed;
    private Boolean policeSampleRequired;
}
