package au.com.iag.execution.claimdetailsapi;

import au.com.iag.execution.claimdetailsapi.builders.*;
import au.com.iag.execution.claimdetailsapi.configuration.*;
import au.com.iag.execution.claimdetailsapi.model.*;
import au.com.iag.execution.claimdetailsapi.service.*;
import au.com.iag.execution.claimdetailsapi.verifiers.*;
import au.com.iag.execution.common.service.claims.*;
import au.com.iag.glados.common.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.*;
import org.springframework.test.context.junit.jupiter.*;
import static org.apache.http.HttpStatus.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.*;
import static au.com.iag.core.model.security.BaseSecurityConstants.SYSTEM_SECURITY_TOKEN_MISSING;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.core.model.security.BaseSecurityConstants.X_IAG_CONSUMER_SYSTEM;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.common.constants.ApiConstants.INVALID_SYSTEM_TOKEN;
import static au.com.iag.execution.common.constants.ApiConstants.SYSTEM_SECURITY_VALIDATION_FAILURE;
import java.util.*;

@SpringBootTest()
@ExtendWith({ SpringExtension.class, GladosRunnerExtension.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = { ClaimDetailsConfiguration.class})
@Tags({@Tag("RecoveryJourney"), @Tag("ViewLossItems"), @Tag("ClaimDetails")})
public class ViewLossItemsTest {

    @Autowired
    ClaimDetailsRequestBuilder claimDetailsRequestBuilder;

    @Value("${test.api.source.system.brand}")
    public String brand;

    @Value("${test.api.product.code}")
    public String productCode;

    @Autowired
    ClaimsDbService claimsDbService;

    @Autowired
    ClaimDetailService claimDetailService;

    @Autowired
    ClaimDetailsVerifier claimDetailsVerifier;

    static List<Map<String, Object>> claimIdDetails;
    private ClaimDetailsArtifact claimDetailsArtifact;
    Map<String, Object> claimData;
    String claimId;

    @BeforeAll
    public void setUpOnce() throws Exception {
        claimIdDetails = claimsDbService.getClaimsHavingLossItems(productCode);
    }

    @BeforeEach
    public void setup() throws Exception {

        claimData = claimIdDetails.get(new Random().nextInt(claimIdDetails.size()));
        claimId = claimData.get(DB_CC_CLAIMNUMBER).toString();
        claimDetailsArtifact = claimDetailsRequestBuilder.setUpClaimDetails();
        setClaimDetailsArtifact(claimDetailsArtifact);
    }

    @Tags({@Tag("health"), @Tag("healthClaimDetails")})
    @Test
    public void viewLossItems() {

        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_OK);
        claimDetailsVerifier.verifyViewLoss(response, claimId);
    }

    @Test
    public void ViewLossItemsWithInvalidClaimId() {
        claimId = "COMO99900000";
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_NOT_FOUND);
        String errorMessage = "Could not find Claim 'COMO99900000'";
        claimDetailsVerifier.verifyErrorResponse(response, errorMessage);
    }

    @Test
    public void inValidSecuritySystemViewLossItems() {
        Map<String, Object> requestHeaders = getClaimDetailsArtifact().getHeaders();
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_VALIDATION_FAILURE);
    }

    @Test
    public void noSecurityConsumerSystemViewLossItems() {
        Map<String, Object> requestHeaders = getClaimDetailsArtifact().getHeaders();
        requestHeaders.remove(X_IAG_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_SYSTEM);
    }

    @Test
    public void noSecurityTokenViewLossItems() {
        Map<String, Object> requestHeaders = getClaimDetailsArtifact().getHeaders();
        requestHeaders.remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, SYSTEM_SECURITY_TOKEN_MISSING);
    }

    @Test
    public void inValidSecurityTokenViewLossItems() {
        Map<String, Object> requestHeaders = getClaimDetailsArtifact().getHeaders();
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, "invalid");
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_SYSTEM_TOKEN);
    }

    @Test
    public void validSecurtytokenDiffClaimViewLossItems() {
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetails(claimDetailsArtifact, createRequestToViewLossItems("COL300000001"), SC_UNAUTHORIZED);
        claimDetailsVerifier.verifyErrorResponse(response, INVALID_USER);
    }

    @Test
    public void viewLossItemsExternal() {
        claimDetailsArtifact = claimDetailsRequestBuilder.buildClaimDetailsExternal(claimDetailsArtifact);
        claimDetailsArtifact = claimDetailsRequestBuilder.setUserSecurityToken(claimDetailsArtifact, claimId);
        Response response = claimDetailService.executeClaimDetailsExternal(claimDetailsArtifact, createRequestToViewLossItems(claimId), SC_OK);
        claimDetailsVerifier.verifyViewLoss(response, claimId);
    }

    private String createRequestToViewLossItems(String claimId) {
        StringBuffer url = new StringBuffer();
        url.append("/"+ claimId+"/loss-items");
        return url.toString();
    }

    public ClaimDetailsArtifact getClaimDetailsArtifact() {
        return claimDetailsArtifact;
    }

    public void setClaimDetailsArtifact(ClaimDetailsArtifact claimDetailsArtifact) {
        this.claimDetailsArtifact = claimDetailsArtifact;
    }
}
