package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PayPalDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("receipt_number")
    private String receiptNumber ;

  
    @ApiModelProperty(
        value = "Pay pal receipt number",
        required = false
    )
    public String getReceiptNumber() {
       return receiptNumber;
    }
 

}