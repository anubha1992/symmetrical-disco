package au.com.iag.execution.common.service.lodgeclaims;

import au.com.iag.execution.common.model.claims.property.*;
import au.com.iag.execution.common.model.huon.util.*;
import au.com.iag.execution.common.service.crods.*;
import au.com.iag.execution.common.service.huon.*;
import au.com.iag.execution.common.service.wimp.*;
import au.com.iag.glados.common.*;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static org.apache.http.HttpStatus.*;
import static org.junit.Assert.*;
import static au.com.iag.execution.common.constants.ApiConstants.*;
import static au.com.iag.execution.common.constants.WimpConstants.*;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_OPERATION;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_USER_PROFILE;
import static au.com.iag.glados.model.constants.GladosConstants.*;
import java.text.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

@Service
public class LodgePropertyClaimService {
    @Autowired
    private JsonMapperService jsonMapperService;
    @Autowired
    private ResourceReaderService resourceReaderService;
    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;
    @Autowired
    WimpDbService wimpDbService;
    @Autowired
    CrodsDbService crodsDbService;
    @Autowired
    private SecurityService securityService;

    @Autowired
    SearchHUONPolicies searchHUONPolicies;

    @Value("${test.api.source.system}")
    private String apiSourceSystem;
    @Value("${test.api.product.code}")
    private String productCode;
    @Value("${test.api.source.system.brand}")
    private String brand;
    @Value("${test.security.consumer}")
    private String consumerSystem;
    @Value("${test.security.provider}")
    private String providerSystem;

    @Value("${test.api.retrieveclaimpolicy.route}")
    private String retriveClaimPolicyPath;
    @Value("${test.api.policysearchsummary.route}")
    private String policySearchSummaryDistinctPath;

    @Value("${test.api.claimPolicyRetrieveService.authorization}")
    public String authorizationDetails;
    @Value("${test.api.lodgepropertyclaim.route}")
    private String lodgePropertyClaimPath;

    @Value("${env.name.huon}")
    public String envNameHUON;

    private String lodgePropertyClaimsRequestPath = "requests/property-claim-lodgement-api/";

    public Claim buildClaimDetails(Claim claim) throws Exception {
        return buildPropertyPolicy(claim);
    }

    public Response lodgeClaim(int expectStatusCode) throws Exception {
        String fileName = "lodgePropertyClaim.json";
        if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI")) { //This is for NZ State lodgement in test2 environment
            fileName = "lodgeNZSTATEPropertyClaim.json";
        }
        Claim claim = jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource(lodgePropertyClaimsRequestPath + fileName), Claim.class);

        claim = buildPropertyPolicy(claim);

        return executeClaimLodgement(claim, expectStatusCode);
    }

    private Claim buildPropertyPolicy(Claim claim) throws Exception{
        Policy huonPolicy = null;
        String policyIdentifier= "";
        String inceptionDate = "";
        String expiryDate = "";

        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            if (brand.equalsIgnoreCase("NZ STATE")) {
                return setPropertyPolicyFromCrods(claim);
            } else {
                huonPolicy = searchHUONPolicies.findHuonPolicyDetails(huonPolicy, envNameHUON, productCode);
                policyIdentifier = huonPolicy.getPolicyNumber();
                inceptionDate = searchHUONPolicies.getEffectiveDateForHUONPolicy(huonPolicy);
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
                expiryDate = LocalDate.parse(inceptionDate, dtf).plusYears(1).toString();
            }
        } else if (apiSourceSystem.equalsIgnoreCase("GENNETICA")) {
            List<Map<String, Object>> policies = wimpDbService.getCurrentPoliciesForSourceSystemAndProduct(apiSourceSystem, productCode);
            Map<String, Object> policy = policies.get(new Random().nextInt(policies.size()));
            policyIdentifier = policy.get(DB_POLICY_NUMBER).toString();
            inceptionDate = policy.get(DB_POLICY_INCEPTION).toString();
            expiryDate = policy.get(DB_POLICY_EXPIRY).toString();
        } else {
            policyIdentifier = "C0010171627";
            inceptionDate = "2019-05-01";
            expiryDate = "2020-05-01";
        }
        System.out.println("POLICY NUMBER ****** " + policyIdentifier);
        String dateOfLoss = getDateOfLoss(inceptionDate, expiryDate);

        claim.setPolicyIdentifier(policyIdentifier);
        claim.setDateOfLoss(OffsetDateTime.parse(dateOfLoss));

        try {
            Map<String, Object> riskAddressDB = getRiskAddress(dateOfLoss, policyIdentifier);
            claim.getIncidents().get(0).getRiskUnit().getRiskAddress().setAddressLineOne(riskAddressDB.get(DB_STREET_NAME_LINE1).toString());
            claim.getIncidents().get(0).getRiskUnit().getRiskAddress().setSuburb(riskAddressDB.get(DB_SUBURB).toString());
            claim.getIncidents().get(0).getRiskUnit().getRiskAddress().setPostcode(riskAddressDB.get(DB_POST_CODE).toString());
            // claim.getIncidents().get(0).getRiskUnit().getRiskAddress().setState(riskAddressDB.get(DB_STATE).toString());
            if (apiSourceSystem.equalsIgnoreCase("HUON")) {
                claim.getIncidents().get(0).getRiskUnit().getRiskAddress().setIdentifier(riskAddressDB.get(DB_IDENTIFIER).toString());
                claim.getIncidents().get(0).getExposures().get(0).getCoverage().setPolicyCoverageCode("CONTENTS");
            } else {
                claim.getIncidents().get(0).getExposures().get(0).getCoverage().setPolicyCoverageCode("CONTENT");
            }
        }
        catch (Exception e){
        }

        if (isNzBrand()){
            claim.getReportingChannel().setSourceReportedDate(OffsetDateTime.parse(dateOfLoss));
        }

        return claim;
    }

    private Response executeClaimLodgement(Claim claim, int expectStatusCode){

        Response response = gladosEnrichmentService.sendPostRequest(
                getHeaders(),
                lodgePropertyClaimPath,
                claim,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Claim setPropertyPolicyFromCrods(Claim claim) throws Exception {

        String crodsBrand = "STATE";
        List<String> riskTypes = Arrays.asList("HPAC", "CONT");
        if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("NZSTATE") || brand.equalsIgnoreCase("NZSTATE")) {
            Map<String, Object> policyIdDetails = crodsDbService.getPoliciesByBrand(crodsBrand, riskTypes, productCode, apiSourceSystem);
            claim.setPolicyIdentifier(policyIdDetails.get(DB_CRODS_POLICYNUMBER).toString());
            String inceptionDate = policyIdDetails.get(DB_CRODS_POLICY_INCEPTION).toString();
            String expiryDate = policyIdDetails.get(DB_CORDS_POLICY_EXPIRY).toString();

            String dateOfLoss = getDateOfLoss(inceptionDate, expiryDate);
            claim.setDateOfLoss(OffsetDateTime.parse(dateOfLoss));
            claim.getReportingChannel().setSourceReportedDate(OffsetDateTime.parse(dateOfLoss));
        }
        return claim;
    }

    private String getDateOfLoss(String inceptionDate, String expiryDate) throws Exception {
        String dateOfLoss = null;
        System.out.println("Inception Date is ****** " + inceptionDate);
        System.out.println("Expiry Date is ****** " + expiryDate);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cInceptionDate = Calendar.getInstance();
        cInceptionDate.setTime(sdf.parse(inceptionDate));
        Date currentDate = new Date();

        //We cant have claims raised on the same date for a given policy, as CC treats it as duplicate claim and lodgement fails.
        //hence a logic is added below to add radomise dates [Inception date + random days = date of loss]

        //Also need to incorporate below rules when deciding date of loss
        //1. Date of loss should be greater than inception date but less than expiry date of policy
        //2. If policy expiry is a future date, then date of loss should be between inception date and today's date

        long term = (sdf.parse(expiryDate).getTime() - currentDate.getTime()) / ((1000 * 60 * 60 * 24));
        if (term > 0) { //Expiry date > current date
            long n = (currentDate.getTime() - sdf.parse(inceptionDate).getTime()) / ((1000 * 60 * 60 * 24));
            System.out.println("Difference in date from inception to current day is ****** " + n);
            cInceptionDate.add(Calendar.DATE, getRandom((int) (long) n));
            inceptionDate = sdf.format(cInceptionDate.getTime());
            dateOfLoss = inceptionDate + "T00:03:00+00:00";
            System.out.println("Date of loss is ****** " + dateOfLoss);
        } else { //Expiry date < current date
            long n = (sdf.parse(expiryDate).getTime() - sdf.parse(inceptionDate).getTime()) / ((1000 * 60 * 60 * 24));
            System.out.println("Difference in date from inception to expiry day is ****** " + n);
            cInceptionDate.add(Calendar.DATE, getRandom((int) (long) n));
            inceptionDate = sdf.format(cInceptionDate.getTime());
            dateOfLoss = inceptionDate + "T00:03:00+00:00";
            System.out.println("Date of loss is ****** " + dateOfLoss);
        }
        return dateOfLoss;
    }

    private int getRandom(int limit) {
        Random rand = new Random();
        return rand.nextInt(limit) + 1;
    }

    private Map<String, Object>  getRiskAddress(String dateOfLoss, String policyIdentifier) throws Exception{
        Map<String, Object> riskAddressDB = new HashMap<>();
        if (apiSourceSystem.equalsIgnoreCase("HUON") || apiSourceSystem.equalsIgnoreCase("EXIGEN") ) {
            riskAddressDB = new HashMap<>();
            //Calling DistictSearch api to get risk address.
            //BUT CC needs address in old legacy format for HUON brands. But claim SearchIntermediaryDocuments response is single line address which will not work for lodgement in all cases
            Response riskAddress = executeDistinctTermSearchService(dateOfLoss,policyIdentifier, SC_OK);
            riskAddressDB.put(DB_STREET_NAME_LINE1,riskAddress.path("policy_summaries[0].risk_summary[0].address_summary.single_line_address").toString());
            riskAddressDB.put(DB_SUBURB,riskAddress.path("policy_summaries[0].risk_summary[0].address_summary.suburb").toString());
            riskAddressDB.put(DB_POST_CODE,riskAddress.path("policy_summaries[0].risk_summary[0].address_summary.post_code").toString());
            //riskAddressDB.put(DB_STATE,riskAddress.path("policy_summaries[0].risk_summary[0].address_summary.state").toString());

            //JAPI-428 A new field will be added to propertyClaimLodgement to pass in address identifier - which effectively solves above issue
            Response policyRetrieve = executeRetrieveClaimPolicyDetails(policyIdentifier,dateOfLoss, SC_OK);
            riskAddressDB.put(DB_IDENTIFIER,policyRetrieve.path("product_offering.risk[0].coverable.location.location_address.identifier").toString());
        }
        else {
            List<Map<String, Object>> policyRiskAddress = wimpDbService.getPolicyRiskAddress(policyIdentifier);
            riskAddressDB = policyRiskAddress.get(0);
        }
        return riskAddressDB;
    }

    private Response executeDistinctTermSearchService(String dateOfLoss, String policyNumber, int expectStatusCode){
        DistinctTermRequest policySearchRequest = new DistinctTermRequest();
        policySearchRequest.setAsAtDate(dateOfLoss.substring(0,19));
        policySearchRequest.setPolicyNumber(policyNumber);
        Response response = gladosEnrichmentService.sendPostRequest(
                getPolicySearchJsonHeaders(),
                policySearchSummaryDistinctPath,
                policySearchRequest,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);

    }

    private Response executeRetrieveClaimPolicyDetails(String policyNumber, String dateOfLoss, int expectStatusCode){

        String queryString = "policy_id=" + policyNumber + "&as_at_date=" + dateOfLoss;
        Response response = gladosEnrichmentService.sendGetRequest(
                getClaimsPolicyRetrieveHeaders(),
                retriveClaimPolicyPath,
                queryString,
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Map<String, Object> getHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        requestHeaders.put("Accept", APPLICATION_JSON);
        requestHeaders.put(X_IAG_CONSUMER_SYSTEM, BAPI);
        requestHeaders.put(X_IAG_CHANNEL,"Digital");
        requestHeaders.put(X_IAG_BRAND,brand);
        requestHeaders.put(SOURCE_ID, "DC");
        if (brand.equalsIgnoreCase("NRMA") || brand.equalsIgnoreCase("SGIO") || brand.equalsIgnoreCase("SGIC") || brand.equalsIgnoreCase("RACV")) {
            requestHeaders.put(X_IAG_DISTRIBUTOR, brand);
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_USER, "WEBNIIP");
            requestHeaders.put(X_IAG_USER_PROFILE, "IAGSM");
            requestHeaders.put(X_IAG_USER_ALIASES, "HUON=PRJUSER");
            requestHeaders.put(X_IAG_OPERATION,"RetrievePolicy");
        }else if (brand.equalsIgnoreCase("NZ STATE") || brand.equalsIgnoreCase("AMI")) {
            requestHeaders.put(X_IAG_USER, "WEBZIIP");
            requestHeaders.put(X_IAG_USER_PROFILE, "IAGNZ");
            requestHeaders.put(X_IAG_AGENT_ID, "INT");
            requestHeaders.put(X_IAG_DISTRIBUTOR, "NRMA");
        }
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));

        return requestHeaders;

    }

    public Map<String, Object> getPolicySearchJsonHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put(CHARSET, FORMAT_UTF);
        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            requestHeaders = getBasicHuonHeaders(requestHeaders, "NRMA");
            requestHeaders.put("X-Iag-Operation", "searchPolicy");
            if (brand.equalsIgnoreCase("NZ STATE")) {
                requestHeaders = getBasicHuonNzStateHeaders(requestHeaders, brand.toUpperCase());
                requestHeaders.put("X-Iag-Operation", "Policy Search NZ");
            } else {

                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
            }
        } else {

            if (apiSourceSystem.equalsIgnoreCase("EXIGEN")) {
                requestHeaders.put("X-Iag-Brand", brand);
            }
        }
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        requestHeaders.put(CONTENT_TYPE, APPLICATION_JSON);
        return requestHeaders;
    }

    private Map<String, Object> getClaimsPolicyRetrieveHeaders() {
        Map<String, Object> requestHeaders = new HashMap<>();
        requestHeaders.put("Accept", APPLICATION_JSON);
        requestHeaders.put(AUTHORIZATION, authorizationDetails);
        requestHeaders.put("policy_system", apiSourceSystem.toLowerCase());
        if (apiSourceSystem.equalsIgnoreCase("HUON")) {
            requestHeaders = getBasicHuonHeaders(requestHeaders, brand.toUpperCase());
            if (productCode.equalsIgnoreCase("CTP")) {
                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
                requestHeaders.put("X-Iag-Operation", "retrieveCTPPolicy");

            } else {
                requestHeaders = getAdditionalHuonHeaders(requestHeaders);
                requestHeaders.put("X-Iag-Operation", "retrievePolicy");
                requestHeaders.put("policy_system", "huon_" + productCode.toLowerCase());
                if (brand.equalsIgnoreCase("NZ STATE")) {
                    requestHeaders = getBasicHuonNzStateHeaders(requestHeaders, brand.toUpperCase());
                    requestHeaders.put("X-Iag-Operation", "retrievePolicy");
                    requestHeaders.put("policy_system", "huon_" + productCode.toLowerCase());
                }
            }
        }
        requestHeaders.put(X_IAG_AUTH_CONSUMER_SYSTEM, securityService.getSystemSecurityToken(consumerSystem, providerSystem));
        return requestHeaders;
    }

    private Map<String, Object> getBasicHuonNzStateHeaders(Map<String, Object> requestHeaders, String brand) {
        requestHeaders = getBasicHuonHeaders(requestHeaders, brand.toUpperCase());
        requestHeaders.put("X-Iag-User", "WEBZIIP");
        requestHeaders.put("X-Iag-Consumer-System", "BAPI");
        requestHeaders.put("X-Iag-User-Profile", "IAGNZ");
        requestHeaders.put("X-Iag-User-Aliases", "HUON=WEBZIIP");
        return requestHeaders;
    }

    private Map<String, Object> getBasicHuonHeaders(Map<String, Object> requestHeaders, String brand) {
        requestHeaders.put("Content-Type", "text/xml");
        requestHeaders.put("X-Iag-Brand", brand);
        requestHeaders.put("X-Iag-Agent-Id", "INT");
        requestHeaders.put("X-Iag-Distributor", brand);
        requestHeaders.put("X-Iag-Channel", "Digital");
        return requestHeaders;
    }

    private Map<String, Object> getAdditionalHuonHeaders(Map<String, Object> requestHeaders) {
        requestHeaders.put("X-Iag-User", "WEBNIIP");
        requestHeaders.put("X-Iag-Consumer-System", "BAPI");
        requestHeaders.put("X-Iag-User-Profile", "IAGSM");
        requestHeaders.put("X-Iag-User-Aliases", "MRJUSER");
        return requestHeaders;
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }

    private boolean isNzBrand() {
        return brand.equalsIgnoreCase("NZ STATE")
                || brand.equalsIgnoreCase("AMI")
                || brand.equalsIgnoreCase("NZSTATE")
                || brand.equalsIgnoreCase("STATE");
    }

}
