package au.com.iag.execution.common.builders.notifyapi;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import org.springframework.stereotype.Component;

import au.com.iag.execution.partyapi.model.business.Individual;
import au.com.iag.execution.partyapi.model.business.IndividualNameDetails;
import au.com.iag.execution.partyapi.model.business.IndividualNames;
import au.com.iag.execution.partyapi.model.business.InternationalAddress;
import au.com.iag.execution.partyapi.model.business.MailingAddress;
import au.com.iag.execution.partyapi.model.business.Organisation;
import au.com.iag.execution.partyapi.model.business.OrganisationName;
import au.com.iag.execution.partyapi.model.business.PostalAddress;
import au.com.iag.execution.partyapi.model.business.PreferenceDetails;
import au.com.iag.execution.partyapi.model.business.RegisteredNumber;
import au.com.iag.execution.partyapi.model.business.StaffDetail;
import au.com.iag.execution.partyapi.model.business.StreetAddress;
import au.com.iag.glados.service.RandomContentService;
import com.github.javafaker.Faker;

@Component
public class PartyBuilderForNotify {
    Faker faker = new Faker();
//    LocalDate localDateToday = LocalDate.now();
    Random rand = new Random();
    RandomContentService randomContentService = new RandomContentService();
//    EmailBuilder emailBuilder = new EmailBuilder();
//    PhoneDetailsBuilder phoneDetailsBuilder = new PhoneDetailsBuilder();



    public Individual buildFullPartyDetails(Individual party) throws IOException {
        party.setDateOfBirth(buildRandomDOB());
        party.setGender(getRandomGender());
        party.setNames(buildFullIndividualNameDetails(party.getNames()));
        party.setStaff(buildStaffDetails());
        party.setAddresses(Collections.singletonList(buildSingleAddressByCountryAndType("AUS", "STREET")));
        party.setAssessments(null);
//        party.setEmailContacts(emailBuilder.buildSingleEmailContact());
//        party.setPhoneContacts(phoneDetailsBuilder.buildSinglePhoneDetails());
        party.setPreferences(buildPreferenceDetails(party.getPreferences()));
        party.setRegisteredNumbers(buildRegisteredNumbers(Arrays.asList("ABN")));
        return party;
    }

    public Organisation buildFullPartyDetails(Organisation party) throws IOException {
        party.setType(getRandomOrgType());
        party.setNames(buildOrganisationNameDetails(Arrays.asList("REGISTERED", "TRADING")));
        party.setAddresses(Collections.singletonList(buildSingleAddressByCountryAndType("AUS", "STREET")));
        party.setAssessments(null);
//        party.setEmailContacts(emailBuilder.buildSingleEmailContact());
//        party.setPhoneContacts(phoneDetailsBuilder.buildSinglePhoneDetails());
        party.setPreferences(buildPreferenceDetails(party.getPreferences()));
        party.setRegisteredNumbers(buildRegisteredNumbers(Arrays.asList("ABN","ACN")));
        return party;
    }


// Individual Specific
// DOB

    public IndividualNames buildFullIndividualNameDetails(IndividualNames individualNames) {
        IndividualNameDetails individualNameDetails = individualNames.getDetails().get(0);

        individualNameDetails.setFirstName(faker.name().firstName());
        individualNameDetails.setMiddleName(faker.name().nameWithMiddle().split(" ")[1]);
        individualNameDetails.setLastName(faker.name().lastName());
        individualNameDetails.setTitle("DR");
        individualNameDetails.setType("LEGAL");

        individualNames.getDetails().replaceAll(nameDetails -> individualNameDetails);
        individualNames.setPreferredName(individualNameDetails.getFirstName());

        return individualNames;
    }
    public LocalDate buildRandomDOB(){
        return faker.date().birthday(21, 99)
                .toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    public String getRandomGender() {
        return getRandomStringValueFromList(Arrays.asList("MALE", "FEMALE"));
    }

    public StaffDetail buildStaffDetails() {
        StaffDetail staffDetail = new StaffDetail();
        staffDetail.setType(getRandomStringValueFromList(Arrays.asList("HSBC_STAFF", "NRMA_STAFF", "IAG_STAFF_AU","IAG_STAFF_OVER_25_YEARS")));
        staffDetail.setNumber(randomContentService.getRandomNumber(8));
        return staffDetail;
    }

//    Organisation specific

    public String getRandomOrgType() {
        return getRandomStringValueFromList(Arrays.asList("LIMITED", "PARTNERSHIP", "PTY_LTD", "SOLE_TRADER"));
    }

    public List<OrganisationName> buildOrganisationNameDetails(List<String> nameTypesRequired){
        List<OrganisationName> organisationNames = new ArrayList<>();
        for (String type: nameTypesRequired) {
            OrganisationName organisationNameDetails = new OrganisationName();
            organisationNameDetails.setType(type.toUpperCase());
            organisationNameDetails.setName(faker.company().name());
            organisationNames.add(organisationNameDetails);
        }
        return organisationNames;
    }


    // General

    /// Preferences
    public PreferenceDetails buildPreferenceDetails(PreferenceDetails preferenceDetails) {
        List<Boolean> booleanValues = Arrays.asList(true, false);
        preferenceDetails.setMarketingConsent(booleanValues.get(rand.nextInt(booleanValues.size())));
        return preferenceDetails;
    }

    public MailingAddress buildSingleAddressByCountryAndType(String countryCode, String addressType) {
        MailingAddress requestAddress = new MailingAddress();
        requestAddress.setCountry(countryCode);
        requestAddress.setAttention(faker.funnyName().name());
        requestAddress.setType("MAIL");

        switch (countryCode) {
            case "AUS":
                Faker fakerAUS = new Faker(new Locale.Builder().setLanguageTag("en-AU").build());
                requestAddress.setState(fakerAUS.address().stateAbbr());
                requestAddress.setPostcode(fakerAUS.address().zipCode());
                requestAddress.setLocalityName(fakerAUS.address().cityName());
                requestAddress.setTownCityName(null);
                fillAddressBasedOnType(fakerAUS, requestAddress, addressType);
                break;
            case "NZL":
                Faker fakerNZL = new Faker(new Locale.Builder().setLanguageTag("en-NZ").build());
                requestAddress.setState(fakerNZL.address().stateAbbr());
                requestAddress.setPostcode(fakerNZL.address().zipCode());
                requestAddress.setTownCityName(fakerNZL.address().cityName());
                requestAddress.setLocalityName(null);
                fillAddressBasedOnType(fakerNZL, requestAddress, addressType);
                break;
            default:
                Faker fakerIntl = new Faker(new Locale.Builder().setLanguageTag("en-GB").build());
                requestAddress.setState(fakerIntl.address().stateAbbr());
                requestAddress.setPostcode(fakerIntl.address().zipCode());
                requestAddress.setLocalityName(fakerIntl.address().cityName());
                requestAddress.setTownCityName(null);
                fillAddressBasedOnType(fakerIntl, requestAddress, addressType);
                break;
        }
        return requestAddress;
    };

    protected MailingAddress fillAddressBasedOnType(Faker fakerRegion, MailingAddress requestAddress, String addressType) {
        int randomNumber = randomContentService.getRandomNumber(2, 20);
        switch (addressType){
            case ("STREET"):
                StreetAddress streetAddress = new StreetAddress();
                if(randomNumber % 2 == 0) {
                    streetAddress.setFlatUnitNumber(String.valueOf(randomNumber));
                    streetAddress.setFloorLevelNumber(String.valueOf(randomNumber-1));
                    streetAddress.setLotNumber(String.valueOf(randomNumber));
                }
                streetAddress.setHouseNumber(fakerRegion.address().streetAddressNumber());
                streetAddress.setStreetName(fakerRegion.address().streetName());
                streetAddress.setStreetType(fakerRegion.address().streetSuffix());
                requestAddress.setStreetAddress(streetAddress);
                break;
            case ("POSTAL"):
                PostalAddress postalAddress = new PostalAddress();
                postalAddress.setBoxLobbyName(fakerRegion.gameOfThrones().character());
                postalAddress.setBuildingName(fakerRegion.funnyName().name());
                postalAddress.setPostalNumber(String.valueOf(randomNumber));
                requestAddress.setPostalAddress(postalAddress);
                break;
            case ("INTERNATIONAL"):
                InternationalAddress internationalAddress = new InternationalAddress();
                internationalAddress.setAddressLine1(fakerRegion.address().fullAddress());
                internationalAddress.setAddressLine2(fakerRegion.address().secondaryAddress());
                internationalAddress.setCountyProvinceState(fakerRegion.address().cityName());
                requestAddress.setInternationalAddress(internationalAddress);
                break;
            default:
                break;
        }
        return requestAddress;
    }
    public List<RegisteredNumber> buildRegisteredNumbers(List<String> registeredTypesRequired){
        List<RegisteredNumber> registeredNumbers = new ArrayList<>();
        for (String type: registeredTypesRequired) {
            RegisteredNumber registeredNumber = new RegisteredNumber();
            registeredNumber.setType(type);
            registeredNumber.setNumber("ABN".equalsIgnoreCase(type)? getRandomAbn() : getRandomAcn());
            registeredNumbers.add(registeredNumber);
        }
        return registeredNumbers;
    }



    // Helper
    public String getRandomStringValueFromList(List<String> valuesList) {
        return valuesList.get(rand.nextInt(valuesList.size()));
    }

    protected String getRandomAbn(){
        Random rand = new Random();
        List<String> randomAbns = Arrays.asList("76861743447", "99149618782", "94250884986","43145118743", "74149264095");
        String randomAbn = randomAbns.get(rand.nextInt(randomAbns.size()));
        return randomAbn;
    }

    protected String getRandomAcn(){
        Random rand = new Random();
        List<String> randomAcns = Arrays.asList("000250000", "000500005", "001749999","002249998", "003499992");
        String randomAcn = randomAcns.get(rand.nextInt(randomAcns.size()));
        return randomAcn;
    }


}
