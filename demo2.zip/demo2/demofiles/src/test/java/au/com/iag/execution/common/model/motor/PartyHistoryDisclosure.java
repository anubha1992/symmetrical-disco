package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PartyHistoryDisclosure implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("incident_or_claim")
    private Boolean incidentOrClaim ;
    @JsonProperty("incident_or_claim_effective_from")
    private String incidentOrClaimEffectiveFrom ;
    @JsonProperty("incident_or_claim_number_of_years")
    private Integer incidentOrClaimNumberOfYears ;
    @JsonProperty("incident_or_claims")
    private java.util.List<InsuranceHistoryDisclosure> incidentOrClaims = new java.util.ArrayList<InsuranceHistoryDisclosure>();
    @JsonProperty("insurance_declined_cancelled_refused")
    private Boolean insuranceDeclinedCancelledRefused ;
    @JsonProperty("insurance_declined_cancelled_refused_effective_from")
    private String insuranceDeclinedCancelledRefusedEffectiveFrom ;
    @JsonProperty("insurance_declined_cancelled_refused_number_of_years")
    private Integer insuranceDeclinedCancelledRefusedNumberOfYears ;
    @JsonProperty("insurance_declined_cancelled_refused_reason")
    private String insuranceDeclinedCancelledRefusedReason ;
    @JsonProperty("insureds_convicted_of_fraud")
    private Boolean insuredsConvictedOfFraud ;
    @JsonProperty("insureds_convicted_of_fraud_effective_from")
    private String insuredsConvictedOfFraudEffectiveFrom ;
    @JsonProperty("insureds_convicted_of_fraud_number_of_years")
    private Integer insuredsConvictedOfFraudNumberOfYears ;

  
    @ApiModelProperty(
        value = "Indicates if there is any prior incident or claim for parties covered by policy",
        required = false
    )
    public Boolean getIncidentOrClaim() {
       return incidentOrClaim;
    }
 
    @ApiModelProperty(
        value = "The effective date from when the prior incident or claim is for. Format: yyyy-MM",
        example = "2019-06",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getIncidentOrClaimEffectiveFrom() {
       return incidentOrClaimEffectiveFrom;
    }
 
    @ApiModelProperty(
        value = "The number of years the prior incident or claim is for.",
        example = "1",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Integer getIncidentOrClaimNumberOfYears() {
       return incidentOrClaimNumberOfYears;
    }
 
    @ApiModelProperty(
        value = "List of incident or claims details",
        required = false
    )
    public java.util.List<InsuranceHistoryDisclosure> getIncidentOrClaims() {
       return incidentOrClaims;
    }
 
    @ApiModelProperty(
        value = "Indicates if party covered has had insurance declined, cancelled, refused or had special conditions imposed",
        required = false
    )
    public Boolean getInsuranceDeclinedCancelledRefused() {
       return insuranceDeclinedCancelledRefused;
    }
 
    @ApiModelProperty(
        value = "The effective date from when the insurance declined, cancelled, refused or had special conditions imposed is for. Format: yyyy-MM",
        example = "2019-07",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getInsuranceDeclinedCancelledRefusedEffectiveFrom() {
       return insuranceDeclinedCancelledRefusedEffectiveFrom;
    }
 
    @ApiModelProperty(
        value = "The number of years insurance declined, cancelled, refused or had special conditions imposed is for.",
        example = "1",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Integer getInsuranceDeclinedCancelledRefusedNumberOfYears() {
       return insuranceDeclinedCancelledRefusedNumberOfYears;
    }
 
    @ApiModelProperty(
        value = "Reason for insurance declined, cancelled, refused or had special conditions imposed [Ref Data: insurance_declined_reason]",
        required = false
    )
    public String getInsuranceDeclinedCancelledRefusedReason() {
       return insuranceDeclinedCancelledRefusedReason;
    }
 
    @ApiModelProperty(
        value = "Indicator to support insureds convicted of fraud",
        required = false
    )
    public Boolean getInsuredsConvictedOfFraud() {
       return insuredsConvictedOfFraud;
    }
 
    @ApiModelProperty(
        value = "The effective date from when the fraud conviction is for. Format: yyyy-MM",
        example = "2019-07",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public String getInsuredsConvictedOfFraudEffectiveFrom() {
       return insuredsConvictedOfFraudEffectiveFrom;
    }
 
    @ApiModelProperty(
        value = "The number of years fraud conviction is for.",
        example = "1",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Integer getInsuredsConvictedOfFraudNumberOfYears() {
       return insuredsConvictedOfFraudNumberOfYears;
    }
 

}