package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class CollectionBizConstraints implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("max_occurs")
    private Integer maxOccurs ;
    @JsonProperty("min_occurs")
    private Integer minOccurs ;

  
    @ApiModelProperty(
        value = "Optional. The maximum number of occurrences of the section. Default &#x3D; Integer.MAX",
        required = false
    )
    public Integer getMaxOccurs() {
       return maxOccurs;
    }
 
    @ApiModelProperty(
        value = "Optional. The minimum number of occurrences of the section. Default &#x3D; 1.",
        required = false
    )
    public Integer getMinOccurs() {
       return minOccurs;
    }
 

}