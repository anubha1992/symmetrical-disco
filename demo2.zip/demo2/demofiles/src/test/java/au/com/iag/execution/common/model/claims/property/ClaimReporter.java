package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;
import java.time.*;
import java.util.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ClaimReporter extends Person implements Serializable {
    private static final long serialVersionUID = -8574141065008615391L;
    private String dateOfBirthKnown;
    private String relationshipToInsured;
    private Boolean authorisedToLodge;
    private List<OrganisationName> organisationName = new ArrayList<>();

    public List<OrganisationName> getOrganisationName() { return organisationName;  }

    /////
    private String title;
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private String genderCode;

    public void setOrganisationName(List<OrganisationName> organisationName) { this.organisationName = organisationName;    }
    public String getDateOfBirthKnown() {  return dateOfBirthKnown;  }
    public void setDateOfBirthKnown(String dateOfBirthKnown) { this.dateOfBirthKnown = dateOfBirthKnown; }
    public String getRelationshipToInsured() {
        return relationshipToInsured;
    }
    public void setRelationshipToInsured(String relationshipToInsured) {  this.relationshipToInsured = relationshipToInsured; }
    public Boolean getAuthorisedToLodge() {
        return authorisedToLodge;
    }
    public void setAuthorisedToLodge(Boolean authorisedToLodge) {
        this.authorisedToLodge = authorisedToLodge;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGenderCode() {
        return genderCode;
    }

    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }

    /////

    private Boolean policyContact;
    private String partyType;
    private List<Contact> contactDetails = new ArrayList<>();
    private List<String> roles;

    public Boolean isPolicyContact() {
        return policyContact;
    }

    public void setPolicyContact(Boolean policyContact) {
        this.policyContact = policyContact;
    }

    public String getPartyType() {
        return partyType;
    }

    public void setPartyType(String partyType) {
        this.partyType = partyType;
    }

    public List<Contact> getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(List<Contact> contactDetails) {
        this.contactDetails = contactDetails;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }
}
