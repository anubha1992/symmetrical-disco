package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ReferenceDataList implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("dynamic_value_list")
    private String dynamicValueList ;
    @JsonProperty("filters")
    private java.util.List<ReferenceDataFilter> filters = new java.util.ArrayList<ReferenceDataFilter>();
    @JsonProperty("name")
    private String name ;
    @JsonProperty("value_list")
    private java.util.List<ValueObject> valueList = new java.util.ArrayList<ValueObject>();

  
    @ApiModelProperty(
        value = "Name of the dynamic value list to retrieve values from",
        required = false
    )
    public String getDynamicValueList() {
       return dynamicValueList;
    }
 
    @ApiModelProperty(
        value = "Named filter to use to filter values returned from RDM",
        required = false
    )
    public java.util.List<ReferenceDataFilter> getFilters() {
       return filters;
    }
 
    @ApiModelProperty(
        value = "Name of the RDM Entity/List to retrieve values from.",
        required = false
    )
    public String getName() {
       return name;
    }
 
    @ApiModelProperty(
        value = "List of value objects",
        required = false
    )
    public java.util.List<ValueObject> getValueList() {
       return valueList;
    }
 

}