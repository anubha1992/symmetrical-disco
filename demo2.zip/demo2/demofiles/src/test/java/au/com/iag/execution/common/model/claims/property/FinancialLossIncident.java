package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class FinancialLossIncident extends Incident implements Serializable {


    private static final long serialVersionUID = -5207011565998782240L;

    private String financialLossType;

    public String getFinancialLossType() {
        return financialLossType;
    }

    public void setFinancialLossType(String financialLossType) {
        this.financialLossType = financialLossType;
    }

}
