package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class LossEstimateItemFeature implements Serializable {

    private static final long serialVersionUID = 1L;


    @JsonProperty("Identifier that uniquely references the Loss Item’s SubCategory Feature")
    private String featureId;

//    @ApiModelProperty(example = "string", value = "Identifier that uniquely references the Loss Item’s SubCategory Feature", required = true)
//    private String featureId;

    @JsonProperty("Identifier that uniquely references the Loss Item’s SubCategory Feature")
    private String value;


//    @ApiModelProperty(example = "string", value = "Value of the Loss Item Feature", required = true)
//    private String value;

    public String getFeatureId() {
        return featureId;
    }

    public void setFeatureId(String featureId) {
        this.featureId = featureId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
