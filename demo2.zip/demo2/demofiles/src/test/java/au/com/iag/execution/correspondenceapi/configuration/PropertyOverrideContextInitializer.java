package au.com.iag.execution.correspondenceapi.configuration;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;

import static org.springframework.test.context.support.TestPropertySourceUtils.addPropertiesFilesToEnvironment;

public class PropertyOverrideContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        addPropertiesFilesToEnvironment(
            configurableApplicationContext,
            "classpath:config/application-test.properties",
            "classpath:config/correspondence-api/application-test.properties",
            "classpath:config/correspondence-api/${env}/application-test.properties");
    }
}
