package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.glados.service.RandomContentService;
import com.github.javafaker.Faker;
import com.github.javafaker.service.FakeValuesService;
import com.github.javafaker.service.RandomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.DECIMAL_FORMAT;
import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.FAKER_LOCALE_STRING;

@Component
public class MiscDataBuilder {

    @Autowired
    private RandomContentService randomContentService;

    public double getDouble(double origin, double bound){
        double value = ThreadLocalRandom.current().nextDouble(origin, bound);
        return formatDouble(value);
    }

    public double formatDouble(double value) {
        DecimalFormat df = new DecimalFormat(DECIMAL_FORMAT);
        return Double.valueOf(df.format(value));
    }

    public String getPolicyNumber(){
        return "QTE"+randomContentService.getRandomNumber(11);
    }

    public Faker getFakerWithAusLocale(){
        return new Faker(new Locale.Builder().setLanguageTag(FAKER_LOCALE_STRING).build());
    }

    public int getRandomYear(final int minYear, final int maxYear){
        Random random = new Random();
        int minDay = (int) LocalDate.of(minYear, 1, 1).toEpochDay();
        int maxDay = (int) LocalDate.of(maxYear, 1, 1).toEpochDay();
        long randomDay = minDay + random.nextInt(maxDay - minDay);
        return LocalDate.ofEpochDay(randomDay).getYear();
    }

    public String getRandomEmail(){
        FakeValuesService fakeValuesService = new FakeValuesService(new Locale(FAKER_LOCALE_STRING), new RandomService());
        return fakeValuesService.bothify("????##@iag.com.au");
    }

    public int getRandomInt(){
        Random rand = new Random();
        return rand.nextInt((10 - 4) + 1) + 4;
    }

    public String getRandomCollectionName(){
        Faker faker = new Faker();
        int randomInt = new Random().nextInt(10 - 1 + 1) + 1;
        switch (randomInt){
            case 1:
                return "My Beer collection - "+faker.beer().name();
            case 2:
                return "My Chuck Norris collection - "+faker.chuckNorris().fact();
            case 3:
                return "My Book collection - "+faker.book().title();
            case 4:
                return "My Superhero collection - "+faker.superhero().name();
            case 5:
                return "My Harry Potter character collection - "+faker.harryPotter().character();
            case 6:
                return "My Arts collection - "+faker.artist().name();
            case 7:
                return "My Avatar collection - "+faker.avatar().image();
            case 8:
                return "My Model Aircraft collection - "+faker.aviation().aircraft();
            case 9:
                return "My Game of Thrones dragon collection - "+faker.gameOfThrones().dragon();
            case 10:
                return "My Coin collection - "+faker.currency().name();
            default:
                return "Best Items from American Pickers";
        }
    }

    public Map<String, List<String>> getVehicleMakeAndModels(){
        return Map.of("BMW", Arrays.asList("328i", "M3", "M5", "X1", "X3", "X5"),
                "Audi", Arrays.asList("A4", "A5", "S5", "A7", "A8"),
                "Toyota", Arrays.asList("Prius", "Camry", "Corolla"),
                "Chevy", Arrays.asList("Camero", "Silverado", "Malibu"),
                "Ford", Arrays.asList("Mustang", "F150", "Focus", "Fiesta"),
                "Dodge", Arrays.asList("Ram", "Challenger", "Charger", "Durango"),
                "Nissan", Arrays.asList("Rogue", "Juke", "Cube", "Pathfiner", "Versa", "Altima"),
                "Honda", Arrays.asList("Accord", "Civic", "CR-V", "Odyssey")
        );
    }

    public List<String> getListOfVehicleBodyTypes(){
        return Arrays.asList("Cargo Van", "Convertible", "Coupe", "Crew Cab Pickup", "Extended Cab Pickup", "Hatchback", "Minivan", "Passenger Van", "Regular Cab Pickup", "SUV", "Sedan", "Wagon");
    }

    public List<Integer> getListOfEngineCapacities(){
        return Arrays.asList(1000, 1200, 1300, 1500);
    }

    public List<String> getListOfEngineTypes(){
        return Arrays.asList("Petrol", "Diesel", "Ethanol");
    }

    public List<String> getListOfEquipmentLevels(){
        return Arrays.asList("LUXURY", "PREMIUM COMPACT", "COMPACT EXECUTIVE", "EXECUTIVE", "ULTRA LUXURY", "LUXURY SALOON", "BASIC", "STANDARD");
    }
}
