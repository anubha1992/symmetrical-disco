package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class NotificationItem {

    @ApiModelProperty(value = "Audanet quote Id to identify this repair/quote", example = "123")
    private String assessmentReference;
    @ApiModelProperty(value = "Total amount of repair (including gst)")
    private Amount totalAmount;
}
