package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class ComparisonAsset implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("comparisons")
    private java.util.List<Comparison> comparisons = new java.util.ArrayList<Comparison>();

  
    @ApiModelProperty(
        value = "Price comparisons at asset level",
        required = false
    )
    public java.util.List<Comparison> getComparisons() {
       return comparisons;
    }
 

}