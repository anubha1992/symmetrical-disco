package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.PolicyDetails;
import au.com.iag.execution.correspondenceapi.model.PolicySendCorrespondenceArtifact;
import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import au.com.iag.execution.correspondenceapi.service.CorrespondenceService;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;
import static org.apache.http.HttpStatus.SC_OK;

@Component
public class PolicyGenerator {

    @Autowired private CorrespondenceRequestBuilder correspondenceRequestBuilder;
    @Autowired private CorrespondenceService correspondenceService;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private DatesBuilder datesBuilder;

    public PolicyDetails executeHomeBuildingAndContentsMultiAssetNewBusiness() throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualMultiAsset(PRODUCT_HOME_INSURANCE, CORRESPONDENCE_TYPE_NEW_BUSINESS);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }

    public PolicyDetails executeMotorMultiAssetNewBusiness() throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualMultiAsset(PRODUCT_MOTOR_INSURANCE, CORRESPONDENCE_TYPE_NEW_BUSINESS);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }

    public PolicyDetails executeMotorQuotation(String policyNumber) throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualSingleAsset(PRODUCT_MOTOR_INSURANCE, CORRESPONDENCE_TYPE_QUOTATION);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        if (StringUtils.isNotBlank(policyNumber))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails().setPolicyNumber(policyNumber);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }

    public PolicyDetails executeMotorNewBusiness(String policyNumber, String correspondenceChannel, String correspondenceEmail) throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualSingleAsset(PRODUCT_MOTOR_INSURANCE, CORRESPONDENCE_TYPE_NEW_BUSINESS);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().setChannel(correspondenceChannel);
        if (CORRESPONDENCE_CHANNEL_POST.equals(correspondenceChannel))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence()
                    .getPrimaryRecipient().getIndividual().getAddress().setDescriptiveFullAddress("181 William Street Melbourne VIC 3000");
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().getPrimaryRecipient().getIndividual()
                .setEmailContact(primaryRecipientBuilder.getCorrespondenceEmailContacts(correspondenceEmail, StringUtils.isNotBlank(correspondenceEmail)?true:false));
        if (StringUtils.isNotBlank(policyNumber))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails().setPolicyNumber(policyNumber);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }

    public PolicyDetails executeMotorNewBusinessWithInserts(String policyNumber) throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualSingleAsset(PRODUCT_MOTOR_INSURANCE, CORRESPONDENCE_TYPE_NEW_BUSINESS);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        PolicyCorrespondence policyCorrespondence = policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest();
        policyCorrespondence.getCorrespondence().setInserts(Arrays.asList("1035004583547"));
        policyCorrespondence.getCorrespondence().setInsertEffectiveDate(datesBuilder.formatInsertEffectiveDate(LocalDate.now()));
        if (StringUtils.isNotBlank(policyNumber))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails().setPolicyNumber(policyNumber);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }

    public PolicyDetails executeHomeNewBusiness(String policyNumber, String correspondenceChannel, String correspondenceEmail) throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceOrganisationSingleAsset(PRODUCT_HOME_INSURANCE, CORRESPONDENCE_TYPE_NEW_BUSINESS);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().setChannel(correspondenceChannel);
        if (CORRESPONDENCE_CHANNEL_POST.equals(correspondenceChannel))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence()
                    .getPrimaryRecipient().getOrganisation().getAddress().setDescriptiveFullAddress("181 William Street Melbourne VIC 3000");
        policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getCorrespondence().getPrimaryRecipient().getOrganisation()
                .setEmailContact(primaryRecipientBuilder.getCorrespondenceEmailContacts(correspondenceEmail, StringUtils.isNotBlank(correspondenceEmail)?true:false));
        if (StringUtils.isNotBlank(policyNumber))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails().setPolicyNumber(policyNumber);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }

    public PolicyDetails executeHomeQuotation(String policyNumber) throws Exception{
        PolicySendCorrespondenceArtifact policySendCorrespondenceArtifact = correspondenceRequestBuilder
                .setupPolicySendCorrespondenceIndividualSingleAsset(PRODUCT_HOME_INSURANCE, CORRESPONDENCE_TYPE_QUOTATION);
        policySendCorrespondenceArtifact.setValidateResponseSchema(false);
        if (StringUtils.isNotBlank(policyNumber))
            policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest().getPolicyDetails().setPolicyNumber(policyNumber);
        Response response = correspondenceService.executeSendCorrespondence(policySendCorrespondenceArtifact, SC_OK);
        return PolicyDetails.builder().policyCorrespondence(policySendCorrespondenceArtifact.getPolicyCorrespondenceRequest()).response(response).build();
    }
}
