package au.com.iag.execution.claimupdateapi.model;

import au.com.iag.execution.claimupdateapi.model.business.ClaimActivityRequest;
import lombok.Data;

import java.util.Map;

@Data
public class ClaimActivityArtifact {
    private Map<String, Object> headers;
    private String path;
    private String claimId;

    private ClaimActivityRequest claimActivityRequest;
}
