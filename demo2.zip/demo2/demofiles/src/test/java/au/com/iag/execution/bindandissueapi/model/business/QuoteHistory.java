package au.com.iag.execution.bindandissueapi.model.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class QuoteHistory implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("quote_number")
    private String quoteNumber ;

  
    @ApiModelProperty(
        value = "Quote number",
        example = "QTE1234567",
        required = false
    )
    public String getQuoteNumber() {
       return quoteNumber;
    }
 

}