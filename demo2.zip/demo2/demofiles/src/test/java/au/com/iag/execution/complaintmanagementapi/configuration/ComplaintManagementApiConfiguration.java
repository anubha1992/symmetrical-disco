package au.com.iag.execution.complaintmanagementapi.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({
    "au.com.iag.glados*",
    "au.com.iag.execution.complaintmanagementapi*",
    "au.com.iag.execution.common.service.claims",
    "au.com.iag.execution.common.model.claims"
})
public class ComplaintManagementApiConfiguration {

}
