package au.com.iag.execution.common.constants;

public class ApiConstants {

    public static final String SOURCE_ID = "source_id";
    public static final String BAPI = "BAPI";
    public static final String DB_CC_CLAIMNUMBER = "CLAIMNUMBER";
    public static final String DB_CC_INSUREDDENORMID = "INSUREDDENORMID";
    public static final String DB_CC_CGU_CUSTOMERNUMBER = "CGU_CUSTOMERNUMBER";
    public static final String API_SOURCE_SYSTEM_BRAND_IS_NZ_STATE_AND_AMI = "#{environment['test.api.source.system.brand'].toUpperCase().matches('NZ STATE|AMI')}";
    public static final String API_SOURCE_SYSTEM_BRAND_FOR_PROPERTY_CLAIM_NOT_NZ = "#{environment['test.api.source.system.brand'].toUpperCase().matches('COLES|NRMA|RACV|SGIO|SGIC')}";
    public static final String API_SOURCE_SYSTEM_BRAND_IS_NRMA = "#{environment['test.api.source.system.brand'].toUpperCase().matches('NRMA')}";

    public static final String X_IAG_USER_PROFILE = "X-Iag-User-Profile";
    public static final String X_IAG_OPERATION = "X-Iag-Operation";
    public static final String X_IAG_REGION = "X-Iag-Region";
    public static final String X_IAG_VENDOR_CODE = "X-Iag-Vendor-Code";
    public static final String BUSINESS_API_PROVIDER = "business-api-provider";

    //Claim Center database
    public static final String DB_CC_POLICYNUMBER = "POLICYNUMBER";

    // Crods database
    public static final String DB_CRODS_POLICYNUMBER = "SSBREFERENCE";
    public static final String DB_CRODS_VEHICLE_REGISTRATION = "LOBDISPLAYLEVEL2";
    public static final String DB_CRODS_POLICY_INCEPTION = "START_DATE";
    public static final String DB_CORDS_POLICY_EXPIRY = "RENEWAL_DUE_DATE";


    public static final String API_SOURCE_SYSTEM_BRAND_FOR_MOTOR_CLAIM = "#{environment['test.api.source.system.brand'].toUpperCase().matches('COLES|NRMA|RACV|SGIO|SGIC')}";

    public static final String INVALID_SYSTEM_TOKEN = "Security Token Validation Failure: Invalid System Token provided ";
    public static final String EXPIRED_SYSTEM_TOKEN = "Security Token Validation Failure: Expired System Token provided ";
    public static final String INVALID_USER_TOKEN = "Security Token Validation Failure: Invalid User Token provided ";
    public static final String EXPIRED_USER_TOKEN = "Security Token Validation Failure: Expired User Token provided ";
    public static final String SYSTEM_SECURITY_VALIDATION_FAILURE = " System Security Validation Failure. ";
}