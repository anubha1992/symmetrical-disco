package au.com.iag.execution.common.model.huon;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import au.com.iag.execution.common.exception.InvalidDataException;
import au.com.iag.execution.common.model.huon.util.Address;
import au.com.iag.execution.common.model.huon.util.Customer;
import au.com.iag.execution.common.model.huon.util.DataHandler;
import au.com.iag.execution.common.model.huon.util.HuonException;
import au.com.iag.execution.common.model.huon.util.MotorVehicle;
import au.com.iag.execution.common.model.huon.util.Policy;
import au.com.iag.execution.common.model.huon.util.SuperOwnerDriver;
import au.com.iag.execution.common.service.crods.CrodsDbService;
import com.jagacy.util.JagacyException;

/**
 * This is the super class for client or policy creation, or even capture or renewal, etc through HUON.
 */
public class HuonCreator {
    protected HuonSession huon = null;
    protected HuonErrorHandler errorHandler = null;
    protected HuonReporter reporter = null;
    protected String testcaseDir = "";

    @Autowired
    CrodsDbService crodsDbService;

    /**
     * Constructor to create new HuonSession
     */
    public HuonCreator(String env, String testcaseDir) throws HuonException, JagacyException {
        try {
            huon = new HuonSession(env);
            huon.open(); // Open and logon and navigate to start screen HH100
            /*
             * Create an error handler to use
             */
            this.testcaseDir = testcaseDir;
            reporter = new HuonReporter(testcaseDir);
            this.errorHandler = new HuonErrorHandler(huon, reporter);
        } catch (JagacyException ex) {
//			System.err.println("Exception happened when trying to create and logon a HuonSession: " + ex);
//			ex.printStackTrace();
            if (huon != null) {
                huon.abort();
            }
            throw ex;

//			System.exit(0);
        }
    }

    /**
     * Constructor to start from an existing HuonSession
     *
     * @param huon
     */
    public HuonCreator(HuonSession huon, String testcaseDir) throws JagacyException {
        this.huon = huon;
        this.testcaseDir = testcaseDir;
        reporter = new HuonReporter(testcaseDir);
        this.errorHandler = new HuonErrorHandler(huon, reporter);
    }

    /**
     * Get the HuonSession.
     *
     * @return
     */
    public HuonSession getSession() {
        return huon;
    }

    /**
     * Close the session
     */
    public void close() {
        try {
            huon.close();
        } catch (JagacyException ex) {
            if (huon != null) {
                huon.abort();
            }
        }
    }


    /**
     * Prepare all customers
     *
     * @param policy
     * @return The first client number
     * @throws JagacyException
     * @throws ParseException
     * @throws InvalidDataException
     * @throws HuonException
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public String prepareCustomers(Policy policy) throws JagacyException, ParseException, InvalidDataException, HuonException, ClassNotFoundException, SQLException {
        /*
         * Check all clients:
         * If new client create him/her from HUON.
         * If existing client, and client number is provided, SearchIntermediaryDocuments for other information
         * If existing client, and client number is blank, SearchIntermediaryDocuments by other information
         */

        List<SuperOwnerDriver> ownerDrivers = policy.getSuperOwnerDrivers();

        List<String> newClients = new ArrayList<String>();
        // List<HomePolicy.owner> owners = home.getOwnerList();
        HuonCustomerCreator customerCreator = new HuonCustomerCreator(huon,
                this.testcaseDir);
        for (int i = 0; i < ownerDrivers.size(); i++) {
            if (ownerDrivers.get(i).isExistingCustomers()) { // Existing client
                boolean found = false;
                String clientNumber = ownerDrivers.get(i).getCustomer()
                        .getClientNumber().trim();
                if (clientNumber.isEmpty()) {
                    clientNumber = customerCreator.searchClient(ownerDrivers
                            .get(i).getCustomer());
                    if (!clientNumber.isEmpty())
                        found = true;
                    ownerDrivers.get(i).getCustomer()
                            .setClientNumber(clientNumber);
                } else {
                    found = customerCreator.getByNumber(clientNumber,
                            ownerDrivers.get(i).getCustomer());
                }

                if (!found) {
                    throw new HuonException(
                            "Existing client is not found from HUON: "
                                    + ownerDrivers.get(i).getCustomer());
                }


            } else { // New customer
                if (!ownerDrivers.get(i).isAnonymous()) {
                    String clientNumber = customerCreator.createClient(ownerDrivers
                            .get(i).getCustomer());
                    ownerDrivers.get(i).getCustomer().setClientNumber(clientNumber);

                    // Record new created client
                    newClients.add(clientNumber);
                }
            }
        }

        /*
         * Check the new client is already in CRODS
         */
        if (!policy.getDistributor().equalsIgnoreCase(Policy.RACV))
            for (String newClient : newClients) {
                // Check the client from CRODS.
                // If returns false, meaning we cannot check it and it already waits
                // for some time, so we don't need to do for other clients
                if (!crodsDbService.waitForCustomerExisting(newClient))
                    break;
            }

        /*
         * find the first client created
         */
        String clientNumber = "";
        for (int i = 0; i < ownerDrivers.size(); i++) {
            clientNumber = ownerDrivers.get(i).getCustomer().getClientNumber().trim();
            if (!clientNumber.isEmpty())
                break;
        }
        if (clientNumber.isEmpty()) {
            reporter.captureScreenshot("Exception");
            throw new HuonException("No client number is provided to create home quote. Please provide at least 1 client with client number." + Arrays.toString(ownerDrivers.toArray()));
        }

        System.out.println("Client created: " + clientNumber);

        return clientNumber;

    }

    protected void startNewBusiness(Policy policy, String clientNumber) throws JagacyException, InvalidDataException, HuonException, ParseException {
        startNewBusiness(policy.getHuonAgent(), policy, clientNumber);
    }

    protected void startNewBusiness(String agent, Policy policy, String clientNumber) throws JagacyException, InvalidDataException, HuonException, ParseException {
        //We must call it in case the screen is in an abnormal state
        huon.gotoHH100();

        //Start to create policy
        huon.gotoScreen("PP013");
        huon.input(3, 12, "1");
        huon.eraseField(13, 18);
        huon.input(13, 18, clientNumber);
        String effectiveDate = policy.getEffectiveDateString();
        if (effectiveDate.isEmpty()) {
            throw new HuonException("Effective date is blank.");
        }
        if (isBlank(policy.getRiskAddress().getState())){
            policy.getRiskAddress().setState("NSW");
        }
        huon.input(15, 32, effectiveDate);
        huon.input(16, 32, agent);
        huon.input(16, 59, policy.getRiskAddress().getStateCode());
        huon.input(17, 32, policy.getHuonProductType());
        huon.input(17, 59, policy.getHuonSection());
        huon.enter();

        // Check error
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "Failed to create policy -- " + policy
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
        }
    }

    protected void startQuote(Policy policy, String clientNumber) throws JagacyException, InvalidDataException, HuonException, ParseException {
        startQuote(policy.getHuonAgent(), policy, clientNumber);
    }

    protected void startQuote(String agent, Policy policy, String clientNumber) throws JagacyException, InvalidDataException, HuonException, ParseException {
        //We must call it in case the screen is in an abnormal state
        huon.gotoHH100();

        /*
         * If needed, populate address details by GeoID
         */
        if (!policy.getRiskAddress().getGeoId().isEmpty() && policy.getRiskAddress().getStreetNo().isEmpty()) {
            populateAddressByGeoid(policy.getRiskAddress());
        }

        //Start to create quote
        huon.gotoScreen("PP011");
        huon.input(3, 12, "1");
        huon.eraseField(11, 18);
        huon.input(11, 18, clientNumber);
        String effectiveDate = policy.getEffectiveDateString();
        if (effectiveDate.isEmpty()) {
            throw new HuonException("Effective date is blank.");
        }

        huon.input(13, 18, effectiveDate);
        huon.input(14, 18, policy.getHuonAgent());
        huon.input(14, 44, policy.getRiskAddress().getStateCode());
        huon.input(14, 59, policy.getHuonProductType());
        huon.input(14, 75, policy.getHuonSection());
        huon.input(15, 18, "1");
        huon.enter();

        // Check error
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "Failed to create quote -- " + policy
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
        }

    }

    /*
     * Select owners
     * @throws JagacyException
     */
    protected void selectOwners(Policy policy) throws JagacyException {
        List<SuperOwnerDriver> owners = policy.getSuperOwnersOnly();
        for (int i = 0; i < owners.size(); i++) {
            if (!owners.get(i).isAnonymous()) {
                huon.input(4, 18, "Y");
                huon.eraseField(4, 20);
                huon.input(4, 20, owners.get(i).getCustomer().getClientNumber());
                huon.enter();
                huon.input(9, 1, "S");
                huon.enter();

                // Check error
                if (!errorHandler.perform()) {
                    throw new JagacyException(JagacyException.MODEL_ERROR,
                            "Failed to create policy when trying to add more owners -- "
                                    + Arrays.toString(owners.toArray()) + " -- and Error is ["
                                    + errorHandler.getErrorMessage() + "]");
                }

                huon.waitForScreen("HY011");
            }
        }
    }

    protected void selectOwner(Customer owner) throws JagacyException {

        huon.input(4, 18, "Y");
        huon.eraseField(4, 20);
        huon.input(4, 20, owner.getClientNumber());
        huon.enter();
        huon.input(9, 1, "S");
        huon.enter();

        // Check error
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "Failed to add owner: "
                            + errorHandler.getErrorMessage() + "]" + ": " + owner);
        }

        huon.waitForScreen("HY011");

    }

    public void authorize(String policyNumber) throws JagacyException {
        huon.gotoScreen("PP870");
        huon.input(3, 14, policyNumber);
        huon.enter();
        if (huon.readFromField(7, 5, 16).trim().isEmpty())
            return;

        huon.input(7, 2, "S");
        huon.enter();

        huon.waitForScreen("PP871");
        huon.input(3, 26, "Y");
        huon.input(3, 47, "N");
        huon.enter();

        huon.waitForScreen("PP870");

    }

    /*
     * Selece risk address
     */
    protected void selectRiskAddress(Address address) throws JagacyException {

        //Indicator
        if (!address.getHuonIndicator().isEmpty())
            huon.input(17, 8, address.getHuonIndicator());
        if (!address.getUnitNo().isEmpty())
            huon.input(17, 14, address.getUnitNo());
        if (!address.getHuonIndicator2().isEmpty())
            huon.input(17, 29, address.getHuonIndicator2());
        if (!address.getUnitNo2().isEmpty())
            huon.input(17, 35, address.getUnitNo2());
        huon.input(18, 5, address.getStreetNo());
        huon.input(18, 16, address.getStreetName());
        huon.input(18, 57, address.getHuonStreetType());
        if (!address.getHuonStreetDirection().isEmpty())
            huon.input(18, 62, address.getHuonStreetDirection());
        huon.input(19, 13, address.getSuburb());
        huon.input(19, 51, address.getStateCode());
        huon.input(19, 59, address.getPostcode());

        huon.enter();

//		String currentScreen = huon.waitForScreens(new String[] {"PP165", "HZ700", "TB310"});
        String currentScreen = huon.readScreenName();

        if (currentScreen.equalsIgnoreCase("PPO165")) {
            huon.input(6, 3, "S");
            huon.enter();
//			huon.waitForScreen("TB310");
        }

        if (currentScreen.equalsIgnoreCase("HZO700")) {
            huon.input(6, 79, "Y");
            huon.enter();
            huon.waitForScreen("PPO165");
            huon.enter();
//			huon.waitForScreen("TB310");
        }

    }

    /*
     * Finish the billing information for new business
     * The process is same for all products.
     */
    public String finishBillingForNB(Policy policy) throws JagacyException, HuonException {
        /*
         * Billing
         */
        huon.waitForScreen("WP222");
        /*
         * Check PIRRI issue here
         */
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "PIRRI related error -- " + policy
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
        }
        if (policy.getBillPlan().equalsIgnoreCase("Monthly") || policy.getBillPlan().equalsIgnoreCase("PBTM")) {
            huon.input(4, 50, "S");
        } else {
            huon.input(4, 22, "S");
        }
        huon.enter();

        /*
         * Balance
         */
        huon.waitForScreen("PP260");
        huon.input(21, 20, "N");
        huon.enter();

        /*
         * Billing schedule
         * The first PP281
         */
        huon.waitForScreen("PP281");
        huon.enter();

        /*
         * Terms
         */
        huon.waitForScreen("WP285");
        huon.gotoLastPage();
        huon.input(22, 74, "Y");
        huon.enter();

        /*
         * The 2nd PP281
         */
        huon.waitForScreen("PP281");
        try {
            huon.input(10, 50, "N");
        } catch (JagacyException je) {
            //For PBTM, it is disabled to "Y"
        }
        huon.enter();

        /*
         * The 2nd WP285
         */
        huon.waitForScreen("WP285");
        huon.enter();

        /*
         * May have the 3rd WP285 for PBTM
         */
        if (huon.readScreenName().equals("WPO285")) {
            huon.enter();
        }

        huon.waitForScreen("PP281");
        huon.enter();

        /*
         * Finished
         */
        huon.waitForScreen("PP013");

        /*
         * Get policy number
         */
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.enter();

        huon.waitForScreen("PP510");
        String policyNumber = huon.readFromField(1, 50, 61).trim();
        policy.setPolicyNumber(policyNumber);
        System.out.println("Policy number: " + policyNumber);
        //Check authorization
        String auMessage = huon.readFromField(17, 52, 80).trim();
        boolean needAuthorization = false;
        if (auMessage.equalsIgnoreCase("POLICY REQUIRES AUTHORIZATION")) {
            needAuthorization = true;
        }
        if (needAuthorization && policy.isDoAuthorization())
            authorize(policyNumber);

        if (!(needAuthorization && !policy.isDoAuthorization())) {
            if (policy.getPaymentOption().equalsIgnoreCase(Policy.PAID) || policy.getPaymentOption().equalsIgnoreCase(Policy.RECEIPT_NO_BATCH)) {
                boolean monthly = false;
                if (policy.getBillPlan().equalsIgnoreCase(Policy.MONTHLY))
                    monthly = true;
                boolean doBatch = true;
                if (policy.getPaymentOption().equalsIgnoreCase(Policy.RECEIPT_NO_BATCH))
                    doBatch = false;

                HuonPayment payment = new HuonPayment(huon);
                payment.payPolicy(policyNumber, monthly, policy.getInstalments(), doBatch);
            }
        }

		/*if (policy.getPaymentOption().equalsIgnoreCase(Policy.PAID) && !(needAuthorization && !policy.isDoAuthorization())) {
			boolean monthly = false;
			if (policy.getBillPlan().equalsIgnoreCase(Policy.MONTHLY))
				monthly = true;
				boolean doBatch = false;

				HuonPayment payment = new HuonPayment(huon);
				payment.payPolicy(policyNumber, monthly, policy.getInstalments(), doBatch);
			}*/

        return policyNumber;
    }

    public void finishBillingForQuote(Policy policy) throws JagacyException {
//		String currentScreen = "";
        /*
         * Bill plan
         */
        huon.waitForScreen("WP222");
        /*
         * Check PIRRI issue here
         */
        if (!errorHandler.perform()) {
            throw new JagacyException(JagacyException.MODEL_ERROR,
                    "PIRRI related error -- " + policy
                            + " -- and Error is ["
                            + errorHandler.getErrorMessage() + "]");
        }
        if (policy.getBillPlan().equalsIgnoreCase("Monthly") || policy.getBillPlan().equalsIgnoreCase("PBTM")) {
            huon.input(4, 50, "S");
        } else {
            huon.input(4, 22, "S");
        }
        huon.enter();

        /*
         * Balance
         */
        huon.waitForScreen("PP260");
        huon.tryInput(21, 20, "N");
        huon.enter();

        /*
         * Billing schedule
         * The first PP281
         */
        huon.waitForScreen("PP281");
        huon.enter();

//		currentScreen = huon.readScreenName();
//		if (currentScreen.equalsIgnoreCase("WPO285")) {
//			huon.gotoLastPage();
//			huon.input(22, 74, "Y");
//			huon.enter();
//		}

        /*
         * Finished
         */
        huon.waitForScreen("PP011");

        /*
         * Get policy number
         */
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.enter();

        huon.waitForScreen("PP618");
        String quoteNumber = huon.readFromField(1, 52, 63).trim();
        policy.setQuoteNumber(quoteNumber);
        System.out.println("Quote number: " + quoteNumber);
        //Check authorization
        String auMessage = huon.readFromField(13, 36, 80).trim();
        boolean needAuthorization = false;
        if (auMessage.equalsIgnoreCase("QUOTE REQUIRES AUTHORIZATION")) {
            needAuthorization = true;
        }
        if (needAuthorization && policy.isDoAuthorization())
            authorize(quoteNumber);
    }

    /*
     * Policy header screen PP120 for all products
     * returns policy number which is used in HuonBoatCreator
     */
    protected String inputPolicyHeader() throws JagacyException {
        huon.waitForScreen("PP120");

        //Get policy number here in case there is error later
        String policyNumber = huon.readFromField(1, 50, 61);

        huon.input(9, 19, "N");
        try {
            huon.input(15, 43, "1");
        } catch (JagacyException e) {

        }
        huon.input(19, 19, "N");
        huon.input(19, 43, "N");
        huon.input(19, 67, "N");
        huon.enter();

        return policyNumber;
    }

    //90026 - DATE ENTERED MUST BE LESS THAN OR EQUAL TO TODAYS DATE
    protected void handleDriverDisclosuredDate(int row, int col) throws JagacyException {
        if (huon.extractErrorCode().equalsIgnoreCase("90026")) {
            String today = DataHandler.todayString();
            huon.input(row, col, today);
            huon.enter();
        }
    }

    protected void gotoPolicyHeaderScreen(String policyNumber) throws JagacyException {
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.input(4, 33, policyNumber);
        huon.enter();
        huon.waitForScreen("PP510");
    }

    /**
     * Populate address details by GeoId
     *
     * @param address
     * @throws JagacyException
     * @throws HuonException
     * @throws InvalidDataException
     * @throws ParseException
     */
    public void populateAddressByGeoid(Address address) throws JagacyException, HuonException, InvalidDataException, ParseException {
        if (address.getGeoId().isEmpty())
            return;

//		if (!address.getStreetNo().isEmpty())
//			return;

        huon.gotoScreen("WR680");
        huon.waitForScreen("WR680");
        huon.input(4, 36, address.getGeoId());
        huon.enter();

        String error = huon.extractErrorCode();
        //800284 - GEO ID IS NOT ASSOCIATED TO A HUON ADDRESS
        //800289 - MULTIPLE ADDRESSES ARE ASSOCIATED TO THIS GEO ID
        if (error.equals("800284") || error.equals("800289")
                || huon.readFromField(11, 50, 51).trim().isEmpty())
            throw new HuonException("Failed to get address details by GeoID: " + address.getGeoId() + " - " + huon.readErrorMessage());

        address.setIndicator(huon.readFromField(9, 8, 8).trim());
        address.setUnitNo(huon.readFromField(9, 13, 20).trim());
        address.setIndicator2(huon.readFromField(9, 29, 29).trim());
        address.setUnitNo2(huon.readFromField(9, 34, 41).trim());
        address.setStreetNo(huon.readFromField(10, 9, 18).trim());
        address.setStreetName(huon.readFromField(10, 20, 59).trim());
        address.setStreetType(huon.readFromField(10, 61, 64).trim(), true);
        address.setSuburb(huon.readFromField(11, 9, 42).trim());
        address.setStateByCode(huon.readFromField(11, 50, 51).trim());
        address.setPostcode(huon.readFromField(11, 57, 60).trim());

        if (address.getState().isEmpty())
            throw new HuonException("Failed to get address details by GeoID: " + address.getGeoId() + " - " + huon.readErrorMessage());
    }

    /**
     * Populate motor vehicle details by sequence number.
     *
     * @param vehicle
     * @throws HuonException
     * @throws JagacyException
     */
    public void populateVehicleBySequenceNumber(MotorVehicle vehicle) throws HuonException, JagacyException {
        if (vehicle.getSequenceNumber().trim().isEmpty())
            return;

        huon.gotoScreen("WR153");
        huon.waitForScreen("WR153");
        huon.input(3, 14, vehicle.getSequenceNumber().trim());
        huon.enter();

        String error = huon.readErrorMessage();
        if (!error.isEmpty())
            throw new HuonException("Failed to get vehicle details by sequence number: " + vehicle.getSequenceNumber() + " - " + error);

        vehicle.setVehicleYear(huon.readFromField(4, 7, 10).trim());
        vehicle.setVehicleMaker(huon.readFromField(4, 19, 34).trim());
        vehicle.setVehicleModel(huon.readFromField(4, 42, 59).trim());
        vehicle.setVehicleShape(huon.readFromField(4, 66, 70).trim());
        vehicle.setVehicleSeries(huon.readFromField(5, 9, 14).trim());
        vehicle.setVehicleEquipment(huon.readFromField(5, 38, 47).trim());
        vehicle.setVehicleEngineSize(huon.readFromField(5, 54, 57).trim());
        vehicle.setVehicleEngineType(huon.readFromField(5, 71, 72).trim());

        huon.gotoHH100();
    }

    /*
     * Select vehicle  WPO179         VEHICLE IDENTIFICATION
     */
    protected void selectVehicle(MotorVehicle vehicle) throws JagacyException {
        huon.waitForScreen("WPO179");
        if (!vehicle.getVehicleYear().isEmpty()) {
            huon.input(4, 9, vehicle.getVehicleYear());
            huon.eraseField(4, 20);
            huon.input(4, 20, vehicle.getVehicleMaker());
            huon.eraseField(4, 42);
            huon.input(4, 42, vehicle.getVehicleModel());

            huon.eraseField(4, 63);
            huon.input(4, 63, vehicle.getVehicleShape());
//			if (riskType.startsWith("BK")) {
//				huon.input(4, 63, "MBIKE");
//			} else {
//				huon.input(4, 63, vehicle.getVehicleShape());
//			}

            huon.eraseField(5, 9);
            huon.input(5, 9, vehicle.getVehicleSeries());

            //Tare added on 13/10/2016 for CTP
            huon.eraseField(5, 21);
            if (!vehicle.getVehicleTare().isEmpty())
                huon.input(5, 21, vehicle.getVehicleTare());

            huon.eraseField(5, 38);
            huon.input(5, 38, vehicle.getVehicleEquipment());
            huon.eraseField(5, 54);
            huon.input(5, 54, vehicle.getVehicleEngineSize());    //CC, need to convert
            huon.eraseField(5, 70);
            huon.input(5, 70, vehicle.getVehicleEngineType());

            huon.enter();
            // Check error
            if (!errorHandler.perform()) {
                throw new JagacyException(JagacyException.MODEL_ERROR,
                        "Failed to create SearchIntermediaryDocuments vehicle -- " + vehicle
                                + " -- and Error is ["
                                + errorHandler.getErrorMessage() + "]");
            }
        } else {    //No vehicle provided, use default
            Calendar cal = Calendar.getInstance();
            int year = cal.get(Calendar.YEAR);
            year = year - 4;
            huon.input(4, 9, Integer.toString(year).trim());
            if (vehicle.getVehicleShape().equalsIgnoreCase("MBIKE")) {
                huon.input(4, 20, "HONDA");
                huon.input(4, 63, "MBIKE");
            } else {
                huon.input(4, 20, "TOYOTA");
                huon.input(4, 63, "SEDAN");
            }

            huon.enter();
            // Check error
            if (!errorHandler.perform()) {
                throw new JagacyException(JagacyException.MODEL_ERROR,
                        "Failed to create SearchIntermediaryDocuments vehicle -- " + vehicle
                                + " -- and Error is ["
                                + errorHandler.getErrorMessage() + "]");
            }
        }

        /*
         * Update vehicle information
         */
        vehicle.setVehicleYear(huon.readFromField(9, 4, 7).trim());
        vehicle.setVehicleMaker(huon.readFromField(9, 9, 22).trim());
        vehicle.setVehicleModel(huon.readFromField(9, 24, 38).trim());
        vehicle.setVehicleShape(huon.readFromField(9, 39, 43).trim());
        vehicle.setVehicleSeries(huon.readFromField(9, 45, 50).trim());
        vehicle.setVehicleTare(huon.readFromField(10, 45, 50).trim());
        vehicle.setVehicleEquipment(huon.readFromField(9, 52, 61).trim());
        vehicle.setVehicleEngineSize(huon.readFromField(9, 63, 66).trim());
        vehicle.setVehicleEngineType(huon.readFromField(9, 68, 71).trim());

        huon.input(9, 2, "S");
        huon.enter();
    }

}
