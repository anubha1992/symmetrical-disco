package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.*;
import au.com.iag.glados.service.JsonMapperService;
import au.com.iag.glados.service.RandomContentService;
import au.com.iag.glados.service.ResourceReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

import static au.com.iag.execution.correspondenceapi.model.CommonErdData.*;
import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class HomeCorrespondenceRequestBuilder {

    @Autowired private JsonMapperService jsonMapperService;
    @Autowired private ResourceReaderService resourceReaderService;
    @Autowired private PartyBuilder partyBuilder;
    @Autowired private HomeAssetBuilder homeAssetBuilder;
    @Autowired private PolicyDatesBuilder policyDatesBuilder;
    @Autowired private RandomContentService randomContentService;
    @Autowired private BaseRequestBuilder baseRequestBuilder;
    @Autowired private PrimaryRecipientBuilder primaryRecipientBuilder;
    @Autowired private PolicyBuilder policyBuilder;

    public PolicyCorrespondence getHomeCorrespondenceRequest(final String correspondenceType, String primaryRecipientType
            , List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = readHomeCorrespondenceFromConfig(correspondenceType);
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        policyCorrespondence.getCorrespondence().setCorrespondenceType(correspondenceType);
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        parties.setDrivers(null);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Vehicle Assets
        policyCorrespondence.getPolicyDetails().getAssets()
                .setHomeAssets(homeAssetBuilder.buildHomeAssets(policyCorrespondence, listOfCoverableToPartyRoleSpec));
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        //Build Policy dates
        policyCorrespondence.getPolicyDetails().setPolicyDates(policyDatesBuilder.getPolicyDates());
        //Update PartyId of history disclosures
        partyBuilder.updatePartyIdOnIncidentsOrClaims(policyCorrespondence);
        //Update policy type
        policyBuilder.updatePolicyCorrespondenceByType(correspondenceType, policyCorrespondence);
        return policyCorrespondence;
    }

    public PolicyCorrespondence getHomeCoCRequest(String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getHomeCoCRequestFromConfig();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        parties.setDrivers(null);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Vehicle Assets
        policyCorrespondence.getPolicyDetails().getAssets()
                .setHomeAssets(homeAssetBuilder.buildHomeAssets(policyCorrespondence, listOfCoverableToPartyRoleSpec));
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        primaryRecipientBuilder.updatePrimaryRecipientAddress(primaryRecipientType, correspondenceParties, CORRESPONDENCE_COUNTRY_AUS);
        return policyCorrespondence;
    }

    public PolicyCorrespondence getHomeCoCRequestFromConfig() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/cocHome.json")
                        , PolicyCorrespondence.class);
    }

    public PolicyCorrespondence getHomeAnonymousQuoteRequest(String primaryRecipientType, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) throws IOException {
        PolicyCorrespondence policyCorrespondence = getHomeAnonymousQuoteRequestFromConfig();
        //General data setup
        policyCorrespondence.getPolicyDetails().setPolicyNumber("QTE"+randomContentService.getRandomNumber(11));
        //Build Parties
        Parties parties = partyBuilder.buildParties(policyCorrespondence, listOfCoverableToPartyRoleSpec);
        policyCorrespondence.getPolicyDetails().setParties(parties);
        //Build Vehicle Assets
        policyCorrespondence.getPolicyDetails().getAssets()
                .setHomeAssets(homeAssetBuilder.buildHomeAssets(policyCorrespondence, listOfCoverableToPartyRoleSpec));
        //Build Primary Recipient
        CorrespondenceParties correspondenceParties = baseRequestBuilder.getCorrespondenceParties(primaryRecipientType, policyCorrespondence, parties);
        policyCorrespondence.getCorrespondence().setPrimaryRecipient(correspondenceParties);
        policyCorrespondence.getCorrespondence().setChannel(CORRESPONDENCE_CHANNEL_EMAIL);
        return policyCorrespondence;
    }

    public PolicyCorrespondence getHomeAnonymousQuoteRequestFromConfig() throws IOException {
        return jsonMapperService.getObjectMapper()
                .readValue(resourceReaderService.generateStringFromResource("requests/correspondence-api/policyCorrespondenceHomeAnonymousQuote.json")
                        , PolicyCorrespondence.class);
    }

    public void updateHomePolicyToBeContentOnly(PolicyCorrespondence policyCorrespondence){
        policyCorrespondence.getPolicyDetails().getAssets().getHomeAssets().stream().forEach(homeAsset -> {
            homeAsset.setBuildingAsset(false);
            homeAsset.setBuilding(getBuildingDetailsForContentOnlyPolicy());
            homeAsset.getEmbargoesExclusionsConditions().getConditions().setUnoccupiedProperty(null);
        });
    }

    public void updateHomePolicyToBeBuildingOnly(PolicyCorrespondence policyCorrespondence){
        policyCorrespondence.getPolicyDetails().getAssets().getHomeAssets().stream().forEach(homeAsset -> {
            homeAsset.setContentsAsset(false);
            homeAsset.setContents(null);
        });
    }

    private BuildingDetails getBuildingDetailsForContentOnlyPolicy(){
        BuildingDetails buildingDetails = new BuildingDetails();
        buildingDetails.setPropertyType(HOME_BUILDING_PROPERTY_TYPE);
        BuildingUsage buildingUsage = new BuildingUsage();
        buildingUsage.setUsageArrangement(HOME_BUILDING_USAGE_ARRANGEMENT);
        buildingDetails.setUsage(buildingUsage);
        buildingDetails.setDistanceToBushland(HOME_BUILDING_DISTANCE_TO_BUSHLAND);
        buildingDetails.setStoreyCount("1");
        return buildingDetails;
    }

    private PolicyCorrespondence readHomeCorrespondenceFromConfig(final String correspondenceType) throws IOException{
        switch (correspondenceType){
            case CORRESPONDENCE_TYPE_NEW_BUSINESS:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceHomeNewBusiness.json")
                                , PolicyCorrespondence.class);
            case CORRESPONDENCE_TYPE_RENEWAL:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceHomeRenewal.json")
                                , PolicyCorrespondence.class);
            case CORRESPONDENCE_TYPE_AMENDMENT:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceHomeAmendment.json")
                                , PolicyCorrespondence.class);
            default:
                return jsonMapperService.getObjectMapper()
                        .readValue(resourceReaderService
                                        .generateStringFromResource("requests/correspondence-api/policyCorrespondenceHomeQuotation.json")
                                , PolicyCorrespondence.class);
        }
    }
}
