package au.com.iag.execution.common.model.huon;

import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.*;
import com.jagacy.util.*;

/**
 * Pay a policy from HUON
 */
public class HuonPayment {
    protected HuonSession huon = null;
    HuonReporter reporter = null;

    /**
     * Constructor to createa new HuonSession
     *
     * @param env
     */
    public HuonPayment(String env) throws HuonException, JagacyException {
        try {
            huon = new HuonSession(env);
            huon.open(); // Open and logon and navigate to start screen HH100
        } catch (JagacyException ex) {
            if (huon != null) {
                huon.abort();
            }
            throw ex;
        }
    }

    /**
     * Constructor to start from an existing HuonSession
     *
     * @param huon
     */
    public HuonPayment(HuonSession huon) throws JagacyException {
        this.huon = huon;
    }

    /**
     * Constructor to create new HuonSession and write payment result to report.
     *
     * @param env
     * @param testcaseDir test case screenshot dir
     * @throws JagacyException
     */
    public HuonPayment(String env, String testcaseDir) throws HuonException, JagacyException {
        try {
            huon = new HuonSession(env);
            huon.open(); // Open and logon and navigate to start screen HH100
        } catch (JagacyException ex) {
            if (huon != null) {
                huon.abort();
            }
            throw ex;
        }

        reporter = new HuonReporter(testcaseDir);
    }

    /**
     * Constructor to start from an existing HuonSession and write payment result to report.
     *
     * @param huon
     * @param testcaseDir test case screenshot dir
     */
    public HuonPayment(HuonSession huon, String testcaseDir) throws JagacyException {
        this.huon = huon;
        reporter = new HuonReporter(testcaseDir);
    }

    /**
     * Get the HuonSession.
     *
     * @return
     */
    public HuonSession getSession() {
        return huon;
    }

    /**
     * Pay a policy (new business or renewal).
     *
     * @param policyNumber
     * @param monthly      true monthly
     * @param instalments  the number of instalments to pay for monthly only
     * @return
     * @throws JagacyException
     * @throws HuonException
     */
    public boolean payPolicy(String policyNumber, boolean monthly, int instalments) throws JagacyException, HuonException {
        return payPolicy(policyNumber, monthly, instalments, true);
    }

    /**
     * Pay a policy (new business or renewal).
     *
     * @param policyNumber
     * @param monthly      true monthly
     * @param instalments  the number of instalments to pay for monthly only
     * @param doBatch      true - do batch, false - not do batch
     * @return
     * @throws JagacyException
     * @throws HuonException
     */
    public boolean payPolicy(String policyNumber, boolean monthly, int instalments, boolean doBatch) throws JagacyException, HuonException {
        boolean result = true;
        String processingBranch = "";

        policyNumber = policyNumber.replaceAll(" ", "");

        if (policyNumber.length() != 12) {
            if (reporter != null)
                reporter.writeError("Policy " + policyNumber + " payment failed because policy number length is not 12.");
            throw new HuonException(" payment-The policy number is not a valid policy number -- " + policyNumber);
        }

        if (policyNumber.startsWith("CTP")) {
            if (reporter != null)
                reporter.writeError("Policy " + policyNumber + " payment failed because the payment script does not support CTP for now.");
            throw new HuonException(" payment-The payment script hasn't handled CTP policies -- " + policyNumber);
        }

        try {
            huon.gotoHH100();
            huon.gotoScreen("PP000");
            huon.input(4, 17, "04");
            huon.input(4, 33, policyNumber);
            huon.enter();

            String error = huon.readErrorMessage();
            String errorCode = huon.extractErrorCode();
            if (errorCode.equalsIgnoreCase("6044")) {
                if (reporter != null)
                    reporter.writeError("Policy " + policyNumber + " payment failed because the policy is not in HUON.");
                throw new HuonException(" payment-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
            }

            huon.waitForScreen("PP510");
            processingBranch = huon.readFromField(11, 18, 21).trim();

            String totalAmountStr = "";
            float totalAmount = 0.0f;
            if (!monthly) {
                huon.gotoScreen("PA216");
                huon.enter();
                huon.waitForScreen("PA216");
                huon.input(4, 12, policyNumber);
                huon.input(8, 21, "I");
                huon.enter();
                error = huon.readErrorMessage();
                errorCode = huon.extractErrorCode();
                if (!errorCode.equalsIgnoreCase("108") && !errorCode.isEmpty()) {
                    if (reporter != null)
                        reporter.writeError("Policy " + policyNumber + " payment failed because policy number length is not 12.");
                    throw new HuonException(" payment-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
                }

                totalAmountStr = huon.readFromField(8, 30, 42).trim();
            } else {    //Monthly


                huon.gotoScreen("HB530");
                huon.enter();
                huon.waitForScreen("HB530");
                huon.input(4, 13, policyNumber);
                huon.enter();
                error = huon.readErrorMessage();
                errorCode = huon.extractErrorCode();
                if (!errorCode.equalsIgnoreCase("108") && !errorCode.isEmpty()) {
                    if (reporter != null)
                        reporter.writeError("Policy " + policyNumber + " payment failed because policy number length is not 12.");
                    throw new HuonException(" payment-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
                }

                int startRow;
                if (huon.readFromField(22, 7, 16).trim().isEmpty()) {//For new business
                    startRow = 21;
                    if (instalments <= 0 || instalments > 11) {
                        instalments = 11;
                    }
                } else {    //For renewal
                    startRow = 22;
                    if (instalments <= 0 || instalments > 12) {
                        instalments = 12;
                    }
                }

                String strAmount = "";
                totalAmount = 0.0f;
                for (int i = 1; i <= instalments; i++) {
                    strAmount = huon.readFromField(startRow, 22, 30).trim().replaceAll(",", "");
                    float amount = Float.parseFloat(strAmount);
                    totalAmount = totalAmount + amount;
                    startRow--;
                }

                totalAmountStr = String.format("%.2f", totalAmount);

            }

            //Start to pay
            huon.gotoScreen("HR840");
            huon.input(5, 22, "A");
            huon.input(5, 70, "A");
            huon.input(8, 22, totalAmountStr);
            huon.input(8, 61, totalAmountStr);
            huon.enter();
            error = huon.readErrorMessage();
            if (error.equalsIgnoreCase("8023 - CASH AMOUNT MUST BE NUMERIC")) {
                if (reporter != null)
                    reporter.writeTxt("Policy " + policyNumber + " payment failed because " + error);
                throw new HuonException(" payment-The amount to pay is: " + totalAmountStr + " -- " + policyNumber + ";Error=" + error);
            }

            huon.waitForScreen("HR842");
            if (!monthly) {
                huon.input(7, 22, "P");
            } else {
                huon.input(7, 22, "I");
            }

            huon.input(7, 50, totalAmountStr);
            huon.input(9, 50, policyNumber.substring(0, 3));
            huon.input(9, 56, policyNumber.substring(3));
            huon.enter();
            if (!huon.readErrorMessage().isEmpty()) {
                if (reporter != null)
                    reporter.writeError("Policy " + policyNumber + " payment failed because " + error);
                throw new HuonException(" payment-failed -- " + policyNumber + ";Error=" + error);
            }

            /*
             * Batch job
             */
            if (doBatch) {
                boolean pass = batchJobSuccessful(processingBranch);
                if (!pass)
                    throw new HuonException("Batch job still not done after long time waiting!");
            }
        } catch (JagacyException je) {
            //Capture screenshot
            reporter.captureScreenshot("Exception");
            throw je;
        }

        if (reporter != null)
            reporter.writeTxt("Policy " + policyNumber + " payment succeed.");

        return result;
    }

    /**
     * Pay a policy (new business or renewal). It will check whether the policy is Annually or PBTM. If PBTM, it pays all instalments.
     *
     * @param policyNumber
     * @return
     * @throws JagacyException
     * @throws HuonException
     */
    public boolean payPolicy(String policyNumber) throws JagacyException, HuonException {
        return payPolicy(policyNumber, true);

    }

    /**
     * Pay a policy (new business or renewal). It will check whether the policy is Annually or PBTM. If PBTM, it pays all instalments.
     *
     * @param policyNumber
     * @param doBatch
     * @return
     * @throws JagacyException
     * @throws HuonException
     */
    public boolean payPolicy(String policyNumber, boolean doBatch) throws JagacyException, HuonException {
        policyNumber = policyNumber.replaceAll(" ", "");

        if (policyNumber.length() != 12) {
            throw new HuonException(" payment-The policy number is not a valid policy number -- " + policyNumber);
        }

        if (policyNumber.startsWith("CTP")) {
            throw new HuonException(" payment-The payment script hasn't handled CTP policies -- " + policyNumber);
        }

        huon.gotoHH100();
        huon.gotoScreen("PP000");
        huon.input(4, 17, "04");
        huon.input(4, 33, policyNumber);
        huon.enter();
        String error = huon.readErrorMessage();
        String errorCode = huon.extractErrorCode();
        if (errorCode.equalsIgnoreCase("6044")) {
            throw new HuonException(" payment-The policy number is not in HUON -- " + policyNumber + ";Error=" + error);
        }

        huon.waitForScreen("PP510");
        huon.input(3, 13, "BC");
        huon.enter();
        huon.waitForScreen("WB530");
        String billPlan = huon.readFromField(6, 23, 26).trim();
        boolean monthly = false;
        if (billPlan.endsWith("TH"))
            monthly = true;

        return payPolicy(policyNumber, monthly, 0, doBatch);
    }

    /**
     * Pay CTP policy
     *
     * @param policyNumber a quote number or CTP number
     * @param amount
     * @return
     * @throws HuonException
     * @throws JagacyException
     */
    public boolean payCtp(String policyNumber, String rtaNumber, String amount, String agent) throws JagacyException, HuonException {
        //Start to pay
        huon.gotoScreen("HR840");
        huon.input(5, 22, "A");
        huon.input(5, 70, "A");
        huon.input(8, 22, amount);

        huon.input(8, 61, amount);
        huon.enter();
        String error = huon.readErrorMessage();
        if (error.equalsIgnoreCase("8023 - CASH AMOUNT MUST BE NUMERIC")) {
            if (reporter != null)
                reporter.writeTxt("Policy " + policyNumber + " payment failed because " + error);
            throw new HuonException(" payment-The amount to pay is: " + amount + " -- " + policyNumber + ";Error=" + error);
        }

        huon.waitForScreen("HR842");
        huon.input(7, 22, "N");

        huon.input(7, 50, amount);
        String no;
        if (rtaNumber.startsWith("RTA"))
            no = rtaNumber.substring(3);
        else
            no = rtaNumber;
        huon.input(15, 22, no);

        huon.enter();
        if (!huon.readErrorMessage().isEmpty()) {
            if (reporter != null)
                reporter.writeError("Policy " + policyNumber + " payment failed because " + error);
            throw new HuonException(" payment-failed -- " + policyNumber + ";Error=" + error);
        }

        /*
         * Batch job
         */
        String[] branches = {"", ""};
        switch (agent) {
            case "SWA":
            case "CS0":
                branches[0] = "2002";
                break;
            case "TOY":
                branches[0] = "2001";
                break;
            default:
                branches[0] = "9000";
                branches[1] = "8000";
                break;
        }

        for (int i = 0; i < branches.length; i++) {
            if (branches[i].isEmpty())
                continue;
            batchJobSuccessful(branches[i]);
        }

        return true;
    }


    public boolean batchJobSuccessful(String processBranch) throws JagacyException, HuonException {
        //At most 10 times
        boolean pass = false;
        for (int i = 0; i < 10; i++) {
            pass = batchJob(processBranch);
            if (pass)
                break;
        }

        return pass;
    }

    private boolean batchJob(String processBranch) throws JagacyException, HuonException {
        int nWait = 300;    //at most wait for 300 seconds

        //Clear mails
        huon.gotoHH100();
        String line = huon.readFromField(24, 2, 79).trim();
        if (line.toUpperCase().contains("MAIL")) {
            huon.pressKey(Key.PF6);

            huon.waitForScreen("HM900");
            while (!huon.readFromField(3, 2, 30).trim().isEmpty()) {
                huon.input(3, 2, "D");
                huon.enter();
                String screen = huon.waitForScreens(new String[]{"HH100", "HM900"});
                if (screen.equalsIgnoreCase("HH100")) {
                    break;
                }
            }
        }

        //Initialize batch job
        huon.gotoScreen("HR870");
        String user = huon.readFromField(2, 72, 79).trim();
        huon.input(5, 44, processBranch);
        huon.input(7, 44, "100000000");
        huon.input(9, 44, "N");
        huon.input(11, 44, "N");
        huon.input(13, 44, user);
        huon.input(15, 44, "1");
        huon.enter();

        //Check whether it is locked
        boolean initialized = false;
        for (int i = 0; i < nWait; i++) {
            String message = huon.readErrorMessage();
            if (message.contains("ROW IN TABLE IS LOCKED")) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    // do nothing
                }
                huon.enter();
                continue;
            } else {
                initialized = true;
                break;
            }
        }


        if (!initialized) {
            throw new HuonException(" payment-batch job is not initialized after " + nWait / 60 + " minutes because the account is locked.");
        }


        boolean finished = false;
        for (int i = 0; i < nWait; i++) {
            huon.gotoHH100();
            line = huon.readFromField(24, 2, 79).trim();
            if (line.toUpperCase().contains("MAIL")) {
                finished = true;
                break;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ie) {
                //do nothing
            }
        }

        if (!finished) {
            throw new HuonException(" payment-batch job is not finished after " + nWait / 60 + " minutes");
        }

        huon.pressKey(Key.PF6);

        huon.waitForScreen("HM900");
        boolean pass = true;
        while (!huon.readFromField(3, 2, 30).trim().isEmpty()) {
            if (!huon.readFromField(3, 4, 31).trim().toUpperCase().contains("COMPLETED"))
                pass = false;

            huon.input(3, 2, "D");
            huon.enter();
            String screen = huon.waitForScreens(new String[]{"HH100", "HM900"});
            if (screen.equalsIgnoreCase("HH100")) {
                break;
            }
        }

        return pass;
    }
}
