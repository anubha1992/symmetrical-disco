package au.com.iag.execution.common.service.claims;

import au.com.iag.glados.integration.*;
import au.com.iag.glados.model.artifacts.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import static au.com.iag.glados.model.artifacts.DatabaseConnectionArtifact.*;
import java.sql.*;
import java.util.*;

@Service
public class ClaimsDbService {

    @Autowired
    private DatabaseClient databaseClient;

    @Value("${claims.datasource.username}") private String username;
    @Value("${claims.datasource.password}") private String password;
    @Value("${claims.datasource.url}") private String connectionString;
    @Value("${claims.datasource.driver-class-name}") private String driverName;

    public List<Map<String, Object>> getClaimResultSet(String productCode) throws Exception {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String query= "Select cc_policy.POLICYNUMBER, cc_claim.* from ccuser.cc_claim "
                + "join ccuser.cc_policy on cc_policy.ID = cc_claim.POLICYID "
                + "where cc_policy.POLICYNUMBER like '" + productCode + "%' "
                + "and cc_policy.CGU_SOURCEPOLICY_POLICYCIPHER = '" + productCode + "' "
                + "and cc_claim.STATE =2 and LENGTH(cc_policy.POLICYNUMBER)>11 "
                + "order by cc_policy.POLICYNUMBER desc "
                + "fetch first 100 rows only";

        List<Map<String, Object>> result = databaseClient.executeQuery(connection, query);
        return result;
    }

    public List<Map<String, Object>> getClaimsHavingServiceRequest(String productCode) throws SQLException, ClassNotFoundException {

        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String query= "Select cc_claim.claimnumber, cc_policy.POLICYNUMBER from ccuser.cc_claim "
                + "join ccuser.cc_policy on cc_policy.ID = cc_claim.POLICYID "
                + "where cc_policy.POLICYNUMBER like '" + productCode + "%' "
                + "and cc_policy.CGU_SOURCEPOLICY_POLICYCIPHER = '" + productCode + "' "
                + "and cc_claim.STATE =2 and LENGTH(cc_policy.POLICYNUMBER)>11 "
                + "and cc_claim.ID IN (select distinct claim from ccuser.CCX_CGU_SR_ABSTRACT)"
                + "order by cc_policy.POLICYNUMBER desc "
                + "fetch first 100 rows only";

        List<Map<String, Object>> result = databaseClient.executeQuery(connection, query);
        return result;
    }

    public List<Map<String, Object>> getClaimsHavingLossItems(String productCode) throws Exception {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String query = "Select CC_CLAIM.CLAIMNUMBER,CC_POLICY.POLICYNUMBER from CCUSER.CC_CLAIM "
                + "join CCUSER.CC_POLICY on cc_policy.ID = cc_claim.POLICYID "
                + "where cc_policy.POLICYNUMBER like '" + productCode + "%' "
                + "and cc_policy.CGU_SOURCEPOLICY_POLICYCIPHER = '" + productCode + "' "
                + "and cc_claim.STATE =2 and LENGTH(cc_policy.POLICYNUMBER)>11 "
                + "and cc_claim.ID IN (Select CC_INCIDENT.CLAIMID from CCUSER.CC_INCIDENT JOIN CCUSER.CCX_CGU_LOSSESTIMATE ON CC_INCIDENT.ID = CCX_CGU_LOSSESTIMATE.INCIDENTID)"
                + "order by cc_policy.POLICYNUMBER desc "
                + "fetch first 10 rows only";

        List<Map<String, Object>> result = databaseClient.executeQuery(connection, query);
        return result;
    }

    public List<Map<String, Object>> getClaimsByBrand(String brand) throws Exception {
        DatabaseConnectionArtifact databaseConnectionArtifact = buildDatabaseConnectionDetails();
        Connection connection = databaseClient.establishConnection(databaseConnectionArtifact);

        String query= "Select cc_policy.POLICYNUMBER, cc_policy.CGU_CUSTOMERNUMBER, cc_claim.* from ccuser.cc_claim "
                + "join ccuser.cc_policy on cc_policy.ID = cc_claim.POLICYID "
                + "where cc_claim.CLAIMNUMBER like '" + brand + "%' "
                + "and cc_claim.STATE =2 and LENGTH(cc_policy.POLICYNUMBER)>11 "
                + "order by cc_policy.POLICYNUMBER desc "
                + "fetch first 100 rows only";

        List<Map<String, Object>> result = databaseClient.executeQuery(connection, query);
        return result;
    }

    private DatabaseConnectionArtifact buildDatabaseConnectionDetails() {
        return builder().connectionString(connectionString)
                .jdbcClassName(driverName)
                .username(username)
                .password(password)
                .build();
    }

}
