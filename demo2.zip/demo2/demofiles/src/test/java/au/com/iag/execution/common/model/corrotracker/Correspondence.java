package au.com.iag.execution.common.model.corrotracker;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;

public class Correspondence implements Serializable {

	@JsonProperty("documents")
	private List<DocumentsItem> documents;

	@JsonProperty("dataVersion")
	private String dataVersion;

	@JsonProperty("eventType")
	private String eventType;

	@JsonProperty("distributor")
	private String distributor;

	@JsonProperty("userId")
	private String userId;

	@JsonProperty("emailAddress")
	private String emailAddress;

	@JsonProperty("statusHistory")
	private List<StatusHistoryItem> statusHistory;

	@JsonProperty("userChannel")
	private String userChannel;

	@JsonProperty("authorisation")
	private String authorisation;

	@JsonProperty("eventTime")
	private String eventTime;

	@JsonProperty("eventDescription")
	private String eventDescription;

	@JsonProperty("systemInitiator")
	private String systemInitiator;

	@JsonProperty("id")
	private int id;

	@JsonProperty("customerIdentifier")
	private CustomerIdentifier customerIdentifier;

	@JsonProperty("correspondenceType")
	private String correspondenceType;

	@JsonProperty("correspondenceDirection")
	private String correspondenceDirection;

	@JsonProperty("correspondenceBusiness")
	private CorrespondenceBusiness correspondenceBusiness;

	@JsonProperty("status")
	private String status;

	@JsonProperty("distributionChannel")
	private String distributionChannel;

	@JsonProperty("brand")
	private String brand;

	@JsonProperty("portfolio")
	private String portfolio;

	@JsonProperty("product")
	private String product;

	public void setDataVersion(String dataVersion){
		this.dataVersion = dataVersion;
	}

	public String getDataVersion(){
		return dataVersion;
	}

	public void setEventType(String eventType){
		this.eventType = eventType;
	}

	public String getEventType(){
		return eventType;
	}

	public void setDistributor(String distributor){
		this.distributor = distributor;
	}

	public String getDistributor(){
		return distributor;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return userId;
	}

	public void setEmailAddress(String emailAddress){
		this.emailAddress = emailAddress;
	}

	public String getEmailAddress(){
		return emailAddress;
	}

	public void setStatusHistory(List<StatusHistoryItem> statusHistory){
		this.statusHistory = statusHistory;
	}

	public List<StatusHistoryItem> getStatusHistory(){
		return statusHistory;
	}

	public void setUserChannel(String userChannel){
		this.userChannel = userChannel;
	}

	public String getUserChannel(){
		return userChannel;
	}

	public void setAuthorisation(String authorisation){
		this.authorisation = authorisation;
	}

	public String getAuthorisation(){
		return authorisation;
	}

	public void setEventTime(String eventTime){
		this.eventTime = eventTime;
	}

	public String getEventTime(){
		return eventTime;
	}

	public void setEventDescription(String eventDescription){
		this.eventDescription = eventDescription;
	}

	public String getEventDescription(){
		return eventDescription;
	}

	public void setSystemInitiator(String systemInitiator){
		this.systemInitiator = systemInitiator;
	}

	public String getSystemInitiator(){
		return systemInitiator;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setCustomerIdentifier(CustomerIdentifier customerIdentifier){
		this.customerIdentifier = customerIdentifier;
	}

	public CustomerIdentifier getCustomerIdentifier(){
		return customerIdentifier;
	}

	public void setCorrespondenceType(String correspondenceType){
		this.correspondenceType = correspondenceType;
	}

	public String getCorrespondenceType(){
		return correspondenceType;
	}

	public void setCorrespondenceDirection(String correspondenceDirection){
		this.correspondenceDirection = correspondenceDirection;
	}

	public String getCorrespondenceDirection(){
		return correspondenceDirection;
	}

	public void setCorrespondenceBusiness(CorrespondenceBusiness correspondenceBusiness){
		this.correspondenceBusiness = correspondenceBusiness;
	}

	public CorrespondenceBusiness getCorrespondenceBusiness(){
		return correspondenceBusiness;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	public String getIdAsString(){
		return Integer.toString(getId());
	}

	public String getDistributionChannel() {
		return distributionChannel;
	}

	public void setDistributionChannel(String distributionChannel) {
		this.distributionChannel = distributionChannel;
	}

	public void setDocuments(List<DocumentsItem> documents){
		this.documents = documents;
	}

	public List<DocumentsItem> getDocuments(){
		return documents;
	}

	public String getBrand() {
		return brand;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public String getProduct() {
		return product;
	}

	@Override
	public String toString(){
		return
				"Correspondence{" +
						"dataVersion = '" + dataVersion + '\'' +
						",eventType = '" + eventType + '\'' +
						",distributor = '" + distributor + '\'' +
						",userId = '" + userId + '\'' +
						",emailAddress = '" + emailAddress + '\'' +
						",statusHistory = '" + statusHistory + '\'' +
						",userChannel = '" + userChannel + '\'' +
						",authorisation = '" + authorisation + '\'' +
						",eventTime = '" + eventTime + '\'' +
						",eventDescription = '" + eventDescription + '\'' +
						",systemInitiator = '" + systemInitiator + '\'' +
						",id = '" + id + '\'' +
						",customerIdentifier = '" + customerIdentifier + '\'' +
						",correspondenceType = '" + correspondenceType + '\'' +
						",correspondenceDirection = '" + correspondenceDirection + '\'' +
						",correspondenceBusiness = '" + correspondenceBusiness + '\'' +
						",status = '" + status + '\'' +
						"}";
	}
}