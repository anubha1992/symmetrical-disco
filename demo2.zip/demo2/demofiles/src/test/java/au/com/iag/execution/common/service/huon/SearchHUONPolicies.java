package au.com.iag.execution.common.service.huon;

import au.com.iag.execution.common.exception.*;
import au.com.iag.execution.common.model.huon.*;
import au.com.iag.execution.common.model.huon.util.*;
import com.jagacy.util.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import java.text.*;
import java.util.*;


@Service
public class SearchHUONPolicies {

    @Value("${test.api.source.system.brand}")
    private String brand;
    
    @Value("${test.huon.read.data.from}")
    private String huonReadDataFrom;

    public Policy findHuonPolicyDetails(Policy huonPolicy, String envNameHUON, String productCode)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        if (huonPolicy == null || huonPolicy.getPolicyNumber().isEmpty()) {
            huonPolicy = getHUONPolicyDetailsForProductCode(envNameHUON, productCode);

        }
        return huonPolicy;
    }

    public Policy getHUONPolicyDetailsForProductCode(String env, String productCode)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        String policyNumber = getHUONPolicyNumberForProductCode(env, productCode);
        while (policyNumber.length() < 12) {
            policyNumber = policyNumber.substring(0, 3) + "0" + policyNumber.substring(3);
        }
        return SearchHuonPolicyCapture.capturePolicyDetails(env, policyNumber);
    }

    public String getHUONPolicyNumberForProductCode(String env, String productCode)
            throws JagacyException, HuonException, ParseException, InvalidDataException {
        ArrayList<String> huonPolicies = new ArrayList<String>();
        String brand = getBrand();
        HuonSession huon = SearchHuonPolicyCapture.changeUserProfile(env, brand);
        huonPolicies = SearchHuonPolicyCapture.capturePolicies(huon, env, productCode, brand);
        return huonPolicies.get(new Random().nextInt(huonPolicies.size()));
//        return firstElementOf(huonPolicies);
        //        return lastElementOf(huonPolicies);
    }

    public String getEffectiveDateForHUONPolicy(Policy huonPolicy) {
        //        return huonPolicy.getEffectiveDateStringInLocalDateFormat()+ "T00:00:00";
        return huonPolicy.getEffectiveDateStringInLocalDateFormat() + "T00:00:00";
    }

    public String getBrand() {
        if (brand.equalsIgnoreCase("NZ STATE")) {
            brand = "NZL";
        }
        return brand;
    }

}
