package au.com.iag.execution.complaintmanagementapi.verifiers;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import au.com.iag.execution.complaintmanagementapi.model.business.ValidationErrorResponse;
import au.com.iag.glados.service.JsonMapperService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;

@Component
public class ComplaintManagementVerifier {

    @Autowired
    private JsonMapperService jsonMapperService;

    public void verifyNotifyCaseValidationResponse(Response response) throws IOException {
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        ValidationErrorResponse validationMessagesResponse = null;

        validationMessagesResponse = objectMapper
                .readValue(objectMapper.writeValueAsString(response.jsonPath().get()), ValidationErrorResponse.class);
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("business_timestamp") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "business_timestamp should be a mandatory field");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("case_id") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "case_id should be a mandatory field");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("case_status") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "case_status should be a mandatory field");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("claim_id") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "claim_id should be a mandatory field");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("inception_date") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "inception_date should be a mandatory field");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("notification_type") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "notification_type should be a mandatory field");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                .equalsIgnoreCase("notify_owner") && x.getCode().equalsIgnoreCase("mandatory_value_missing")),
                "notify_owner is mandatory.");

    }

    public void verifyInvalidRefdataValidationResponse(Response response) throws IOException {
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        ValidationErrorResponse validationMessagesResponse = null;

        validationMessagesResponse = objectMapper
                .readValue(objectMapper.writeValueAsString(response.jsonPath().get()), ValidationErrorResponse.class);
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                        .equalsIgnoreCase("case_status") && x.getCode().equalsIgnoreCase("value_not_allowed")),
                "case_status value validation not performed");
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                        .equalsIgnoreCase("notification_type") && x.getCode().equalsIgnoreCase("value_not_allowed")),
                "notification_type value validation not performed");

    }

    public void verifyInvalidBrandValidationResponse(Response response) throws IOException {
        ObjectMapper objectMapper = jsonMapperService.getObjectMapper();
        ValidationErrorResponse validationMessagesResponse = null;

        validationMessagesResponse = objectMapper
                .readValue(objectMapper.writeValueAsString(response.jsonPath().get()), ValidationErrorResponse.class);
        assertTrue(validationMessagesResponse.getValidationMessages().stream().anyMatch(x -> x.getField()
                        .contains("X-Iag-Brand/X-Iag-Channel") && x.getCode().equalsIgnoreCase("value_not_allowed")),
                "Brand validation for reference data not performed");

    }

    public void verifyErrorCodeAndMessage(Response response, int expected_error_code, String expected_message) {
        assertTrue(response.path("message").toString().contains(expected_message));
        int error_code = response.path("error_code");
        assertEquals(expected_error_code, error_code);
        assertNotNull(response.path("trace_id"));
    }
}
