package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class BillingPlanOptions implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("aggregate_premium_details")
    private PremiumDetails aggregatePremiumDetails = new PremiumDetails();
    @JsonProperty("billing_frequency")
    private String billingFrequency ;
    @JsonProperty("billing_plan_comparisons")
    private java.util.List<BillingPlanComparison> billingPlanComparisons = new java.util.ArrayList<BillingPlanComparison>();
    @JsonProperty("direct_debit")
    private Boolean directDebit ;
    @JsonProperty("instalments")
    private java.util.List<InstallmentDetails> instalments = new java.util.ArrayList<InstallmentDetails>();

  
    @ApiModelProperty(
        value = "Aggregated premium details for the respective billing plan",
        required = false
    )
    public PremiumDetails getAggregatePremiumDetails() {
       return aggregatePremiumDetails;
    }
 
    @ApiModelProperty(
        value = "Billing frequency. [Ref Data: billing_frequency]",
        example = "MONTHLY",
        required = false
    )
    public String getBillingFrequency() {
       return billingFrequency;
    }
 
    @ApiModelProperty(
        value = "Comparative amounts across different billing plans",
        required = false
    )
    public java.util.List<BillingPlanComparison> getBillingPlanComparisons() {
       return billingPlanComparisons;
    }
 
    @ApiModelProperty(
        value = "Indicator used to indicate whether payment is viadirect debit or not for this plan.",
        accessMode = ApiModelProperty.AccessMode.READ_ONLY,
        required = false
    )
    public Boolean getDirectDebit() {
       return directDebit;
    }
 
    @ApiModelProperty(
        value = "List of installment details",
        required = false
    )
    public java.util.List<InstallmentDetails> getInstalments() {
       return instalments;
    }
 

}