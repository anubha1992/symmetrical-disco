package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class LicenceEvent implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("date")
    private String date ;
    @JsonProperty("length")
    private String length ;
    @JsonProperty("number")
    private Integer number ;
    @JsonProperty("public_id")
    private String publicId ;
    @JsonProperty("temp_id")
    private String tempId ;
    @JsonProperty("type")
    private String type ;

  
    @ApiModelProperty(
        value = "Year of event. Pattern: yyyy",
        example = "2019",
        required = false
    )
    public String getDate() {
       return date;
    }
 
    @ApiModelProperty(
        value = "Licence event length such as licence suspension duration. [Ref Data: driver_licence_disqualification_duration]",
        required = false
    )
    public String getLength() {
       return length;
    }
 
    @ApiModelProperty(
        value = "Event number",
        example = "12345",
        required = false
    )
    public Integer getNumber() {
       return number;
    }
 
    @ApiModelProperty(
        value = "Public id is the persisted identifier for this object.",
        example = "pc:581955",
        required = false
    )
    public String getPublicId() {
       return publicId;
    }
 
    @ApiModelProperty(
        value = "Represents the temporary id that is not persisted for this object instance. Digital to send temp id for new objects. Value to start with &#x27;TEMP&#x27;.",
        example = "TEMP000555",
        required = false
    )
    public String getTempId() {
       return tempId;
    }
 
    @ApiModelProperty(
        value = "Event type to indicate licence situation. [Ref Data: driver_licence_incident]",
        example = "LICENCE_CANCELLED",
        required = false
    )
    public String getType() {
       return type;
    }
 

}