package au.com.iag.execution.claimupdateapi.service;

import au.com.iag.execution.claimupdateapi.model.*;
import au.com.iag.glados.common.GladosEnrichmentService;
import au.com.iag.glados.service.*;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static org.apache.http.HttpStatus.*;
import static org.junit.Assert.assertEquals;

@Service
public class ClaimUpdateService {

    @Autowired
    private GladosEnrichmentService gladosEnrichmentService;

    @Autowired private SchemaValidationService schemaValidationService;

    @Value("${test.schema.file.path}")
    private String schemaFilePath;

    public String getApiUrl() {
        return gladosEnrichmentService.getUrl();
    }

    public Response executeCreateActivity(ClaimActivityArtifact claimActivityArtifact, int expectStatusCode) {
        String path = claimActivityArtifact.getPath();
        if (claimActivityArtifact.getClaimId() != null) {
            path = path + claimActivityArtifact.getClaimId();
        }
        Response response = gladosEnrichmentService.sendPostRequest(
                claimActivityArtifact.getHeaders(),
                path + "/activity",
                claimActivityArtifact.getClaimActivityRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeMotorLodgeServiceRequest(LodgeMotorServiceRequestArtifact lodgeMotorServiceRequestArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequest(
                lodgeMotorServiceRequestArtifact.getHeaders(),
                lodgeMotorServiceRequestArtifact.getPath(),
                lodgeMotorServiceRequestArtifact.getMotorServiceRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeSendCorrespondenceRequest(SendCorrespondenceArtifact sendCorrespondenceArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequest(
                sendCorrespondenceArtifact.getHeaders(),
                sendCorrespondenceArtifact.getPath(),
                sendCorrespondenceArtifact.getClaimCorrespondence(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeSendCorrespondenceRequestExternal(SendCorrespondenceArtifact sendCorrespondenceArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequestExternal(
                sendCorrespondenceArtifact.getHeaders(),
                sendCorrespondenceArtifact.getPath(),
                sendCorrespondenceArtifact.getClaimCorrespondence(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeNotifyServiceRequest(NotifyServiceRequestArtifact notifyServiceRequestArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPutRequest(
                notifyServiceRequestArtifact.getHeaders(),
                notifyServiceRequestArtifact.getPath(),
                notifyServiceRequestArtifact.getNotifyServiceRequest(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    public Response executeUpdateAssessmentServiceRequest(AssessmentServiceRequestArtifact assessmentServiceRequestArtifact, int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPutRequest(
                assessmentServiceRequestArtifact.getHeaders(),
                assessmentServiceRequestArtifact.getPath(),
                assessmentServiceRequestArtifact.getUpdateAssessment(),
                expectStatusCode);
        return checkResponseStatus(expectStatusCode, response);
    }

    private Response checkResponseStatus(int expectStatusCode, Response response) {
        assertEquals(expectStatusCode, response.getStatusCode());
        return response;
    }

    private void validateSchema(int statusCode, Response response, String url) {
        if (statusCode == SC_OK) {
            schemaValidationService.validate(response, schemaFilePath, url);
        }
    }

    public void getSwaggerSchema() {
        schemaValidationService.getSwaggerSchema(getApiUrl(), schemaFilePath);
    }
}
