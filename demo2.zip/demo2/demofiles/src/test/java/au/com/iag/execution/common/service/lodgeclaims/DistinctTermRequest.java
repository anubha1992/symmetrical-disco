package au.com.iag.execution.common.service.lodgeclaims;


import au.com.iag.execution.claimdetailsapi.model.business.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.*;
import java.io.*;

@JsonInclude(NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class DistinctTermRequest implements Serializable {

    private static final long serialVersionUID = 1L;

//    @ApiModelProperty(required = true, value = "Policy number")
//    @NotNull(message = "Policy number of SearchIntermediaryDocuments criteria cannot be null")
//    @Pattern(regexp = "^.*\\S.*$", message = "Policy number cannot be blank")
    private String policyNumber;

    private String asAtDate;
    private DateRange dateRange;
    private int numberOfSearchResults = 0;

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

//    @JsonSerialize(using = CustomDateSerializer.class)
//    @JsonDeserialize(using = CustomDateDeserializer.class)
//    @ApiModelProperty(example = "2017-07-20T12:00:00", required = false)
//    @JsonFormat(pattern = DATE_TIME_FORMAT)
    public String getAsAtDate() {
        return asAtDate;
    }

    public void setAsAtDate(String asAtDate) {
        this.asAtDate = asAtDate;
    }

    public DateRange getDateRange() {
        return dateRange;
    }

    public void setDateRange(DateRange dateRange) {
        this.dateRange = dateRange;
    }

    public int getNumberOfSearchResults() {
        return numberOfSearchResults;
    }

    public void setNumberOfSearchResults(int numberOfSearchResults) {
        this.numberOfSearchResults = numberOfSearchResults;
    }
}
