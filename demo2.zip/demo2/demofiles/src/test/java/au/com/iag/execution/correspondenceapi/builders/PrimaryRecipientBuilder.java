package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.business.*;
import au.com.iag.execution.correspondenceapi.model.business.digital.SendCertificateRequest;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.*;

@Component
public class PrimaryRecipientBuilder {

    public CorrespondenceParties getCorrespondenceIndividual(PolicyCorrespondence policyCorrespondence, Parties parties){
        CorrespondenceIndividual correspondenceIndividual = SerializationUtils.clone(policyCorrespondence.getCorrespondence().getPrimaryRecipient().getIndividual());
        correspondenceIndividual.setPartyId(getPartyIdForRole(parties, PARTY_ROLE_PRIMARY_POLICY_HOLDER));
        CorrespondenceParties correspondenceParties = new CorrespondenceParties();
        correspondenceParties.setIndividual(correspondenceIndividual);
        return correspondenceParties;
    }

    public CorrespondenceParties getCorrespondenceOrganisation(PolicyCorrespondence policyCorrespondence, Parties parties){
        CorrespondenceOrganisation correspondenceOrganisation = SerializationUtils.clone(policyCorrespondence.getCorrespondence().getPrimaryRecipient().getOrganisation());
        correspondenceOrganisation.setPartyId(getPartyIdForRole(parties, PARTY_ROLE_PRIMARY_POLICY_HOLDER));
        CorrespondenceParties correspondenceParties = new CorrespondenceParties();
        correspondenceParties.setOrganisation(correspondenceOrganisation);
        return correspondenceParties;
    }

    public void updatePrimaryRecipientAddress(String primaryRecipientType, CorrespondenceParties correspondenceParties, String countryCode){
        switch (primaryRecipientType) {
            case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                updateAddress(correspondenceParties.getIndividual().getAddress(), countryCode);
                break;
            case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                updateAddress(correspondenceParties.getOrganisation().getAddress(), countryCode);
                break;
            default:
                throw new IllegalArgumentException("Invalid primary recipient type - " + primaryRecipientType);
        }
    }

    public void updatePrimaryRecipient(PolicyCorrespondence policyCorrespondence, final String primaryRecipientType) {
        switch (primaryRecipientType) {
            case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                policyCorrespondence.getCorrespondence().getPrimaryRecipient().setOrganisation(null);
                break;
            case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                policyCorrespondence.getCorrespondence().getPrimaryRecipient().setIndividual(null);
                break;
            default:
                throw new IllegalArgumentException("Invalid Primary Recipient Type - " + primaryRecipientType);
        }
    }

    public void updatePrimaryRecipient(SendCertificateRequest sendCertificateRequest, final String primaryRecipientType) {
        switch (primaryRecipientType) {
            case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                sendCertificateRequest.getCorrespondence().getPrimaryRecipient().setOrganisation(null);
                break;
            case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                sendCertificateRequest.getCorrespondence().getPrimaryRecipient().setIndividual(null);
                break;
            default:
                throw new IllegalArgumentException("Invalid Primary Recipient Type - " + primaryRecipientType);
        }
    }

    public CorrespondenceEmailContacts getCorrespondenceEmailContacts(String email, boolean isPaperlessConsentGiven){
        CorrespondenceEmailContacts correspondenceEmailContacts = new CorrespondenceEmailContacts();
        if(email== null){
            correspondenceEmailContacts.setEmail(null);
        }
        else {
            Email email1 = new Email();
            email1.setEmailAddress(email);
            correspondenceEmailContacts.setEmail(email1);
        }
        if(isPaperlessConsentGiven){
            correspondenceEmailContacts.setGoPaperlessConsent(true);
            correspondenceEmailContacts.setGoPaperlessEmailType("PRIMARY");
            correspondenceEmailContacts.setGoPaperlessConsentDate(DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDate.now()));
        }
        else {
            correspondenceEmailContacts.setGoPaperlessConsent(false);
        }
        return correspondenceEmailContacts;
    }

    private String getPartyIdForRole(Parties parties, final String role){
        return parties.getPartyRoles().stream().filter(partyRole -> role.equals(partyRole.getRole())).findFirst().get().getPartyId();
    }

    private void updateAddress(MailingAddress mailingAddress, String countryCode){
        mailingAddress.setCountry(countryCode);
        switch (countryCode){
            case CORRESPONDENCE_COUNTRY_AUS:
                mailingAddress.setInternationalAddress(null);
                mailingAddress.setTownCityName(null);
                break;
            case CORRESPONDENCE_COUNTRY_NZL:
                mailingAddress.setInternationalAddress(null);
                mailingAddress.setLocalityName(null);
                mailingAddress.setState(null);
                mailingAddress.setTownCityName("Matakana Auckland");
                break;
            default:
                mailingAddress.setDescriptiveFullAddress(null);
                mailingAddress.setDisplayAddressLine1(null);
                mailingAddress.setDisplayAddressLine2(null);
                mailingAddress.setLocalityName(null);
                mailingAddress.setTownCityName(null);
                mailingAddress.setState(null);
                mailingAddress.setInternationalAddress(getInternationalAddress());
                mailingAddress.setPostcode("WD99 4JN");
        }
    }

    private InternationalAddress getInternationalAddress(){
        InternationalAddress internationalAddress = new InternationalAddress();
        internationalAddress.setAddressLine1("452 Aldo Fields");
        internationalAddress.setAddressLine2("Apt. 515");
        internationalAddress.setCountyProvinceState("GB West Devorachester VA");
        return internationalAddress;
    }
}
