package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.CorrespondenceParties;
import au.com.iag.execution.correspondenceapi.model.business.Parties;
import au.com.iag.execution.correspondenceapi.model.business.PolicyCorrespondence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.PRIMARY_RECIPIENT_TYPE_INDIVIDUAL;
import static au.com.iag.execution.correspondenceapi.model.CorrespondenceApiConstants.PRIMARY_RECIPIENT_TYPE_ORGANISATION;

@Component
public class BaseRequestBuilder {

    @Autowired
    private PrimaryRecipientBuilder primaryRecipientBuilder;

    public CorrespondenceParties getCorrespondenceParties(String primaryRecipientType, PolicyCorrespondence policyCorrespondence, Parties parties) {
        switch (primaryRecipientType) {
            case PRIMARY_RECIPIENT_TYPE_INDIVIDUAL:
                return primaryRecipientBuilder.getCorrespondenceIndividual(policyCorrespondence, parties);
            case PRIMARY_RECIPIENT_TYPE_ORGANISATION:
                return primaryRecipientBuilder.getCorrespondenceOrganisation(policyCorrespondence, parties);
            default:
                throw new IllegalArgumentException("Invalid primary recipient type - " + primaryRecipientType);
        }
    }

    public int getMax(List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec) {
        List<Integer> listOfAssetIndices = new ArrayList<>();
        listOfCoverableToPartyRoleSpec.forEach(coverableToPartyRoleSpec -> {
            Map<Integer, List<String>> mapOfAssetIndexToAssetLevelRoles = coverableToPartyRoleSpec.getMapOfAssetIndexToAssetLevelRoles();
            if (mapOfAssetIndexToAssetLevelRoles != null) {
                listOfAssetIndices.addAll(mapOfAssetIndexToAssetLevelRoles.keySet());
            }
        });
        if (listOfAssetIndices.size() <= 0) {
            return 0;
        }
        return listOfAssetIndices.stream().max(Comparator.naturalOrder()).get();
    }
}
