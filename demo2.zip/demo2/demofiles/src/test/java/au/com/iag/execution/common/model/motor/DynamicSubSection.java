package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class DynamicSubSection implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("biz_constraints")
    private BizConstraints bizConstraints = new BizConstraints();
    @JsonProperty("dynamic_section_ref")
    private String dynamicSectionRef ;
    @JsonProperty("name")
    private String name ;

  
    @ApiModelProperty(
        value = "The biz constraints for the dynamic sub section",
        required = false
    )
    public BizConstraints getBizConstraints() {
       return bizConstraints;
    }
 
    @ApiModelProperty(
        value = "The reference to the dynamic_sections &#x27;ref_name&#x27;.",
        required = false
    )
    public String getDynamicSectionRef() {
       return dynamicSectionRef;
    }
 
    @ApiModelProperty(
        value = "The name of the section as it appears in the data structure",
        required = false
    )
    public String getName() {
       return name;
    }
 

}