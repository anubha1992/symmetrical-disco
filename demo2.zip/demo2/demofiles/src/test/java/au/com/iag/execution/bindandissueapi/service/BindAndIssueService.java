package au.com.iag.execution.bindandissueapi.service;

import au.com.iag.execution.bindandissueapi.model.BindAndIssueArtifact;

import au.com.iag.glados.common.GladosEnrichmentService;

import au.com.iag.glados.service.SchemaValidationService;

import io.restassured.response.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Service;

import static org.apache.http.HttpStatus.SC_CREATED;


@Service
public class BindAndIssueService {

    @Autowired private GladosEnrichmentService gladosEnrichmentService;
    @Autowired private SchemaValidationService schemaValidationService;

    @Value("${test.schema.file.path}") private String schemaFilePath;

    public void getSwaggerSchema() {
        schemaValidationService.getSwaggerSchema(gladosEnrichmentService.getUrl(), schemaFilePath);
    }

    public Response executeRequest(final BindAndIssueArtifact bindAndIssueArtifact, final int expectStatusCode) {
        Response response = gladosEnrichmentService.sendPostRequest(
                bindAndIssueArtifact.getHeaders(),
                bindAndIssueArtifact.getPath(),
                bindAndIssueArtifact.getBindAndIssueRequest(),
                expectStatusCode);
        validateSchema(response);
        return response;
    }

    private void validateSchema(Response response) {
        if (response.getStatusCode() == SC_CREATED) {
            schemaValidationService
                    .validate(response, schemaFilePath, "/definitions/BindAndIssueResponse");
        }
    }
}
