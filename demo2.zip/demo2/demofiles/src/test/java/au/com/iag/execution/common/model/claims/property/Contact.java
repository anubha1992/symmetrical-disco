package au.com.iag.execution.common.model.claims.property;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;
import java.io.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Contact implements Serializable {
    private static final long serialVersionUID = 7584699149248773777L;

    private String mobile;
    private String work;
    private String home;
    private String email;
    private String teamEmail;
    private String teamPhone;
    private String preferredContact;
    private Address address;
    private String allowSmsNotification;
    private String allowEmailNotification;
    private String referenceNumber;

    public String getAllowSmsNotification() { return allowSmsNotification;    }

    public void setAllowSmsNotification(String allowSmsNotification) { this.allowSmsNotification = allowSmsNotification;    }

    public String getAllowEmailNotification() { return allowEmailNotification;    }

    public void setAllowEmailNotification(String allowEmailNotification) { this.allowEmailNotification = allowEmailNotification;  }
    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getHome() {
        return home;
    }

    public void setHome(String home) {
        this.home = home;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPreferredContact() {
        return preferredContact;
    }

    public void setPreferredContact(String preferredContact) {
        this.preferredContact = preferredContact;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getTeamEmail() {
        return teamEmail;
    }

    public void setTeamEmail(String teamEmail) {
        this.teamEmail = teamEmail;
    }

    public String getTeamPhone() {
        return teamPhone;
    }

    public void setTeamPhone(String teamPhone) {
        this.teamPhone = teamPhone;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }


}
