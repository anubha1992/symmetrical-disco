package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class PriceQuoteResponse implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("discounts")
    private Discount discounts = new Discount();
    @JsonProperty("metadata")
    private Sections metadata = new Sections();
    @JsonProperty("policy_details")
    private PriceQuotePolicyDetailsResponse policyDetails = new PriceQuotePolicyDetailsResponse();
    @JsonProperty("validation_messages")
    private java.util.List<ValidationMessage> validationMessages = new java.util.ArrayList<ValidationMessage>();

  
    @ApiModelProperty(
        value = "Details of discounts applied on the quote",
        required = false
    )
    public Discount getDiscounts() {
       return discounts;
    }
 
    @ApiModelProperty(
        value = "Metadata for Policy Details",
        required = false
    )
    public Sections getMetadata() {
       return metadata;
    }
 
    @ApiModelProperty(
        value = "Policy details",
        required = false
    )
    public PriceQuotePolicyDetailsResponse getPolicyDetails() {
       return policyDetails;
    }
 
    @ApiModelProperty(
        value = "List of validation messages",
        required = false
    )
    public java.util.List<ValidationMessage> getValidationMessages() {
       return validationMessages;
    }
 

}