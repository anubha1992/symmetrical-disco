package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class InstallmentDetails implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("amount")
    private Double amount ;
    @JsonProperty("due_date")
    private java.time.LocalDate dueDate ;
    @JsonProperty("number")
    private String number ;
    @JsonProperty("premium_details")
    private java.util.List<PremiumDetails> premiumDetails = new java.util.ArrayList<PremiumDetails>();
    @JsonProperty("status")
    private String status ;

  
    @ApiModelProperty(
        value = "Instalment amount that must be paid when it is due. Instalment Payment Amount (includes GST).",
        example = "51.3",
        required = false
    )
    public Double getAmount() {
       return amount;
    }
 
    @ApiModelProperty(
        value = "Date when the next instalment is due. Format yyyy-MM-dd",
        example = "2019-03-21",
        required = false
    )
    public java.time.LocalDate getDueDate() {
       return dueDate;
    }
 
    @ApiModelProperty(
        value = "Instalment Sequence Number.",
        example = "5",
        required = false
    )
    public String getNumber() {
       return number;
    }
 
    @ApiModelProperty(
        value = "Premium details by instalments.",
        required = false
    )
    public java.util.List<PremiumDetails> getPremiumDetails() {
       return premiumDetails;
    }
 
    @ApiModelProperty(
        value = "Instalment Status. [Ref Data: instalment_status]",
        example = "PAID",
        required = false
    )
    public String getStatus() {
       return status;
    }
 

}