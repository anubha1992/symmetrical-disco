package au.com.iag.execution.claimupdateapi.model.business.qapter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.util.*;

@Data
public class Damage {
    private List<DamageAreaSeverity> areaSeverity;
    @ApiModelProperty(
            value = "incident type. https://confluence.iag.com.au/display/GICP/CC+Damage+Incident+Type",
            example = "F - Fire")
    private String incident;
}
