package au.com.iag.execution.common.model.motor;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class VehicleAssetParty implements Serializable {
    private static final long serialVersionUID = 1L;


    @JsonProperty("party_roles")
    private java.util.List<AssetPartyRole> partyRoles = new java.util.ArrayList<AssetPartyRole>();
    @JsonProperty("vehicle_drivers")
    private java.util.List<VehicleDriver> vehicleDrivers = new java.util.ArrayList<VehicleDriver>();

  
    @ApiModelProperty(
        value = "List of party roles",
        required = false
    )
    public java.util.List<AssetPartyRole> getPartyRoles() {
       return partyRoles;
    }
 
    @ApiModelProperty(
        value = "List of drivers",
        required = false
    )
    public java.util.List<VehicleDriver> getVehicleDrivers() {
       return vehicleDrivers;
    }
 

}