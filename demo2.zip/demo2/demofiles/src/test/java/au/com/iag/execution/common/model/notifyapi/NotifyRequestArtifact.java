package au.com.iag.execution.common.model.notifyapi;

import java.io.Serializable;
import java.util.Map;

import au.com.iag.execution.common.model.notifyapi.business.Policy;
import lombok.Data;

@Data
public class NotifyRequestArtifact implements Serializable {
        private Map<String, Object> headers;
        private String path;
        private Policy request;
}
