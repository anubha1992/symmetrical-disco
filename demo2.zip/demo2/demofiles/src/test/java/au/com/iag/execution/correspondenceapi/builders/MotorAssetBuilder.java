package au.com.iag.execution.correspondenceapi.builders;

import au.com.iag.execution.correspondenceapi.model.CoverableToPartyRoleSpec;
import au.com.iag.execution.correspondenceapi.model.business.*;
import au.com.iag.glados.service.RandomContentService;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.IntStream;

@Component
public class MotorAssetBuilder {

    @Autowired private RandomContentService randomContentService;
    @Autowired private MiscDataBuilder miscDataBuilder;
    @Autowired private CoverageBuilder coverageBuilder;
    private static final Random RANDOM = new Random();


    List<VehicleAsset> buildVehicleAssets(PolicyCorrespondence policyCorrespondence, List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec){
        final int maxCoverables = getMax(listOfCoverableToPartyRoleSpec);
        List<VehicleAsset> listOfVehicleAssets = new ArrayList<>();
        IntStream.range(0, maxCoverables+1).forEachOrdered(assetIndex -> {
            VehicleAsset vehicleAsset = getVehicleAsset(policyCorrespondence);
            VehicleAssetParty vehicleAssetParty1 = new VehicleAssetParty();

            List<VehicleDriver> listOfVehicleDrivers = new ArrayList<>();
            List<AssetPartyRole> listOfAssetPartyRoles = new ArrayList<>();
            listOfCoverableToPartyRoleSpec.forEach(coverableToPartyRoleSpec -> {
                Map<Integer, List<String>> mapOfAssetIndexToAssetLevelRoles = coverableToPartyRoleSpec.getMapOfAssetIndexToAssetLevelRoles();
                if(mapOfAssetIndexToAssetLevelRoles != null) {
                    List<String> listOfAssetRoles = mapOfAssetIndexToAssetLevelRoles.get(assetIndex);
                    if(listOfAssetRoles != null) {
                        listOfAssetRoles.stream().filter("DRIVER"::equals).forEach(driverRole -> {
                            VehicleDriver vehicleDriver = new VehicleDriver();
                            vehicleDriver.setPartyId(coverableToPartyRoleSpec.getPartyId());
                            double totalExcess = miscDataBuilder.getDouble(750, 2500);
                            vehicleDriver.setImposedExcess(totalExcess - 500);
                            vehicleDriver.setTotalExcess(totalExcess);
                            listOfVehicleDrivers.add(vehicleDriver);
                        });
                        listOfAssetRoles.forEach(assetRole -> {
                            AssetPartyRole assetPartyRole = new AssetPartyRole();
                            assetPartyRole.setPartyId(coverableToPartyRoleSpec.getPartyId());
                            assetPartyRole.setRole(assetRole);
                            listOfAssetPartyRoles.add(assetPartyRole);
                        });
                    }
                }
            });
            vehicleAssetParty1.setPartyRoles(listOfAssetPartyRoles);
            vehicleAssetParty1.setVehicleDrivers(listOfVehicleDrivers);
            vehicleAsset.setParties(vehicleAssetParty1);
            vehicleAsset.setPremiumDetails(getTotalPremium(miscDataBuilder.formatDouble(1000 + RANDOM.nextDouble() * (2000 - 1000))));
            vehicleAsset.setCoverages(coverageBuilder.getCoveragesByType(policyCorrespondence, VehicleCoverages.class));
            listOfVehicleAssets.add(vehicleAsset);
        });
        return listOfVehicleAssets;
    }

    private VehicleAsset getVehicleAsset(PolicyCorrespondence policyCorrespondence){
        VehicleAsset vehicleAsset = SerializationUtils.clone(policyCorrespondence.getPolicyDetails().getAssets().getVehicleAssets().get(0));
        vehicleAsset.setAssetNumber(String.valueOf(randomContentService.getRandomNumber(100, 1000)));
        return vehicleAsset;
    }

    private TotalPremium getTotalPremium(double netPremium) {
        TotalPremium totalPremium = new TotalPremium();
        totalPremium.setTotalPremium(netPremium);
        return totalPremium;
    }

    private int getMax(List<CoverableToPartyRoleSpec> listOfCoverableToPartyRoleSpec){
        List<Integer> listOfAssetIndices = new ArrayList<>();
        listOfCoverableToPartyRoleSpec.forEach(coverableToPartyRoleSpec -> {
            Map<Integer, List<String>> mapOfAssetIndexToAssetLevelRoles = coverableToPartyRoleSpec.getMapOfAssetIndexToAssetLevelRoles();
            if(mapOfAssetIndexToAssetLevelRoles != null){
                listOfAssetIndices.addAll(mapOfAssetIndexToAssetLevelRoles.keySet());
            }
        });
        if(listOfAssetIndices.size() <= 0){
            return 0;
        }
        return listOfAssetIndices.stream().max(Comparator.naturalOrder()).get();
    }
}
