package au.com.iag.execution.common.model.crods;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InternationalAddress{

	@JsonProperty("countyProvinceState")
	private String countyProvinceState;

	@JsonProperty("addressLine1")
	private String addressLine1;

	@JsonProperty("addressLine2")
	private String addressLine2;

	public void setCountyProvinceState(String countyProvinceState){
		this.countyProvinceState = countyProvinceState;
	}

	public String getCountyProvinceState(){
		return countyProvinceState;
	}

	public void setAddressLine1(String addressLine1){
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine1(){
		return addressLine1;
	}

	public void setAddressLine2(String addressLine2){
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine2(){
		return addressLine2;
	}

	@Override
 	public String toString(){
		return 
			"InternationalAddress{" + 
			"countyProvinceState = '" + countyProvinceState + '\'' + 
			",addressLine1 = '" + addressLine1 + '\'' + 
			",addressLine2 = '" + addressLine2 + '\'' + 
			"}";
		}
}