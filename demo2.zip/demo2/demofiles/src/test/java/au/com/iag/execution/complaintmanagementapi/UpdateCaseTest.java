package au.com.iag.execution.complaintmanagementapi;

import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_CREATED;
import static org.apache.http.HttpStatus.SC_FORBIDDEN;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_OK;
import static org.apache.http.HttpStatus.SC_UNAUTHORIZED;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static au.com.iag.execution.common.constants.ApiConstants.DB_CC_CLAIMNUMBER;
import static au.com.iag.execution.pricingremediationapi.model.PricingRemediationApiConstants.MESSAGE;
import static au.com.iag.glados.model.constants.GladosConstants.INVALID_SYSTEM_TOKEN;
import static au.com.iag.glados.model.constants.GladosConstants.MISSING_BRAND_HEADER;
import static au.com.iag.glados.model.constants.GladosConstants.MISSING_CHANNEL_HEADER;
import static au.com.iag.glados.model.constants.GladosConstants.MISSING_CONSUMER_SYSTEM_HEADER;
import static au.com.iag.glados.model.constants.GladosConstants.MISSING_SYSTEM_TOKEN;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_AUTH_CONSUMER_SYSTEM;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_BRAND;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CHANNEL;
import static au.com.iag.glados.model.constants.GladosConstants.X_IAG_CONSUMER_SYSTEM;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import au.com.iag.execution.common.service.claims.ClaimsDbService;
import au.com.iag.execution.complaintmanagementapi.builders.NotifyCaseRequestBuilder;
import au.com.iag.execution.complaintmanagementapi.configuration.ComplaintManagementApiConfiguration;
import au.com.iag.execution.complaintmanagementapi.configuration.PropertyOverrideContextInitializer;
import au.com.iag.execution.complaintmanagementapi.model.NotifyCaseArtifact;
import au.com.iag.execution.complaintmanagementapi.service.NotifyCaseService;
import au.com.iag.execution.complaintmanagementapi.verifiers.ComplaintManagementVerifier;
import au.com.iag.glados.common.GladosRunnerExtension;
import io.restassured.response.Response;

@SpringBootTest()
@ExtendWith({SpringExtension.class, GladosRunnerExtension.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ContextConfiguration(initializers = PropertyOverrideContextInitializer.class, classes = {ComplaintManagementApiConfiguration.class})
@Tags({@Tag("UpdateCaseTest"), @Tag("complaint-management-api")})
public class UpdateCaseTest {

    @Autowired private NotifyCaseService notifyCaseService;
    @Autowired private NotifyCaseRequestBuilder notifyCaseRequestBuilder;
    @Autowired private ComplaintManagementVerifier complaintManagementVerifier;

    @Value("${test.api.product.code}")
    private String productCode;

    @Value("${test.api.product.code.LTC}")
    private String longTailClaimProductCode;

    @Autowired
    ClaimsDbService claimsDbService;

    private String caseId;

    private String claimID;

    private NotifyCaseArtifact notifyCaseArtifact;

    private List<Map<String, Object>> claimIdDetails;

    private Map<String, Object> claimIdDetailsMap;

    @BeforeAll
    public void setUpOnce() throws Exception {
        notifyCaseService.getSwaggerSchema();
        caseId = UUID.randomUUID().toString();

        claimIdDetails = claimsDbService.getClaimResultSet(productCode);
        if (claimIdDetails.isEmpty()) {
            Assert.fail("No claim found for product " + productCode);
        }

        claimIdDetailsMap = claimIdDetails.get(new Random().nextInt(claimIdDetails.size()));
        claimID = claimIdDetailsMap.get(DB_CC_CLAIMNUMBER).toString();

        // Create a complaint using NotifyCase and later use the case Id for further tests.
        Response response = notifyCaseService.executeNotifycase(notifyCaseRequestBuilder.setupNotifyCaseDefaults(claimID, caseId), SC_CREATED);
        assertEquals("notification success", response.path("response"));
    }

    @BeforeEach
    public void setup() throws IOException {
        NotifyCaseArtifact notifyCaseArtifact = notifyCaseRequestBuilder.setupNotifyCaseDefaults(claimID, caseId);
        setNotifyCaseArtifact(notifyCaseArtifact);
    }

    @Test
    public void postUpdateCaseHappyPath() {
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_OK);
        assertEquals("update notification success", response.path("response"));
        assertEquals(response.getStatusCode(), SC_OK);
    }

    @Test
    public void updateCaseWhenCaseOwnerIsNullAndNotifyOwnerIsFalse() {
        getNotifyCaseArtifact().getNotifyCaseRequest().setNotifyOwner(false);
        getNotifyCaseArtifact().getNotifyCaseRequest().setCaseOwner(null);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_OK);
        assertEquals("update notification success", response.path("response"));
    }

    @Test
    public void caseOwnerNotFoundNotThrownWhenNotifyOwnerIsFalse() {
        getNotifyCaseArtifact().getNotifyCaseRequest().setNotifyOwner(false);
        getNotifyCaseArtifact().getNotifyCaseRequest().setCaseOwner("INVALID_CASE_OWNER");
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_OK);
        assertEquals("update notification success", response.path("response"));
    }

    @Test
    public void missingFieldsUpdateCase() throws IOException {
        NotifyCaseArtifact notifyCaseArtifact = getNotifyCaseArtifact();
        notifyCaseArtifact.getNotifyCaseRequest().setCaseStatus(null);
        notifyCaseArtifact.getNotifyCaseRequest().setCaseId(null);
        notifyCaseArtifact.getNotifyCaseRequest().setBusinessTimestamp(null);
        notifyCaseArtifact.getNotifyCaseRequest().setNotificationType(null);
        notifyCaseArtifact.getNotifyCaseRequest().setInceptionDate(null);
        notifyCaseArtifact.getNotifyCaseRequest().setClaimId(null);
        notifyCaseArtifact.getNotifyCaseRequest().setNotifyOwner(null);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_UNPROCESSABLE_ENTITY);
        complaintManagementVerifier.verifyNotifyCaseValidationResponse(response);
    }

    @Test
    public void invalidReferenceDataFields() throws IOException {
        NotifyCaseArtifact notifyCaseArtifact = getNotifyCaseArtifact();
        notifyCaseArtifact.getNotifyCaseRequest().setCaseStatus("Invalid");
        notifyCaseArtifact.getNotifyCaseRequest().setNotificationType("LEVEL_4_COMPLAINT");
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_UNPROCESSABLE_ENTITY);
        complaintManagementVerifier.verifyInvalidRefdataValidationResponse(response);
    }

    @Test
    public void caseOwnerNotPresent() {
        getNotifyCaseArtifact().getNotifyCaseRequest().setNotifyOwner(true);
        getNotifyCaseArtifact().getNotifyCaseRequest().setCaseOwner("INVALID_CASE_OWNER");
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_NOT_FOUND);
        complaintManagementVerifier.verifyErrorCodeAndMessage(response, SC_NOT_FOUND, "Case owner not found");
    }

    @Test
    public void claimNotPresent() {
        getNotifyCaseArtifact().getNotifyCaseRequest().setClaimId("INVALID_CLAIM_ID_1234");
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_NOT_FOUND);
        complaintManagementVerifier.verifyErrorCodeAndMessage(response, SC_NOT_FOUND, "Claim not found");
    }

    @Test
    public void invalidBrand() throws IOException {
        getNotifyCaseArtifact().getHeaders().put(X_IAG_BRAND, "ABCXYZ");
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_UNPROCESSABLE_ENTITY);
        complaintManagementVerifier.verifyInvalidBrandValidationResponse(response);
    }

    @Test
    public void alreadyReported() {
        OffsetDateTime dateTime = OffsetDateTime.now();
        getNotifyCaseArtifact().getNotifyCaseRequest().setBusinessTimestamp(dateTime);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_OK);
        assertEquals("update notification success", response.path("response"));
        assertEquals(response.getStatusCode(), SC_OK);

        dateTime = dateTime.minusHours(1);
        getNotifyCaseArtifact().getNotifyCaseRequest().setBusinessTimestamp(dateTime);
        Response response2 = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), 208);
        assertEquals("Case already reported", response2.path("response"));
        assertEquals(response2.getStatusCode(), 208);
    }

    @Test
    public void notShortTailClaim() throws Exception {
        // Get a  claim ID which is a long tail claim
        List<Map<String, Object>> claimIdDetails = claimsDbService.getClaimResultSet(longTailClaimProductCode);
        if (claimIdDetails.isEmpty()) {
            Assert.fail("No claim found for product " + productCode);
        }
        Map<String, Object> claimIdDetailsMap = claimIdDetails.get(new Random().nextInt(claimIdDetails.size()));
        String claimID = claimIdDetailsMap.get(DB_CC_CLAIMNUMBER).toString();

        //Set the long tail claim ID
        getNotifyCaseArtifact().getNotifyCaseRequest().setClaimId(claimID);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_FORBIDDEN);
        complaintManagementVerifier.verifyErrorCodeAndMessage(response, SC_FORBIDDEN, "Not a short tail claim");
    }

    @Test
    public void missingSystemToken() {
        getNotifyCaseArtifact().getHeaders().remove(X_IAG_AUTH_CONSUMER_SYSTEM);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_UNAUTHORIZED);
        assertEquals(MISSING_SYSTEM_TOKEN, response.path("message"));
    }

    @Test
    public void invalidSystemToken() {
        String invalidToken = getNotifyCaseArtifact().getHeaders().get(X_IAG_AUTH_CONSUMER_SYSTEM) + "i";
        getNotifyCaseArtifact().getHeaders().put(X_IAG_AUTH_CONSUMER_SYSTEM, invalidToken);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_UNAUTHORIZED);
        assertEquals(INVALID_SYSTEM_TOKEN, response.path("message"));
    }

    @Test
    public void missingConsumerSystem() {
        getNotifyCaseArtifact().getHeaders().remove(X_IAG_CONSUMER_SYSTEM);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_BAD_REQUEST);
        assertEquals(MISSING_CONSUMER_SYSTEM_HEADER, response.path(MESSAGE));
    }

    @Test
    public void missingBrandHeader() {
        getNotifyCaseArtifact().getHeaders().remove(X_IAG_BRAND);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_BAD_REQUEST);
        assertEquals(MISSING_BRAND_HEADER, response.path(MESSAGE));
    }

    @Test
    public void missingChannelHeader() {
        getNotifyCaseArtifact().getHeaders().remove(X_IAG_CHANNEL);
        Response response = notifyCaseService.executeUpdateCase(getNotifyCaseArtifact(), SC_BAD_REQUEST);
        assertEquals(MISSING_CHANNEL_HEADER, response.path(MESSAGE));
    }

    private NotifyCaseArtifact getNotifyCaseArtifact() {
        return notifyCaseArtifact;
    }

    private void setNotifyCaseArtifact(NotifyCaseArtifact notifyCaseArtifact) {
        this.notifyCaseArtifact = notifyCaseArtifact;
    }
}